$( "form" ).submit(function( event ) {
  if ( $( "input:first" ).val() ==="Hr-Analytics" ) {
  
  	window.open (  "https://www.google.com"  );
 }
else if ( $( "input:first" ).val() ==="Team Bonding" ){
 window.open ("https://www.w3schools.com/jquery/");


 }
 else if($( "input:first" ).val() ==="Time Mangement")
 {
 

 window.open ("https://blog.liveedu.tv/javascript-redirect-page-jquery/")  ;


 
 }
 else
 alert('not found');
});
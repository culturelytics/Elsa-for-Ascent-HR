<?php
// error_reporting(-1);
// ini_set('display_errors', 1);

function getEncrypt($plaintext) {
    $key="sf23423sds";
    $ivlen = openssl_cipher_iv_length($cipher="AES-256-CBC");
    $iv = openssl_random_pseudo_bytes($ivlen);
    $ciphertext_raw = openssl_encrypt($plaintext, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);
    $hmac = hash_hmac('sha256', $ciphertext_raw, $key, $as_binary=true);

    $ciphertext = base64_encode( $iv.$hmac.$ciphertext_raw );
    $url = strtr($ciphertext, '+/', '-_');
    $ciphertext = rtrim($url, '=');

    return $ciphertext;
}

function getDecrypt($ciphertext) {    
    $key="sf23423sds";
    $ciphertext = strtr($ciphertext, '-_', '+/') . '='; 
    $c = base64_decode($ciphertext) ;
    $ivlen = openssl_cipher_iv_length($cipher="AES-256-CBC");
    $iv = substr($c, 0, $ivlen);
    $hmac = substr($c, $ivlen, $sha2len=32);
    $ciphertext_raw = substr($c, $ivlen+$sha2len);
    $original_plaintext = openssl_decrypt($ciphertext_raw, $cipher, $key, $options=OPENSSL_RAW_DATA, $iv);

    return $original_plaintext;
}

// if(count($_GET) > 0 && $_GET['key'] !== '') {
//   // decryption goes here
//   $plaintext = getDecrypt($_GET['key']);

//   echo 'Encrypted Text: <br><br>' . $_GET['key'];

//   echo '<br><br><hr><br>Decrypted Plain Text: <br><br>' . $plaintext;
// }
// else {
//   // encryption goes here
//   $plaintext = 'first_name=Demo&last_name=test&date_of_birth=28/08/1991&gender=Male&email_id=harish@ascent-online.net&linkedin=na&twitter=na&contact_number=9481760639&organization_id=025_test&organization_name=Ascent Stohrm Test&industry_id=025_test&industry_name=Ascent Stohrm Test&redirectto=https://stohrm_test.stohrm.com/';
//   $ciphertext = getEncrypt($plaintext);
  
//   echo 'Plain Text: <br><br>' . $plaintext;
  
//   echo '<br><br><hr><br>Encrypted link: <br><br><a href="aesencrypt.php?key='.$ciphertext.'" target="_blank">Click Here</a>'; 

// }
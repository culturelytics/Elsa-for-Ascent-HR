/*
SQLyog Ultimate v11.11 (64 bit)
MySQL - 5.7.26 : Database - e2e
*********************************************************************
*/


/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`e2e` /*!40100 DEFAULT CHARACTER SET latin1 */;

/*Table structure for table `tbl_competencies` */

DROP TABLE IF EXISTS `tbl_competencies`;

CREATE TABLE `tbl_competencies` (
  `prg_id` int(11) NOT NULL AUTO_INCREMENT,
  `prg_name` varchar(255) NOT NULL,
  `prg_status` enum('Active','Inactive') NOT NULL,
  `prg_modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `prg_title` varchar(255) NOT NULL,
  `prg_desc` mediumtext NOT NULL,
  PRIMARY KEY (`prg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

/*Data for the table `tbl_competencies` */

insert  into `tbl_competencies`(`prg_id`,`prg_name`,`prg_status`,`prg_modified_at`,`prg_title`,`prg_desc`) values (1,'New Competency 001_edited','Active','2019-12-06 14:25:31','',''),(2,'New Competency 002','Active','2019-12-06 13:15:27','',''),(3,'New Competency 003','Active','2019-12-06 14:24:50','',''),(4,'New Competency 004','Active','2019-12-06 15:14:46','',''),(5,'New Competency 005','Active','2019-12-06 15:15:12','',''),(6,'New Competency 006','Active','2019-12-06 15:15:19','',''),(7,'New Competency 007','Active','2019-12-06 15:15:25','',''),(8,'New Competency 008','Active','2019-12-06 15:15:46','',''),(9,'New Competency 009','Active','2019-12-06 15:15:54','',''),(10,'New Competency 010','Inactive','2019-12-06 15:37:09','',''),(11,'New Competency 011_edited','Active','2019-12-06 17:14:37','',''),(12,'New Competency 010','Active','2019-12-06 15:37:24','','');

/*Table structure for table `tbl_scale` */

DROP TABLE IF EXISTS `tbl_scale`;

CREATE TABLE `tbl_scale` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scaleName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `tbl_scale` */

/*Table structure for table `tbl_scales` */

DROP TABLE IF EXISTS `tbl_scales`;

CREATE TABLE `tbl_scales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `scaleId` int(11) DEFAULT NULL,
  `scalesName` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `tbl_scales` */


/*Table structure for table `tbl_competency_attributes` */

DROP TABLE IF EXISTS `tbl_competency_attributes`;

CREATE TABLE `tbl_competency_attributes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `competency_id` int(11) NOT NULL,
  `attr_name` varchar(100) DEFAULT NULL,
  `attr_desc` text DEFAULT NULL,
  `attr_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `tbl_competency_attributes` */


/*Table structure for table `tbl_competency_modules` */

DROP TABLE IF EXISTS `tbl_competency_modules`;

CREATE TABLE `tbl_competency_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmdl_c_id` int(11) NOT NULL,
  `cmdl_level` int(10) NOT NULL DEFAULT 0, -- 0 => Basic, 1 => Intermediate, 2 => Expert
  `cmdl_kc_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `tbl_competency_modules` */



/*Table structure for table `tbl_competency_attrmodules` */

DROP TABLE IF EXISTS `tbl_competency_attrmodules`;

CREATE TABLE `tbl_competency_attrmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `camdl_ca_id` int(11) NOT NULL,
  `camdl_kc_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

/*Data for the table `tbl_competency_attrmodules` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

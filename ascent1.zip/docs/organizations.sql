ALTER TABLE `tbl_kc_list` ADD `kl_cat` VARCHAR(10) NULL AFTER `kl_kc_id`;

--
-- Table structure for table `tbl_organization`
--

CREATE TABLE `tbl_organization` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_organization`
--

INSERT INTO `tbl_organization` (`id`, `name`) VALUES 
(NULL, 'A to Z Essays'),
(NULL, 'Aequs'),
(NULL, 'Aequs Pvt Ltd'),
(NULL, 'ascent'),
(NULL, 'AscentHR'),
(NULL, 'Bharat Fritz Werner'),
(NULL, 'Bosch Ltd'),
(NULL, 'CCD'),
(NULL, 'Computer hardware and networking'),
(NULL, 'Culturelytics'),
(NULL, 'e2e'),
(NULL, 'e2e people practices'),
(NULL, 'e2e People Practices Pvt Ltd'),
(NULL, 'Embassy'),
(NULL, 'Embassy Group'),
(NULL, 'Euromonitor International'),
(NULL, 'Falco'),
(NULL, 'Fomax'),
(NULL, 'Forgreens'),
(NULL, 'FuGenX Technologies'),
(NULL, 'HPE'),
(NULL, 'HRAS'),
(NULL, 'I M T M A'),
(NULL, 'IFIM B School'),
(NULL, 'IMTMA'),
(NULL, 'Indian Machine Tool Manufacturer''s Association'),
(NULL, 'Indian machine tool manufacturers association'),
(NULL, 'Indian Machine Tool Manufacturers'' Association'),
(NULL, 'Indian machine tool manufacturersâ€™ association'),
(NULL, 'Ingersoll Rand'),
(NULL, 'Ingersoll Rand Technology Services'),
(NULL, 'Inner Genius'),
(NULL, 'K-Arogia'),
(NULL, 'Kennametal India Ltd'),
(NULL, 'KGK Engineering'),
(NULL, 'L&T'),
(NULL, 'Lenovo'),
(NULL, 'Lupin Ltd'),
(NULL, 'Maini Group'),
(NULL, 'Mckinsey'),
(NULL, 'Medi Assist'),
(NULL, 'Mediassist'),
(NULL, 'MT'),
(NULL, 'MTHR'),
(NULL, 'Netcore'),
(NULL, 'Netcore Solutions'),
(NULL, 'Nexevo'),
(NULL, 'Nextwebi'),
(NULL, 'Novo'),
(NULL, 'Novo Nordisk'),
(NULL, 'Novo Nordisk Ltd'),
(NULL, 'Novo Nordisk Ltd.'),
(NULL, 'NovoNordisk'),
(NULL, 'NTTF'),
(NULL, 'Organization'),
(NULL, 'Origami Creatives'),
(NULL, 'Others'),
(NULL, 'Pay it Forward'),
(NULL, 'Profession'),
(NULL, 'Reliance Retail Limited'),
(NULL, 'Scorpio Engineering'),
(NULL, 'SJCE-STEP'),
(NULL, 'SLN Technologies Pvt Ltd'),
(NULL, 'Sofitel hotels & Resorts'),
(NULL, 'Statestreet'),
(NULL, 'Statwood'),
(NULL, 'Strides Shasun'),
(NULL, 'STUDENT'),
(NULL, 'Sunpure Oil'),
(NULL, 'Suri Auto Products'),
(NULL, 'Surin Automiotive'),
(NULL, 'Swiss Re'),
(NULL, 'Syngene International'),
(NULL, 'Sysfore Technologies'),
(NULL, 'Tata Hitachi'),
(NULL, 'Tata Hitachi Construction Machinery Co. Ltd'),
(NULL, 'Tata Hitachi Construction Machinery Company Pvt. Ltd'),
(NULL, 'Tata Hitachi Construction Machinery Company Pvt. Ltd '),
(NULL, 'TE Connectivity'),
(NULL, 'TE Connectivity , Pune'),
(NULL, 'TE Connectivity India Pvt. Ltd'),
(NULL, 'TE Connectivity, Bangalore'),
(NULL, 'TE Connectivity, Bangaore'),
(NULL, 'TE Connectivity, Pune'),
(NULL, 'Tharoor Associates'),
(NULL, 'Theorem Inc'),
(NULL, 'Trainer'),
(NULL, 'University of Mumbai'),
(NULL, 'Volvo Group India Pvt Ltd'),
(NULL, 'Weir BDK'),
(NULL, 'White cross clinic'),
(NULL, 'Whitecross Health Initiatives Pvt Ltd'),
(NULL, 'Wipro Ltd');



ALTER TABLE `tbl_user` ADD `organization_id` INT(11) UNSIGNED NOT NULL AFTER `organization`;

UPDATE tbl_user u JOIN tbl_organization o ON o.name = u.organization SET u.organization_id = o.id;


--
-- Table structure for table `tbl_industry`
--

CREATE TABLE `tbl_industry` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_industry`
--

INSERT INTO `tbl_industry` (`id`, `name`) VALUES
(1, 'IT'),
(2, 'Pharma'),
(3, 'Accounting'),
(4, 'EV');


ALTER TABLE `tbl_organization` ADD `industry_id` INT(11) UNSIGNED NOT NULL AFTER `name`;


---
---11/12/2019
---
ALTER TABLE `tbl_organization` CHANGE `name` `org_name` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;
ALTER TABLE `tbl_industry` CHANGE `name` `ind_name` VARCHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL;
ALTER TABLE `tbl_user` CHANGE `organization_id` `organization_id` INT(11) UNSIGNED NULL;
ALTER TABLE `tbl_organization` CHANGE `industry_id` `industry_id` INT(11) UNSIGNED NULL;

UPDATE tbl_organization SET industry_id = NULL WHERE industry_id = 0;
UPDATE tbl_user SET organization_id = NULL WHERE organization_id = 0;

ALTER TABLE `tbl_organization` CHANGE `id` `id` INT(11) UNSIGNED NOT NULL primary key AUTO_INCREMENT;

/* 18/12/2019 */
ALTER TABLE `tbl_kc_list` ADD `kl_credits` DECIMAL NOT NULL DEFAULT '0' AFTER `status`;
ALTER TABLE `e2e`.`tbl_kc_list` ADD COLUMN `kl_credits` INT(11) DEFAULT 0 NULL AFTER `kl_link`; 

ALTER TABLE `tbl_knowledge_center` ADD `prg_trtp_id` INT(11) NULL DEFAULT NULL AFTER `prg_desc`;


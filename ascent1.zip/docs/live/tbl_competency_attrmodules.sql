DROP TABLE IF EXISTS `tbl_competency_attrmodules`;

CREATE TABLE `tbl_competency_attrmodules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `camdl_ca_id` int(11) NOT NULL,
  `camdl_kc_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;


SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


CREATE TABLE `tbl_trophy_template` (
  `trpt_id` int(11) UNSIGNED NOT NULL,
  `trpt_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

ALTER TABLE `tbl_trophy_template`
  ADD PRIMARY KEY (`trpt_id`);

--
-- Dumping data for table `tbl_trophy_template`
--

INSERT INTO `tbl_trophy_template` (`trpt_id`, `trpt_name`) VALUES
(1, 'threeshields');
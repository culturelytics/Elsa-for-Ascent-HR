-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 20, 2020 at 06:59 AM
-- Server version: 5.7.14
-- PHP Version: 7.2.17

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `deve2e_v2`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_competencies`
--

CREATE TABLE `tbl_competencies` (
  `prg_id` int(11) NOT NULL,
  `prg_name` varchar(255) NOT NULL,
  `prg_status` enum('Active','Inactive') NOT NULL,
  `prg_modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `prg_title` varchar(255) NOT NULL,
  `prg_desc` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_competencies`
--

INSERT INTO `tbl_competencies` (`prg_id`, `prg_name`, `prg_status`, `prg_modified_at`, `prg_title`, `prg_desc`) VALUES
(1, 'Business Communication', 'Active', '2019-12-21 12:02:53', '', ''),
(2, 'Leading People (O & A )', 'Active', '2020-01-19 11:11:16', '', ''),
(3, 'Managing Performance', 'Active', '2020-01-19 11:11:28', '', ''),
(4, 'Relationships', 'Active', '2020-01-19 11:11:38', '', ''),
(5, 'Conflict Management', 'Active', '2020-01-19 11:11:49', '', ''),
(6, 'Personal Effectiveness (Time Management)', 'Active', '2020-01-19 11:11:57', '', ''),
(7, 'Problem Solving and Decision Making', 'Active', '2020-01-19 11:12:13', '', ''),
(8, 'Self-Development (Interpersonal skills)', 'Active', '2020-01-19 11:12:21', '', ''),
(9, 'Developing Others', 'Active', '2020-01-19 11:12:34', '', ''),
(10, 'Financial Management', 'Active', '2020-01-19 11:12:49', '', ''),
(11, 'Risk Management', 'Active', '2020-01-19 11:13:56', '', ''),
(12, 'Strategic / Business Skills', 'Active', '2020-01-19 11:14:25', '', ''),
(13, 'Personal Brand', 'Active', '2020-01-19 11:15:02', '', ''),
(14, 'Continuous Improvement (Interpersonal Skills)', 'Active', '2020-01-19 11:15:29', '', ''),
(15, 'Teamwork', 'Active', '2020-01-19 11:15:53', '', ''),
(16, 'Managing Change', 'Active', '2020-01-19 11:16:27', '', ''),
(17, 'Client Orientated', 'Active', '2020-01-19 11:16:50', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_competency_attributes`
--

CREATE TABLE `tbl_competency_attributes` (
  `id` int(11) NOT NULL,
  `competency_id` int(11) NOT NULL,
  `attr_name` varchar(100) DEFAULT NULL,
  `attr_desc` text,
  `attr_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_competency_attributes`
--

INSERT INTO `tbl_competency_attributes` (`id`, `competency_id`, `attr_name`, `attr_desc`, `attr_status`) VALUES
(1, 1, 'Encourages open dialogue with all stake holders', '', 'Active'),
(2, 1, 'Encourages others to voice honest & open communication', '', 'Active'),
(3, 1, 'Provides stake holders with the information they need', NULL, 'Active'),
(4, 1, 'Ability to appropriately tailor communication to the audience\r\n', NULL, 'Active'),
(5, 1, 'Listens carefully to input before speaking\r\n', NULL, 'Active'),
(6, 1, 'Is Clear & concise in speaking\r\n', NULL, 'Active'),
(7, 1, 'Has proficient presentation skills\r\n', NULL, 'Active'),
(8, 2, 'Develops a common vision', NULL, 'Active'),
(9, 2, 'Aligns others to the vision', NULL, 'Active'),
(10, 2, 'Ability to Inspire & motivating others', NULL, 'Active'),
(11, 2, 'Acts as a role model to peers & their team', NULL, 'Active'),
(12, 2, 'Brings in flexibility of leadership style', NULL, 'Active'),
(13, 2, 'Is accountable for their actions & takes responsibilities', NULL, 'Active'),
(14, 2, 'Empowers their team to make decisions & take action', NULL, 'Active'),
(15, 2, 'Effectively influences their team', NULL, 'Active'),
(16, 2, 'Champions the organisation\'s values', NULL, 'Active'),
(17, 2, 'Delegates work appropriately to concerned stake holders', NULL, 'Active'),
(18, 3, 'Establishes clear targets for others', NULL, 'Active'),
(19, 3, 'Obtains top level performance from others', NULL, 'Active'),
(20, 3, 'Provides appropriate levels of support where required', NULL, 'Active'),
(21, 3, 'Effectively Monitors & measures team performance', NULL, 'Active'),
(22, 3, 'Provides constructive & developmental feedback', NULL, 'Active'),
(23, 3, 'Effectively provides critical feedback', NULL, 'Active'),
(24, 3, 'Effectively addresses poor performance in timely & transparent manner', NULL, 'Active'),
(25, 4, 'Invests time in building relationships', NULL, 'Active'),
(26, 4, 'Is genuinely interested in others', NULL, 'Active'),
(27, 4, 'Treats people fairly and consistently', NULL, 'Active'),
(28, 4, 'Brings out the best in people', NULL, 'Active'),
(29, 4, 'Builds effective relationships', NULL, 'Active'),
(30, 4, 'Treats others with respect and dignity', NULL, 'Active'),
(31, 4, 'Values diversity', NULL, 'Active'),
(32, 4, 'Values differences in opinions', NULL, 'Active'),
(33, 4, 'Is emotionally intelligent', NULL, 'Active'),
(34, 4, 'Establishes effective networks', NULL, 'Active'),
(35, 5, 'Confronts issues in early stages', NULL, 'Active'),
(36, 5, 'Constructively deals with disagreements', NULL, 'Active'),
(37, 5, 'Effectively works through resolving issues', NULL, 'Active'),
(38, 6, 'Places the organisation first', NULL, 'Active'),
(39, 6, 'Demonstrates true drive and energy', NULL, 'Active'),
(40, 6, 'Is proactive and achievement oriented', NULL, 'Active'),
(41, 6, 'Effectively prioritises own workload', NULL, 'Active'),
(42, 6, 'Is well organised', NULL, 'Active'),
(43, 6, 'Ability to handle multiple demands and competing priorities', NULL, 'Active'),
(44, 6, 'Ability to exceed target expectations', NULL, 'Active'),
(45, 6, 'Reacts positively under pressure', NULL, 'Active'),
(46, 6, 'Displays commitment to excellence', NULL, 'Active'),
(47, 6, 'Understands own personal strengths and weaknesses', NULL, 'Active'),
(48, 6, 'Is self-confident', NULL, 'Active'),
(49, 6, 'Follows through and gets work completed', NULL, 'Active'),
(50, 6, 'Expresses feelings, beliefs and thoughts in a non-destructive way', NULL, 'Active'),
(51, 6, 'Takes calculated risks', NULL, 'Active'),
(52, 6, 'Leverages own strengths', NULL, 'Active'),
(53, 6, 'Stays on the leading edge of professional and technical best practice', NULL, 'Active'),
(54, 6, 'Effectively delegates to others', NULL, 'Active'),
(55, 6, 'Displays technical excellence', NULL, 'Active'),
(56, 7, 'Resolves problems without delay', NULL, 'Active'),
(57, 7, 'Shows creativity in their problem solving approach', NULL, 'Active'),
(58, 7, 'Logically approaches problems', NULL, 'Active'),
(59, 7, 'Makes effective & timely decisions', NULL, 'Active'),
(60, 7, 'Shows integrity and fairness in decision making', NULL, 'Active'),
(61, 7, 'Involves appropriate people in the decision making process', NULL, 'Active'),
(62, 7, 'Ability to take tough decisions', NULL, 'Active'),
(63, 8, 'Strives to improve own performance', NULL, 'Active'),
(64, 8, 'Understands own strengths and weaknesses', NULL, 'Active'),
(65, 8, 'Pursues focused self-development', NULL, 'Active'),
(66, 8, 'Seeks new challenges', NULL, 'Active'),
(67, 8, 'Learns from own mistakes', NULL, 'Active'),
(68, 8, 'Open to feedback', NULL, 'Active'),
(69, 8, 'Uses feedback to improve performance', NULL, 'Active'),
(70, 9, 'Expresses interest towards the development of their staff as a key priority', NULL, 'Active'),
(71, 9, 'Creates an environment that encourages continuous learning', NULL, 'Active'),
(72, 9, 'Actively develops others', NULL, 'Active'),
(73, 9, 'Identifies the development needs of others', NULL, 'Active'),
(74, 9, 'Generates development opportunities for staff', NULL, 'Active'),
(75, 9, 'Coaches staff for better performance', NULL, 'Active'),
(76, 9, 'Commits to growing leadership talent', NULL, 'Active'),
(77, 9, 'Has a succession plan for their team', NULL, 'Active'),
(78, 10, 'Has sound financial awareness', NULL, 'Active'),
(79, 10, 'Effectively budgets management', NULL, 'Active'),
(80, 10, 'Makes sound financial decisions', NULL, 'Active'),
(81, 10, 'Anticipates financial constraints and plans accordingly', NULL, 'Active'),
(82, 10, 'Looks for ways to improve cost effectiveness whilst maintaining & improving quality of service', NULL, 'Active'),
(83, 11, 'Creates an environment that recognises and addresses potential risks', NULL, 'Active'),
(84, 11, 'Makes people feel secure to take risks', NULL, 'Active'),
(85, 11, 'Takes appropriate risks to achieve desired goals', NULL, 'Active'),
(86, 11, 'Effectively prioritises risks', NULL, 'Active'),
(87, 12, 'Understands the dynamics of the market place', NULL, 'Active'),
(88, 12, 'Considers the bigger picture and thinks strategically', NULL, 'Active'),
(89, 12, 'Maintains a long term big picture view of the business', NULL, 'Active'),
(90, 12, 'Recognises when it is time to shift strategic direction', NULL, 'Active'),
(91, 12, 'Understands the total business value chain', NULL, 'Active'),
(92, 12, 'Converts long term strategic thinking into action', NULL, 'Active'),
(93, 12, 'Encourages others to see how they contribute to the bigger picture', NULL, 'Active'),
(94, 12, 'Takes an entrepreneurial approach to drive business success', NULL, 'Active'),
(95, 12, 'Works with the whole organisation in mind', NULL, 'Active'),
(96, 12, 'Works collaboratively with other business areas', NULL, 'Active'),
(97, 12, 'Actively looks for new business opportunities', NULL, 'Active'),
(98, 12, 'Posses superior business winning (sales) skills', NULL, 'Active'),
(99, 12, 'Balances technical & leadership role with senior team responsibilities', NULL, 'Active'),
(100, 13, 'Projects an appropriate degree of self confidence', NULL, 'Active'),
(101, 13, 'Readily commanding respect', NULL, 'Active'),
(102, 13, 'Is actively networking within their market', NULL, 'Active'),
(103, 13, 'Is known and trusted in their market', NULL, 'Active'),
(104, 13, 'Has a good reputation', NULL, 'Active'),
(105, 13, 'Has credibility in own area of expertise', NULL, 'Active'),
(106, 13, 'Shows consistency between actions and words', NULL, 'Active'),
(107, 13, 'Acts with honesty and integrity', NULL, 'Active'),
(108, 13, 'Displays executive presence', NULL, 'Active'),
(109, 14, 'Creates a culture of continuous improvement', NULL, 'Active'),
(110, 14, 'Actively looks for better ways of doing things', NULL, 'Active'),
(111, 14, 'Inspires people to look beyond existing limitations', NULL, 'Active'),
(112, 14, 'Actively seeks out external ideas, best practice and current thinking', NULL, 'Active'),
(113, 14, 'Keeps up to date with competitor activities and practices', NULL, 'Active'),
(114, 14, 'Challenges the Status Quo', NULL, 'Active'),
(115, 14, 'Invites improvement feedback from customers', NULL, 'Active'),
(116, 14, 'Treats complaints as opportunities to improve', NULL, 'Active'),
(117, 14, 'Is open about mistakes', NULL, 'Active'),
(118, 14, 'Shares best practice with other teams / departments', NULL, 'Active'),
(119, 15, 'Fosters a positive team spirit', NULL, 'Active'),
(120, 15, 'Builds a high performing team', NULL, 'Active'),
(121, 15, 'Demonstrates personal commitment to the team', NULL, 'Active'),
(122, 15, 'Puts success of team above own interests', NULL, 'Active'),
(123, 15, 'Provides clear direction for the team', NULL, 'Active'),
(124, 15, 'Creates a blame free culture', NULL, 'Active'),
(125, 16, 'Recognises the need for change', NULL, 'Active'),
(126, 16, 'Maintains energy and motivation during times of change', NULL, 'Active'),
(127, 16, 'Leads and manages well in turbulent times', NULL, 'Active'),
(128, 16, 'Effectively deals with ambiguous situations', NULL, 'Active'),
(129, 16, 'Prepares people for change', NULL, 'Active'),
(130, 16, 'Articulates the reasons for change to those affected', NULL, 'Active'),
(131, 16, 'Gains the buy-in and cooperation of others', NULL, 'Active'),
(132, 16, 'Gives people a sense that change is achievable and that their contribution matters', NULL, 'Active'),
(133, 16, 'Supports individuals through the change process', NULL, 'Active'),
(134, 16, 'Identifies and removes barriers to effective change', NULL, 'Active'),
(135, 17, 'Is a role model for delivering excellent service to customers', NULL, 'Active'),
(136, 17, 'Understands the needs and expectations of customers', NULL, 'Active'),
(137, 17, 'Focuses on client needs and expectations', NULL, 'Active'),
(138, 17, 'Builds effective working relationships with customers', NULL, 'Active'),
(139, 17, 'Benchmarks client satisfaction against others in similar areas', NULL, 'Active'),
(140, 17, 'Takes action to improve service before complaints arise', NULL, 'Active'),
(141, 17, 'Seeks regular feedback from customers', NULL, 'Active'),
(142, 17, 'Gives people a sense that change is achievable and that their contribution matters', NULL, 'Active');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_competency_attrmodules`
--

CREATE TABLE `tbl_competency_attrmodules` (
  `id` int(11) NOT NULL,
  `camdl_ca_id` int(11) NOT NULL,
  `camdl_kc_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_competency_attrmodules`
--

INSERT INTO `tbl_competency_attrmodules` (`id`, `camdl_ca_id`, `camdl_kc_id`) VALUES
(1, 1, 49),
(2, 2, 50),
(3, 2, 51),
(4, 3, 50),
(5, 4, 49),
(6, 4, 51),
(7, 5, 49),
(8, 6, 49),
(9, 6, 51),
(10, 7, 49),
(11, 7, 50),
(12, 8, 54),
(13, 8, 53),
(14, 9, 54),
(15, 9, 53),
(16, 10, 54),
(17, 10, 53),
(18, 11, 54),
(19, 11, 53),
(20, 12, 54),
(21, 12, 53),
(22, 13, 55),
(23, 14, 55),
(24, 15, 55),
(25, 16, 55),
(26, 17, 55),
(27, 18, 56),
(28, 18, 58),
(29, 19, 56),
(30, 19, 58),
(31, 20, 56),
(32, 20, 58),
(33, 21, 56),
(34, 22, 57),
(35, 23, 57),
(36, 24, 57),
(37, 25, 59),
(38, 26, 59),
(39, 26, 60),
(40, 27, 60),
(41, 27, 61),
(42, 28, 59),
(43, 28, 62),
(44, 29, 59),
(45, 30, 60),
(46, 30, 61),
(47, 31, 61),
(48, 32, 59),
(49, 33, 62),
(50, 34, 59),
(51, 35, 65),
(52, 36, 65),
(53, 37, 65),
(54, 38, 66),
(55, 39, 66),
(56, 40, 66),
(57, 41, 66),
(58, 42, 66),
(59, 43, 66),
(60, 44, 67),
(61, 45, 67),
(62, 46, 67),
(63, 47, 67),
(64, 48, 67),
(65, 49, 67),
(66, 50, 68),
(67, 51, 68),
(68, 52, 68),
(69, 53, 68),
(70, 54, 68),
(71, 55, 68),
(72, 56, 69),
(73, 57, 69),
(74, 58, 69),
(75, 59, 70),
(76, 60, 70),
(77, 60, 71),
(78, 61, 70),
(79, 61, 71),
(80, 62, 70),
(81, 62, 71),
(82, 63, 77),
(83, 64, 77),
(84, 65, 77),
(85, 66, 77),
(86, 67, 77),
(87, 68, 77),
(88, 69, 77),
(89, 70, 78),
(90, 70, 79),
(91, 71, 80),
(92, 71, 79),
(93, 72, 79),
(94, 72, 82),
(95, 73, 80),
(96, 73, 81),
(97, 74, 82),
(98, 74, 78),
(99, 75, 79),
(100, 76, 78),
(101, 76, 79),
(102, 77, 78),
(103, 78, 83),
(104, 79, 83),
(105, 80, 83),
(106, 81, 84),
(107, 82, 84),
(108, 83, 86),
(109, 84, 87),
(110, 85, 113),
(111, 86, 88),
(112, 87, 92),
(113, 88, 92),
(114, 89, 92),
(115, 90, 92),
(116, 91, 92),
(117, 92, 92),
(118, 93, 92),
(119, 94, 92),
(120, 95, 92),
(121, 96, 92),
(122, 97, 92),
(123, 98, 92),
(124, 99, 92),
(125, 100, 93),
(126, 101, 93),
(127, 102, 93),
(128, 103, 94),
(129, 104, 94),
(130, 105, 94),
(131, 105, 95),
(132, 106, 94),
(133, 107, 94),
(134, 108, 95),
(135, 109, 96),
(136, 110, 96),
(137, 110, 97),
(138, 111, 97),
(139, 112, 97),
(140, 113, 98),
(141, 114, 98),
(142, 115, 97),
(143, 116, 97),
(144, 117, 98),
(145, 118, 98),
(146, 119, 99),
(147, 119, 100),
(148, 120, 100),
(149, 121, 99),
(150, 122, 99),
(151, 122, 101),
(152, 123, 100),
(153, 124, 101),
(154, 124, 102),
(155, 125, 103),
(156, 126, 104),
(157, 127, 105),
(158, 128, 105),
(159, 128, 104),
(160, 129, 106),
(161, 130, 106),
(162, 131, 106),
(163, 132, 105),
(164, 132, 106),
(165, 133, 106),
(166, 134, 103),
(167, 135, 111),
(168, 136, 111),
(169, 137, 111),
(170, 138, 111),
(171, 139, 111),
(172, 140, 112),
(173, 141, 112),
(174, 142, 112);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_competency_modules`
--

CREATE TABLE `tbl_competency_modules` (
  `id` int(11) NOT NULL,
  `cmdl_c_id` int(11) NOT NULL,
  `cmdl_level` int(10) NOT NULL DEFAULT '0',
  `cmdl_kc_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_competency_modules`
--

INSERT INTO `tbl_competency_modules` (`id`, `cmdl_c_id`, `cmdl_level`, `cmdl_kc_id`) VALUES
(1, 1, 0, 49),
(2, 1, 1, 50),
(3, 1, 2, 51),
(4, 1, 2, 5),
(5, 2, 0, 53),
(6, 2, 1, 54),
(7, 2, 2, 55),
(8, 3, 0, 56),
(9, 3, 1, 57),
(10, 3, 2, 58),
(11, 4, 0, 59),
(12, 4, 1, 60),
(13, 4, 2, 62),
(14, 5, 0, 63),
(15, 5, 1, 64),
(16, 5, 2, 65),
(17, 6, 0, 66),
(18, 6, 1, 67),
(19, 6, 2, 68),
(20, 7, 0, 69),
(21, 7, 1, 70),
(22, 7, 2, 71),
(23, 8, 0, 72),
(24, 8, 1, 75),
(25, 8, 2, 77),
(26, 8, 0, 73),
(27, 8, 1, 76),
(28, 8, 0, 74),
(29, 9, 0, 78),
(30, 9, 1, 79),
(31, 9, 2, 82),
(32, 9, 1, 80),
(33, 9, 1, 81),
(34, 10, 0, 83),
(35, 10, 1, 84),
(36, 10, 2, 85),
(37, 11, 0, 86),
(38, 11, 1, 87),
(39, 11, 2, 88),
(40, 11, 1, 113),
(41, 12, 0, 89),
(42, 12, 1, 90),
(43, 12, 2, 91),
(44, 12, 2, 92),
(45, 13, 0, 93),
(46, 13, 1, 94),
(47, 13, 2, 95),
(48, 14, 0, 96),
(49, 14, 1, 97),
(50, 14, 2, 98),
(51, 15, 0, 99),
(52, 15, 1, 100),
(53, 15, 2, 102),
(54, 15, 2, 101),
(55, 16, 0, 103),
(56, 16, 1, 104),
(57, 16, 2, 106),
(58, 16, 1, 105),
(59, 17, 0, 110),
(60, 17, 1, 111),
(61, 17, 2, 112),
(62, 17, 0, 108),
(63, 17, 0, 109),
(64, 17, 0, 107);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_competencies`
--
ALTER TABLE `tbl_competencies`
  ADD PRIMARY KEY (`prg_id`);

--
-- Indexes for table `tbl_competency_attributes`
--
ALTER TABLE `tbl_competency_attributes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_competency_attrmodules`
--
ALTER TABLE `tbl_competency_attrmodules`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_competency_modules`
--
ALTER TABLE `tbl_competency_modules`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_competencies`
--
ALTER TABLE `tbl_competencies`
  MODIFY `prg_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tbl_competency_attributes`
--
ALTER TABLE `tbl_competency_attributes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=143;
--
-- AUTO_INCREMENT for table `tbl_competency_attrmodules`
--
ALTER TABLE `tbl_competency_attrmodules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=175;
--
-- AUTO_INCREMENT for table `tbl_competency_modules`
--
ALTER TABLE `tbl_competency_modules`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

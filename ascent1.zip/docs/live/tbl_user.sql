ALTER TABLE `tbl_user` ADD `organization_id` INT(11) UNSIGNED NOT NULL AFTER `organization`;
UPDATE tbl_user u JOIN tbl_organization o ON o.org_name = u.organization SET u.organization_id = o.id;
ALTER TABLE `tbl_user` CHANGE `organization_id` `organization_id` INT(11) UNSIGNED NULL;
UPDATE tbl_user SET organization_id = NULL WHERE organization_id = 0;

ALTER TABLE `tbl_user` ADD `kc_c_access` VARCHAR(255) NOT NULL DEFAULT 'no' AFTER `kaccess`;

ALTER TABLE `tbl_user` ADD `idp_c_access` VARCHAR(255) NOT NULL DEFAULT 'no' AFTER `caccess`;

ALTER TABLE `tbl_user` ADD `birth_date` DATE NULL DEFAULT NULL AFTER `organization_id`;
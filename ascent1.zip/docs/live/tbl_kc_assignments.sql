
-- --------------------------------------------------------

--
-- Table structure for table `tbl_kc_assignments`
--

CREATE TABLE `tbl_kc_assignments` (
  `kca_id` int(11) UNSIGNED NOT NULL,
  `kca_user_id` int(11) NOT NULL,
  `kca_kc_id` int(11) NOT NULL,
  `kca_created_at` timestamp NOT NULL,
  `kca_status` enum('Active','Inactive') NOT NULL DEFAULT 'Active'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_kc_assignments`
--
ALTER TABLE `tbl_kc_assignments`
  ADD PRIMARY KEY (`kca_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_kc_assignments`
--
ALTER TABLE `tbl_kc_assignments`
  MODIFY `kca_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;

---
--- 24/12/19
---
ALTER TABLE `tbl_kc_assignments` ADD `kca_isself` BOOLEAN NOT NULL DEFAULT FALSE AFTER `kca_status`;

ALTER TABLE `tbl_kc_assignments` ADD `kca_credits` DECIMAL NOT NULL DEFAULT '0' AFTER `kca_isself`;
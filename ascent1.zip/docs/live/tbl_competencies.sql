-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 26, 2019 at 07:57 AM
-- Server version: 5.7.24
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elsa_dev_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_competencies`
--

DROP TABLE IF EXISTS `tbl_competencies`;
CREATE TABLE IF NOT EXISTS `tbl_competencies` (
  `prg_id` int(11) NOT NULL AUTO_INCREMENT,
  `prg_name` varchar(255) NOT NULL,
  `prg_status` enum('Active','Inactive') NOT NULL,
  `prg_modified_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `prg_title` varchar(255) NOT NULL,
  `prg_desc` mediumtext NOT NULL,
  PRIMARY KEY (`prg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_competencies`
--

INSERT INTO `tbl_competencies` (`prg_id`, `prg_name`, `prg_status`, `prg_modified_at`, `prg_title`, `prg_desc`) VALUES
(1, 'Business Communication', 'Active', '2019-12-21 12:02:53', '', ''),
(2, 'Relationships', 'Active', '2019-12-06 07:45:27', '', ''),
(3, 'Team Work', 'Active', '2019-12-06 08:54:50', '', ''),
(4, 'Problem Solving and Decision Ma', 'Active', '2019-12-06 09:44:46', '', ''),
(5, 'Developing Others', 'Active', '2019-12-06 09:45:12', '', ''),
(6, 'Personal Brand', 'Active', '2019-12-06 09:45:19', '', ''),
(7, 'Continuous Improvement Opportunities', 'Active', '2019-12-06 09:45:25', '', ''),
(8, 'Managing Change', 'Active', '2019-12-06 09:45:46', '', ''),
(9, 'Risk Management', 'Active', '2019-12-06 09:45:54', '', '');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

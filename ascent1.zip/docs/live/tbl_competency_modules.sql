DROP TABLE IF EXISTS `tbl_competency_modules`;

CREATE TABLE `tbl_competency_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cmdl_c_id` int(11) NOT NULL,
  `cmdl_level` int(10) NOT NULL DEFAULT 0, -- 0 => Basic, 1 => Intermediate, 2 => Expert
  `cmdl_kc_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

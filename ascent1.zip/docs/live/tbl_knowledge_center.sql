ALTER TABLE `tbl_knowledge_center` ADD COLUMN `org_id` INT(11) DEFAULT 0 NULL AFTER `prg_id`; 

ALTER TABLE `tbl_knowledge_center` ADD `prg_trtp_id` INT(11) NULL DEFAULT NULL AFTER `prg_desc`;


update `tbl_knowledge_center` set `prg_trtp_id` = 1;
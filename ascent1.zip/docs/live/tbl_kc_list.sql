ALTER TABLE `tbl_kc_list` ADD `kl_cat` VARCHAR(10) NULL AFTER `kl_kc_id`;
ALTER TABLE `tbl_kc_list` ADD `kl_credits` DECIMAL NOT NULL DEFAULT '0' AFTER `status`;
ALTER TABLE `tbl_kc_list` ADD COLUMN `kl_type` TEXT NULL AFTER `kl_prg_id`; 

ALTER TABLE `tbl_kc_list` ADD `kl_file_url` VARCHAR(500) NULL AFTER `kl_credits`;

--
-- Table structure for table `tbl_groups`
--

CREATE TABLE `tbl_groups` (
  `id` int(10) UNSIGNED NOT NULL,
  `org_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Indexes for table `tbl_groups`
--
ALTER TABLE `tbl_groups`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tbl_groups`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

--
-- Table structure for table `tbl_group_user`
--

CREATE TABLE `tbl_group_user` (
  `id` int(11) UNSIGNED NOT NULL,
  `group_id` int(11) UNSIGNED NOT NULL,
  `user_id` int(11) UNSIGNED NOT NULL,
  `is_admin` tinyint(11) NOT NULL DEFAULT '0',
  `status` VARCHAR(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


--
-- Indexes for table `tbl_group_user`
--
ALTER TABLE `tbl_group_user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `group_user_group_id_index` (`group_id`),
  ADD KEY `group_user_user_id_index` (`user_id`);

ALTER TABLE `tbl_group_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;


CREATE TABLE `tbl_group_kc` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `kc_id` int(11) NOT NULL,
  `is_client` TINYINT NOT NULL DEFAULT '0',
  `status` VARCHAR(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbl_group_kc`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `tbl_group_kc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;


CREATE TABLE `tbl_group_idp` (
  `id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `idp_id` int(11) NOT NULL,
  `status` VARCHAR(20) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `created_by` int(11) NOT NULL,
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `updated_by` int(11) NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

ALTER TABLE `tbl_group_idp`
  ADD PRIMARY KEY (`id`);
  
ALTER TABLE `tbl_group_idp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;

ALTER TABLE `tbl_group_idp` ADD `module_ids` TEXT NOT NULL AFTER `idp_id`;

-- --------------

ALTER TABLE `tbl_admin` ADD `role` VARCHAR(20) NOT NULL AFTER `password`, ADD `org_id` INT(11) NOT NULL AFTER `role`, ADD `user_id` INT(11) NOT NULL AFTER `org_id`;
ALTER TABLE `tbl_admin` ADD `group_ids` TEXT NULL AFTER `user_id`;
ALTER TABLE `tbl_admin` ADD `is_org_admin` TINYINT NOT NULL DEFAULT '0' AFTER `password`;

-- ALTER TABLE `tbl_group_user` ADD `status` VARCHAR(20) NOT NULL AFTER `is_admin`;

-- ALTER TABLE `tbl_group_kc` ADD `is_client` TINYINT NOT NULL DEFAULT '0' AFTER `kc_id`;
ALTER TABLE `tbl_group_idp` ADD `is_client` TINYINT NOT NULL DEFAULT '0' AFTER `idp_id`;


UPDATE `tbl_admin` SET `role` = 'super_admin' WHERE `tbl_admin`.`id` = 1;

ALTER TABLE `tbl_admin` DROP `org_id`;

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";



CREATE TABLE `tbl_trophy_template_slab` (
  `trps_id` int(11) UNSIGNED NOT NULL,
  `trps_trpt_id` int(11) UNSIGNED NOT NULL,
  `trps_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `trps_perc` decimal(10,0) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for table `tbl_trophy_template_slab`
--
ALTER TABLE `tbl_trophy_template_slab`
  ADD PRIMARY KEY (`trps_id`);


INSERT INTO `tbl_trophy_template_slab` (`trps_id`, `trps_trpt_id`, `trps_name`, `trps_perc`) VALUES
(1, 1, 'Bronze', '35'),
(2, 1, 'Silver', '70'),
(3, 1, 'Gold', '100');

--
-- Indexes for dumped tables
--

--

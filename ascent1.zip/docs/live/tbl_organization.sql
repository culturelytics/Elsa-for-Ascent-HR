-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 25, 2019 at 07:09 PM
-- Server version: 5.7.24
-- PHP Version: 7.3.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `elsa_dev_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_organization`
--

DROP TABLE IF EXISTS `tbl_organization`;
CREATE TABLE IF NOT EXISTS `tbl_organization` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `org_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `industry_id` int(11) UNSIGNED DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=94 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tbl_organization`
--

INSERT INTO `tbl_organization` (`id`, `org_name`, `industry_id`) VALUES
(1, 'A to Z Essays', NULL),
(2, 'Aequs', NULL),
(3, 'Aequs Pvt Ltd', NULL),
(4, 'ascent', NULL),
(5, 'AscentHR', NULL),
(6, 'Bharat Fritz Werner', NULL),
(7, 'Bosch Ltd', NULL),
(8, 'CCD', NULL),
(9, 'Computer hardware and networking', NULL),
(10, 'Culturelytics', NULL),
(11, 'e2e', NULL),
(12, 'e2e people practices', NULL),
(13, 'e2e People Practices Pvt Ltd', NULL),
(14, 'Embassy', NULL),
(15, 'Embassy Group', NULL),
(16, 'Euromonitor International', NULL),
(17, 'Falco', NULL),
(18, 'Fomax', NULL),
(19, 'Forgreens', NULL),
(20, 'FuGenX Technologies', NULL),
(21, 'HPE', NULL),
(22, 'HRAS', NULL),
(23, 'I M T M A', NULL),
(24, 'IFIM B School', NULL),
(25, 'IMTMA', NULL),
(26, 'Indian Machine Tool Manufacturer\'s Association', NULL),
(27, 'Indian machine tool manufacturers association', NULL),
(28, 'Indian Machine Tool Manufacturers\' Association', NULL),
(29, 'Indian machine tool manufacturersâ€™ association', NULL),
(30, 'Ingersoll Rand', NULL),
(31, 'Ingersoll Rand Technology Services', NULL),
(32, 'Inner Genius', NULL),
(33, 'K-Arogia', NULL),
(34, 'Kennametal India Ltd', NULL),
(35, 'KGK Engineering', NULL),
(36, 'L&T', NULL),
(37, 'Lenovo', NULL),
(38, 'Lupin Ltd', NULL),
(39, 'Maini Group', NULL),
(40, 'Mckinsey', NULL),
(41, 'Medi Assist', NULL),
(42, 'Mediassist', NULL),
(43, 'MT', NULL),
(44, 'MTHR', NULL),
(45, 'Netcore', NULL),
(46, 'Netcore Solutions', NULL),
(47, 'Nexevo', NULL),
(48, 'Nextwebi', NULL),
(49, 'Novo', NULL),
(50, 'Novo Nordisk', NULL),
(51, 'Novo Nordisk Ltd', NULL),
(52, 'Novo Nordisk Ltd.', NULL),
(53, 'NovoNordisk', NULL),
(54, 'NTTF', NULL),
(55, 'Organization', NULL),
(56, 'Origami Creatives', NULL),
(57, 'Others', NULL),
(58, 'Pay it Forward', NULL),
(59, 'Profession', NULL),
(60, 'Reliance Retail Limited', NULL),
(61, 'Scorpio Engineering', NULL),
(62, 'SJCE-STEP', NULL),
(63, 'SLN Technologies Pvt Ltd', NULL),
(64, 'Sofitel hotels & Resorts', NULL),
(65, 'Statestreet', NULL),
(66, 'Statwood', NULL),
(67, 'Strides Shasun', NULL),
(68, 'STUDENT', NULL),
(69, 'Sunpure Oil', NULL),
(70, 'Suri Auto Products', NULL),
(71, 'Surin Automiotive', NULL),
(72, 'Swiss Re', NULL),
(73, 'Syngene International', NULL),
(74, 'Sysfore Technologies', NULL),
(75, 'Tata Hitachi', NULL),
(76, 'Tata Hitachi Construction Machinery Co. Ltd', NULL),
(77, 'Tata Hitachi Construction Machinery Company Pvt. Ltd', NULL),
(78, 'Tata Hitachi Construction Machinery Company Pvt. Ltd ', NULL),
(79, 'TE Connectivity', NULL),
(80, 'TE Connectivity , Pune', NULL),
(81, 'TE Connectivity India Pvt. Ltd', NULL),
(82, 'TE Connectivity, Bangalore', NULL),
(83, 'TE Connectivity, Bangaore', NULL),
(84, 'TE Connectivity, Pune', NULL),
(85, 'Tharoor Associates', NULL),
(86, 'Theorem Inc', NULL),
(87, 'Trainer', NULL),
(88, 'University of Mumbai', NULL),
(89, 'Volvo Group India Pvt Ltd', NULL),
(90, 'Weir BDK', NULL),
(91, 'White cross clinic', NULL),
(92, 'Whitecross Health Initiatives Pvt Ltd', NULL),
(93, 'Wipro Ltd', NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

ALTER TABLE `tbl_organization` ADD `org_code` varchar(30) NULL DEFAULT NULL AFTER `industry_id`;
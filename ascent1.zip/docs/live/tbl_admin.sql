ALTER TABLE `tbl_admin` ADD `contact` VARCHAR(20) NULL;
ALTER TABLE `tbl_admin` ADD `status` VARCHAR(10) NOT NULL DEFAULT 'active';
ALTER TABLE `tbl_admin` ADD `last_name` VARCHAR(20) NULL;
ALTER TABLE `tbl_admin` ADD `gender` VARCHAR(5) NULL;
ALTER TABLE `tbl_admin` ADD `linkedin` VARCHAR(255) NULL;
ALTER TABLE `tbl_admin` ADD `twitter` VARCHAR(255) NULL;
ALTER TABLE `tbl_admin` ADD `birth_date` DATE NULL DEFAULT NULL;

ALTER TABLE `tbl_admin` ADD `organization_id` INT(11) UNSIGNED NULL;


UPDATE `tbl_admin` SET organization_id = NULL WHERE organization_id = 0;

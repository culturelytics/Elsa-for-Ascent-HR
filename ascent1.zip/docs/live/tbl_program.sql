ALTER TABLE `tbl_programs` ADD COLUMN `org_id` INT DEFAULT 0 NULL AFTER `prg_id`; 

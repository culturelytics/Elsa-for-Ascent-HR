<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
 <title> Search for contact</title>
</head>
<body bgcolor = "#CCFFFF" text = "#660099">

<?php
$self = $_SERVER['PHP_SELF'];
?>
 <form action="<?=$self?>" method="GET">
 Date : <input type="text" name="name" />
 Company:<input type="text" name="company"/>
 Program:<input type="text" name="program"/>

 <input type="hidden" name="search" />

 <input type="submit" value = "Search" />
 </form>
<?php
if(isset($_GET['search'])) { 
$dbh = mysql_connect("localhost", "nexevonew", "Hameed@786")or die(mysql_error());
 mysql_select_db('admin_nexevonew') or die(mysql_error());

 $nme=$_GET["name"];
 $cmp=$_GET["company"];              
$pgm=$_GET["program"];
 echo "<p>Searching for $nme,$cmp,$pgm</p>";
 $query=mysql_query("SELECT Date,Company,Program,round(avg(Coverage),2),round(avg(Clarity),2),round(avg(CaseStudy),2),round(avg(Knowledge),2),round(avg(Presentation),2),round(avg(Examples),2),round(avg(Queries),2),round(avg(Impact),2) FROM Feedback WHERE Date='$nme' and Company='$cmp' and program='$pgm' ");       

 if(mysql_num_rows($query) > 0) {
?>
 <table border="1" style="border-collapse:collapse; color:#404040">
 <tr>
<th>Date</th>
<th>Company</th>
<th>Program</th>
 <th> Coverage of Subject</th>
 <th>  Clarity of Objective</th>
 <th> Case Study</th>
 <th> Knowledge Of Subject</th>
 <th> Presentation Skills</th>
 <th> Examples Used</th>
 <th> Answering Queries</th>
 <th> OverAll Impact</th><br>
<!-- <th> Average of Feedback Content</th>
	<th> Average of  Faculty Feedback</th>-->	 
 </tr>
	
<?php
 while ($row=mysql_fetch_array($query))
 {
 echo "<tr> <td>$row[0]</td> <td>$row[1]</td>";
 echo "<td>$row[2]</td> <td>$row[3]</td>";
 echo "<td>$row[4]</td> <td>$row[5]</td>";
 echo "<td>$row[6]</td> <td>$row[7]</td>";
 echo "<td>$row[8]</td> <td>$row[9]</td> ";
 echo "<td>$row[10]</td></tr>";
	$num1=round((($row[3]+$row[4]+$row[5])/3),2);
	$num2=round((($row[6]+$row[7]+$row[8]+$row[9]+$row[10])/5),2);
	$num3=round((($num1+$num2)/2),2);
	 echo "Average-Feedback on Content: $num1<br>";
	 echo "Average-Feedback on Faculty: $num2<br>";
	 echo "Final Average Value: $num3";	 
 }
 } else
echo "<p><b> No matches found... </b></p>";

 mysql_free_result($row);
 mysql_close($dbh);
}
?>
 </table>
 </body>
</html>
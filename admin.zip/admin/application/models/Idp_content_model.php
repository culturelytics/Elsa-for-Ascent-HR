<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class idp_content_model extends CI_Model {
	 
	
	
	public function get_program($org_id)	
	{
		 $this->db->select('*');
		 $this->db->from('tbl_idp');
		 $this->db->where('idp_status','Active');
                 $this->db->where('org_id',$org_id);
		 $query =$this->db->get();
		 return $query->result();
		  
	}
        public function get_orgDetails($org_id)	
	{
		 $this->db->select('*');
		 $this->db->from('tbl_organization');
                 $this->db->where('id',$org_id);
		 $query =$this->db->get();
		 return $query->result();
	}
	public function add($data,$data1)	
	{
		$this->db->insert('tbl_idp', $data);
		$id=$this->db->insert_id();

		foreach ($data1 as $row) {
			$this->db->query('INSERT IGNORE INTO tbl_idp_programs(`idp_p_idpid`, `idp_p_prgid`) VALUES("'.$id.'","'.$row.'")');
		}

	}


	
public function get_query()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_idp');

		 $query =$this->db->get();
		 return $query->result();
		  
	}
	public function update_data($shahul, $kl,$data1)	
	{

		  $this->db->where('id', $kl);
		  $this->db->update('tbl_idp', $shahul);

		  foreach ($data1 as $row) {
			$this->db->query('INSERT IGNORE INTO tbl_idp_programs(`idp_p_idpid`, `idp_p_prgid`) VALUES("'.$kl.'","'.$row.'")');
		}
  
	}
		public function delete($id)	
		{
		  $shahul=array('idp_status'=>'Inactive');

		  $this->db->where('id', $id);
		  $this->db->update('tbl_idp', $shahul);
		  echo $this->db->last_query();;
		 // return 1;

		}
  
	
	 
}
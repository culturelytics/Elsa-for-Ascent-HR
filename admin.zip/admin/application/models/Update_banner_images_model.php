<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Update_banner_images_model extends CI_Model {
	 
	public function addimage($value)	
	{
		$this->db->insert('tbl_images',$value);
		return ($this->db->affected_rows() != 1) ? FALSE : TRUE;
	}
	public function get_image()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_images');

		 $query =$this->db->get();
		 return $query->result();
		  
	}
	public function update_image($value, $id)	
	{

		  $this->db->where('imagesid', $id);
		  $this->db->update('tbl_images', $value);
		  return TRUE;
	}
	public function deletee($kl)	
	{
		 
		  $this->db->where('imagesid', $kl);
		  $this->db->delete('tbl_images');
		  return ;
	 		 
		  
	} 
	public function save_location($get)
	{
		$row = $this->db->insert('tbl_images',$get);
		return $row;
	}



}	 

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Feedback_model extends CI_Model {
	 
	public function get_data()	
	{

		 $this->db->select('*');
		 $this->db->from('feedback');

		 $query =$this->db->get();
		 return $query->result();
	}
	
public function get_query()	
	{

	     $this->db->select('*');
		 $this->db->from('feedback');
		 /*$this->db->join('tbl_programs', 'tbl_query.module = tbl_programs.prg_id', 'left');
		 $this->db->join('tbl_idp', 'tbl_query.idp_id_from_uip = tbl_idp.id', 'left');*/
	    /* $this->db->order_by('prg_id', 'asc'); */
		 $query =$this->db->get();
		 return $query->result();  
	}
	
	 
}
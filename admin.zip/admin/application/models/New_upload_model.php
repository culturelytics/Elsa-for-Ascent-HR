<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class New_upload_model extends CI_Model {
	 
	public function addimage($get)	
	{

		$row = $this->db->insert('tbl_images',$get);
		return $row;
		  
	}
	/*public function get_image()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_images');

		 $query =$this->db->get();
		 return $query->result();
		  
	}
	public function update_image($shahul, $kl)	
	{

		  $this->db->where('id', $kl);
		  $this->db->update('tbl_images', $shahul);

		  
	}
	public function delete_image($kl)	
	{
		 
		  $this->db->where('id', $kl);
		  $this->db->delete('tbl_images');
	 		 
		  
	} */
	public function save_location($get)
	{
		$row = $this->db->insert('tbl_images',$get);
		return $row;
	}



}	 

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class competency_center_model extends CI_Model {
	 
	public function get_data()	
	{
		$this->db->select('*');
		$this->db->from('tbl_competencies');
		$this->db->where('prg_status', 'Active');
		$q=$this->db->get();
		return $q->result();
	}

	public function get_details($competency_id)	
	{
		$this->db->select('*');
		$this->db->from('tbl_competencies');
		$this->db->where('prg_id', $competency_id);
		$this->db->where('prg_status', 'Active');
		return $this->db->get()->row();
	}

	public function addprogram($data)	
	{
		$this->db->insert('tbl_competencies', $data);
	}

	public function get_user(){
		$this->db->select('email,name,id');
		$this->db->from('tbl_user');
		$q=$this->db->get()->result();
		return $q;
	}

	public function export_event($user_id='ALL'){

		$this->db->select('*');
		$this->db->from('tbl_event_history');
		$this->db->join('tbl_kc_list', 'tbl_event_history.eh_kc_list_id = tbl_kc_list.kl_id', 'left');
		$this->db->join('tbl_kc_content', 'tbl_kc_list.kl_kc_id = tbl_kc_content.kc_id', 'left');
		$this->db->join('tbl_competencies', 'tbl_kc_content.kc_prg_id = tbl_competencies.prg_id', 'left');
		$this->db->join('tbl_user', 'tbl_event_history.eh_u_id = tbl_user.id', 'left');
		$this->db->join('tbl_user_login_history', 'tbl_event_history.eh_ul_id = tbl_user_login_history.ulh_id', 'left');

		$this->db->where('eh_cori','content');
		if($user_id!='ALL'){
			$this->db->where('eh_u_id', $user_id);
		}
		$this->db->order_by('organization', 'asc');
		$res=$this->db->get()->result();

		$newline="\n";
		$newtab="\t";	
		$columnHeader = '';  
		$columnHeader = "" . $newtab.$newtab.$newtab. "Analytical Report" . $newtab. "" . "\t \n \n";  
		$columnHeader = $columnHeader. "Sl.NO" . $newtab. "Date" . $newtab. "User ID" . $newtab."First Name "."$newtab"."Last Name"."$newtab"."Email ID"."$newtab"."Phone No"."$newtab"."Organization"."$newtab"."Sex"."$newtab"."Age"."$newtab"."Linked IN"."$newtab"."Twitter"."$newtab"."Date"."$newtab"."Login Time"."$newtab"."Logout Time"."$newtab"."Page Name"."$newtab"."Links"."$newtab"."Page Link Open Time"."$newtab"."Module"."$newtab"."\t \n" ;  		
		$setData = '';
		if(is_array($res) && count($res)>0){
			$i=0;
			$old_id='';
			$old_id1='';
		foreach($res as $row){ 
			$age=$row->age=="1"?'21-36':($row->age=="2"?'37-50':'50+');
			if($old_id!=$row->eh_ul_id){
			 $i++;
			    $Startdate=date('Y-m-d H:i:s',strtotime('+330 minutes',strtotime( $row->eh_created_at)));
			    $Starttime=date(' H:i:s',strtotime('+330 minutes', strtotime( $row->ulh_start_time)));
			    $endtime=date(' H:i:s',strtotime('+330 minutes',strtotime( $row->ulh_end_time)));
			    $createdat=date('Y-m-d H:i:s',strtotime('+330 minutes', strtotime( $row->eh_created_at)));
				$date=date('Y-m-d',strtotime('+0 minutes',strtotime($row->ulh_start_time)));
				$setData = $setData. "$i" . $newtab. date('Y-m-d',strtotime($Startdate)) . $newtab. "E2E".sprintf("%06d", $row->id) . $newtab."$row->name"."$newtab"."$row->last_name"."$newtab"."$row->email"."$newtab"."$row->contact"."$newtab"."$row->organization"."$newtab"."$row->gender"."$newtab"."$age"."$newtab"."$row->linkedin"."$newtab"."$row->twitter"."$newtab"."$date"."$newtab"."$Starttime"."$newtab"."$endtime"."$newtab"."$row->kc_title"."$newtab"."$row->kl_list"."$newtab"."$createdat"."$newtab"."$row->prg_name"."\n" ;  
			}else{
				if($old_id1!=$row->kc_title){
				$createdat=date('Y-m-d H:i:s',strtotime('+330 minutes', strtotime( $row->eh_created_at)));
				$setData = $setData. "" . $newtab. "" . $newtab. "". $newtab.""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab"."$row->kc_title"."$newtab"."$row->kl_list"."$newtab"."$createdat"."$newtab"."$row->prg_name"."\n" ;  	  	
			}else{
				  $createdat=date('Y-m-d H:i:s',strtotime('+330 minutes', strtotime( $row->eh_created_at)));
				$setData = $setData. "" . $newtab. "" . $newtab. "". $newtab.""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab".""."$newtab"."$row->kl_list"."$newtab"."$createdat"."$newtab"."\n" ;  	  	
			}

			}
			$old_id=$row->eh_ul_id;
			$old_id1=$row->kc_title;
		}
		}else{
		$columnHeader = $columnHeader. "" . $newtab. "" . $newtab. "" . $newtab."No Records Found"."\t".""."\t".""."\t".""."\t"."".$newtab;
		}
		header("Content-type: application/octet-stream");  
		header("Content-Disposition: attachment; filename=Analytical Report.xls");  
		header("Pragma: no-cache");  
		header("Expires: 0");    
		echo ucwords($columnHeader) . $setData . "\n";
	}

	public function editprogram($data)	
	{
		$this->db->select('*');
		$this->db->from('tbl_competencies');
		$this->db->where('prg_status', 'Active');
		$this->db->where('prg_id', $data['pid']);
		$q=$this->db->get();

		if($q->num_rows()>0){
			return $q->result();
		}else{
			return array();
		}
	}

	public function updateprogram($data)	
	{
		$object=array(
			'prg_name'=>$data['prg_name1']
			);
		$this->db->where(array('prg_id'=>$data['prg_id1']));
		$this->db->update('tbl_competencies', $object);
		if($this->db->affected_rows()>0){
			return 1;
		}else{
			return 0;
		}
	}

	public function deleteprogram($data)	
	{
		$object=array(
			'prg_status'=>'Inactive'
			);
		$this->db->where(array('prg_id'=>$data));
		$this->db->update('tbl_competencies', $object);
		if($this->db->affected_rows()>0){
			return 1;
		}else{
			return 0;
		}
	}

	public function get_list($id)	
	{
		$this->db->select('*');
		$this->db->from('tbl_kc_content');
		$this->db->join('tbl_kc_list', 'tbl_kc_list.kl_kc_id = tbl_kc_content.kc_id', 'left');
		$this->db->where('tbl_kc_list.status','Active');
		$this->db->where('tbl_kc_content.status','Active');
		$this->db->where('kc_prg_id', $id);
		$this->db->where('kl_prg_id', $id);
		return $this->db->get()->result();
	}

	public function get_attributes($competency_id)	
	{
		$this->db->select('*');
		$this->db->from('tbl_competency_attributes');
		$this->db->where('competency_id', $competency_id);
		$this->db->where('attr_status', 'Active');
		return $this->db->get()->result();
	}

	public function get_attribute($attribute_id)	
	{
		$this->db->select('*');
		$this->db->from('tbl_competency_attributes');
		$this->db->where('id', $attribute_id);
		$this->db->where('attr_status', 'Active');
		return $this->db->get()->row();
	}

	public function add_attribute($data,$id)	
	{
		$data['competency_id'] = $id;
		$this->db->insert('tbl_competency_attributes', $data);
	}

	public function update_attribute($data)
	{
		$object = array(
			'attr_name' => $data['attr_name'],
			'attr_desc' => $data['attr_desc']
		);
		$this->db->where(array('id' => $data['id']));
		$this->db->update('tbl_competency_attributes', $object);
		if ($this->db->affected_rows() > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	public function delete_attribute($id)
	{
		$object = array(
			'attr_status' => 'InActive'
		);
		$this->db->where(array('id' => $id));
		$this->db->update('tbl_competency_attributes', $object);
		if ($this->db->affected_rows() > 0) {
			return 1;
		} else {
			return 0;
		}
	}

	
	/* Modules -start */
	public function get_moduleslist()	
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledge_center');
		$this->db->where('prg_status', 'Active');
                $this->db->where('org_id', 0);
                
		$this->db->order_by('prg_name');
		return $this->db->get()->result();
	}
	
	public function get_modules($competency_id)	
	{
		$this->db->select('*');
		$this->db->from('tbl_competency_modules');
		$this->db->join('tbl_knowledge_center', 'tbl_knowledge_center.prg_id = tbl_competency_modules.cmdl_kc_id', 'left');
		$this->db->where('cmdl_c_id', $competency_id);
		return $this->db->get()->result();
	}

	public function get_module($id)
	{
		$this->db->select('*');
		$this->db->from('tbl_competency_modules');
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	public function add_module($data, $id)
	{
		$data['cmdl_c_id'] = $id;
		$this->db->insert('tbl_competency_modules', $data);
	}

	public function update_module($data)
	{
		$object = array(
			'cmdl_c_id' => $data['cmdl_c_id'],
			'cmdl_level' => $data['cmdl_level'],
			'cmdl_kc_id' => $data['cmdl_kc_id']
		);
		$this->db->where(array('id' => $data['id']));
		$this->db->update('tbl_competency_modules', $object);
		if ($this->db->affected_rows() > 0) {
			return 1;
		} else {
			return 0;
		}
	}
	
	public function delete_module($id)
	{
		$this->db->where(array('id' => $id));
		$this->db->delete('tbl_competency_modules');
		if ($this->db->affected_rows() > 0) {
			return 1;
		} else {
			return 0;
		}
	}
	/* Modules -end */

	
	/* AttrModules -start */
	public function get_attrmoduleslist()	
	{
		$this->db->select('*');
		$this->db->from('tbl_knowledge_center');
		$this->db->where('prg_status', 'Active');
		return $this->db->get()->result();
	}
	
	public function get_attrmodules($competency_attrid)	
	{
		$this->db->select('*');
		$this->db->from('tbl_competency_attrmodules');
		$this->db->join('tbl_knowledge_center', 'tbl_knowledge_center.prg_id = tbl_competency_attrmodules.camdl_kc_id', 'left');
		$this->db->where('camdl_ca_id', $competency_attrid);
		return $this->db->get()->result();
	}

	public function get_attrmodule($id)
	{
		$this->db->select('*');
		$this->db->from('tbl_competency_attrmodules');
		$this->db->where('id', $id);
		return $this->db->get()->row();
	}

	public function add_attrmodule($data, $id)
	{
		$data['camdl_ca_id'] = $id;
		$this->db->insert('tbl_competency_attrmodules', $data);
	}

	public function update_attrmodule($data)
	{
		$object = array(
			'camdl_ca_id' => $data['camdl_ca_id'],
			'camdl_kc_id' => $data['camdl_kc_id']
		);
		$this->db->where(array('id' => $data['id']));
		$this->db->update('tbl_competency_attrmodules', $object);
		if ($this->db->affected_rows() > 0) {
			return 1;
		} else {
			return 0;
		}
	}
	
	public function delete_attrmodule($id)
	{
		$this->db->where(array('id' => $id));
		$this->db->delete('tbl_competency_attrmodules');
		if ($this->db->affected_rows() > 0) {
			return 1;
		} else {
			return 0;
		}
	}
	/* AttrModules -end */

}	 

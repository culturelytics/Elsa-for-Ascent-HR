<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class org_model extends CI_Model
{

    public function get_data()
    {
        $this->db->select('*');
        $this->db->from('tbl_admin');
        $this->db->where(array('status' => 'Active', 'role' => 'group_admin'));
        $q = $this->db->get();
        return $q->result();
    }

    public function get_groups($org_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_groups');
        $this->db->where('organization_id', $org_id);
        $q = $this->db->get();
        return $q->result();
    }

    public function get_details($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_groups');
        $this->db->where('id', $group_id);
        //$this->db->where('deleted_at', null);
        return $this->db->get()->row();
    }

    public function adddetail($post)
    {
		if(isset($post['admins'])) {
			foreach ($post['admins'] as $row5_1) {
				$this->db->select('*');
				$this->db->from('tbl_admin');
				//$this->db->where(array('is_org_admin' => 1, 'user_id' => $row5_1));
				$this->db->where(array('user_id' => $row5_1, 'organization_id' => $post['org_id']));
				$admusers = $this->db->get()->row();
				
				if ($this->db->affected_rows() > 0) {
					$data5_1 = array('is_org_admin' => 1, 'role' => 'org_admin', 'status' => 'active');
					$this->db->where('id', $admusers->id);
					$this->db->update('tbl_admin', $data5_1);
				} else {
					$this->db->select('*');
					$this->db->from('tbl_user');
					$this->db->where('id', $row5_1);
					$userdata = $this->db->get()->row();

					$data5_admin = array('username' => $userdata->name, 'email' => $userdata->email, 'password' => $userdata->password,
						'is_org_admin' => 1, 'organization_id' => $post['org_id'], 'user_id' => $userdata->id,
						'role' => 'org_admin', 'status' => 'active'
					);
					$this->db->insert('tbl_admin', $data5_admin);
				}
            }
           

			$this->db->where(array('is_org_admin' => 1, 'organization_id' => $post['org_id']));
			$this->db->where_not_in('user_id', $post['admins']);
            $data5_d = array('is_org_admin' => 0);
           
            $this->db->update('tbl_admin', $data5_d);

            $this->db->where(array('is_org_admin' => 0, 'organization_id' => $post['org_id']));
            $this->db->where_not_in('user_id', $post['admins']);
            $this->db->where_not_in('group_ids', null);
            $data6_d = array('role' => 'group_admin');
           
            $this->db->update('tbl_admin', $data6_d);
          
		} else {
           
			$this->db->where(array('is_org_admin' => 1, 'organization_id' => $post['org_id']));
            $data5_d = array('is_org_admin' => 0);
           
            $this->db->update('tbl_admin', $data5_d);
            
            $this->db->where(array('is_org_admin' => 0, 'organization_id' => $post['org_id']));
            $this->db->where_not_in('group_ids', null);
            $data7_d = array('role' => 'group_admin');
           
            $this->db->update('tbl_admin', $data7_d);

		}

        return 1;

	}
	
    public function get_organizations(){
        $sql = "SELECT o.id AS id, o.org_name, ind.ind_name,GROUP_CONCAT(ta.username ORDER BY ta.username) admin_users, GROUP_CONCAT(ta.user_id) admin_userids FROM `tbl_organization` AS o LEFT JOIN `tbl_admin` AS ta ON ta.organization_id = o.id AND is_org_admin = 1 LEFT JOIN `tbl_industry` AS ind ON ind.id = o.industry_id GROUP BY o.id, o.org_name;";
	return $this->db->query($sql)->result();
    }

	public function get_users()
    {
        $this->db->select('*');
        $this->db->from('tbl_user');
        $this->db->where(['status' => 'Active']);
        $q = $this->db->get();
        return $q->result();
	}
        
        public function get_industry(){
            $this->db->select('*');
            $this->db->from('tbl_industry');
            $q = $this->db->get();
            return $q->result();
        }

	public function get_org_users($org_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_user');
        $this->db->where(['organization_id' => $org_id, 'status' => 'Active']);
        $q = $this->db->get();
        return $q->result();
	}
    public function update_org($data){
       
        $orgdata = array('org_name' => $data['orgname']);
        $this->db->where('id', $data['sel_org_id']);
        $this->db->update('tbl_organization', $orgdata);
    }
    public function add_org_inds($orgdata){
        if($orgdata['Industry_name'] !== '' && !ctype_space($orgdata['Industry_name'])){
            $indsdata = array('ind_name' => $orgdata['Industry_name']); 
            $return = $this->db->insert('tbl_industry', $indsdata);
             
            $this->db->select('*');
            $this->db->from('tbl_industry');
            $this->db->where('ind_name', $orgdata['Industry_name']);
        
            $createdIndustry = $this->db->get()->row();
            $orgdata2 = array('org_name' => $orgdata['org_name'],'industry_id'=>$createdIndustry->id); 
            $orgInsert = $this->db->insert('tbl_organization', $orgdata2);
        }else{
           if($orgdata['industryid'] !== '' && !ctype_space($orgdata['industryid'])){
               $orgdata1 = array('org_name' => $orgdata['org_name'],'industry_id'=>$orgdata['industryid']); 
               $orgInsert = $this->db->insert('tbl_organization', $orgdata1);
           }
        }
    }
}

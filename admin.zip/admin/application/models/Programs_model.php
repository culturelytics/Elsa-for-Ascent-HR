<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class programs_model extends CI_Model {
	 
	public function get_data($id)	
	{
		$this->db->select('*');
		$this->db->from('tbl_programs');
		$this->db->where('prg_status', 'Active');
                $this->db->where('org_id', $id);
		$q=$this->db->get();
		return $q->result();
	}

	public function addprogram($data)	
	{
		$this->db->insert('tbl_programs', $data);
	}
        public function get_orgDetails($org_id)	
	{
		 $this->db->select('*');
		 $this->db->from('tbl_organization');
                 $this->db->where('id',$org_id);
		 $query =$this->db->get();
		 return $query->result();
	}
	public function editprogram($data)	
	{
		$this->db->select('*');
		$this->db->from('tbl_programs');
		$this->db->where('prg_status', 'Active');
		$this->db->where('prg_id', $data['pid']);
		$q=$this->db->get();

		if($q->num_rows()>0){
			return $q->result();
		}else{
			return array();
		}
	}

	public function updateprogram($data)	
	{
		$object=array(
			'prg_name'=>$data['prg_name1']
			);
		$this->db->where(array('prg_id'=>$data['prg_id1']));
		$this->db->update('tbl_programs', $object);
		if($this->db->affected_rows()>0){
			return 1;
		}else{
			return 0;
		}
	}
	public function deleteprogram($data)	
	{
		$object=array(
			'prg_status'=>'Inactive'
			);
		$this->db->where(array('prg_id'=>$data));
		$this->db->update('tbl_programs', $object);
		if($this->db->affected_rows()>0){
			return 1;
		}else{
			return 0;
		}
	}

}	 

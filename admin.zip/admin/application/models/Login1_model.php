<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/* Author: Jorge Torres
 * Description: Login model class
 */
class Login1_model extends CI_Model{
    function __construct(){
        parent::__construct();
    }

    public function validate($logininfo){
        // grab user input
       

        $this->db->select('*');
        $this->db->from('tbl_admin');
        $this->db->where('email', $logininfo['email']);
        $this->db->where('password', $logininfo['password']);
        $query = $this->db->get();

        
        if($query->num_rows() == 1)
        {
            
            /* $row = $query->row();
            
            $data = array(
                    'email' => $row->email,
                    'password' => $row->password,
                    'validated' => true,
                    'user_name' => trim($row->username . ' ' . $row->last_name)
                    );
            $this->session->set_userdata($data);*/
           
            //If there is a user, then create session data
            $row = $query->row(); $return = true;
            $data = array(
                    'email' => $row->email,
                    'password' => $row->password,
                    'validated' => true,
                    'user_name' => trim($row->username . ' ' . $row->last_name),
                    'is_org_admin' => $row->is_org_admin,
                    'role' => $row->role,
                    'org_id' => $row->organization_id,
                    'user_id' => $row->user_id,
                    'group_ids' => $row->group_ids,
                    'status' => $row->status
                    );
            if($row->role === 'super_admin') {
                $data['role'] = 'super_admin';
            }
            else {
                if($row->organization_id !== null && $row->organization_id > 0) {

                    $this->db->select('*');
                    $this->db->from('tbl_organization');
                    $this->db->where('id', $row->organization_id);
                    $oquery = $this->db->get();
                    if($oquery->num_rows() == 1) {
                        $orow = $oquery->row();
                        $data['org_name'] = $orow->org_name;
                        
                        if($row->is_org_admin === 1 || $row->is_org_admin === '1') {
                            $data['role'] = 'org_admin';
                        }
                        else if($row->role === 'group_admin') {
                            $data['role'] = 'group_admin';
                        }
                        else {
                            $return = false;
                        }
                    }
                    else {
                        $return = false;
                    }
                    
                }
                else {
                    $return = false;
                }
            }

            if($return) {
                $this->session->set_userdata($data);
            }

            return $return;
        }
        else {
            return false;
          // redirect(base_url().'login', refresh); 
        }
        // If the previous process did not validate
        // then return false.
       
    }
}
?>
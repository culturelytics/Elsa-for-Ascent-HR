<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Addmodulecontent_model extends CI_Model {
	 
	public function getusermodule($user_id) {
		$this->db->select('title, ui_idp_id,ui_module_ids, tbl_idp.org_id');
		$this->db->from('tbl_user_idp_programs');
		$this->db->join('tbl_idp', 'tbl_idp.id = tbl_user_idp_programs.ui_idp_id');

		$this->db->where('ui_user_id', $user_id);
		return $this->db->get()->result_array();
	}

	
	public function getusermodulenames($prog_ids) {
		if(count($prog_ids) > 0) {
			$this->db->select('prg_id, prg_name');
			$this->db->from('tbl_programs');
			$this->db->where_in('prg_id', $prog_ids);
			return $this->db->get()->result_array();
		}
		else {
			return array();
		}
	}
	
	public function idpname($data1) {
		$this->db->select('title, id');
		$this->db->from('tbl_idp');
		$this->db->where('id', $data1);
		
		//print_r($this->db->get()->result_array());
		return $this->db->get()->result_array();
	}
	
	// public function adddetail($post)
	// {
		// $get=array(
		 	// 'email' => $post['email'],
		  	// 'name' => $post['name'],
		  	// 'password' =>  $post['password'],
		 	// 'contact' => $post['phone'],
		 	// 'status' => $post['status'],
		 	// 'kaccess' => $post['access1'],
		 	// 'caccess' => $post['access2'],
		 	// 'last_name' => $post['last_name'],
		 	// 'linkedin' => $post['linkedin'],
		 	// 'twitter' => $post['twitter'],
		 	// 'age' => $post['age'],
		 	// 'gender' => $post['gender'],
		 	// 'organization' => $post['organization'],
		// );
		// $this->db->insert('tbl_user',$get);
		// $row_id=$this->db->insert_id();



		// foreach ($post['idp'] as $row) {
			// $data=array('ui_user_id'=>$row_id,'ui_idp_id'=>$row,'ui_module_ids'=>serialize($post['selected_'.$row]));
			// $this->db->insert('tbl_user_idp_programs',$data);
		// }

		// if($post['status']=='active'){
		// $to = $post['email'];
		// $subject = "Account Acctivation";
		// $message = "
		// <html>
		// <body>
		// <p><b>Dear ".$post['name'].",</b></p>
		// <p>Your account has been activated successfully.</p>
		
		// <p>Login Details are:</p>
		// <p><b>User Name : </b>" .$post['email']." </p>
		// <p><b>Password : </b>" .$post['password']."</p>
		
		// </html>
		// ";
		// $headers = "MIME-Version: 1.0" . "\r\n";
		// $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		// $headers .= 'From: <info@e2epeoplepractices.com>' . "\r\n";
		// mail($to, $subject,$message,$headers);
		// }
		// return 1;

	// }

	// public function get_edit_idp_id($id){
		// $this->db->select('*');
		// $this->db->from('tbl_user_idp_programs');
		// $this->db->where('ui_user_id', $id);
		// return $this->db->get()->result();
	// }

	
	// public function get_data()	
	// {
		 // $this->db->select('*');
		 // $this->db->from('tbl_user');
		 // $query =$this->db->get();
		 // return $query->result();  
	// }


	// public function get_all_idp(){
		 // $this->db->select('*');
		 // $this->db->from('tbl_idp');
		 // $this->db->where('idp_status','Active');
		 // $query =$this->db->get();
		 // return $query->result();
	// }


	// public function get_all_programs(){
		// $this->db->select('prg_id as id,prg_name as text');
		// $this->db->from('tbl_programs');
		// $this->db->where('prg_status', 'Active');
		// $q=$this->db->get();
		// return $q->result();
	// }
	// public function get_all_idp_programs($id){
		// $this->db->select('idp_p_prgid as id');
		// $this->db->from('tbl_idp_programs');
		// $this->db->where('idp_p_idpid',$id);
		// $q=$this->db->get();
		// return $q->result();	
	// }	

	// public function get_program()	
	// {
		 // $this->db->select('*');
		 // $this->db->from('tbl_program');
		 // $query =$this->db->get();
		 // return $query->result();  
	// }
	// public function update_data($post, $id)	
	// {	

// $this->db->select('email,status');
// $this->db->from('tbl_user');
// $q=$this->db->where('id', $id)->get()->row();

		// $data=array(
		  	// 'name' => $post['name'],
		  	// 'password' =>  $post['password'],
		 	// 'contact' => $post['phone'],
		 	// 'status' => $post['status'],
		 	// 'kaccess' => $post['kaccess'],
		 	// 'caccess' => $post['caccess'],

		 	// 'last_name' => $post['last_name'],
		 	// 'linkedin' => $post['linkedin'],
		 	// 'twitter' => $post['twitter'],
		 	// 'age' => $post['age'],
		 	// 'gender' => $post['gender'],
		 	// 'organization' => $post['organization'],

		// );

		// $this->db->where('id', $id);
		// $this->db->update('tbl_user', $data); 


		// if($q->status=='inactive' &&  $post['status']=='active'){
		// //$email=
		// $to = $q->email;
		// $subject = "Account Acctivation";
		// $message = "
		// <html>
		// <body>
		// <p><b>Dear ".$post['name'].",</b></p>
		// <p>Your account has been activated successfully.</p>
		
		// <p>Login Details are:</p>
		// <p> <b>User Name : </b>" .$q->email." </p>
		// <p><b>Password : </b>" .$post['password']." </p>
		
		// </html>
		// ";
		// $headers = "MIME-Version: 1.0" . "\r\n";
		// $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		// $headers .= 'From: <info@e2epeoplepractices.com>' . "\r\n";
		// mail($to, $subject,$message,$headers);

// /*		$this->load->library('email');



		// $this->email->from('info@e2epeoplepractices.com', 'E2E');
		// $this->email->to($to);
		// $this->email->subject($subject);
		// $this->email->message($message);
		// $config['mail_type']='html';
		// $this->email->initialize($config);
		// $this->email->send();*/

		// }


		// $this->db->where('ui_user_id', $id);
		// $this->db->delete('tbl_user_idp_programs');
		// if($data['caccess']=='yes'){
		// foreach ($post['idp'] as $row) {
			// $data=array('ui_user_id'=>$id,'ui_idp_id'=>$row,'ui_module_ids'=>serialize($post['selected_'.$row]));
			// $this->db->insert('tbl_user_idp_programs',$data);
			// }
		// }
	// }
	// public function deletee($kl)	
	// {
		  // $this->db->where('id', $kl);
		  // $this->db->delete('tbl_user');
	// }

	 
}
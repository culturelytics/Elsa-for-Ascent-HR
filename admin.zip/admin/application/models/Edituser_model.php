<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Edituser_model extends CI_Model {
	 
	public function adddetail($get)	
	{

		$row = $this->db->insert('tbl_user',$get);
		return $row;
		  
	}
	public function get_data($sha)	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_user');
                 $this->db->where('id', $sha);
		 
		 $query =$this->db->get();
		 return $query->row();
		  
	}
	public function get_1data($sha)	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_user');
		 $this->db->where('id', $sha);

		 $query =$this->db->get();
		 return $query->row();
		  
	}

	public function get_program()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_program');

		 $query =$this->db->get();
		 return $query->result();
		  
	}
	public function update_data($shahul, $kl)	
	{

		  $this->db->where('id', $kl);
		  $this->db->update('tbl_user', $shahul);

		  
	}
	

	 
}
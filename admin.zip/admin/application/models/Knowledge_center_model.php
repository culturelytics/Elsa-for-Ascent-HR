<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class knowledge_center_model extends CI_Model {

    public function get_data($orgid) {
        $this->db->select('*');
        $this->db->from('tbl_knowledge_center');
        $this->db->where('prg_status', 'Active');
        $this->db->where('org_id', $orgid);
        $q = $this->db->get();
        return $q->result();
    }
    
    public function get_org_data() {
        return $this->db->query("SELECT id, org_name FROM tbl_organization;")->result_array();

    }

    public function addprogram($data) {
        $this->db->insert('tbl_knowledge_center', $data);
    }

    public function get_user() {
        $this->db->select('email,name,id');
        $this->db->from('tbl_user');
        $q = $this->db->get()->result();
        return $q;
    }

    public function export_event($user_id = 'ALL') {

        $this->db->select('*');
        $this->db->from('tbl_event_history');
        $this->db->join('tbl_kc_list', 'tbl_event_history.eh_kc_list_id = tbl_kc_list.kl_id', 'left');
        $this->db->join('tbl_kc_content', 'tbl_kc_list.kl_kc_id = tbl_kc_content.kc_id', 'left');
        $this->db->join('tbl_knowledge_center', 'tbl_kc_content.kc_prg_id = tbl_knowledge_center.prg_id', 'left');
        $this->db->join('tbl_user', 'tbl_event_history.eh_u_id = tbl_user.id', 'left');
        $this->db->join('tbl_user_login_history', 'tbl_event_history.eh_ul_id = tbl_user_login_history.ulh_id', 'left');

        $this->db->where('eh_cori', 'content');
        if ($user_id != 'ALL') {
            $this->db->where('eh_u_id', $user_id);
        }
        $this->db->order_by('organization', 'asc');
        $res = $this->db->get()->result();

        $newline = "\n";
        $newtab = "\t";
        $columnHeader = '';
        $columnHeader = "" . $newtab . $newtab . $newtab . "Analytical Report" . $newtab . "" . "\t \n \n";
        $columnHeader = $columnHeader . "Sl.NO" . $newtab . "Date" . $newtab . "User ID" . $newtab . "First Name " . "$newtab" . "Last Name" . "$newtab" . "Email ID" . "$newtab" . "Phone No" . "$newtab" . "Organization" . "$newtab" . "Sex" . "$newtab" . "Age" . "$newtab" . "Linked IN" . "$newtab" . "Twitter" . "$newtab" . "Date" . "$newtab" . "Login Time" . "$newtab" . "Logout Time" . "$newtab" . "Page Name" . "$newtab" . "Links" . "$newtab" . "Page Link Open Time" . "$newtab" . "Module" . "$newtab" . "\t \n";
        $setData = '';
        if (is_array($res) && count($res) > 0) {
            $i = 0;
            $old_id = '';
            $old_id1 = '';
            foreach ($res as $row) {
                $age = $row->age == "1" ? '21-36' : ($row->age == "2" ? '37-50' : '50+');
                if ($old_id != $row->eh_ul_id) {
                    $i++;
                    $Startdate = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                    $Starttime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_start_time)));
                    $endtime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_end_time)));
                    $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                    $date = date('Y-m-d', strtotime('+0 minutes', strtotime($row->ulh_start_time)));
                    $setData = $setData . "$i" . $newtab . date('Y-m-d', strtotime($Startdate)) . $newtab . "E2E" . sprintf("%06d", $row->id) . $newtab . "$row->name" . "$newtab" . "$row->last_name" . "$newtab" . "$row->email" . "$newtab" . "$row->contact" . "$newtab" . "$row->organization" . "$newtab" . "$row->gender" . "$newtab" . "$age" . "$newtab" . "$row->linkedin" . "$newtab" . "$row->twitter" . "$newtab" . "$date" . "$newtab" . "$Starttime" . "$newtab" . "$endtime" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";
                } else {
                    if ($old_id1 != $row->kc_title) {
                        $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                        $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";
                    } else {
                        $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                        $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "\n";
                    }
                }
                $old_id = $row->eh_ul_id;
                $old_id1 = $row->kc_title;
            }
        } else {
            $columnHeader = $columnHeader . "" . $newtab . "" . $newtab . "" . $newtab . "No Records Found" . "\t" . "" . "\t" . "" . "\t" . "" . "\t" . "" . $newtab;
        }
        header("Content-type: application/octet-stream");
        header("Content-Disposition: attachment; filename=Analytical Report.xls");
        header("Pragma: no-cache");
        header("Expires: 0");
        echo ucwords($columnHeader) . $setData . "\n";
    }

    public function editprogram($data) {
        $this->db->select('*');
        $this->db->from('tbl_knowledge_center');
        $this->db->where('prg_status', 'Active');
        $this->db->where('prg_id', $data['pid']);
        $q = $this->db->get();

        if ($q->num_rows() > 0) {
            return $q->result();
        } else {
            return array();
        }
    }

    public function editcontent($data) {
        $this->db->select('*');
        $this->db->from('tbl_kc_content');

        $this->db->where('kc_id', $data['kcid']);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            return $q->result();
        } else {
            return array();
        }
    }    

    public function deleteContent($prg_id, $content_id) {
        // Inactive Topic
        $topic_object = array('status' => 'Inactive');
        $this->db->where(array('kc_id' => $content_id));
        $this->db->update('tbl_kc_content', $topic_object);

        // Inactive Content
        $content_object = array('status' => 'Inactive');
        $this->db->where(array('kl_kc_id' => $content_id));
        $this->db->update('tbl_kc_list', $content_object);
        
        // Inactive Assessment
        $assessment_object = array('status' => '3', 'lastmodifiedon' => time());
        $this->db->where(array('contentid' => $content_id));
        $this->db->update('tbl_assessment', $assessment_object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function updateprogram($data) {
        $object = array(
            'prg_name' => $data['prg_name1']
        );
        if ($data['prg_desc1'] !== 'undefined' || $data['prg_desc1'] !== null) {
            $object['prg_desc'] = $data['prg_desc1'];
        }


        $this->db->where(array('prg_id' => $data['prg_id1']));
        $this->db->update('tbl_knowledge_center', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function deleteprogram($data) {
        $object = array(
            'prg_status' => 'Inactive'
        );
        $this->db->where(array('prg_id' => $data));
        $this->db->update('tbl_knowledge_center', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function deleteSubContent($contentid, $subcontentid) {
        $object = array('status' => 'Inactive');
        $this->db->where(array('kl_id' => $subcontentid));
        $this->db->update('tbl_kc_list', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function deleteAssessment($contentid, $subcontentid) {
        $this->deleteSubContent($contentid, $subcontentid);

        $object = array('status' => '3', 'lastmodifiedon' => time());
        $this->db->where(array('subcontentid' => $subcontentid));
        $this->db->update('tbl_assessment', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function expire_assessment() {
        $lastmodifiedon = time();
        return $this->db->query("UPDATE tbl_assessment SET STATUS = '2', lastmodifiedon = '".$lastmodifiedon."' WHERE valid_till < UNIX_TIMESTAMP(NOW()) AND STATUS IN ('0', '1');");
    }

    public function publishAssessment($moduleid, $subcontentid) {
        $object = array('status' => '1', 'lastmodifiedon' => time());
        $this->db->where(array('subcontentid' => $subcontentid));
        $this->db->update('tbl_assessment', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function get_list($id) {
         return $this->db->query("SELECT *,tbl_kc_content.status AS cstatus FROM tbl_kc_content LEFT JOIN `tbl_kc_list` ON `tbl_kc_list`.`kl_kc_id` = `tbl_kc_content`.`kc_id` WHERE tbl_kc_content.status =  'Active' AND kc_prg_id =  ".$id." ORDER BY kc_id ASC;")->result_array();

    }
    
    public function get_assessment_list($id) {
        $assessment_list = array();

        $result_set = $this->db->query("SELECT * FROM tbl_assessment WHERE status != 3 AND moduleid =  ".$id." ORDER BY subcontentid ASC;")->result_array();
        
        if(!empty($result_set)) {
            foreach($result_set as $each_result) {
                $assessment_list[$each_result['subcontentid']]['contentid'] = $each_result['contentid'];
                $assessment_list[$each_result['subcontentid']]['subcontentid'] = $each_result['subcontentid'];
                $assessment_list[$each_result['subcontentid']]['assessment_title'] = $each_result['assessment_title'];
                $assessment_list[$each_result['subcontentid']]['assessment_detail'] = $each_result['assessment_detail'];
                $assessment_list[$each_result['subcontentid']]['status'] = $each_result['status'];
            }
        }

        return $assessment_list;
    }
    
    public function cloneAssessment($moduleid, $subcontentid) {
        $result_set = $this->db->query("SELECT * FROM tbl_assessment WHERE status = 2 AND subcontentid =  ".$subcontentid." ORDER BY subcontentid ASC;")->result();
        
        $datacontent['contentid'] = $result_set[0]->contentid;
        $datacontent['kc_content']['64'][] = $result_set[0]->assessment_title;
        $datacontent['kc_content']['64'][] = 'Elsa Assessment';
        $datacontent['kc_content']['64'][] = '';
        $datacontent['kc_content']['64'][] = '';
        $datacontent['subcontentid'] = $this->add_kc_content($datacontent, $moduleid, 'id');
        if ($datacontent['subcontentid']) {
            $object = array('moduleid' => $moduleid, 'contentid' => $result_set[0]->contentid, 'subcontentid' => $datacontent['subcontentid'], 'assessment_title' => $result_set[0]->assessment_title, 'assessment_detail' => $result_set[0]->assessment_detail, 'valid_till' => strtotime("+6 months"), 'status' => 0, 'createdby' => '', 'createdon' => time());
            $this->db->insert('tbl_assessment', $object);
        }
    }

    public function add_topic($data, $id) {

        if ($data['topicId'] == '') {
            foreach ($data['kc_content'] as $row) {
                $object = array('kc_prg_id' => $id, 'kc_title' => $row[0]);
                $this->db->insert('tbl_kc_content', $object);
            }
        } else {
            foreach ($data['kc_content'] as $row) {
                $object = array('kc_title' => $row[0]);
                $this->db->where('kc_id', $data['topicId']);
                $this->db->update('tbl_kc_content', $object);
            }
        }
    }

    public function add_kc_content($data, $id, $returntype = '') {
        if ($data['subcontentid'] == '') {
            foreach ($data['kc_content'] as $row) {
                $object = array('kl_kc_id' => $data['contentid'], 'kl_list' => $row[0], 'kl_prg_id' => $id, 'kl_cat' => $row[1], 'kl_link' => $row[2], 'kl_credits' => $row[3], 'kl_file_url' => $data['file_url']);
                $return = $this->db->insert('tbl_kc_list', $object);
                if($returntype == 'id') {
                    $return =  $this->db->insert_id();
                }
            }
        } else {
            foreach ($data['kc_content'] as $row) {
                $object = array('kl_kc_id' => $data['contentid'], 'kl_list' => $row[0], 'kl_prg_id' => $id, 'kl_cat' => $row[1], 'kl_link' => $row[2], 'kl_credits' => $row[3], 'kl_file_url' => $data['file_url']);
                $this->db->where('kl_id', $data['subcontentid']);
                $return = $this->db->update('tbl_kc_list', $object);
            }
        }
        return $return;
    }

    public function add_assessment($data, $id) {
        $assessment_detail = array();
        if(count($data['qtitle']) > 0) {
            for($i=0; $i<count($data['qtitle']); $i++) {
                $assessment_detail[$i+1]['qtitle'] = str_replace("'","",$data['qtitle'][$i]);
                $assessment_detail[$i+1]['options'][1]['opttext'] = str_replace("'","",$data['qopt1'][$i]);
                $assessment_detail[$i+1]['options'][1]['is_correct'] = ($data['correct_answer'][$i] == 1) ? 0 : 1;
                $assessment_detail[$i+1]['options'][2]['opttext'] = str_replace("'","",$data['qopt2'][$i]);
                $assessment_detail[$i+1]['options'][2]['is_correct'] = ($data['correct_answer'][$i] == 2) ? 0 : 1;
                $assessment_detail[$i+1]['options'][3]['opttext'] = str_replace("'","",$data['qopt3'][$i]);
                $assessment_detail[$i+1]['options'][3]['is_correct'] = ($data['correct_answer'][$i] == 3) ? 0 : 1;
                $assessment_detail[$i+1]['options'][4]['opttext'] = str_replace("'","",$data['qopt4'][$i]);
                $assessment_detail[$i+1]['options'][4]['is_correct'] = ($data['correct_answer'][$i] == 4) ? 0 : 1;
            }
            if ($data['edit_action']) {
                $object = array('assessment_title' => $data['assessment_title'], 'assessment_detail' => json_encode($assessment_detail), 'lastmodifiedby' => '', 'lastmodifiedon' => time());
                $this->db->where('subcontentid', $data['subcontentid']);
                $this->db->update('tbl_assessment', $object);
            } else {
                $object = array('moduleid' => $id, 'contentid' => $data['contentid'], 'subcontentid' => $data['subcontentid'], 'assessment_title' => $data['assessment_title'], 'assessment_detail' => json_encode($assessment_detail), 'valid_till' => strtotime("+6 months"), 'status' => 0, 'createdby' => '', 'createdon' => time());
                $this->db->insert('tbl_assessment', $object);
            }
        }
    }

    public function add_kc_image_content($data, $id) {
        if ($data['subcontentid'] == '') {
            foreach ($data['kc_content'] as $row) {
                $object = array('kl_kc_id' => $data['contentid'], 'kl_list' => $row[0], 'kl_prg_id' => $id, 'kl_cat' => $row[1], 'kl_link' => $row[2], 'kl_credits' => $row[3]);
                $this->db->insert('tbl_kc_list', $object);
            }
        } else {
            foreach ($data['kc_content'] as $row) {
                $object = array('kl_kc_id' => $data['contentid'], 'kl_list' => $row[0], 'kl_prg_id' => $id, 'kl_cat' => $row[1], 'kl_link' => $row[2], 'kl_credits' => $row[3]);
                $this->db->where('kl_id', $data['subcontentid']);
                $this->db->update('tbl_kc_list', $object);
            }
        }
    }

    public function add_content($data, $id) {

        $object = array('prg_title' => $data['kc_title_old'], 'prg_desc' => $data['kc_content_old']);
        $this->db->where('prg_id', $id);
        $this->db->update('tbl_knowledge_center', $object);

        $object1 = array('status' => 'Inactive');
        $this->db->where('kc_prg_id', $id);
        $this->db->update('tbl_kc_content', $object1);

        $object2 = array('status' => 'Inactive');
        $this->db->where('kl_prg_id', $id);
        $this->db->update('tbl_kc_list', $object2);

        $i = 0;
        foreach ($data['kc_title'] as $row) {
            if ($i == 0) {
                $object = array('kc_prg_id' => $id, 'kc_title' => $row);
                $this->db->insert('tbl_kc_content', $object);
                $id1 = $this->db->insert_id();
                $a = current($data['kc_content']);
                $b = current($data['kc_link']);
                foreach ($a as $key => $row1) {
                    $object = array('kl_kc_id' => $id1, 'kl_list' => $row1, 'kl_prg_id' => $id, 'kl_link' => $b[$key]);
                    $this->db->insert('tbl_kc_list', $object);
                }
            } else {
                $object = array('kc_prg_id' => $id, 'kc_title' => $row);
                $this->db->insert('tbl_kc_content', $object);
                $id1 = $this->db->insert_id();
                $a = next($data['kc_content']);
                $b = next($data['kc_link']);
                foreach ($a as $key => $row1) {
                    $object = array('kl_kc_id' => $id1, 'kl_list' => $row1, 'kl_prg_id' => $id, 'kl_link' => $b[$key]);
                    $this->db->insert('tbl_kc_list', $object);
                }
            }
            $i++;
        }
    }

    public function add_image_content($data) {
        $editdata = array(
            'img_title' => $data['img_title'],
            'img_link' => $data['img_link'],
            'img_name' => $data['img_name'],
            'img_kc_id' => $data['img_kc_id'],
        );
        
        if ($data['img_id'] === '' || $data['img_id'] === null ) {
            $this->db->insert('tbl_image_content', $editdata);
        } else {
            $this->db->where('img_id', $data['img_id']);
            $this->db->update('tbl_image_content', $editdata);
        }
    }

    public function get_image($id) {
        $this->db->select('*');
        $this->db->from('tbl_image_content');
        $this->db->where('img_kc_id', $id);
        return $this->db->get()->result();
    }

    public function edit_image($data) {
        $this->db->select('*');
        $this->db->from('tbl_image_content');
        $this->db->where('img_id', $data['imgid']);
        $q = $this->db->get()->result();
        return $q;
    }

    public function delete_image($id) {
        $this->db->select('img_name');
        $this->db->from('tbl_image_content');
        $this->db->where('img_id', $id);
        $q = $this->db->get()->row()->img_name;

        $file = './uploads/content_images/' . $q;
        unlink($file);

        $this->db->where('img_id', $id);
        $this->db->delete('tbl_image_content');
        return 1;
    }

    public function update_image($data, $id) {
        if (isset($data['picture'])) {
            $q = $data['picture'];
            $file = './uploads/content_images/' . $q;
            unlink($file);
        }

        $this->db->where(array('img_id' => $id));
        $this->db->update('tbl_image_content', $data);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

}

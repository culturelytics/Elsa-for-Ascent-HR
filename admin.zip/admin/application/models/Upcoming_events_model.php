<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class upcoming_events_model extends CI_Model {

    public function get_data($orgid) {
        $this->db->select('*');
        $this->db->from('tbl_events');
        //$this->db->where('deleted_status', 0);
        $this->db->where('org_id', $orgid);
        $q = $this->db->get();
        return $q->result();
    }

    public function addprogram($data) {
        $this->db->insert('tbl_events', $data);
    }
    
    public function get_org_data() {
        return $this->db->query("SELECT id, org_name FROM tbl_organization;")->result_array();
    }

    public function get_user() {
        $this->db->select('email,name,id');
        $this->db->from('tbl_user');
        $q = $this->db->get()->result();
        return $q;
    }
    public function editprogram($data) {
        $this->db->select('*');
        $this->db->from('tbl_events');
        //$this->db->where('status', 'active');
        $this->db->where('id', $data['pid']);
        $q = $this->db->get();
        if ($q->num_rows() > 0) {
            return $q->result();
        } else {
            return array();
        }
    }

    public function updateprogram($data) {
        $object = array(
            'title' => $data['prg_name1']
        );
        if ($data['prg_desc1'] !== 'undefined' || $data['prg_desc1'] !== null) {
            $object['description'] = $data['prg_desc1'];
        }
		if ($data['prg_status'] !== 'undefined' || $data['prg_status'] !== null) {
			$object['status'] = $data['prg_status'];
		}

        $this->db->where(array('id' => $data['prg_id1']));
        $this->db->update('tbl_events', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function deleteprogram($data) {
//       var_dump($data);
        // $object = array(
        //     'status' => 'inactive',
        //     'deleted_status' => 1
        // );
        //$this->db->where(array('id' => $data));
        $this->db->delete('tbl_events', array('id' => $data));
        //$this->db->update('tbl_events', $object);        
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }
}

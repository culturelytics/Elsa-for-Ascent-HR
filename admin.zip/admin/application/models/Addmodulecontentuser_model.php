<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Addmodulecontentuser_model extends CI_Model {
	
	public function getmodulecontent($arraydata) {		
			
		$this->db->select('*');
		$this->db->where($arraydata);
		$query = $this->db->get('tbl_user_modulecontent');
		$count = $query->num_rows();
		if ($count > 0){
			return $query->row();
		}else {
			echo "Cannot select the values";
		}

	}
	public function getmodulename($id) {
		$this->db->select('prg_name');
		
		$this->db->where('prg_id', $id);
		$query = $this->db->get('tbl_programs');
		$count = $query->num_rows();
		if ($count > 0){
			return $query->row();
		}else {
			return;
		}
	}
	
	public function add($data){
		$this->db->select('*');
		$this->db->from('tbl_user_modulecontent');
		$this->db->where('userid', $data['userid']);
		$this->db->where('idpid', $data['idpid']);
		$this->db->where('idpmoduleid', $data['idpmoduleid']);
		$count = $this->db->get()->num_rows();
		if($count > 0) {
			$this->db->where('userid', $data['userid']);
			$this->db->where('idpid', $data['idpid']);
			$this->db->where('idpmoduleid', $data['idpmoduleid']);
			$this->db->update('tbl_user_modulecontent',$data);
			return ($this->db->affected_rows() != 1) ? false : true;
		}else {
			$this->db->insert('tbl_user_modulecontent',$data);
			return ($this->db->affected_rows() != 1) ? false : true;
		}
	}
	
	public function deletedoc($data){
		$emptydata=array('docs'=> '');
		$this->db->where($data);
		$this->db->update('tbl_user_modulecontent', $emptydata);		
		return ($this->db->affected_rows() != 1) ? false : true;
	}
	// public function getusermodule($user_id) {
		// $this->db->select('title, ui_idp_id,ui_module_ids');
		// $this->db->from('tbl_user_idp_programs');
		// $this->db->join('tbl_idp', 'tbl_idp.id = tbl_user_idp_programs.ui_idp_id');

		// $this->db->where('ui_user_id', $user_id);
		// return $this->db->get()->result_array();
	// }
	
	// public function idpname($data1) {
		// $this->db->select('title, id');
		// $this->db->from('tbl_idp');
		// $this->db->where('id', $data1);
		
		// //print_r($this->db->get()->result_array());
		// return $this->db->get()->result_array();
	// }
	


	 
}
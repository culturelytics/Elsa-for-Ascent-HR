<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Editbanner_model extends CI_Model {
	 
	public function adddetail($get)	
	{

		$row = $this->db->insert('tbl_images',$get);
		return $row;
		  
	}
	public function get_data($sha)	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_images');
	 
$this->db->where('imagesid', $sha);
		 
		 $query =$this->db->get();
		 return $query->row();
		  
	}
	
	public function get_program()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_images');

		 $query =$this->db->get();
		 return $query->result();
		  
	}
	public function update_data($shahul, $kl)	
	{

		  $this->db->where('imagesid', $kl);
		  $this->db->update('tbl_images', $shahul);

		  
	}
	

	 
}
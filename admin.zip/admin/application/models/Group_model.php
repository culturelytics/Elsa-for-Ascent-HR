<?php if (!defined('BASEPATH')) {
    exit('No direct script access allowed');
}

class group_model extends CI_Model
{

    public function get_data()
    {
        $this->db->select('*');
        $this->db->from('tbl_groups');
        $this->db->where('status', 'Active');
        $q = $this->db->get();
        return $q->result();
    }

    public function get_groups($org_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_groups');
        $this->db->where('org_id', $org_id);
        $q = $this->db->get();
        return $q->result();
    }

    public function get_details($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_groups');
        $this->db->where('id', $group_id);
        //$this->db->where('deleted_at', null);
        return $this->db->get()->row();
    }

    public function adddetail($post)
    {
        $get = array(
            'group_name' => $post['name'],
            'description' => $post['description'],
            'status' => $post['status'],
            'org_id' => $post['org_id'],
			
		);
		
		if($post['id'] == 0) {
			$get['created_at'] = date('Y-m-d H:i:s');
			$get['created_by'] = $post['user_id'];
			$get['batch_no'] = $post['batch'];
			$get['training_startdate'] = $post['startdate'];
			$get['training_enddate'] = $post['enddate'];
			$get['training_starttime'] = $post['starttime'];
			$get['training_endtime'] = $post['endtime'];
			$get['training_location'] = $post['location'];
			$get['module_type'] = $post['module'];
			$get['trainer_name'] = $_SESSION["user_name"];

			

			$this->db->insert('tbl_groups', $get);
        	$row_id = $this->db->insert_id();
		} else {
			$get['updated_at'] = date('Y-m-d H:i:s');
			$get['updated_by'] = $post['user_id'];
			$get['batch_no'] = $post['batch'];
			$get['training_startdate'] = $post['startdate'];
			$get['training_enddate'] = $post['enddate'];
			$get['training_starttime'] = $post['starttime'];
			$get['training_endtime'] = $post['endtime'];
			$get['training_location'] = $post['location'];
			$get['module_type'] = $post['module'];
			$get['trainer_name'] = $_SESSION["user_name"];
			

			$this->db->where('id', $post['id']);
			$this->db->update('tbl_groups', $get);
        	$row_id = $post['id'];
		}

		$post['admins'] = isset($post['admins']) && count($post['admins']) > 0 ? $post['admins'] : array();

		$this->db->select('*');
		$this->db->from('tbl_admin');
		//$this->db->where('role', 'group_admin');
		$this->db->where('organization_id', $post['org_id']);
		$admusers = $this->db->get()->result();
		
		foreach($admusers as $rw_adm) {
			if(!in_array($rw_adm->user_id, $post['admins'])) {
				$gpids = unserialize($rw_adm->group_ids);
				$idx = array_search($row_id, $gpids);
				
				if($idx !== false) {
					unset($gpids[$idx]);
					$data5_admin = array('group_ids' => serialize($gpids));
					$this->db->where('id', $rw_adm->id);
					$this->db->update('tbl_admin', $data5_admin);
					
					$this->db->select('*');
					$this->db->from('tbl_group_user');
					$this->db->where(array('group_id' => $row_id, 'user_id' => $rw_adm->user_id));
					$dr5_1 = $this->db->get();
					//echo $this->db->affected_rows();die;
					if ($this->db->affected_rows() > 0) {
						$this->db->where(array('group_id' => $row_id, 'user_id' => $rw_adm->user_id));
						$data5_1 = array('status' => 'active', 'is_admin' => 0, 'group_id' => $row_id, 'user_id' => $rw_adm->user_id, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $rw_adm->user_id);
						$this->db->update('tbl_group_user', $data5_1);
					}
				}
			}
		}
		/* Admins */
		if(isset($post['admins']) && count($post['admins']) > 0) {
			foreach ($post['admins'] as $row5_1) {
				//$data5 = array('group_id' => $row_id, 'user_id' => $row5, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => 1);
				//$this->db->insert('tbl_group_user', $data5);
				
				$this->db->select('*');
				$this->db->from('tbl_group_user');
				$this->db->where(array('group_id' => $row_id, 'user_id' => $row5_1));
				$dr5_1 = $this->db->get();

				if ($this->db->affected_rows() > 0) {
					$this->db->where(array('group_id' => $row_id, 'user_id' => $row5_1));
					$data5_1 = array('status' => 'active', 'is_admin' => 1, 'group_id' => $row_id, 'user_id' => $row5_1, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
					$this->db->update('tbl_group_user', $data5_1);

					$this->db->select('*');
					$this->db->from('tbl_admin');
					$this->db->where('user_id', $row5_1);
					$userdata = $this->db->get()->row();
					if ($this->db->affected_rows() > 0) {
						$gpids = !empty($userdata->group_ids) ? unserialize($userdata->group_ids) : array();
						//$gpids = unserialize($userdata->group_ids);
						if(!in_array($row_id, $gpids)) {
							//$gpids[] = $row_id;
							array_push($gpids, $row_id);
							$data5_admin = array('group_ids' => serialize($gpids));
							if($userdata->is_org_admin == 0) {
								$data5_admin = array('group_ids' => serialize($gpids), 'role' => 'group_admin');
							}
							$this->db->where('user_id', $row5_1);
							$this->db->update('tbl_admin', $data5_admin);
						}
					} else {
						$this->db->select('*');
						$this->db->from('tbl_user');
						$this->db->where('id', $row5_1);
						$userdata1 = $this->db->get()->row();

						$data5_admin = array('username' => $userdata1->name, 'email' => $userdata1->email, 'password' => $userdata1->password,
							'role' => 'group_admin', 'organization_id' => $post['org_id'], 'user_id' => $userdata1->id, 
							'group_ids' => serialize(array($row_id))
						);
						$this->db->insert('tbl_admin', $data5_admin);
					}
				} else {
					$data5_1 = array('status' => 'active', 'is_admin' => 1, 'group_id' => $row_id, 'user_id' => $row5_1, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
					$this->db->insert('tbl_group_user', $data5_1);
					
					$this->db->select('*');
					$this->db->from('tbl_admin');
					$this->db->where('user_id', $row5_1);
					$userdata = $this->db->get()->row();
					if ($this->db->affected_rows() > 0) {
						$gpids = !empty($userdata->group_ids) ? unserialize($userdata->group_ids) : array();
						if(!in_array($row_id, $gpids)) {
							array_push($gpids, $row_id);
							$data5_admin = array('group_ids' => serialize($gpids));
							if($userdata->is_org_admin == 0) {
								$data5_admin = array('group_ids' => serialize($gpids), 'role' => 'group_admin');
							}
							$this->db->where('user_id', $row5_1);
							$this->db->update('tbl_admin', $data5_admin);
						}
					} else {
						$this->db->select('*');
						$this->db->from('tbl_user');
						$this->db->where('id', $row5_1);
						$userdata = $this->db->get()->row();

						$data5_admin = array('username' => $userdata->name, 'email' => $userdata->email, 'password' => $userdata->password,
							'role' => 'group_admin', 'organization_id' => $post['org_id'], 'user_id' => $userdata->id, 
							'group_ids' => serialize(array($row_id))
						);
						$this->db->insert('tbl_admin', $data5_admin);
					}
				}
				if(in_array($row5_1, $post['users'])) {
					unset($post['users'][array_search($row5_1, $post['users'])]);
				}
			}

			$this->db->where(array('group_id' => $row_id, 'is_admin' => 1));
			$this->db->where_not_in('user_id', $post['admins']);
			$data5_d = array('status' => 'inactive', 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
			$this->db->update('tbl_group_user', $data5_d);
		}

		/* Users */
		if(isset($post['users']) && count($post['users'])>0){
			//$this->db->where(array('group_id' => $row_id));
			//$this->db->delete('tbl_group_user');

			foreach ($post['users'] as $row5) {
				//$data5 = array('group_id' => $row_id, 'user_id' => $row5, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => 1);
				//$this->db->insert('tbl_group_user', $data5);
				
				$this->db->select('*');
				$this->db->from('tbl_group_user');
				$this->db->where(array('group_id' => $row_id, 'user_id' => $row5));
				$dr1 = $this->db->get();

				if ($this->db->affected_rows() > 0) {
					$this->db->where(array('group_id' => $row_id, 'user_id' => $row5));
					$data5 = array('status' => 'active', 'is_admin' => 0, 'group_id' => $row_id, 'user_id' => $row5, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
					$this->db->update('tbl_group_user', $data5);
				} else {
					$data5 = array('status' => 'active', 'is_admin' => 0, 'group_id' => $row_id, 'user_id' => $row5, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
					$this->db->insert('tbl_group_user', $data5);
				}
			}

			$this->db->where(array('group_id' => $row_id, 'is_admin' => 0));
			$this->db->where_not_in('user_id', $post['users']);
			$data1_d = array('status' => 'inactive', 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
			$this->db->update('tbl_group_user', $data1_d);
		}

		/* Aggregator assignment - KC */
		
        //$this->db->where(array('group_id' => $row_id));
		//$this->db->delete('tbl_group_kc');
		
        foreach ($post['kca'] as $row1) {
			//$data1 = array('group_id' => $row_id, 'kc_id' => $row1, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => 1);
			//$this->db->insert('tbl_group_kc', $data1);

			$this->db->select('*');
			$this->db->from('tbl_group_kc');
			$this->db->where(array('group_id' => $row_id, 'kc_id' => $row1));
			$dr1 = $this->db->get();

			if ($this->db->affected_rows() > 0) {
				$this->db->where(array('group_id' => $row_id, 'kc_id' => $row1));
				$data1 = array('status' => 'active', 'is_client' => 0, 'group_id' => $row_id, 'kc_id' => $row1, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
            	$this->db->update('tbl_group_kc', $data1);
			} else {
				$data1 = array('status' => 'active', 'is_client' => 0, 'group_id' => $row_id, 'kc_id' => $row1, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
            	$this->db->insert('tbl_group_kc', $data1);
			}
            
			// Assignment
			foreach ($post['users'] as $row1_1) {
				$this->db->select('*');
				$this->db->from('tbl_kc_assignments');
				$this->db->where(array('kca_kc_id' => $row1, 'kca_user_id' => $row1_1));
				$dr1 = $this->db->get();

				if ($this->db->affected_rows() > 0) {
					$this->db->where(array('kca_kc_id' => $row1, 'kca_user_id' => $row1_1));
					$data1_1=array('kca_user_id'=>$row1_1,'kca_kc_id'=>$row1,'kca_created_at'=> date('Y-m-d H:i:s'),'kca_isself'=>false);
					$this->db->update('tbl_kc_assignments',$data1_1);
				} else {
					$data1_1=array('kca_user_id'=>$row1_1,'kca_kc_id'=>$row1,'kca_created_at'=> date('Y-m-d H:i:s'),'kca_isself'=>false);
					$this->db->insert('tbl_kc_assignments',$data1_1);
				}
			}
		}
		
		//$this->db->where(array('group_id' => $row_id, 'kc_id not in ' => '(' . implode(',', $post['kca']) . ')'));
		$this->db->where(array('group_id' => $row_id, 'is_client' => 0));
		$this->db->where_not_in('kc_id', $post['kca']);
		$data1 = array('status' => 'inactive', 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
		$this->db->update('tbl_group_kc', $data1);
		//var_dump($this->db->last_query());die;

        /* Client assignment - KC */
        foreach ($post['kca_c'] as $row2) {
            //$data2 = array('group_id' => $row_id, 'kc_id' => $row2, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => 1);
			//$this->db->insert('tbl_group_kc', $data2);

			$this->db->select('*');
			$this->db->from('tbl_group_kc');
			$this->db->where('group_id', $row_id);
			$this->db->where('kc_id', $row2);
			$dr2 = $this->db->get();

			if ($this->db->affected_rows() > 0) {
				$this->db->where(array('group_id' => $row_id, 'kc_id' => $row2));
				$data2 = array('status' => 'active', 'is_client' => 1, 'group_id' => $row_id, 'kc_id' => $row2, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
				$this->db->update('tbl_group_kc', $data2);
			} else {
				$data2 = array('status' => 'active', 'is_client' => 1, 'group_id' => $row_id, 'kc_id' => $row2, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
				$this->db->insert('tbl_group_kc', $data2);
			}
            
			// Assignment
			foreach ($post['users'] as $row2_1) {
				$this->db->select('*');
				$this->db->from('tbl_kc_assignments');
				$this->db->where(array('kca_kc_id' => $row2, 'kca_user_id' => $row2_1));
				$dr2_1 = $this->db->get();

				if ($this->db->affected_rows() > 0) {
					//return 1;
				} else {
					$data2_1=array('kca_user_id'=>$row2_1,'kca_kc_id'=>$row2,'kca_created_at'=> date('Y-m-d H:i:s'),'kca_isself'=>false);
					$this->db->insert('tbl_kc_assignments',$data2_1);
				}
			}
		}

		$this->db->where(array('group_id' => $row_id, 'is_client' => 1));
		$this->db->where_not_in('kc_id', $post['kca_c']);
		$data1 = array('status' => 'inactive', 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
		$this->db->update('tbl_group_kc', $data1);

		/* Aggregator assignment - IDP */
		
        $this->db->where(array('group_id' => $row_id));
		$this->db->delete('tbl_group_idp');
		
        foreach ($post['idpa'] as $row3) {
            //$data3 = array('group_id' => $row_id, 'idp_id' => $row3, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => 1);
			//$this->db->insert('tbl_group_idp', $data3);
			
			$this->db->select('*');
			$this->db->from('tbl_group_idp');
			$this->db->where(array('idp_id' => $row3, 'group_id' => $row_id));
			$dr1 = $this->db->get();

			if ($this->db->affected_rows() > 0) {
				$data3 = array('status' => 'active', 'is_client' => 0, 'group_id' => $row_id, 'idp_id' => $row3, 'module_ids'=>serialize($post['selected_'.$row3]), 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
				$this->db->where(array('idp_id' => $row3, 'group_id' => $row3_1));
				$this->db->update('tbl_group_idp', $data3);
			} else {
				$data3 = array('status' => 'active', 'is_client' => 0, 'group_id' => $row_id, 'idp_id' => $row3, 'module_ids'=>serialize($post['selected_'.$row3]), 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
				$this->db->insert('tbl_group_idp', $data3);
			}

			// Assignment
			foreach ($post['users'] as $row3_1) {
				$this->db->select('*');
				$this->db->from('tbl_user_idp_programs');
				$this->db->where(array('ui_idp_id' => $row3, 'ui_user_id' => $row3_1));
				$dr3_1 = $this->db->get();

				if ($this->db->affected_rows() > 0) {
					$data3_1=array('ui_user_id'=>$row3_1,'ui_idp_id'=>$row3, 'ui_module_ids'=>serialize($post['selected_'.$row3]));
					$this->db->where(array('ui_idp_id' => $row3, 'ui_user_id' => $row3_1));
					$this->db->update('tbl_user_idp_programs',$data3_1);
				} else {
					$data3_1=array('ui_user_id'=>$row3_1,'ui_idp_id'=>$row3, 'ui_module_ids'=>serialize($post['selected_'.$row3]),'ui_created_at'=> date('Y-m-d H:i:s'));
					$this->db->insert('tbl_user_idp_programs',$data3_1);
				}
			}
		}

		$this->db->where(array('group_id' => $row_id, 'is_client' => 0));
		$this->db->where_not_in('idp_id', $post['idpa']);
		$data1 = array('status' => 'inactive', 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
		$this->db->update('tbl_group_idp', $data1);

        /* Client assignment - IDP */
        foreach ($post['idpa_c'] as $row4) {
            //$data4 = array('group_id' => $row_id, 'idp_id' => $row4, 'created_at' => date('Y-m-d H:i:s'), 'created_by' => 1);
			//$this->db->insert('tbl_group_idp', $data4);
			
			$this->db->select('*');
			$this->db->from('tbl_group_idp');
			$this->db->where('group_id', $row_id);
			$this->db->where('idp_id', $row4);
			$dr1 = $this->db->get();
			
			if ($this->db->affected_rows() > 0) {
				$data4 = array('status' => 'active', 'is_client' => 1, 'group_id' => $row_id, 'idp_id' => $row4, 'module_ids'=>serialize($post['selected_c_'.$row4]), 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
				$this->db->where(array('idp_id' => $row4, 'group_id' => $row4_1));
				$this->db->update('tbl_group_idp', $data4);
			} else {
				$data4 = array('status' => 'active', 'is_client' => 1, 'group_id' => $row_id, 'idp_id' => $row4, 'module_ids'=>serialize($post['selected_c_'.$row4]), 'created_at' => date('Y-m-d H:i:s'), 'created_by' => $post['user_id']);
				$this->db->insert('tbl_group_idp', $data4);
			}

			// Assignment
			foreach ($post['users'] as $row4_1) {
				$this->db->select('*');
				$this->db->from('tbl_user_idp_programs');
				$this->db->where(array('ui_idp_id' => $row4, 'ui_user_id' => $row4_1));
				$dr4_1 = $this->db->get();

				if ($this->db->affected_rows() > 0) {
					$data4_1=array('ui_user_id'=>$row4_1,'ui_idp_id'=>$row4, 'ui_module_ids'=>serialize($post['selected_c_'.$row4]));
					$this->db->where(array('ui_idp_id' => $row4, 'ui_user_id' => $row4_1));
					$this->db->update('tbl_user_idp_programs',$data4_1);
				} else {
					$data4_1=array('ui_user_id'=>$row4_1,'ui_idp_id'=>$row4, 'ui_module_ids'=>serialize($post['selected_c_'.$row4]),'ui_created_at'=> date('Y-m-d H:i:s'));
					$this->db->insert('tbl_user_idp_programs',$data4_1);
				}
			}
        }
		

		$this->db->where(array('group_id' => $row_id, 'is_client' => 1));
		$this->db->where_not_in('idp_id', $post['idpa_c']);
		$data1 = array('status' => 'inactive', 'updated_at' => date('Y-m-d H:i:s'), 'updated_by' => $post['user_id']);
		$this->db->update('tbl_group_idp', $data1);
		

        return 1;

    }

    public function editprogram($data)
    {
        $this->db->select('*');
        $this->db->from('tbl_groups');
        $this->db->where('deleted_at', null);
        $this->db->where('id', $data['pid']);
        $q = $this->db->get();

        if ($q->num_rows() > 0) {
            return $q->result();
        } else {
            return array();
        }
    }

    public function updateprogram($data)
    {
        $object = array(
            'group_name' => $data['name'],
        );
        $this->db->where(array('id' => $data['id']));
        $this->db->update('tbl_groups', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function deleteprogram($data)
    {
        $object = array(
            'status' => 'inactive',
		);
		
        $this->db->where(array('id' => $data));
        $this->db->update('tbl_groups', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    /* Group User -start */
    public function get_userlist()
    {
        $this->db->select('*');
        $this->db->from('tbl_group_user');
        //$this->db->where('prg_status', 'Active');
        //$this->db->where('org_id', 0);

        //$this->db->order_by('prg_name');
        return $this->db->get()->result();
    }

    public function get_groupusers($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_user');
        $this->db->join('tbl_group', 'tbl_group.id = tbl_group_user.group_id', 'left');
        $this->db->where('group_id', $group_id);
        return $this->db->get()->result();
    }

    public function get_groupuser($id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_user');
        $this->db->where('id', $id);
        return $this->db->get()->row();
    }

    public function add_groupuser($data, $id)
    {
        $data['group_id'] = $id;
        $this->db->insert('tbl_group_user', $data);
    }

    public function update_groupuser($data)
    {
        $object = array(
            'cmdl_c_id' => $data['cmdl_c_id'],
            'cmdl_level' => $data['cmdl_level'],
            'cmdl_kc_id' => $data['cmdl_kc_id'],
        );
        $this->db->where(array('id' => $data['id']));
        $this->db->update('tbl_group_user', $object);
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public function delete_groupuser($id)
    {
        $this->db->where(array('id' => $id));
        $this->db->delete('tbl_group_user');
        if ($this->db->affected_rows() > 0) {
            return 1;
        } else {
            return 0;
        }
    }
    /* Modules -end */

    public function get_organizations()
    {
        $this->db->select('*');
        $this->db->from('tbl_organization');
        $q = $this->db->get();
        return $q->result();
	}
	
    public function get_all_users_list($org_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_user');
        $this->db->where([
			'status' => 'active', 
			'organization_id' => $org_id
			]);
        $q = $this->db->get();
        return $q->result();
	}
	
	// admins list
	
    public function get_admins_list($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_user');
        $this->db->where(['group_id' => $group_id, 'is_admin' => 1]);
        $q = $this->db->get();
        return $q->result();
	}
	
	// users list

    public function get_users_list($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_user');
        $this->db->where(['group_id' => $group_id, 'is_admin' => 0]);
        $q = $this->db->get();
        return $q->result();
	}
	
	// KC list

    public function get_all_kc_a_list()
    {
        $this->db->select('*');
        $this->db->from('tbl_knowledge_center');
        $this->db->where(['prg_status' => 'Active', 'org_id' => 0]);
        $q = $this->db->get();
        return $q->result();
    }

    public function get_all_kc_c_list($org_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_knowledge_center');
        $this->db->where(['prg_status' => 'Active', 'org_id' => $org_id]);
        $q = $this->db->get();
        return $q->result();
    }

    /*
    Aggregator Assignments - KC
     */
    public function get_all_kca_a($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_kc');
        $this->db->join('tbl_knowledge_center', 'tbl_knowledge_center.prg_id = tbl_group_kc.kc_id');
        $this->db->where(['status' => 'active', 'is_client' => 0, 'tbl_group_kc.group_id' => $group_id, 'tbl_knowledge_center.org_id' => 0]);
        $q = $this->db->get();
        return $q->result();
    }

    /*
    Client Assignments - KC
     */
    public function get_all_kca_c($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_kc');
        $this->db->join('tbl_knowledge_center', 'tbl_knowledge_center.prg_id = tbl_group_kc.kc_id');
        $this->db->where(['status' => 'active', 'is_client' => 1, 'tbl_group_kc.group_id' => $group_id, 'tbl_knowledge_center.org_id !=' => 0]);
        $q = $this->db->get();
        return $q->result();
	}
	
	

    public function get_all_idp_a_list()
    {
        $this->db->select('*');
        $this->db->from('tbl_idp');
        $this->db->where(['idp_status' => 'Active', 'org_id' => 0]);
        $q = $this->db->get();
        return $q->result();
    }

    public function get_all_idp_c_list($org_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_idp');
        $this->db->where(['idp_status' => 'Active', 'org_id' => $org_id]);
        $q = $this->db->get();
        return $q->result();
    }

    /*
    Aggregator Assignments - idp
     */
    public function get_all_idpa_a($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_idp');
        $this->db->join('tbl_idp', 'tbl_idp.id = tbl_group_idp.idp_id');
        $this->db->where(['status' => 'active', 'is_client' => 0, 'tbl_group_idp.group_id' => $group_id, 'tbl_idp.org_id' => 0]);
        $q = $this->db->get();
        return $q->result();
    }

    /*
    Client Assignments - idp
     */
    public function get_all_idpa_c($group_id)
    {
        $this->db->select('*');
        $this->db->from('tbl_group_idp');
        $this->db->join('tbl_idp', 'tbl_idp.id = tbl_group_idp.idp_id');
        $this->db->where(['status' => 'active', 'is_client' => 1, 'tbl_group_idp.group_id' => $group_id, 'tbl_idp.org_id !=' => 0]);
        $q = $this->db->get();
        return $q->result();
	}
	
	////
	
	public function get_all_programs(){
		/*$this->db->select('prg_id as id,prg_name as text');
		$this->db->from('tbl_programs');
		$this->db->where('prg_status', 'Active');
		$q=$this->db->get();
		return $q->result();*/
		$sql = "SELECT idp.id as idpid, idp.title, prg_id as id,prg_name as text, p.* FROM `tbl_programs` p JOIN `tbl_idp_programs` ip ON ip.idp_p_prgid = p.prg_id	JOIN `tbl_idp` idp ON idp.id = ip.idp_p_idpid;";
		$query = $this->db->query($sql);
		return $query->result();
	}
	public function get_all_idp_programs($id){
		$this->db->select('idp_p_prgid as id');
		$this->db->from('tbl_idp_programs');
		$this->db->where('idp_p_idpid',$id);
		$q=$this->db->get();
		return $q->result();	
	}	

	public function get_program()	
	{
		 $this->db->select('*');
		 $this->db->from('tbl_program');
		 $query =$this->db->get();
		 return $query->result();  
	}

}

<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Editclients_query_model extends CI_Model {
	 

	public function get_data($sha)	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_query');
	 
         $this->db->where('id', $sha);
		 
		 $query =$this->db->get();
		 return $query->row();
		  
	}
	

	public function get_query()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_query');
           $this->db->where('id', $sha);
		 $query =$this->db->get();
		 return $query->result();
		  
	}
	public function update_data($shahul, $kl)	
	{
		
		  $this->db->where('id', $kl);
		  $this->db->update('tbl_query', $shahul);

		  
	}
	

	 
}
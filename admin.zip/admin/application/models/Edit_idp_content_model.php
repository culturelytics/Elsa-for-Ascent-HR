<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Edit_idp_content_model extends CI_Model {
	 

	public function get_data($sha)	
	{
		 $this->db->select('*');
		 $this->db->from('tbl_idp');
         $this->db->where('id', $sha);
		 $query =$this->db->get();
		 return $query->row();
	}
	public function get_extra_data($id){
		 $this->db->select('idp_p_prgid');
		 $this->db->from('tbl_idp_programs');
         $this->db->where('idp_p_idpid', $id);
		 $query =$this->db->get();
		 return array_map('current',$query->result());	
	}

	public function get_program()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_idp');
           $this->db->where('id', $sha);
		 $query =$this->db->get();
		return $query->result();
		  
	}
	public function update_data($shahul, $kl,$data1)	
	{
		$this->db->where('id', $kl);
		$this->db->update('tbl_idp', $shahul);
		
		$this->db->where('idp_p_idpid', $kl);
		$this->db->delete('tbl_idp_programs');

		foreach ($data1 as $row) {
			$this->db->query('INSERT IGNORE INTO tbl_idp_programs(`idp_p_idpid`, `idp_p_prgid`) VALUES("'.$kl.'","'.$row.'")');
		}
		return 1;
	}
	

	 
}
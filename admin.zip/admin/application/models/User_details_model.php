<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class User_details_model extends CI_Model {
	 
	public function adddetail($post)	
	{
		$get=array(
		 	'email' => $post['email'],
		  	'name' => $post['name'],
		  	'password' =>  $post['password'],
		 	'contact' => $post['phone'],
		 	'status' => $post['status'],
		 	'kaccess' => $post['kaccess'],
		 	'kc_c_access' => $post['kc_c_access'],
		 	'caccess' => $post['access2'],
		 	'idp_c_access' => $post['idp_c_access'],
		 	'last_name' => $post['last_name'],
		 	'linkedin' => $post['linkedin'],
		 	'twitter' => $post['twitter'],
		 	'age' => $post['age'],
		 	'gender' => $post['gender'],
		 	//'organization' => $post['organization'],
		 	'organization_id' => $post['organization_id'],
		);
		$this->db->insert('tbl_user',$get);
		$row_id=$this->db->insert_id();

		/* Aggregator assignment */
		if($post['kaccess']=='yes'){
		foreach ($post['kca'] as $row1) {
			$data1=array('kca_user_id'=>$row_id,'kca_kc_id'=>$row1,'kca_created_at'=> date('Y-m-d H:i:s'),'kca_isself'=>false);
			$this->db->insert('tbl_kc_assignments',$data1);
			}
		}

		/* Client assignment */
		if($post['kc_c_access']=='yes'){
		foreach ($post['kca_c'] as $row2) {
			$data2=array('kca_user_id'=>$row_id,'kca_kc_id'=>$row2,'kca_created_at'=> date('Y-m-d H:i:s'),'kca_isself'=>false);
			$this->db->insert('tbl_kc_assignments',$data2);
			}
		}

		/* Aggregator IDP */
		foreach ($post['idp'] as $row3) {
			$data3=array('ui_user_id'=>$row_id,'ui_idp_id'=>$row3,'ui_module_ids'=>serialize($post['selected_'.$row3]));
			$this->db->insert('tbl_user_idp_programs',$data3);
		}
		
		/* Client IDP */
		foreach ($post['idp_c'] as $row4) {
			$data4=array('ui_user_id'=>$row_id,'ui_idp_id'=>$row4,'ui_module_ids'=>serialize($post['selected_c_'.$row4]));
			$this->db->insert('tbl_user_idp_programs',$data4);
		}

		if($post['status']=='active'){
		$to = $post['email'];
		$subject = "Account Acctivation";
		$message = "
		<html>
		<body>
		<p><b>Dear ".$post['name'].",</b></p>
		<p>Your account has been activated successfully.</p>
		
		<p>Login Details are:</p>
		<p><b>User Name : </b>" .$post['email']." </p>
		<p><b>Password : </b>" .$post['password']."</p>
		
		</html>
		";
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: <info@e2epeoplepractices.com>' . "\r\n";
		mail($to, $subject,$message,$headers);
		}
		return 1;

	}

	public function get_edit_idp_id($id){
		$this->db->select('*');
		$this->db->from('tbl_user_idp_programs');
		$this->db->join('tbl_idp', 'tbl_idp.id = tbl_user_idp_programs.ui_idp_id');
        $this->db->where(['tbl_user_idp_programs.ui_user_id' => $id, 'tbl_idp.org_id' => 0]);
		return $this->db->get()->result();
	}

	public function get_edit_idp_id_c($id){
		$this->db->select('*');
		$this->db->from('tbl_user_idp_programs');
		$this->db->join('tbl_idp', 'tbl_idp.id = tbl_user_idp_programs.ui_idp_id');
        $this->db->where(['tbl_user_idp_programs.ui_user_id' => $id, 'tbl_idp.org_id !=' => 0]);
		return $this->db->get()->result();
	}

	
	public function get_data($organization_id)	
	{
		 $this->db->select('*');
		 $this->db->from('tbl_user');
		 if($organization_id != 0 && !empty($organization_id)) {
			$this->db->where(['organization_id' => $organization_id]); // TODO - to be enabled after roles implementation
		 }
		 
		 $query =$this->db->get();
		 return $query->result();  
	}


	public function get_all_idp(){
		 $this->db->select('*');
		 $this->db->from('tbl_idp');
		 $this->db->where(['idp_status' => 'Active', 'org_id' => 0]);
		 $query =$this->db->get();
		 return $query->result();
	}

	public function get_all_idp_c($org_id){
		 $this->db->select('*');
		 $this->db->from('tbl_idp');
		 $this->db->where(['idp_status' => 'Active','org_id' => $org_id]);
		 $query =$this->db->get();
		 return $query->result();
	}


	public function get_all_programs(){
		$this->db->select('prg_id as id,prg_name as text');
		$this->db->from('tbl_programs');
		$this->db->where('prg_status', 'Active');
		$q=$this->db->get();
		return $q->result();
	}
	public function get_all_idp_programs($id){
		$this->db->select('idp_p_prgid as id');
		$this->db->from('tbl_idp_programs');
		$this->db->where('idp_p_idpid',$id);
		$q=$this->db->get();
		return $q->result();	
	}	

	public function get_program()	
	{
		 $this->db->select('*');
		 $this->db->from('tbl_program');
		 $query =$this->db->get();
		 return $query->result();  
	}
	public function update_data($post, $id)	
	{
            $this->db->select('email,status');
            $this->db->from('tbl_user');
            $q=$this->db->where('id', $id)->get()->row();

		$data=array(
		  	'name' => $post['name'],
		  	'password' =>  $post['password'],
		 	'contact' => $post['phone'],
		 	'status' => $post['status'],
		 	'kaccess' => $post['kaccess'],
		 	'kc_c_access' => $post['kc_c_access'],
		 	'caccess' => $post['caccess'],
			'idp_c_access' => $post['idp_c_access'],
		 	'last_name' => $post['last_name'],
		 	'linkedin' => $post['linkedin'],
		 	'twitter' => $post['twitter'],
		 	'age' => $post['age'],
		 	'gender' => $post['gender'],
		 	'organization' => $post['organization'],
		 	'organization_id' => $post['organization_id'],

		);

		$this->db->where('id', $id);
		$this->db->update('tbl_user', $data); 


		if($q->status=='inactive' &&  $post['status']=='active'){
		//$email=
		$to = $q->email;
		$subject = "Account Acctivation";
		$message = "
		<html>
		<body>
		<p><b>Dear ".$post['name'].",</b></p>
		<p>Your account has been activated successfully.</p>
		
		<p>Login Details are:</p>
		<p> <b>User Name : </b>" .$q->email." </p>
		<p><b>Password : </b>" .$post['password']." </p>
		
		</html>
		";
		$headers = "MIME-Version: 1.0" . "\r\n";
		$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
		$headers .= 'From: <info@e2epeoplepractices.com>' . "\r\n";
		mail($to, $subject,$message,$headers);

/*		$this->load->library('email');



		$this->email->from('info@e2epeoplepractices.com', 'E2E');
		$this->email->to($to);
		$this->email->subject($subject);
		$this->email->message($message);
		$config['mail_type']='html';
		$this->email->initialize($config);
		$this->email->send();*/

		}
		
		/* Aggregator assignment */
		$this->db->where('kca_user_id', $id);
		$this->db->delete('tbl_kc_assignments');
		if($data['kaccess']=='yes'){
			foreach ($post['kca'] as $row) {
				$data1=array('kca_user_id'=>$id,'kca_kc_id'=>$row,'kca_created_at'=> date('Y-m-d H:i:s'),'kca_isself'=>false);
				$this->db->insert('tbl_kc_assignments',$data1);
			}
		}
		
		/* Client assignment */
		if($data['kc_c_access']=='yes'){
			foreach ($post['kca_c'] as $row2) {
				$data2=array('kca_user_id'=>$id,'kca_kc_id'=>$row2,'kca_created_at'=> date('Y-m-d H:i:s'),'kca_isself'=>false);
				$this->db->insert('tbl_kc_assignments',$data2);
			}
		}
		
		/* Aggregator IDP */
		$this->db->where('ui_user_id', $id);
		$this->db->delete('tbl_user_idp_programs');
		if($data['caccess']=='yes'){
		foreach ($post['idp'] as $row3) {
			$data3=array('ui_user_id'=>$id,'ui_idp_id'=>$row3,'ui_module_ids'=>serialize($post['selected_'.$row3]));
			$this->db->insert('tbl_user_idp_programs',$data3);
			}
		}
		
		/* Client IDP */
		if($data['idp_c_access']=='yes'){
		foreach ($post['idp_c'] as $row4) {
			$data4=array('ui_user_id'=>$id,'ui_idp_id'=>$row4,'ui_module_ids'=>serialize($post['selected_c_'.$row4]));
			$this->db->insert('tbl_user_idp_programs',$data4);
			}
		}
	}
	public function deletee($kl)	
	{
		  $this->db->where('id', $kl);
		  $this->db->delete('tbl_user');
	}

	 
    public function get_all_kc_a_list() {
        $this->db->select('*');
        $this->db->from('tbl_knowledge_center');
        $this->db->where(['prg_status' => 'Active', 'org_id' => 0]);
        $q = $this->db->get();
        return $q->result();
	}
	
    public function get_all_kc_c_list($org_id) {
        $this->db->select('*');
        $this->db->from('tbl_knowledge_center');
        $this->db->where(['prg_status' => 'Active', 'org_id' => $org_id]);
        $q = $this->db->get();
        return $q->result();
    }
	
	/* 
	Aggregator Assignments
	*/
    public function get_all_kca_a($user_id) {
        $this->db->select('*');
        $this->db->from('tbl_kc_assignments');
		$this->db->join('tbl_knowledge_center', 'tbl_knowledge_center.prg_id = tbl_kc_assignments.kca_kc_id');
        $this->db->where(['tbl_kc_assignments.kca_user_id' => $user_id, 'tbl_kc_assignments.kca_status' => 'Active', 'tbl_knowledge_center.org_id' => 0]);
        $q = $this->db->get();
        return $q->result();
	}
	 
	/* 
	Client Assignments
	*/
    public function get_all_kca_c($user_id) {
        $this->db->select('*');
        $this->db->from('tbl_kc_assignments');
		$this->db->join('tbl_knowledge_center', 'tbl_knowledge_center.prg_id = tbl_kc_assignments.kca_kc_id');
        $this->db->where(['tbl_kc_assignments.kca_user_id' => $user_id, 'tbl_kc_assignments.kca_status' => 'Active', 'tbl_knowledge_center.org_id !=' => 0]);
        $q = $this->db->get();
        return $q->result();
	}
	 
    public function get_admin_by_email($email) {
        $this->db->select('*');
        $this->db->from('tbl_admin');
        $this->db->where(['email' => $email]);
		$q = $this->db->get()->row();
        return $q;
	}
	
    public function get_organizations($user_id) {
		// TODO - prepare list as per user, dropdown list
        $this->db->select('*');
        $this->db->from('tbl_organization');
        //$this->db->where(['kca_user_id' => $user_id, 'kca_status' => 'Active']);
        $q = $this->db->get();
        return $q->result();
	}
	

}
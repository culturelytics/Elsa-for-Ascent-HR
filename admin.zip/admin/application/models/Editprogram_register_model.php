<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Editprogram_register_model extends CI_Model {
	 

	public function get_data($sha)	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_program');
	 
         $this->db->where('programid', $sha);
		 
		 $query =$this->db->get();
		 return $query->row();
		  
	}
	

	public function get_program()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_program');
           $this->db->where('programid', $sha);
		 $query =$this->db->get();
		 return $query->result();
		  
	}
	public function update_data($shahul, $kl)	
	{
		
		  $this->db->where('programid', $kl);
		  $this->db->update('tbl_program', $shahul);

		  
	}
	

	 
}
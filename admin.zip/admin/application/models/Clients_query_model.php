<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Clients_query_model extends CI_Model {
	 
	
	
	public function get_data()	
	{

		 $this->db->select('*');
		 $this->db->from('tbl_query');

		 $query =$this->db->get();
		 return $query->result();
		  
	}
	
	public function get_query($orgid = 0, $users = array())	
	{

	     $this->db->select('*,tbl_programs.prg_name as module,tbl_idp.title as program,tbl_query.id as aa');
		 $this->db->from('tbl_query');
		 $this->db->join('tbl_programs', 'tbl_query.module = tbl_programs.prg_id', 'left');
		 $this->db->join('tbl_idp', 'tbl_query.idp_id_from_uip = tbl_idp.id', 'left');
		 $this->db->join('tbl_user', ' tbl_query.user_id = tbl_user.id', 'left');
		 if($orgid != 0){
			$this->db->where('tbl_user.organization_id',$orgid);
		 }
		 if(count($users) > 0) {
			 $this->db->where_in('tbl_user.id', $users);
		 }
		
	    /* $this->db->order_by('prg_id', 'asc'); */
		 $query =$this->db->get();
		
		 return $query->result();
		  
	}
	public function update_data($shahul, $kl)	
	{

		  $this->db->where('id', $kl);
		  $this->db->update('tbl_query', $shahul);

		  
	}
	public function deletee($kl)	
	{
		 
		  $this->db->where('id', $kl);
		  $this->db->delete('tbl_query');
	 		 
		  
	}
	public function get_grps($adminid)	
	{
		$this->db->select('group_ids');
		$this->db->from('tbl_admin');
		$this->db->where('user_id',$adminid);
		$userdata = $this->db->get()->row();
		$gpids = unserialize($userdata->group_ids);
		return $gpids;
	}

	public function get_grpmembers($grps)	
	{
		$this->db->select('user_id');
		$this->db->from('tbl_group_user');
		$this->db->where_in('group_id',$grps);
		
		$query =$this->db->get();
		return $query->result();
	
	}
}


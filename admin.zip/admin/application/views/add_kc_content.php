<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $this->config->item('page_title') ?></title>
        <!-- Bootstrap core CSS-->
        <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Page level plugin CSS-->
        <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
        <!-- Custom styles for this template-->
        <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
    </head>

    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <!-- Navigation-->
        <?php include "sidebar.php"; ?>
        <div class="content-wrapper admpage2">
            <div class="container-headbox">
                <!-- Breadcrumbs-->
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo base_url() ?>dashboard/">Home</a>
                    </li>
                    
                    <?php if ($this->uri->segment(4) !== 'client') { ?>
                        <li class="breadcrumb-item">
                            <a href="<?php echo base_url() ?>knowledge_center/aggregator">Aggregator Knowledge Center</a>
                        </li>
                    <?php } else { ?>
                        <li class="breadcrumb-item">
                            <a href="<?php echo base_url() ?>knowledge_center/client">Client Knowledge Center</a>
                        </li>
                    <?php } ?>
                    <li class="breadcrumb-item active"><?= $kc[0]->prg_name ?> Content</li>
                </ol>
                <!-- Icon Cards-->

                <div class="clearfix">
                    <center>
                        <h3><?= $kc[0]->prg_name ?> Content</h3>
                    </center>
                </div>
            </div>
            <div class="container-fluid rgpage">
                <div class="container kccontent">
                    <form action="<?php echo current_url() ?>" method="post" id="kcctop">
                        <table>
                            <tr>
                                <td style="text-align: right;vertical-align: top;float: right;padding-right: 5px;min-width: 156px;">Module Name : </td>
                                <td colspan="4" style="width: 85%;">
                                    <div>
                                        <input type="text" name="kc_title_old" class="form-control" placeholder="KC Name" disabled required value="<?= $kc[0]->prg_name ? $kc[0]->prg_name : set_value('kc_title_old') ?>">
                                        <?php echo form_error('kc_title_old'); ?>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <td style="text-align: right;vertical-align: top; float: right;padding-right: 5px;min-width: 156px;">Module Description : </td>
                                <td colspan="4" style="width: 85%;">
                                    <div>
                                        <span name="kc_content_old" disabled><?= $kc[0]->prg_desc ?></span>

                                    </div>
                                </td>
                            </tr>
                        </table>
												  
 
						  
                        <div class="gprntdiv">
                            <div class="panel-heading gprnt">
                                <div style="padding: 3px 10px 3px 10px;" class="btn btn-primary expandCollapseGrandParent1" data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1">
                                    <i class="fa fa-caret-right caret rightgp1" aria-hidden="true"></i>
                                    <i class="fa fa-caret-down caret downgp1 hideCaret" aria-hidden="true"></i>
                                    &nbsp;<span> Topics and Content </span>
                                    <input style="float: right;padding: 4px 10px 4px 10px;font-size: 13px;min-width: 100px;" class="btn btn-primary new_row" type="button" name="Add Topics" value="Add Topics" data-toggle="modal" data-target="#addTopicModal" id="checkBtn">
                                </div>
                            </div>
                            <div id="collapse1" class="panel-collapse collapse">
                                <div class="tablemain">
                                    <table class="table table-border">
                                        <tbody id="kc_tbody" class="contentTable">
                                            <?php
                                            $cnt = 0;
                                            $i = 0;
                                            $old_id = '';
                                            $ctnr = 0;
                                            $ctnr2 = 0;
                                            $obj1 = array();
                                            foreach ($list as $klist) {
//                                            var_dump($klist);
                                                if (($obj1[$klist['kl_kc_id']] == 'undefined') || ($obj1[$klist['kl_kc_id']] == null) || ($obj1[$klist['kl_kc_id']] == '')) {
                                                    $obj1[$klist['kl_kc_id']] = 0;
                                                }
                                                $obj1[$klist['kl_kc_id']] += $klist['kl_credits'];
                                            }
                                            foreach ($list as $row) {
                                                $i++;
                                                $next_id = isset($list[$i]['kl_kc_id']) ? $list[$i]['kl_kc_id'] : '';
                                                $cnt++;
//                                            var_dump($row,$row->cstatus,$row['kc_id'] ,$old_id);
                                                if ($row['kc_id'] != $old_id) {
                                                    $ctnr++;
                                                    $ctnr2 = 0;
                                                    ?>
                                                    <tr id="parent_<?= $cnt ?>" class="contenttr" name="<?= $ctnr2 ?>" data-toggle="collapse" data-target=".child_<?= $row['kc_id'] ?>" aria-expanded="false" aria-controls="child_<?= $row['kl_kc_id'] ?>">
                                                        <td colspan="6">
                                                            <div class="btn btn-primary expandCollapseParent">
                                                                <i class="fa fa-caret-right caret rightp_parent_<?= $cnt ?>" aria-hidden="true"></i>
                                                                <i class="fa fa-caret-down caret downp_parent_<?= $cnt ?> hideCaret" aria-hidden="true"></i>&nbsp;&nbsp;<?= $ctnr ?> &nbsp;<span> <?= $row['kc_title'] ?> </span>
                                                                &nbsp;<span><a href="#" class="contentedit" data-pid="<?= $row['kc_prg_id'] ?>" data-kc-id="<?= $row['kc_id'] ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                                                &nbsp;<span><a href="#" class="contentedit contentdelete" data-url="<?php echo base_url() ?>knowledge_center/deleteContent/<?php echo $this->uri->segment(3) ?>/<?php echo $row['kc_id'] ?>/<?php echo $this->uri->segment(4) ?>"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                                                 <div style='float: right'>
                                                                    <span>Total Credits : </span>
                                                                    <span style="font-size: 13px;width: 45px;border-radius: 5px;padding: 2px 10px 2px 10px;"><?= $obj1[$row['kl_kc_id']] ?></span>
                                                                    <input style="padding: 3px 10px 3px 10px;font-size: 13px;min-width: 100px;" class="btn btn-primary inside_new_row addContent" data-kc-id="<?= $row['kc_id'] ?>" data-contentname="<?= $row['kc_title'] ?>" type="button" name="Add Content" value="Add Content" id="checkBtn">
                                                                    <?php ?>
																	 <input style="padding: 3px 10px 3px 10px;font-size: 13px;min-width: 100px;" class="btn btn-primary inside_new_row addAssessment" data-kc-id="<?= $row['kc_id'] ?>" data-contentname="<?= $row['kc_title'] ?>" type="button" name="Add Assessment" value="Add Assessment" id="checkBtn">
                                                                      
                                                                    <?php  ?>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                    if ($row['kl_id'] !== null && $row['status'] == 'Active') {
                                                        ?>
                                                        <tr class="panel-collapse collapse child_<?= $row['kc_id'] ?>" style='height: 30px;'>
                                                            <td></td>
                                                            <td style="font-weight: 600;font-size: 15px; padding: 5px 0px;">Content Title</td>
                                                            <!--td style="font-weight: 600;font-size: 15px; padding: 5px 0px; text-align: center;">Content Type</td-->
                                                            <td style="font-weight: 600;font-size: 15px; padding: 5px 0px;">Content URL</td>
                                                            <td style="font-weight: 600;font-size: 15px; padding: 5px 0px; text-align: center;">Credits</td>
                                                            <td style="font-weight: 600;font-size: 15px; padding: 5px 0px; text-align: center;">Action</td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                $ctnr2++;
                                                $old_id = $row['kc_id'];
//                                            var_dump($row);
                                                if ($row['kl_id'] !== null && $row['status'] == 'Active') {
                                                    ?>

                                                    <tr id="child_<?= $cnt ?>" class="panel-collapse collapse child_<?= $row['kc_id'] ?> kcsubcontent" style='font-size: 14px;'>
                                                        <td style="width: 5%;min-width: 13px; padding: 10px 0px 10px 0px; text-align: center;">
                                                            <div><?= $ctnr ?> . <?= $ctnr2 ?></div>
                                                        </td>
                                                        <td style="width:20%;padding: 10px 0px 10px 0px;">
                                                            <div>
                                                                <span><?= $row['kl_list'] ?></span>
                                                                <?php if ($row['kl_cat'] == 'Elsa Assessment') { ?>
                                                                <span style="font-style: italic; font-weight: bold;">
                                                                    <?php
                                                                        if ($assessment_list[$row['kl_id']]['status'] == '0') {
                                                                            echo " (Draft)";
                                                                        } else if ($assessment_list[$row['kl_id']]['status'] == '1') {
                                                                            echo " (Published)";
                                                                        } else if ($assessment_list[$row['kl_id']]['status'] == '2') {
                                                                            echo " (Expired)";
                                                                        } else {
                                                                            echo " (Deleted)";
                                                                        }
                                                                    ?>
                                                                </span>
                                                                <?php } ?>
                                                            </div>
                                                        </td>
                                                        <td style="width: 10%;min-width: 120px; padding: 10px 0px 10px 0px; text-align: center;">&nbsp;
                                                            <!--div class="form-group">
                                                                <div><span><?php if($row['kl_cat'] == 'Elsa Assessment') { echo ''; } else { echo $row['kl_cat']; } ?></span></div>
                                                            </div-->
                                                        </td>
                                                        <td style="width:40%;max-width: 250px !important;padding: 10px 0px 10px 0px;">
                                                            <div style='width: 98%; overflow: hidden;'><span><?= $row['kl_link'] ?></span></div>
                                                        </td>
                                                        <td style="width: 10%;min-width: 13px;text-align: center;padding: 10px 0px 10px 0px;">
                                                            <div><?= $row['kl_credits'] ?></div>
                                                        </td>
                                                        <td style="padding: 10px; width: 10%;min-width: 26px; text-align: left;">
                                                        <?php
                                                            if($row['kl_cat'] == 'Elsa Assessment') {
                                                        ?>
                                                            <?php
                                                                if($assessment_list[$row['kl_id']]['status'] == '0' || $assessment_list[$row['kl_id']]['status'] == '1') {
                                                            ?>
                                                                    <span><a title="Edit Assessment" href="#" class="editassessment" style="padding: 10px" data-contentid="<?= $assessment_list[$row['kl_id']]['contentid'] ?>" data-subcontentid="<?= $assessment_list[$row['kl_id']]['subcontentid'] ?>" data-assessment_title="<?= $assessment_list[$row['kl_id']]['assessment_title'] ?>" data-assessment_detail='<?= $assessment_list[$row['kl_id']]['assessment_detail'] ?>' data-status="<?= $assessment_list[$row['kl_id']]['status'] ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                                            <?php
                                                                } if($assessment_list[$row['kl_id']]['status'] == '0') {
                                                            ?>
                                                                    <span><a title="Publish Assessment" href="#" class="delete_row_1" style="padding-right: 10px" onclick="confirmationbox('<?php echo base_url() ?>knowledge_center/publishAssessment/<?php echo $this->uri->segment(3) ?>/<?php echo $row['kl_id'] ?>/<?php echo $this->uri->segment(4) ?>','publish')"><i class="fa fa-newspaper-o" aria-hidden="true"></i></a></span>
                                                            <?php
                                                                } if($assessment_list[$row['kl_id']]['status'] == '2') {
                                                            ?>
                                                                    <span><a title="Make a Copy of Assessment" style="padding: 10px" href="#" class="delete_row_1" onclick="confirmationbox('<?php echo base_url() ?>knowledge_center/cloneAssessment/<?php echo $this->uri->segment(3) ?>/<?php echo $row['kl_id'] ?>/<?php echo $this->uri->segment(4) ?>','clone')"><i class="fa fa-clone" aria-hidden="true"></i></a></span>
                                                            <?php
                                                                }
                                                            ?>
                                                                <span><a title="Delete Assessment" href="#" class="delete_row_1" onclick="deleteprogram('<?php echo base_url() ?>knowledge_center/deleteAssessment/<?php echo $this->uri->segment(3) ?>/<?php echo $row['kl_id'] ?>/<?php echo $this->uri->segment(4) ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                                        <?php
                                                            } else {
                                                        ?>
                                                            <span><a title="Edit Content" href="#" class="editsubcontent" data-klid="<?= $row['kl_id'] ?>" data-kc-id="<?= $row['kl_kc_id'] ?>" data-contentname="<?= $row['kc_title'] ?>" data-kllist="<?= $row['kl_list'] ?>" data-kltype="<?= $row['kl_cat'] ?>" data-kllink="<?= $row['kl_link'] ?>" data-klcredits="<?= $row['kl_credits']?>" data-klfileurl="<?= $row['kl_file_url'] ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                                            <span><a title="Delete Content" href="#" class="delete_row_1" onclick="deleteprogram('<?php echo base_url() ?>knowledge_center/deleteSubContent/<?php echo $this->uri->segment(3) ?>/<?php echo $row['kl_id'] ?>/<?php echo $this->uri->segment(4) ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                                        <?php
                                                            }
                                                        ?>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="gprntdiv">
                            <div class="panel-heading gprnt">
                                <button class="btn btn-primary expandCollapseGrandParent2" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">
                                    <i class="fa fa-caret-right caret rightgp2" aria-hidden="true"></i>
                                    <i class="fa fa-caret-down caret downgp2 hideCaret" aria-hidden="true"></i>&nbsp;<span> Books/Images </span>
                                    <input style="float: right;padding: 4px 10px 4px 10px;font-size: 13px;min-width: 100px;" class="btn btn-primary new_row" type="button" name="Add Image" value="Add Image" data-toggle="modal" data-target="#addImageModal" id="checkBtn">
                                </button>
                            </div>
                        </div>
                        <div id="collapse2" class="panel-collapse collapse">
                            <div class="table-responsive">
                                <table class="table table-border">
                                    <tbody id="kc_tbody" class="contentTable">
                                        <?php
                                        if (count($kcimage) > 0) {
                                            ?>
                                            <tr style='font-size: 14px;'>
                                                <td></td>
                                                <td style="font-weight: 600;"><span>Image Name</span></td>
                                                <td style="font-weight: 600; text-align: center;"><span>Image</span></td>
                                                <td style="font-weight: 600;"><span>Image Link</span></td>
                                                <td style="font-weight: 600; text-align: center;">Action</td>
                                            </tr>

                                            <?php
                                        }
                                        $i = 0;

                                        foreach ($kcimage as $row) : $i++;
                                            ?>
                                            <tr style='font-size: 14px;'>
                                                <td style="width: 5%; min-width: 13px; padding: 15px 0px 10px 10px; text-align: center;"><?php echo '1.' . $i; ?></td>
                                                <td style="width:25%;padding: 10px 0px 10px 0px;">
                                                    <div><span><?php echo $row->img_title ?></span></div>
                                                </td>
                                                <td style="width: 10%;min-width: 120px; padding: 15px 0px 10px 0px; text-align: center;">
                                                    <div class="form-group">
                                                        <img src="<?php echo base_url() ?>uploads/content_images/<?= $row->img_name ?>" style="width: 50px;height: 50px">
                                                    </div>
                                                </td>
                                                <td style='width:45%; max-width: 250px !important; padding-top: 15px;'>
                                                    <div style='width: 98%; overflow: hidden;'><span><?php echo $row->img_link ?></span></div>
                                                </td>                                              
                                                <td style="padding:15px 5px 5px 5px; width: 15%; min-width: 26px; text-align: center;">
                                                    <span style="padding: 5px;"><a href="#" class="editsubimage" data-pid="<?= $row->img_kc_id ?>" data-imgid="<?= $row->img_id ?>" data-kc-id="<?= $row->img_kc_id ?>" data-imgtitle="<?= $row->img_title ?>" data-imgname="<?= $row->img_name ?>" data-imglink="<?= $row->img_link ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                                    <span style="padding: 5px;"><a href="#" onclick="deleteprogram('<?php echo base_url() ?>knowledge_center/delete_image/<?php echo $row->img_id ?>/<?php echo $this->uri->segment(3) ?>/<?php echo $this->uri->segment(4) ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <br><br>
                    </form>
                </div>
                <?php include_once('footer.php'); ?>
            </div>
        </div>
        <div class="modal fade" id="addTopicModal" tabindex="-1" role="dialog" aria-labelledby="TopicModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="addTopicModalTitle" style="color: #0069d9;text-align: center;margin-left: 40%;">Add Topic</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="<?php echo base_url() ?>knowledge_center/add_topic/<?= $this->uri->segment(3) ?>" method="post">
                            <table>
                                <tr>
                                    <td valign="top"><span style="padding: 10px 30px 10px 30px;">Topic Title</span></td>
                                    <td>
                                        <div class="form-group">
                                            <textarea style="width: 350px;" id='topicName' class="form-control" name="kc_content[<?= $cnt ?>][]" required></textarea>
                                            <input type="hidden" name='topicId' id='topicId'  value=''>
                                            <input type="hidden" name='topicUrl' value="<?= $this->uri->segment(4) ?>">
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <input class="btn btn-primary" type="submit" name="Save" value="Save" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;" id="checkBtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="addContentModal" tabindex="-1" role="dialog" aria-labelledby="ContentModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="border-bottom: none;padding: 10px 10px 2px 10px;">
                        <h5 class="modal-title" id="addContentModalTitle" style="color: #0069d9;text-align: center;margin-left: 40%;">Add Con</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body" style="padding-top: 5px;">

                        <form action="<?php echo base_url() ?>knowledge_center/add_kc_content/<?= $this->uri->segment(3) ?>" method="post" enctype="multipart/form-data">
                            <table>
                                <tr>
                                    <td><span style="padding: 1px 3px 10px 30px;">Topic Name:</span></td>
                                    <td>
                                        <div class="form-group">
                                            <input type="text" class="form-control" id='content_title' value="" required readonly>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td><span style="padding: 1px 3px 10px 30px;">Content Title:</span></td>
                                    <td>
                                        <div class="form-group">
                                            <textarea style="width: 400px;" id='ctitle' class="form-control" name="kc_content[<?= $cnt ?>][]" required></textarea>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td><span style="padding: 1px 3px 10px 30px;">Content Type:</span></td>
                                    <td>
                                        <div class="form-group">
                                            <select class="form-control" name="kc_content[<?= $cnt ?>][]" id='kctype'>
                                                <!--<option value="Book Suggestions" selected>Book Suggestions</option>-->
                                                <option  value="Article">Video (mp4)</option> 
												<option  value="Article">Audio (mp3)</option> 
<!--                                                <option value="Assessments">Assessments</option>-->
                                                <option value="Article">Documents (jpeg,png,pdf,doc,docx,xls,xlxs,ppt,pptx) </option>
                                               <!-- <option value="SelfAssessment">Self Assessment</option> -->
                                            </select>
                                        </div>
                                    </td>
                                </tr>
                                <tr hidden>
                                    <td><span style="padding: 1px 3px 10px 30px;">Content URL:</span></td>
                                    <td>
                                        <div class="form-group">
                                            <textarea class="form-control" id='kcURL' style="width: 400px;" name="kc_content[<?= $cnt ?>][]" ></textarea>

                                            <input type="hidden" name='contentid' id='contentid' class="form-control" value="">
                                            <input type="hidden" name='subcontentid' id='subcontentid' class="form-control" value="">
                                            <input type="hidden" name='topicUrl' value="<?= $this->uri->segment(4) ?>">

                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td><span style="padding: 1px 3px 10px 30px;">File:</span></td>
                                    <td>
                                        <div class="form-group">
                                    		<input type="file" name="img_name" accept="video/*" id="klfileurl" <?php if ($this->uri->segment(4) == 'client') { ?>required <?php } ?>> 
                                        </div>
                                    </td>
                                </tr>
                                <tr hidden>
                                    <td><span style="padding: 1px 3px 10px 30px;">Content Credits:</span></td>
                                    <td>
                                        <div class="form-group">
                                            <input id='content_credits' max="1" value='1' type="number" class="form-control" name="kc_content[<?= $cnt ?>][]" >

                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <input class="btn btn-primary savetopic" type="submit" name="Save" value="Save" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;" id="checkBtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>        
        <div class="modal fade" id="addAssessmentModal" tabindex="-1" role="dialog" aria-labelledby="AssessmentModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:1200px;max-width: 1200px;" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="border-bottom: none;padding: 10px 10px 2px 10px;">
                        <h5 class="modal-title" id="addAssessmentModalTitle" style="color: #0069d9;text-align: center;margin-left: 40%;">Add Assessment2</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body" style="padding-top: 5px; max-height: 600px; overflow: auto;">

                        <form action="<?php echo base_url() ?>knowledge_center/add_assessment/<?= $this->uri->segment(3) ?>" method="post" enctype="multipart/form-data">
                            <table>
                                <tr>
                                    <td style="width: 160px; text-align: right;" valign="top"><span style="padding: 1px 10px 10px 30px;">Assessment Title</span></td>
                                    <td>
                                        <div class="form-group">
                                            <input type="text" name="assessment_title" class="form-control" id='assessment_title' value="" required style="width: 93%;">
                                            <input type="hidden" name='contentid' id='asscontentid' class="form-control" value="">
                                            <input type="hidden" name='subcontentid' id='asssubcontentid' class="form-control" value="">
                                            <input type="hidden" name='topicUrl' value="<?= $this->uri->segment(4) ?>">
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <table id="questionTable" style="margin-bottom: 10px;">
                                <tbody>
                                    <tr class="tr_clone">
                                        <td>
                                            <div class="questionNo" style="height: 35px; padding: 5px; text-align: center; background: #6085a0; width: 100px; border-top-left-radius: 5px; border-top-right-radius: 5px; color: #fff">
                                                Question 1
                                            </div>
                                            <table style="border: solid 1px #ccc; padding: 5px; border-radius: 10px; border-collapse: separate; margin-bottom: 5px; border-top-left-radius: 0px; background: #f7f7f7;">
                                                <tr>
                                                    <td style="width: 150px; text-align: right;" valign="top"><span style="padding: 1px 10px 10px 30px;">Question Text</span></td>
                                                    <td colspan="4">
                                                        <div class="form-group" style="margin-bottom: 5px">
                                                            <input type="text" id='qtitle' class="form-control" name="qtitle[]" required>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 150px; text-align: right;" valign="top"><span style="padding: 1px 10px 10px 30px;">Options</span></td>
                                                    <td>
                                                        <div class="form-group" style="margin-bottom: 5px;">
                                                            <span style="float: left; height: 38px; width: 30px; background: #efefef; border-top-left-radius: 0.25rem; border-bottom-left-radius: 0.25rem; padding: 5px; text-align: center; border: 1px solid #ced4da; border-right: none;">A.</span>
                                                            <input type="text" id="qopt1" class="form-control" name="qopt1[]" required style="width: 86%; border-top-left-radius: 0px; border-bottom-left-radius: 0px;">
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="form-group" style="margin-bottom: 5px;">
                                                            <span style="float: left; height: 38px; width: 30px; background: #efefef; border-top-left-radius: 0.25rem; border-bottom-left-radius: 0.25rem; padding: 5px; text-align: center; border: 1px solid #ced4da; border-right: none;">B.</span>
                                                            <input type="text" id="qopt2" class="form-control" name="qopt2[]" required style="width: 86%; border-top-left-radius: 0px; border-bottom-left-radius: 0px;">
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="form-group" style="margin-bottom: 5px;">
                                                            <span style="float: left; height: 38px; width: 30px; background: #efefef; border-top-left-radius: 0.25rem; border-bottom-left-radius: 0.25rem; padding: 5px; text-align: center; border: 1px solid #ced4da; border-right: none;">C.</span>
                                                            <input type="text" id="qopt3" class="form-control" name="qopt3[]" required style="width: 86%; border-top-left-radius: 0px; border-bottom-left-radius: 0px;">
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <div class="form-group" style="margin-bottom: 5px;">
                                                            <span style="float: left; height: 38px; width: 30px; background: #efefef; border-top-left-radius: 0.25rem; border-bottom-left-radius: 0.25rem; padding: 5px; text-align: center; border: 1px solid #ced4da; border-right: none;">D.</span>
                                                            <input type="text" id="qopt4" class="form-control" name="qopt4[]" required style="width: 86%; border-top-left-radius: 0px; border-bottom-left-radius: 0px;">
                                                        </div>
                                                    </td>
                                                    <td></td>
                                                </tr>
                                                <tr>
                                                    <td style="width: 150px; text-align: right;" valign="top"><span style="padding: 1px 10px 10px 30px;">Correct Option</span></td>
                                                    <td>
                                                        <div class="form-group" style="margin-bottom: 0px;">
                                                            <select class="form-control" name="correct_answer[]" id="correct_answer" required>
                                                                <option value="">Select Correct Answer</option>
                                                                <option value="1">A</option>
                                                                <option value="2">B</option>
                                                                <option value="3">C</option>
                                                                <option value="4">D</option>
                                                            </select>
                                                        </div>
                                                    </td>
                                                    <td></td>
                                                    <td></td>
                                                    <td></td>
                                                    <td style="width: 60px">
                                                        <div class="form-group" style="margin-bottom: 0px;">
                                                            <i class="fa fa-plus addNewQues" aria-hidden="true" title="Add Row" style="margin-left: 10px; cursor: pointer; color: #007bff; font-size: 14px;"></i>
                                                            <i class="fa fa-trash deleteQues" aria-hidden="true" title="Delete Row" style="margin-left: 10px; cursor: pointer; display: none; color: #007bff; font-size: 14px;"></i>
                                                        </div>
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </tbody>
                            </table>
                            <input class="btn btn-primary savetopic" type="submit" name="Save" value="Save" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;" id="checkBtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="addImageModal" tabindex="-1" role="dialog" aria-labelledby="ImageModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel" style="color: #0069d9;text-align: center;margin-left: 40%;">Add Image</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo base_url() ?>knowledge_center/add_kc_image_content/<?= $this->uri->segment(3) ?>" enctype="multipart/form-data" method="post">
                            <div class="container">
                                <!--<form action="<?php echo current_url() ?>" enctype="multipart/form-data" method="post" id="usersform">-->
                                <table>
                                    <tr>
                                        <td><span style="padding: 1px 3px 10px 30px;">Image Title:</span></td>
                                        <td>
                                            <div class="form-group">
                                                <input type="text" id='imagetitle' name="img_title" style="width: 350px;" placeholder="image title" >
                                                <?php echo form_error('img_title') ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><span style="padding: 1px 3px 10px 30px;">Image:</span></td>
                                        <td>
                                            <div class="form-group"><div id='image' style="float:left;    margin: 5px;"></div>
                                                <input id='imagename' type="file" style="max-width: 350px;" name="img_name" >
                                                <input id='oldimagename' type="hidden"  name="old_img_name" >
                                                <input type="hidden" name='topicUrl' value="<?= $this->uri->segment(4) ?>">

                                            </div>
                                        </td>
                                    </tr>
                                    <tr hidden>
                                        <td ><span style="padding: 1px 3px 10px 30px; float: right;">Image URL:</span></td>
                                        <td>
                                            <div class="form-group">
                                                <input type="text" id='imagelink' name="img_link" style="width: 350px;" placeholder="image link" >
                                                <?php echo form_error('img_link') ?>

                                                <input  id='img_id' name="img_id">

                                            </div>
                                        </td>
                                    </tr>
                                </table>
                                <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;">
                                <!--</form>-->
                            </div>
                            <!--<input class="btn btn-primary" type="submit" name="Save" value="Save" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;" id="checkBtn">-->
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Program</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <form action="<?php echo base_url() ?>knowledge_center/add_content/<?= $this->uri->segment(3) ?>" method="post" enctype="multipart/form-data">
                        <div class="modal-body">
                            <input type="text" name="prg_name1" placeholder="knowledge Center Name" id="prg_name1" value="" required>
                            <input type="hidden" name="prg_id1" placeholder="Program Name" id="prg_id1" value="" required><br>
                            <input type="text" name="img_link1" placeholder="image link" required>
                            <input type="file" name="prg_image" placeholder="knowledge Center Name">
                            <div id='prg_image'></div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="submit">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>




        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- Core plugin JavaScript-->
        <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
        <!-- Page level plugin JavaScript-->
        <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
        <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
        <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
        <!-- Custom scripts for all pages-->
        <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
        <!-- Custom scripts for this page-->
        <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
        <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>

        <script>
                                                    CKEDITOR.replace('kc_content_old', {
                                                        // Define the toolbar groups as it is a more accessible solution.
                                                        toolbar: [{
                                                                "name": 'paragraph',
                                                                "groups": ['list'],
                                                                "items": ['BulletedList']
                                                            }, ]
                                                    });
        </script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('.addContent').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    var kcid = $(this).data('kc-id');
                    var contentname = $(this).data('contentname');
                    $('#content_title').val(contentname);
                    $('#contentid').val(kcid);
                    $("#addContentModalTitle").html('Add Content');
                    $('#addContentModal').modal('show');
                });
                $('.addAssessment').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    $('.deleteQues').each(function(index) {
                        var $tr1 = $(this).closest('.tr_clone');
                        $tr1.find(':text').val('');
                        $tr1.find('select').val('');
                        $tr1.find('.addNewQues').show();
                        $(this).hide();
                        if(index > 0) {
                            $(this).trigger('click');
                        }
                    });
                    var kcid = $(this).data('kc-id');
                    $('#asscontentid').val(kcid);
                    $("#addAssessmentModalTitle").html('Add Assessment');
                    $('#addAssessmentModal').modal('show');
                });
                $('.editsubcontent').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    var kl_list = $(this).data('kllist');
                    var kl_type = $(this).data('kltype');
                    var kl_link = $(this).data('kllink');
                    var kl_file_url = $(this).data('klfileurl');
                    var kcid = $(this).data('kc-id');
                    var contentname = $(this).data('contentname');
                    var klsubcontentid = $(this).data('klid');
                    var klklcredits = $(this).data('klcredits');

                    if(kl_type === '' || kl_type === null || kl_type === undefined) {
                        kl_type = 'Article';
                    }

                    $('#content_title').val(contentname);
                    $('#ctitle').val(kl_list);
                    $('#kcURL').val(kl_link);
                    $('#kctype').val(kl_type);
                    //$('#klfileurl').val(kl_file_url);
                    if(kl_file_url != '') {
                        $('#lnk-file').attr('href', '/admin/uploads/content_images'+kl_file_url);
                        $('#lnk-file').show();
                    } else {
                        $('#lnk-file').hide();
                    }
                    
                    $('#subcontentid').val(klsubcontentid);
                    $('#contentid').val(kcid);
                    $('#content_credits').val(klklcredits);
                    $("#addContentModalTitle").html('Edit Content');
                    $('#addContentModal').modal('show');
                });
                $('.editassessment').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    
                    var contentid = ''; var subcontentid = ''; var assessment_title = ''; var assessment_detail = ''; var assessment_details = ''; var status = '';
                    contentid = $(this).data('contentid');
                    subcontentid = $(this).data('subcontentid');
                    assessment_title = $(this).data('assessment_title');
                    assessment_detail = $(this).data('assessment_detail');
                    assessment_details = JSON.parse(JSON.stringify(assessment_detail));
                    status = $(this).data('status');
                    
                    $('.deleteQues').each(function(index) {
                        var $tr1 = $(this).closest('.tr_clone');
                        if(index > 0) {
                            $tr1.remove();
                        }
                    });
                    var $tr = $('#questionTable').find('.tr_clone');
                    $ref = $tr;
                    $.each(assessment_details, function( index, eachDetail ) {
                        if(index > 1) {
                            var $clone = $ref.clone();
                            $clone.find(':text').val('');
                            $ref.after($clone);
                            $ref = $clone;
                            if($('.tr_clone').length > 1) {
                                $('.deleteQues').show();
                            }
                            $('.questionNo').each(function(index) {
                                $(this).html('Question '+parseInt(index+1));
                            });
                        }
                        $ref.find('#qtitle').val(eachDetail.qtitle);
                        $.each(eachDetail.options, function( eachIndex, value ) {
                            $ref.find('#qopt'+eachIndex).val(value.opttext);
                            if(value.is_correct == 0) {
                                $ref.find('#correct_answer option:selected').removeAttr('selected');
                                $ref.find('#correct_answer option[value="'+eachIndex+'"]').attr('selected', true);
                            }
                        });
                    });
                    $('#assessment_title').val(assessment_title).attr('readonly', true);
                    $('#asscontentid').val(contentid);
                    $('#asssubcontentid').val(subcontentid);

                    $('select option:not(:selected)').prop('disabled', false);
                    $('.addNewQues').show();
                    if(status == '1') {
                        $('select option:not(:selected)').prop('disabled', true);
                        $('.addNewQues').hide();
                        $('.deleteQues').hide();
                    }
                    $("#addAssessmentModalTitle").html('Edit Assessment');
                    $('#addAssessmentModal').modal('show');
                });

                $('.editsubimage').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    
                    var kcid = $(this).data('kc-id');
                    var kl_imgtitle = $(this).data('imgtitle');
                    var kl_imgname = $(this).data('imgname');
                    var kl_imglink = $(this).data('imglink');
                    var kl_imgid = $(this).data('imgid');

                    $('#imagetitle').val(kl_imgtitle);
                    $('#imagename').val('');
                    $('#oldimagename').val(kl_imgname);
                    $('#image').html('<img src="<?php echo base_url() ?>uploads/content_images/' + kl_imgname + '" style="width: 60px;height: 70px;">');
                    $('#imagelink').val(kl_imglink);
                    $('#img_id').val(kl_imgid);
                    $('#addImageModal').modal('show');
                });
                $('.contentedit').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    var kcid = $(this).data('kc-id');
                    if($(this).hasClass('contentdelete')) {
                        var url = $(this).data('url');
                        confirmationbox(url,'deleteContent');
                    } else {
                        $.post('<?php echo base_url() ?>knowledge_center/edit_content', 'kcid=' + kcid, function (rs) {
                            if (rs) {
                                rs = JSON.parse(rs);
                                $('#topicId').val(rs[0].kc_id);
                                $('#topicName').val(rs[0].kc_title);
                                $('#addTopicModal').modal('show');
                            } else {
                                alert("No record found")
                            }
                        });
                    }
                });
                $('.programeditkc').click(function () {
                    var imgid = $(this).data('imgid');
                    console.log(imgid);
                    $.post('<?php echo base_url() ?>knowledge_center/edit_image', 'imgid=' + imgid, function (rs) {
                        if (rs) {
                            rs = JSON.parse(rs);
                            console.log(rs);
                            $('#imagetitle').val(img_title);
                            $('#imagelink').val(kl_imglink);
                            $('#img_id').val(kl_imgid);
                            $('#prg_id1').val(rs[0].img_id);
                            $('#prg_name1').val(rs[0].img_title);
                            $('input[name="prg_image"]').val('');
                            $('input[name="img_link1"]').val(rs[0].img_link);

                            $('#prg_image').html('<img src="<?php echo base_url() ?>uploads/content_images/' + rs[0].img_name + '" style="width: 50px;height: 50px">');
                            $('#myModal').modal('show');
                        } else {
                            alert("No record found")
                        }
                    });
                });
                $(document).on('click', '.addNewQues', function() {
                    var $tr    = $(this).closest('.tr_clone');
                    var $clone = $tr.clone();
                    $clone.find(':text').val('');
                    $tr.after($clone);
                    if($('.tr_clone').length > 1) {
                        $('.deleteQues').show();
                    }
                    $('.questionNo').each(function(index) {
                        $(this).html('Question '+parseInt(index+1));
                    });
                });
                $(document).on('click', '.deleteQues', function() {
                    var $tr = $(this).closest('.tr_clone');
                    $tr.fadeOut( "slow", function() {
                        $tr.remove();
                        $('.questionNo').each(function(index) {
                            $(this).html('Question '+parseInt(index+1));
                        });
                    });
                    if((($('.tr_clone').length)-1) == 1) {
                        $('.deleteQues').hide();
                    }
                });
            });

            var cnt1 = '<?php echo $cnt ?>';
            $(document).on('click', '.expandCollapseGrandParent1', function (e) {
                setTimeout(function () {
                    if ($(".caret").closest(".rightgp1").hasClass('hideCaret')) {
                        $(".rightgp1").removeClass('hideCaret');
                        $(".downgp1").addClass('hideCaret');
                        $(".expandCollapseGrandParent1").removeClass('active');
                    } else {
                        $(".downgp1").removeClass('hideCaret');
                        $(".rightgp1").addClass('hideCaret');
                        $(".expandCollapseGrandParent1").addClass('active');
                    }
                }, 200);
            });
            $(document).on('click', '.expandCollapseGrandParent2', function (e) {
                setTimeout(function () {
                    if ($(".caret").closest(".rightgp2").hasClass('hideCaret')) {
                        $(".rightgp2").removeClass('hideCaret');
                        $(".downgp2").addClass('hideCaret');
                        $(".expandCollapseGrandParent2").removeClass('active');
                    } else {
                        $(".downgp2").removeClass('hideCaret');
                        $(".rightgp2").addClass('hideCaret');
                        $(".expandCollapseGrandParent2").addClass('active');
                    }
                }, 200);
            });
            $(document).on('click', '.contenttr', function (e) {
                var cnt = $(this).attr("id");
                setTimeout(function () {
                    if ($(".rightp_" + cnt).hasClass('hideCaret')) {
                        setTimeout(function () {
                            $(".rightp_" + cnt).removeClass('hideCaret');
                            $(".downp_" + cnt).addClass('hideCaret');
                           $("#"+ cnt +" .expandCollapseParent").css({"border-bottom-left-radius": "4px", "border-bottom-right-radius": "4px"});
                        }, 200);
                    } else {
                        $(".downp_" + cnt).removeClass('hideCaret');
                        $(".rightp_" + cnt).addClass('hideCaret');
                        $("#"+ cnt +" .expandCollapseParent").css({"border-bottom-left-radius": "0px", "border-bottom-right-radius": "0px"});
                    }
                }, 100);
            });
            $(document).on('click', '.savetopic', function (e) {
                $(".savebtn").removeAttr("disabled");
                $("#cancelbtn").removeAttr("disabled");
            });
            $(document).on('click', '.btn', function (e) {
                $(".savebtn").removeAttr("disabled");
                $("#cancelbtn").removeAttr("disabled");
            });

            $(document).on('click', '.new_row', function (e) {
                e.stopPropagation();
                e.preventDefault();
            });
            function deleteprogram(url) {
                a = confirm("Are you sure to delete?");
                console.log(a);
                if (a) {
                    window.location.href = url;
                }
            }
            function confirmationbox(url,messageType) {
                msg = "Are you sure to publish this assessment?";
                if(messageType == 'clone') {
                    msg = "Are you sure to make a copy of this assessment?";
                } else if(messageType == 'deleteContent') {
                    msg = "Deleting this topic will delete all the content inside it. Are you sure, you want to delete this topic? ";
                }
                a = confirm(msg);
                if (a) {
                    window.location.href = url;
                }
            }
        </script>
    </body>

</html>
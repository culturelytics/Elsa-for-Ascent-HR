<!-- <?php
if (!isset($_SESSION["email"])) {
    header("Location: login");
} else {
    ?> -->

    <?php
defined('BASEPATH') or exit('No direct script access allowed');
    ?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $this->config->item('page_title') ?></title>
        <!-- Bootstrap core CSS-->
        <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="<?php echo base_url() ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Page level plugin CSS-->
        <link href="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
        <!-- Custom styles for this template-->
        <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
        <link href="<?php echo base_url() ?>assets/select2/select2.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url() ?>assets/select2/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
    </head>

    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <!-- Navigation-->
        <?php include "sidebar.php";?>
        <div class="content-wrapper admpage2 user">
            <div class="container-headbox">
                <!-- Breadcrumbs-->
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo base_url() ?>dashboard/">Home</a>
                    </li>
                    <li class="breadcrumb-item active">Group Management</li>
                </ol>
                <!-- Icon Cards-->
            </div>
                <div style="float: right;margin-right: 10px;position: relative; z-index: 1000;margin-bottom: 10px;">
                    <a data-toggle="modal" data-target="#addOrgModal" class="btn btn-primary btn-condensed addOrgBtn" style="color: #fff;margin-right: 10px">Add Organization</a>
                </div>
            <div class="container-fluid rgpage">
                <div class="container1 grpm">
                    <div>
                        <p>Group Management</p>
                        
                        <table class="table table-bordered dataTable customTbl customColTbl" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                            <thead>
                                <tr>
                                    <th>S.no</th>
                                    <th>Trainer</th>
                                    <th>Location</th>
                                    <th>Admin</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <?php $i = 0;foreach ($organizations as $row): $i++;?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $row->org_name ?></td>
                                        <td><?php echo $row->ind_name ?></td>
                                        <td><?php echo $row->admin_users ?></td>
                                        <td>
                                            <span>
                                            <input type="hidden" value="<?php echo $row->org_name ?>" class="txt-org_name"/>
                                                <input type="hidden" value="<?php echo $row->admin_userids ?>" class="txt-admin_userids"/>
                                                <input type="hidden" value="<?php echo $row->id ?>" class="txt-org_id"/>
                                                <a data-orgid="<?php echo $row->id ?>" class="lnkManage" href="#">Manage</a>
                                                <a data-orgid="<?php echo $row->id ?>" class="lnkeditorg" href="#">Edit</a>
                                            
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach;?>
                        </table>
                    </div>
                </div>

                <div class="modal fade" id="addAdminModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Add Admin</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo base_url() ?>org_admins/addedit" method="post" id="usersform">
                                    <div>
                                        <h5 class="aeu">Organization / Groups</h5>
                                    </div>

                                    <div class="alab">
                                        <span id="org_name"></span>
                                    </div>

                                    <div>
                                        <h5 class="aeu">Admins</h5>
                                    </div>

                                    <div class="alab">
                                        <div class="col-lg-1211">
                                            <div class="col-lg-911">
                                                <select class="col-lg-3 select2me users_list" name="admins[]" multiple >
                                                                                                    </select>
                                                <?php echo form_error('admins[]'); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <input type="hidden" id="org_id" name="org_id" placeholder="org_id" required>
                                    </div>
                                    <input type="submit" name="submit" class="btn btn-primary" value="submit" id="btnAddEdit">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="modal fade" id="editOrg" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Edit Organization</h5>
                                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">×</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo base_url() ?>org_admins/update_org" method="post" id="usersform">
                                    <div>
                                        <h5>Organization Name: </h5>
                                    
                                        <input type="text" class="form-control" id='orgname' name="orgname" required >
                                        <input type="hidden" id="sel_org_id" name="sel_org_id" >
                                    </div>
                                    <input type="submit" name="submit" class="btn btn-primary" value="submit" id="btnAddEdit">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                
                 <div class=" modal fade" id="addOrgModal" tabindex="-1" role="dialog" aria-labelledby="OrgModalLabel" aria-hidden="true">
                <div class="modal-dialog" style="width:800px;max-width: 800px;" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add Organization</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form action="<?php echo base_url() ?>org_admins/add_org_inds" method="post" class="kedit" id="usersform">
                                <table>
                                    <tr>
                                        <td class="keditfirst">
                                            <span style="padding: 1px 3px 10px 30px;">Organization Name:</span></td>
                                        <td>
                                            <div>
                                                <input type="text" id="org_name" name="org_name" placeholder="Organization Name" required>
                                                <?php echo form_open('org_name'); ?>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                      <td class="keditfirst">
                                            <span style="padding: 1px 3px 10px 30px;">Industry name:</span></td>
                                        <td >
                                            <div class="alab" style="width: 60%;float: left;">
                                                <div class="col-lg-1211">
                                                    <div class="col-lg-911">
                                                         <select class="col-lg-3 select2me industry_list" name="industryid" id="industryid" >
                                                       
                                                              </select> 
                                                        
                                                       <?php echo form_error('industry'); ?>
                                                    </div>
                                                </div>
                                            </div>
                                           <div style="float: right;margin-right: 10px;position: relative; z-index: 1000;margin-bottom: 10px;margin-top: 10px;">
                                                <button type="button" name="add_ind_btn"  class="btn btn-primary " id="add_ind_btn">Add Industry</button>
                                           
                                            </div>
                                        </td>
                                    </tr>
                                    <tr class="inds">
                                        <td class="keditfirst">
                                            <span style="padding: 1px 3px 10px 30px;">Industry Name:</span></td>
                                        <td>
                                            <div>
                                                <input type="text" id="Industry_name" name="Industry_name" placeholder="Please add the Industry Name">
                                               
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                                
                                
                                <input type="submit" name="submit" value="submit" class="btn btn-primary btn-condensed" id="checkBtn">
                            </form>
                        </div>
                    </div>
                </div>
            </div>
                <?php include_once 'footer.php';?>
            </div>
            <!-- Bootstrap core JavaScript-->
            <script src="<?php echo base_url() ?>assets/vendor/jquery/jquery.min.js"></script>
            <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

            <!-- Core plugin JavaScript-->
            <script src="<?php echo base_url() ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
            <!-- Page level plugin JavaScript-->
            <script src="<?php echo base_url() ?>assets/vendor/chart.js/Chart.min.js"></script>
            <script src="<?php echo base_url() ?>assets/vendor/datatables/jquery.dataTables.js"></script>
            <script src="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
            <!-- Custom scripts for all pages-->
            <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
            <!-- Custom scripts for this page-->
            <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
            <script src="<?php echo base_url() ?>assets/select2/select2.full.min.js" type="text/javascript"></script>
            <!--   <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script> -->
            <script type="text/javascript">
                var users = <?php echo isset($users_list) ? json_encode($users_list) : '' ?>;
               
             
                function BindOnClick() {
                    $('.lnkManage').on('click', function(e) {
                        e.preventDefault();
                        var orgid = $(this).siblings('.txt-org_id').val();
                        $('#addAdminModal').find('#org_id').val(orgid);

                        $('#addAdminModal').find('#org_name').text($(this).siblings('.txt-org_name').val());

                        var admin_userids = $(this).siblings('.txt-admin_userids').val();
                        var admin_useridsarr = admin_userids.split(',');
                        //console.log('admin_useridsarr', admin_useridsarr)

                        var orgusers = [];
                        $.each(users, function (index, value) {
                            if(value.organization_id === orgid) {
                                orgusers.push({id: value.id, 'text': value.name});
                            }
                        });
                        console.log('orgusers', orgid, orgusers);
                        if ($('#addAdminModal').find('.users_list').data('select2')) {
                            $('#addAdminModal').find('.users_list').select2('destroy');
                        }
                        $('#addAdminModal').find('.users_list').select2({
                            placeholder: "Select Users",
                            width: 'auto',
                            data: orgusers
                        });
                        if(admin_useridsarr.length > 0) {
                            $('#addAdminModal').find('.users_list').val(admin_useridsarr).trigger("change");
                        }

                        $('#addAdminModal').modal('show');
                    });
              
                    $('.lnkeditorg').on('click', function(e) {
                        e.preventDefault();
                        var orgName = $(this).siblings('.txt-org_name').val();
                        var orgid = $(this).siblings('.txt-org_id').val();
                        $('#orgname').val(orgName);
                        $('#sel_org_id').val(orgid);
                        $('#editOrg').modal('show');
                    });
             
                }
                
                
                $(document).ready(function () {
                    var table = $('#dataTable').DataTable({
                        destroy: true,
                        bFilter: true,
                        bLengthChange: false,
                        "drawCallback": BindOnClick
                    });
                    $(".inds").css("display", "none");
                    
                    var orgIndustry = [];
                    $('.addOrgBtn').on('click', function(e) {
                        $(".inds").css("display", "none");
                        $("#industryid").prop('required',true);
                        $("#Industry_name").prop('required',false);
                        var industry = <?php echo isset($industry) ? json_encode($industry) : '' ?>;
                        orgIndustry.push({id: '', 'text': ''});
                        $.each(industry, function (index, value) {
                            orgIndustry.push({id: value.id, 'text': value.ind_name});
                        });
                        if ($('#addOrgModal').find('.industry_list').data('select2')) {
                            $('#addOrgModal').find('.industry_list').select2('destroy');
                        }
                        $('#addOrgModal').find('.industry_list').select2({
                            placeholder: "Select Industry",
                            width: 'auto',
                            data: orgIndustry,
                            disabled:false
                        });
                    });
                    $('#add_ind_btn').on('click', function(e) { 
                        $(".inds").css("display", "table-row");
                        $("#Industry_name").prop('required',true);
                        $("#industryid").prop('required',false);
                        
                        $('#industryid').select2('enable', false); 
                        $('#addOrgModal').find('.industry_list').val('').trigger("change");

                    });
                
                });
            </script>
        </div>
    </body>
</html>  
<!-- <?php }?> -->

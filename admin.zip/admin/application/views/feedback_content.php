<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper admpage">
  <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <li class="breadcrumb-item active">Feedback</li>
      </ol>
      <!-- Icon Cards-->

      <div class="clearfix">
        <center>
          <h3>Feedback</h3>
        </center>
      </div>
    </div>
    <div class="container-fluid rgpage">
      <p align="right"><a href="feedback-report.php" class="btn btn-primary btn-condensed">Feedback Report</a></p>

      <div class="container">
        
      <p>Details of Feedback Form</p>
          <table class="table table-bordered dataTable customTbl" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">

            <thead>
              <tr role="row">
                <th>S.no</th>
                <th>Name</th>
                <th>Email</th>
                <th>Desgination</th>
                <th>Contact</th>
                <th>Date of Birth</th>
                <th>Company</th>
                <th>Date</th>
                <th>Program</th>
                <th>Coverage of Subject</th>
                <th>Clarity Of Objective</th>
                <th>Case Study/Exercises</th>
                <th>Knowledge of Subject</th>
                <th>Presentation Skills</th>
                <th>Examples Used</th>
                <th>Answering Queries</th>
                <th>Overall Impact</th>
                <th>Comments/Suggestions</th>
                <th>Participants Speak</th>
                <th>Training Things</th>
              </tr>
            </thead>
            <?php $i = 0;
            foreach ($list as $row) : $i++;  ?>
              <tr>

                  <td style="text-align: center"><?php echo $i; ?></td> <!-- php 5.6 version -->
                <td><?php echo $row->Name ?></td>
                <td><?php echo $row->Email ?></td>
                <td><?php echo $row->Desg ?></td>
                <td><?php echo $row->Contact ?></td>
                <td><?php echo $row->DOB ?></td>
                <td><?php echo $row->Company ?></td>
                <td><?php echo $row->Date ?></td>
                <td><?php echo $row->Program ?></td>
                <td><?php echo $row->Coverage ?></td>
                <td><?php echo $row->Clarity ?></td>
                <td><?php echo $row->CaseStudy ?></td>
                <td><?php echo $row->Knowledge ?></td>
                <td><?php echo $row->Presentation ?></td>
                <td><?php echo $row->Examples ?></td>
                <td><?php echo $row->Queries ?></td>
                <td><?php echo $row->Impact ?></td>
                <td><?php echo $row->Comments ?></td>
                <td><?php echo $row->Testimonial ?></td>
                <td><?php echo $row->TrainingThings ?></td>


              </tr>

            <?php endforeach; ?>
          </table>
      </div>
      <?php include_once('footer.php'); ?>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.1.0/js/dataTables.buttons.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.1.0/js/buttons.html5.min.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.1.0/js/buttons.bootstrap.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
    <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
    <script src="https://cdn.datatables.net/buttons/1.1.0/js/buttons.print.min.js"></script>

    <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>

  </div>

</body>

</html>
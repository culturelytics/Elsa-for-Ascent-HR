<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper admpage3">
    <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <li class="breadcrumb-item active">Banner Images</li>
      </ol>
      <!-- Icon Cards-->

      <div class="clearfix">
        <center>
          <h3>Banner Images</h3>
        </center>
      </div>
    </div>
    <div class="container-fluid">
      <?php echo $this->session->flashdata('notification'); ?>
      <?php echo $this->session->flashdata('notification1'); ?>
      <div class="container">
        <?php $notification = $this->session->flashdata('addednotification');
        if ($notification) {
        ?>
          <div class="alert alert-success">
            <?php echo $notification; ?>
          </div>
        <?php
        } ?>
        <?php echo form_error('addednotification'); ?>

        <?php $notification = $this->session->flashdata('notnotification');
        if ($notification) {
        ?>
          <div class="alert alert-danger">
            <?php echo $notification; ?>
          </div>
        <?php
        } ?>
        <?php echo form_error('notnotification'); ?>


        <?php $notification = $this->session->flashdata('deletenotification');
        if ($notification) {
        ?>
          <div class="alert alert-success">
            <?php echo $notification; ?>
          </div>
        <?php
        } ?>
        <?php echo form_error('deletenotification'); ?>

        <?php $notification = $this->session->flashdata('updatenotification');
        if ($notification) {
        ?>
          <div class="alert alert-success">
            <?php echo $notification; ?>
          </div>
        <?php
        } ?>
        <?php echo form_error('updatenotification'); ?>

        <p>Add new Banner image</p>
        <form action="<?php echo base_url() ?>update_banner_images/addimage" method="post" id="imagesform" enctype="multipart/form-data">
          <div>

            <input type="file" name="bannerimg" required>

          </div>
          <div>

            <input type="text" name="imagelink" required placeholder="Enter Image link">
          </div>


          <input type="submit" name="submit" class="btn btn-primary" value="submit" class="imbut">

        </form>
        <hr>
        <div>
          <p>List of all Banner images</p>
          <table border="1" id="imagestable">
            <tr>
              <th>S.no</th>
              <th>Upload Image</th>
              <th>Image link</th>
              <th>Action</th>
            </tr>
            <?php $i = 0;
            foreach ($list as $row) : $i++;  ?>

              <tr>
                <td><?php echo $i; ?></td> <!-- php 5.6 version -->
                <td><img src="<?php echo base_url(); ?><?php echo 'uploads/' . $row->uploadimage . ''; ?>" style="width:100px;"></td>
                <td><?php echo $row->imagelink ?></td>
                <td><span><a href="<?php echo base_url() ?>editbanner/<?php echo $row->imagesid ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                    <span><a href="#" onclick="deleteprogram('<?php echo base_url() ?>update_banner_images/delete/<?php echo $row->imagesid ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span></td>


              </tr>

            <?php endforeach; ?>
          </table>
        </div>
        <?php include_once('footer.php'); ?>
      </div>
      <!-- Bootstrap core JavaScript-->
      <script src=" <?php echo base_url() ?>vendor/jquery/jquery.min.js"> </script>
      <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- Core plugin JavaScript-->
      <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
      <!-- Page level plugin JavaScript-->
      <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
      <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
      <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
      <!-- Custom scripts for this page-->
      <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
      <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>
    </div>
      
      <script type="text/javascript">
      function deleteprogram(url) {
                a = confirm("Are you sure to delete?");
                console.log(a);
                if (a) {
                    window.location.href = url;
                }
            }
      </script>
</body>

</html>
<!-- <?php
if (!isset($_SESSION["email"])) {
    header("Location: login");
} else {
    ?> -->

    <?php
defined('BASEPATH') or exit('No direct script access allowed');
    ?>
    <!DOCTYPE html>
    <html lang="en">

        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="description" content="">
            <meta name="author" content="">
            <title><?php echo $this->config->item('page_title') ?></title>
            <!-- Bootstrap core CSS-->
            <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
            <!-- Custom fonts for this template-->
            <link href="<?php echo base_url() ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
            <!-- Page level plugin CSS-->
            <link href="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
            <!-- Custom styles for this template-->
            <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
            <link href="<?php echo base_url() ?>assets/select2/select2.min.css" rel="stylesheet" type="text/css" />
            <link href="<?php echo base_url() ?>assets/select2/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />

        </head>

        <body class="fixed-nav sticky-footer bg-dark" id="page-top">
            <!-- Navigation-->
            <?php include "sidebar.php";?>
            <div class="content-wrapper admpage2 user">
                <div class="container-headbox">
                    <!-- Breadcrumbs-->
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo base_url() ?>dashboard/">Home</a>
                        </li>
                        <li class="breadcrumb-item active">GROUP Management</li>
                    </ol>
                    <!-- Icon Cards-->

                    <div class="clearfix">
                        <center>
                            <h3>GROUP MANAGEMENT</h3>
                        </center>
                        <div class="row full-width">
                            <div class="col-md-4 col-sm-4">
                                <label for="organization" class="text-right pull-right form-label cdb-lbl">Organization</label>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="form-group" style="display: inline">
                                    <?php if($_SESSION["role"] === 'super_admin'):?>
                                    <select name="org_id" id="org_id" class="form-control user_org select2me">
                                        <?php foreach ($organizations as $k => $org){
                                            if($_SESSION["role"] != 'super_admin' && $org->id != $org_id) {continue;}
                                            if($_SESSION["role"] != 'super_admin'){
                                                echo '<option value="0">All Organizations</option>';
                                            }
                                            ?>
                                            <option value="<?php echo $org->id ?>" <?php echo ($org->id == $org_id ? 'selected="true"' : '') ?>><?php echo $org->org_name; ?></option>
                                        <?php }?>
                                    </select>
                                    <?php else: ?>
                                        <strong><?php echo $_SESSION['org_name']?></strong>
                                        <input type="hidden" name="org_id" id="org_id" value="<?php echo $_SESSION["org_id"] ?>" />
                                    <?php endif ?>
                                </div>
                            </div>
                            <div class="col-md-2 col-sm-2">
                                <?php if ($_SESSION["role"] === 'super_admin'): ?>
                                    <button style="padding: 1px 10px 1px 10px;" type="button" id="orgIdSubmit" class="btn btn-primary btn-condensed">Submit</button>
                                <?php endif;?>
                            </div>
                            <div class="col-md-2 col-sm-2">
                                <?php if ($_SESSION["role"] === 'super_admin' || $_SESSION["role"] === 'org_admin'): ?>
                                    <button style="padding: 1px 10px 1px 10px;" type="button" id="btnAddGroup" class="btn btn-primary btn-condensed">Add Group</button>
                                <?php endif;?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="container-fluid rgpage">
                    <div class="container">
                        <div>
                            <table class="table table-bordered dataTable customTbl customColTbl" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>S.no</th>
                                        <th>Name</th>
                                        <th>Status</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $i = 0;foreach ($list as $row): $i++;?>
	                                    <tr>
	                                        <td><?php echo $i; ?></td>
	                                        <td><?php echo $row->group_name?></td> 
	                                        
	                                        <td><?php echo $row->status?></td>

	                                        <td>
	                                            <span>
	                                                <a href="<?php echo base_url() ?>groups/addedit/<?php echo $row->org_id ?>/<?php echo $row->id ?>">Manage</a></span><span>
	                                                <?php /*<?php if ($row->status == 'active'): ?>
	                                                <a href="#" onclick="deleteprogram('<?php echo base_url() ?>groups/delete/<?php echo $row->id ?>')" ><i class="fa fa-trash" aria-hidden="true"></i></a>
	                                                <?php endif?> */ ?>
                                            </span>
                                        </td>
                                    </tr>
                                <?php endforeach;?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <?php include_once 'footer.php';?>
                </div>
                <!-- Bootstrap core JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/jquery/jquery.min.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                <!-- Core plugin JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
                <!-- Page level plugin JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/chart.js/Chart.min.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/datatables/jquery.dataTables.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
                <!-- Custom scripts for all pages-->
                <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
                <!-- Custom scripts for this page-->
                <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
                <script src="<?php echo base_url() ?>assets/select2/select2.full.min.js" type="text/javascript"></script>
                <!--   <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script> -->
                <script type="text/javascript">
                    $(document).ready(function () {
                        $("select#org_id:not([readonly])").select2({
                            placeholder: "Select Organization",
                            width: '400px'
                        });
                        $('#btnAddGroup').on('click', function () {
                            var orgid = $('#org_id').val();
                            if ('<?php echo $this->uri->segment(1) ?>' === 'groups') {
                                window.location.href = '<?php echo base_url() ?>groups/addedit/' + orgid;
                            }
                        });

                        $('#orgIdSubmit').on('click', function () {
                            var orgid = $('#org_id').val();
                            if ('<?php echo $this->uri->segment(1) ?>' === 'groups') {
                                window.location.href = '<?php echo base_url() ?>groups/index/' + orgid;
                            }
                        });
                    });

                    /*function deleteprogram(url) {
                        a = confirm("Are you sure to delete?");
                        console.log(a);
                        if (a) {
                            window.location.href = url;
                        }
                    }*/
                </script>
            </div>
        </body>
    </html>
    <!-- <?php }?> -->
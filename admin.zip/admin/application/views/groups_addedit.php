<!-- <?php
if (!isset($_SESSION["email"])) {
    header("Location: login");
} else {
    ?> -->

    <?php
defined('BASEPATH') or exit('No direct script access allowed');
    ?>
    <!DOCTYPE html>
    <html lang="en">

        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="description" content="">
            <meta name="author" content="">
            <title><?php echo $this->config->item('page_title') ?></title>
            <!-- Bootstrap core CSS-->
            <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
            <!-- Custom fonts for this template-->
            <link href="<?php echo base_url() ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
            <!-- Page level plugin CSS-->
            <link href="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
            <!-- Custom styles for this template-->
            <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
            <link href="<?php echo base_url() ?>assets/select2/select2.min.css" rel="stylesheet" type="text/css" />
            <link href="<?php echo base_url() ?>assets/select2/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />

        </head>

        <body class="fixed-nav sticky-footer bg-dark" id="page-top">
            <!-- Navigation-->
            <?php include "sidebar.php";?>
            <div class="content-wrapper admpage2 user">
                <div class="container-headbox">
                    <!-- Breadcrumbs-->
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo base_url() ?>dashboard/">Home</a>
                        </li>
                        <li class="breadcrumb-item active">GROUP Management</li>
                    </ol>
                    <!-- Icon Cards-->

                    <?php
                    if(isset($_SESSION["is_org_admin"]) && $_SESSION["is_org_admin"] == 1){
                        
                    }
                    ?>

                    <div class="clearfix">
                        <center>
                            <h3>GROUP MANAGEMENT</h3>
                        </center>
                        <div class="row full-width">
                            <div class="col-md-4 col-sm-4">
                                <label for="organization" class="text-right pull-right form-label cdb-lbl">Organization</label>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="form-group" style="display: inline">
                                    <?php if($_SESSION["role"] === 'super_admin') :?>
                                    <select name="org_id" id="org_id" class="form-control user_org select2me">
                                        <?php foreach ($organizations as $k => $org){
                                            if($_SESSION["role"] != 'super_admin' && $org->id != $org_id) {continue;}
                                            if($_SESSION["role"] != 'super_admin'){
                                                echo '<option value="0">All Organizations</option>';
                                            }
                                            ?>
                                            <option value="<?php echo $org->id ?>" <?php echo ($org->id == $org_id ? 'selected="true"' : '') ?>><?php echo $org->org_name; ?></option>
                                        <?php }?>
                                    </select>
                                    <?php else: ?>
                                        <strong><?php echo $_SESSION['org_name']?></strong>
                                        <input type="hidden" name="org_id" value="<?php echo $_SESSION["org_id"] ?>" />
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                            <?php if($_SESSION["role"] === 'super_admin'): ?>
                                <button style="padding: 1px 10px 1px 10px;" type="button" id="orgIdSubmit" class="btn btn-primary btn-condensed" onclick="redirect();">Submit</button>
                                        <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="container-fluid rgpage">
                    <div class="container">
                        <?php
$notification = $this->session->flashdata('notification');
    if ($notification) {
        ?>
                            <div class="alert alert-success">
                            <?php echo $notification; ?>
                            </div>
                            <?php }?>
                        <?php echo form_error('notification'); ?>

                        <?php
$notification = $this->session->flashdata('updatenotification');
    if ($notification) {
        ?>
                            <div class="alert alert-success">
                            <?php echo $notification; ?>
                            </div>
                            <?php }
    ?>
                        <?php echo form_error('updatenotification'); ?>

                        <?php
$notification = $this->session->flashdata('deletenotification');
    if ($notification) {
        ?>
                            <div class="alert alert-success">
                            <?php echo $notification; ?>
                            </div>
                            <?php }?>
                            <?php echo form_error('deletenotification'); ?>

                        <form action="<?php echo base_url() ?>groups/addedit/<?php echo $this->uri->segment(3) ?>/<?php echo $this->uri->segment(4) ?>" method="post" id="usersform">
                                <?php print_r(form_error());?>

                            <div>
                                <h5 class="aeu"> Name</h5>
                            </div>
                            <div>
                                <input type="text" name="name" placeholder="Name" value="<?=$name?>"  required >
                                <?php echo form_error('name'); ?>
                            </div>

                            <div>
                                <h5 class="aeu"> Description</h5>
                            </div>
                            <div>
                                <textarea name="description" placeholder="Description" value="<?=$description?>" class="form-control"><?=$description?></textarea>
                                <?php echo form_error('description'); ?>
                            </div>

                            <input type="hidden" name="organization_id"  value="<?php echo $org_id ?>">

                            <?php if($_SESSION["role"] === 'super_admin' || $_SESSION["role"] === 'org_admin' || $_SESSION["role"] === 'group_admin'): ?>
                            <div <?php if($_SESSION["role"] === 'group_admin'){echo 'style="display: none;"';}?>>
							<div>
                                <h5 class="aeu"> Admin </h5>
                            </div>
								
								
								

                              <div class="alab" id="mdl-kaccess" <?php if($_SESSION["role"] === 'group_admin'){echo 'type="hidden"';}?>>
                                <div class="col-lg-1211">
                                    <div class="col-lg-911">
                                        <select class="col-lg-3 select2me users_list" name="admins[]" multiple >
                                            <option value=""></option>
                                            <?php
$adminsa_list = json_decode(json_encode($adminsa_list), true);
    $adminsa_id = array_column($adminsa_list, 'user_id');
    foreach ($users_list as $row1) {?>
                                                <option value="<?=$row1->id?>" <?php if (in_array($row1->id, $adminsa_id)) {echo 'selected';}?> ><?=$row1->name?></option>
                                            <?php }?>
                                        </select>
                                        <?php echo form_error('admins[]'); ?>
                                    </div>
                                </div>
                            </div>
								
								
								
								
							</div>
    <?php endif; ?>
<?php if($_SESSION['role'] === 'super_admin' || $_SESSION['role'] === 'group_admin' ){ ?>
							
						
							
							
							
                            <div>

                                <h5 class="aeu">Members</h5>
                            </div>

							
							
					  <div class="alab" id="mdl-kaccess">
                                <div class="col-lg-1211">
                                    <div class="col-lg-911">
                                        <select class="col-lg-3 select2me users_list" name="users[]" multiple >
                                            <option value=""></option>
                                            <?php
$usersa_list = json_decode(json_encode($usersa_list), true);
    $usersa_id = array_column($usersa_list, 'user_id');
    foreach ($users_list as $row1) {?>
                                                <option value="<?=$row1->id?>" <?php if (in_array($row1->id, $usersa_id)) {echo 'selected';}?> ><?=$row1->name?></option>
                                            <?php }?>
                                        </select>
                                        <?php echo form_error('users[]'); ?>
                                    </div>
                                </div>
                            </div>

							
							
							
							
							
							
							
							
							
							
							
							
							
                            <div>
                                <h5 class="aeu">Aggregator Knowledge Center</h5>
                            </div>

                            <div class="alab" id="mdl-kaccess">
                                <div class="col-lg-1211">
                                    <div class="col-lg-911">
                                        <select class="col-lg-3 select2me kca_a_list" name="kca[]" multiple >
                                            <option value=""></option>
                                            <?php
$kca_a_list = json_decode(json_encode($kca_a_list), true);
    $kca_kc_id = array_column($kca_a_list, 'kc_id');
    foreach ($kc_a_list as $row1) {?>
                                                <option value="<?=$row1->prg_id?>" <?php if (in_array($row1->prg_id, $kca_kc_id)) {echo 'selected';}?> ><?=$row1->prg_name?></option>
                                            <?php }?>
                                        </select>
                                        <?php echo form_error('kca[]'); ?>
                                    </div>
                                </div>
                            </div>

                            <div>
                            <h5 class="aeu">Client Knowledge Center</h5>
                            </div>
                            <div class="alab" id="mdl-kc_c_access">
                                <div class="col-lg-1211">
                                    <div class="col-lg-911">
                                        <select class="col-lg-3 select2me kca_c_list" name="kca_c[]" multiple >
                                            <option value=""></option>
                                            <?php $kca_c_list = json_decode(json_encode($kca_c_list), true);
    $kca_kc_id = array_column($kca_c_list, 'kc_id');
    foreach ($kc_c_list as $row2) {?>
                                                  <option value="<?=$row2->prg_id?>" <?php if (in_array($row2->prg_id, $kca_kc_id)) {echo 'selected';}?> ><?=$row2->prg_name?></option>
                                                  <?php }?>
                                        </select>
                                        <?php echo form_error('kca_c[]'); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="alab">
                                <h5>Aggregator MPL</h5>
                            </div>

                            <div class="alab" id="module">
                                <div class="col-lg-1211">
                                    <div class="col-lg-911">
                                        <select class="col-lg-3 select2me idp_program idpa_a_list" name="idpa[]" multiple >
                                            <option value=""></option>
                                            <?php
$idpa_a_list = json_decode(json_encode($idpa_a_list), true);
    $idpa_idp_id = array_column($idpa_a_list, 'idp_id');
    $sel_data = array();
    foreach ($idp_a_list as $row1) {?>
                                                <option value="<?=$row1->id?>" <?php if (in_array($row1->id, $idpa_idp_id)) {echo 'selected';
        $sel_data[$row1->id] = $row1->title;}?> ><?=$row1->title?></option>
                                            <?php }?>
                                        </select>
                                        <?php echo form_error('idpa[]'); ?>
                                    </div>
                                    <?php foreach ($idpa_a_list as $row) {
        $selected_idps = unserialize($row["module_ids"]);?>
                                        <?php //foreach (json_decode($programs) as $row1) { var_dump($row1->id, $row, in_array($row1->id, $selected_idps)); }?>
                                        <div class="col-lg-12 div_<?=$row["idp_id"]?>"><?=$sel_data[$row["idp_id"]]?><div class="col-lg-9">
                                                <select class="col-lg-3 select2me idp_program1" name="selected_<?=$row["idp_id"]?>[]" multiple required>
                                                    <option value=""></option>
                                                    <?php foreach (json_decode($programs) as $row1) {if ($row1->idpid != $row["idp_id"]) {continue;}?>
                                                        <option value="<?=$row1->id?>" <?php echo (in_array($row1->id, $selected_idps) ? 'selected' : '') ?>><?=$row1->text?></option>
                                                    <?php }?>
                                                </select>
                                                <?php echo form_error('selected_' . $row["idp_id"] . '[]'); ?>
                                            </div>
                                        </div>
                                        <?php }?>
                                </div>
                            </div>

                            <div class="alab">
                                <h5>Client MPL</h5>
                            </div>

                            <div class="alab" id="mdl-idp_c_access">
                                <div class="col-lg-1211">
                                    <div class="col-lg-911">

                                    <select class="col-lg-3 select2me idp_program_c idpa_c_list" name="idpa_c[]" multiple >
                                            <option value=""></option>
                                            <?php $idpa_c_list = json_decode(json_encode($idpa_c_list), true);
    $idpa_idp_id = array_column($idpa_c_list, 'idp_id');
    foreach ($idp_c_list as $row2) {?>
                                                  <option value="<?=$row2->id?>" <?php if (in_array($row2->id, $idpa_idp_id)) {echo 'selected';}?> ><?=$row2->title?></option>
                                                  <?php }?>
                                        </select>
                                        <?php echo form_error('idpa_c[]'); ?>
                                    </div>

                                    <?php foreach ($idpa_c_list as $row) {
        $selected_idps = unserialize($row["module_ids"]);?>
                                        <?php //foreach (json_decode($programs) as $row1) { var_dump($row1->id, in_array($row1->id, $selected_idps)); }?>
                                        <div class="col-lg-12 div_c_<?=$row["idp_id"]?>"><?=$sel_data[$row["idp_id"]]?><div class="col-lg-9">
                                                <select class="col-lg-3 select2me idp_program_c1" name="selected_c_<?=$row["idp_id"]?>[]" multiple required>
                                                    <option value=""></option>
                                                    <?php foreach (json_decode($programs) as $row1) {if ($row1->idpid != $row["idp_id"]) {continue;}?>
                                                        <option value="<?=$row1->id?>" <?php echo (in_array($row1->id, $selected_idps) ? 'selected' : '') ?>><?=$row1->text?></option>
                                                    <?php }?>
                                                </select>
                                                <?php echo form_error('selected_c_' . $row["idp_id"] . '[]'); ?>
                                            </div>
                                        </div>
                                        <?php }?>
									
                                </div>
                            </div>

<?php } ?>
                            <div class="alab">
								
                                <h5>Group Status</h5>
                                <select name="status" id="status1" required>
                                    <option selected="" value="">Select Status</option>
                                    <option value="active" <?php echo $status == 'active' ? 'selected' : '' ?>>Active</option>
                                    <option value="inactive" <?php echo $status == 'inactive' ? 'selected' : '' ?>>Inactive</option>
                                </select>

                            <?php echo form_error('status'); ?>
                            </div>
						<!--	
								
							  <div <?php if($_SESSION["role"] === 'org_admin'){echo 'style="display: none;"';}?>>
							<div class="alab">
                                <h5>Batch no</h5>
                                <div>
                                <input type="number" name="batch" placeholder="Batch no" value="<?=$batch?>" >
                                <?php echo form_error('batch'); ?>
                            </div>
							</div>

							</div>
								
								
								
							  <div <?php if($_SESSION["role"] === 'org_admin'){echo 'style="display: none;"';}?>>	
								<div class="alab">
                                <h5>Training Start Date</h5>
                                <div>
                                   <input type="date" name="startdate" placeholder="Start Date" value="<?=$startdate?>" >
                                    <?php echo form_error('startdate'); ?>
                                </div>

                            
                            </div>
								
							</div>
								<div <?php if($_SESSION["role"] === 'org_admin'){echo 'style="display: none;"';}?>>	
								 <div class="alab">
                                <h5>Training End Date</h5>
                                <div>
                                   <input type="date" name="enddate" placeholder="End Date" value="<?=$enddate?>" >
                                    <?php echo form_error('enddate'); ?>
                                </div>
                            </div>
							</div>

                            <div <?php if($_SESSION["role"] === 'org_admin'){echo 'style="display: none;"';}?>>	
                            <div class="alab">
                                <h5>Training Start Time</h5>
                                <div>
                                   <input type="time" name="starttime" placeholder="Start Time" value="<?=$starttime?>" >
                                    <?php echo form_error('starttime'); ?>
                                </div>
                            </div>
							</div>	
							
							<div <?php if($_SESSION["role"] === 'org_admin'){echo 'style="display: none;"';}?>>		
                            <div class="alab">
                                <h5>Training End Time</h5>
                                <div>
                                   <input type="time" name="endtime" placeholder="End Time" value="<?=$endtime ?>" >
                                    <?php echo form_error('endtime'); ?>
                                </div>
                            </div>
							</div>
							
                             <div <?php if($_SESSION["role"] === 'org_admin'){echo 'style="display: none;"';}?>>	
                            <div class="alab">
                                <h5>Training Location</h5>
                                <div>
									  <select name="location"  >
                                    <option selected="" value="">Select Location</option>
                                    <option value="Banglore" <?php echo $location == 'Banglore' ? 'selected' : '' ?>>Banglore</option>
                                    <option value="Chennai" <?php echo $location == 'Chennai' ? 'selected' : '' ?>>Chennai</option>
							        <option value="Mumbai" <?php echo $location == 'Mumbai' ? 'selected' : '' ?>>Mumbai</option>
								    <option value="Delhi" <?php echo $location == 'Delhi' ? 'selected' : '' ?>>Delhi</option>
								    <option value="Kolkata" <?php echo $location == 'Kolkata' ? 'selected' : '' ?>>Kolkata</option>
									<option value="Hydrabad" <?php echo $location == 'Hydrabad' ? 'selected' : '' ?>>Hydrabad</option>
										   
                                </select>
								</div>
								 </div>-->
									
                      <!--             <input type="text" name="location" placeholder="Training Location" value=" <?=$location?>" >
                                    <?php echo form_error('location'); ?>
                                </div>
                            </div>
							</div>-->

<!--
                            <div <?php if($_SESSION["role"] === 'org_admin'){echo 'style="display: none;"';}?>>	
                            <div class="alab">
                                <h5>Training Type</h5>
								</div>
									
									
									  <select name="module"  >
                                    <option selected="" value="">Select Status</option>
                                    <option value="skill" <?php echo $module == 'Skill' ? 'selected' : '' ?>>Skill</option>
                                    <option value="technology" <?php echo $module == 'Technology' ? 'selected' : '' ?>>Technology</option>
							        <option value="functional" <?php echo $module == 'Functional' ? 'selected' : '' ?>>Functional</option>
                                </select>
									
									
									
									
									

                            <?php echo form_error('module'); ?>
                            </div>
							</div>	
								
						
								-->
								

                           
                            
							
							
							
                            <input type="submit" name="submit" class="btn btn-primary" value="Submit">

                        </form>
                    </div>
    <?php include_once 'footer.php';?>
                </div>
                <!-- Bootstrap core JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/jquery/jquery.min.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                <!-- Core plugin JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
                <!-- Page level plugin JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/chart.js/Chart.min.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/datatables/jquery.dataTables.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
                <!-- Custom scripts for all pages-->
                <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
                <!-- Custom scripts for this page-->
                <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
                <script src="<?php echo base_url() ?>assets/select2/select2.full.min.js" type="text/javascript"></script>
                <!--   <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script> -->
                <script type="text/javascript">
                    $(document).ready(function(){
                            $("#org_id:not([readonly])").select2({
                                placeholder: "Select Organization",
                                width: '400px'
                            });


                            $(".users_list").select2({
                                placeholder: "Select Users",
                                width: '400px'
                            });

                            $(".kca_a_list, .kca_c_list").select2({
                                placeholder: "Select Knowlege Center",
                                width: '400px'
                            });

                            $(".idpa_a_list, .idpa_c_list").select2({
                                placeholder: "Select MLP",
                                width: '400px'
                            });

                            $(".idp_program,.idp_program1,.idp_program_c,.idp_program_c1").select2({
                                placeholder: "Select Categories",
                                width: '400px'
                            });

                            var programs = <?php echo isset($programs) ? $programs : 'null' ?>;

                            $('.idp_program').on('select2:select', function (e) {
                                var cat_name = e.params.data.text;
                                var cat_id = e.params.data.id;

                                $("#module").append('<div class="col-lg-12 div_' + cat_id + '">' + cat_name + '<div class="col-lg-9"><select class="col-lg-3 select2me" name="selected_' + cat_id + '[]" multiple></select></div></div>');

                                $.ajax({
                                    url: "<?php echo base_url() ?>groups/get_already_selected_value/" + cat_id,
                                    success: function (result) {
                                        var program_idp = [];
                                        $.each(programs, function (index, value) {
                                            if(value.idpid == cat_id) {
                                                program_idp.push(value);
                                            }
                                        });

                                        data = JSON.parse(result);
                                        var aa = [];
                                        $.each(data, function (index, value) {
                                            aa.push(value.id);
                                        });
                                        $('select[name="selected_' + cat_id + '[]"]').select2({
                                            placeholder: "Select Programs",
                                            width: 'auto',
                                            data: program_idp
                                        }).val(aa).trigger("change");
                                    }
                                });
                            });

$('.idp_program').on('select2:unselect', function (e) {
    var b = e.params.data.id;
    $('.div_' + b).remove();
});

////
var programs_c = <?php echo isset($programs) ? $programs : 'null' ?>;

$('.idp_program_c').on('select2:select', function (e) {
    var cat_name = e.params.data.text;
    var cat_id = e.params.data.id;

    $("#mdl-idp_c_access").append('<div class="col-lg-12 div_c_' + cat_id + '">' + cat_name + '<div class="col-lg-9"><select class="col-lg-3 select2me" name="selected_c_' + cat_id + '[]" multiple></select></div></div>');

    $.ajax({
        url: "<?php echo base_url() ?>groups/get_already_selected_value/" + cat_id,
        success: function (result) {
            var program_c_idp = [];
            $.each(programs_c, function (index, value) {
                if(value.idpid == cat_id) {
                    program_c_idp.push(value);
                }
            });

            data = JSON.parse(result);
            var aa = [];
            $.each(data, function (index, value) {
                aa.push(value.id);
            });
            $('select[name="selected_c_' + cat_id + '[]"]').select2({
                placeholder: "Select Programs",
                width: 'auto',
                data: program_c_idp
            }).val(aa).trigger("change");
        }
    });
});

$('.idp_program_c').on('select2:unselect', function (e) {
    var b = e.params.data.id;
    $('.div_c_' + b).remove();
});

                            $('#checkBtn').on('click', function () {
                                checked = $("input[type=checkbox]:checked").length;
                                if (!checked) {
                                    alert("Select atleast one access pages condition.");
                                    return false;
                                }

                            });
                        });

                            function redirect() {
                                var orgid = $('#org_id').val();
                                if ('<?php echo $this->uri->segment(2) ?>' === 'users') {
                                    window.location.href = ' <?php echo base_url() ?>add_new_users/users/' + orgid;
                                }
                            };
                            function deleteprogram(url) {
                                a = confirm("Are you sure to delete?");
                                console.log(a);
                                if (a) {
                                    window.location.href = url;
                                }
                            }
                </script>


            </div>

        </body>
<style>
	.hide{
  display: none;
}
</style>
    </html>
    <!-- <?php }?> -->
<?php
    defined('BASEPATH') or exit('No direct script access allowed');

    //var_dump(config_item('base_url'), base_url());die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $this->config->item('page_title') ?></title>
    <!-- Bootstrap core CSS-->
    <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
    <!-- Navigation-->
    <?php include "sidebar.php"; ?>
    <div class="content-wrapper admpage2 ccntr">
        <div class="container-headbox">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo base_url() ?>dashboard/">Home</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo base_url() ?>competencies/">Competencies Center</a>
                </li>
                <li class="breadcrumb-item active">Competency Modules</li>
            </ol>
            <!-- Icon Cards-->

            <div class="clearfix">
                <center>
                    <h3>Competency Modules For <?php echo $kc->prg_name ?></h3>
                </center>
            </div>
        </div>
        <div class="container-fluid rgpage">
            <div>
                <!--<center><h3>Competency Center</h3></center>-->
                <p align="right">
                    <a data-toggle="modal" data-target="#mdl-add" class="btn btn-primary btn-condensed" style="color: #fff;">Add New</a>&nbsp;&nbsp;
                </p>
            </div>
            <!--<hr>-->
            <div class="container cmptcycntr" style="padding-right: 0px !important;padding-left: 0px !important;margin-top: -50px;">
                <!--<p>List of all Module</p>-->
                <div class="table-responsive">
                    <table class="table table-bordered dataTable" id="dataTable">
                        <thead>
                            <tr>
                                <th style="width: 7%; min-width: 40px; text-align:left;">S.no</th>
                                <th style="width: 33%; min-width: 150px; text-align:left;">Level</th>
                                <th style="width: 50%; min-width: 150px; text-align:left;">Module</th>
                                <th style="width: 10%; min-width: 80px; text-align:left;">Action</th>
                            </tr>
                        </thead>
                        <?php $i = 0;
                        foreach ($list as $row) : $i++;
                        ?>
                            <tr>
                                <td style="text-align:center;"><?php echo $i; ?></td>
                                <td><?php echo $levels[$row->cmdl_level] ?></td>
                                <td><?php echo $row->prg_title ?></td>
                                <td>
                                    <span><a href="#" class="programeditccenter" data-pid="<?= $row->id ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                    <span><a href="#" class="delete" onclick="deleteprogram('<?php echo base_url() ?>competencies/deletemodule/<?php echo $row->id ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>
            <?php include_once('footer.php'); ?>
        </div>
    </div>
    <div class="modal fade" id="mdl-add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Module</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url() ?>competencies/addmodule/<?php echo $kc->prg_id ?>" method="post" id="frm-add">
                        <div class="form-group">
                            <label for="cmdl_level" class="control-label">Level</label>
                            <select class="form-control" name="cmdl_level" placeholder="Level" required>
                                <?php foreach($levels as $k => $itm): ?>
                                    <option value="<?php echo $k ?>"><?php echo $itm ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="cmdl_kc_id" class="control-label">Module</label>
                            <select class="form-control" name="cmdl_kc_id" placeholder="Module Name" required>
                                <?php
                                    $kca_list = json_decode(json_encode($list), true);
                                    $kca_kc_id = array_column($kca_list, 'cmdl_kc_id');
                                ?>
                                <?php foreach($mdllist as $k => $itm): ?>
                                    <?php if(in_array($itm->prg_id, $kca_kc_id)) {continue;} ?>
                                    <option value="<?php echo $itm->prg_id ?>"><?php echo $itm->prg_name ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="mdl-edit" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
        <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Module</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url() ?>competencies/updatemodule" method="post" id="usersform">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="cmdl_level" class="control-label">Level</label>
                                <select class="form-control" id="cmdl_level" name="cmdl_level" placeholder="Level" required>
                                    <?php foreach($levels as $k => $itm): ?>
                                        <option value="<?php echo $k ?>"><?php echo $itm ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="cmdl_kc_id" class="control-label">Module</label>
                                <select class="form-control" id="cmdl_kc_id" name="cmdl_kc_id" placeholder="Module Name" readonly="true">
                                    <?php foreach($mdllist as $k => $itm): ?>
                                        <option value="<?php echo $itm->prg_id ?>"><?php echo $itm->prg_name ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <input type="hidden" id="id" name="id" />
                        <input type="hidden" id="cmdl_c_id" name="cmdl_c_id" value="<?php echo $kc->prg_id ?>" />
                        <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"> </script>
    <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>

    <script type="text/javascript">
       $(document).on('click', '.programeditccenter',function (e) {
                var pid = $(this).data('pid');
                $.post('<?php echo base_url() ?>competencies/editmodule', {'id': pid}, function(rs) {
                    if (rs) {
                        rs = JSON.parse(rs);
                        console.log(rs);
                        $('#mdl-edit .modal-body #id').val(rs.id);
                        $('#mdl-edit .modal-body #cmdl_c_id').val(rs.cmdl_c_id);
                        $('#mdl-edit .modal-body #cmdl_level').val(rs.cmdl_level);
                        $('#mdl-edit .modal-body #cmdl_kc_id').val(rs.cmdl_kc_id);
                        $('#mdl-edit').modal('show');
                    } else {
                        alert("No record found")
                    }
                });
            });

        function deleteprogram(url) {
            a = confirm("Are you sure to delete?");
            if (a) {
                window.location.href = url;
            }
        }
    </script>
</body>
</html>
<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper admpage idpcontent">
    <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <?php if($this->uri->segment(2)=='client') { ?>
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>knowledge_center/client/<?php echo $this->uri->segment(3) ?>">Client Knowledge Center</a>
          
        </li>
        <li class="breadcrumb-item active"><?php  echo $orgdetails[0]->org_name ; ?> - MLP Page Content</li>
         <?php } else{ ?>
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>knowledge_center/aggregator">Aggregator Knowledge Center</a>    
        </li>
        <li class="breadcrumb-item active">MLP Page Content</li>
        <?php } ?>
        
      </ol>
      <!-- Icon Cards-->

      <div class="clearfix">
        <center>
          <h3>MLP PAGE CONTENT</h3>
        </center>
      </div>
    </div>
    <div class="container-fluid rgpage idpc">
      <div class="container">

        <?php $notification = $this->session->flashdata('updatenotification');
        if ($notification) {
        ?>
          <div class="alert alert-success">
            <?php echo $notification; ?>
          </div>
        <?php
        } ?>
        <?php echo form_error('updatenotification'); ?>

        <div  style="float: right;position: relative; z-index: 1000;">
            
            <a href="<?php echo base_url() ?>idp_content/add/<?php echo $this->uri->segment(2)?>/<?php echo $this->uri->segment(3)?>" class="btn btn-primary btn-condensed">Add MLP</a>

        </div>

        <div>
         
          <table class="table table-bordered dataTable customTbl customColTbl idptable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style=" margin-top: -35px; z-index: 1;">
            <thead>
              <tr role="row">
                <th style="width: 10%;min-width: 50px;">S.no</th>
                <th style="width: 10%;min-width: 50px;">Title</th>
                <th style="width: 20%;min-width: 150px;">Sub Title</th>
                <th style="width: 40%;min-width: 150px;">Description</th>
                <th style="width: 10%;min-width: 50px;">Action</th>
              </tr>
            </thead>
            <?php $i = 0;
            foreach ($list as $row) : $i++;  ?>
              <tr>

                <td style="text-align: center;"><?php echo $i; ?></td> <!-- php 5.6 version -->
                <td><?php echo $row->title ?></td>
                <td><?php echo $row->subtitle ?></td>
                <td><?php echo $row->description ?></td>
                <td class="action"><span><a href="<?php echo base_url() ?>edit_idp_content/<?php echo $this->uri->segment(2)?>/<?php echo $this->uri->segment(3)?>/<?php echo $row->id ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                  <span><a onclick="delete_idp('<?php echo base_url() ?>idp_content/delete/<?php echo $row->id ?>/<?php echo $urlsegment ?>')" href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                </td>
              </tr>

            <?php endforeach; ?>
          </table>

        </div>

      </div>
      <?php include_once('footer.php'); ?>
      <!-- Bootstrap core JavaScript-->
      <script src=" <?php echo base_url() ?>vendor/jquery/jquery.min.js"> </script>
      <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- Core plugin JavaScript-->
      <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
      <!-- Page level plugin JavaScript-->
      <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
      <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
      <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
      <!-- Custom scripts for this page-->
      <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
      <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>
      <script type="text/javascript">
        function delete_idp(url) {
          a = confirm("Are you sure to delete?");
          if (a) {
            window.location.href = url;
          }
        }
      </script>
    </div>
</body>

</html>
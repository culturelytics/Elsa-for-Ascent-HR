<!-- <?php
        if (!isset($_SESSION["email"])) {
            header("Location: login1");
        } else {
        ?> -->

<?php
    defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $this->config->item('page_title') ?></title>
        <!-- Bootstrap core CSS-->
        <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Page level plugin CSS-->
        <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
        <!-- Custom styles for this template-->
        <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
    </head>
    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <!-- Navigation-->
        <?php include "sidebar.php"; ?>
        <div class="content-wrapper admpage2 kcntr">
            <div class="container-headbox">
                <!-- Breadcrumbs-->
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo base_url() ?>dashboard/">Home</a>
                    </li>
                    <li class="breadcrumb-item active">Upcoming Events</li>
                </ol>
                <!-- Icon Cards-->
                <div class="clearfix">
                    <center><h3>UPCOMING EVENTS</h3></center>
                    <?php if($_SESSION['role'] === 'super_admin') { ?>
                    <div class="row full-width">
                        <div class="col-md-4 col-sm-4">
                            <label for="organization" class="text-right pull-right form-label cdb-lbl">Select Organization</label>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <div class="form-group" style="display: inline">
                                <select name="organization_id" id="organization_id" class="form-control orgid_<?php echo $organization_id?>">
                                    <option value="">Global</option>
                                    <?php foreach ($organizations as $k => $org) : ?>
                                        <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-4">
                            <button style="padding: 1px 10px 1px 10px;" type="button" id="orgIdSubmit" class="btn btn-primary btn-condensed" onclick="redirect();">Submit</button>
                        </div>    
                    </div>
                    <?php }?>
                </div>
            </div>
            <div class="container-fluid rgpage">
                <div>
                    <p align="right"><a data-toggle="modal" data-target="#addEvents" class="btn btn-primary btn-condensed" style="color: #fff;">Add Event</a>&nbsp;&nbsp;</p>
                </div>
                <div class="container kcenter" style="padding-right: 0px !important;padding-left: 0px !important;margin-top: -50px;">
                    <!--<p>List of all Module</p>-->
                    <div class="table-responsive">
                        <table class="table table-bordered dataTable customTbl customColTbl" id="dataTable" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                            <thead>
                                <tr>
                                    <th style="width: 10%;">S.no</th>
                                    <th style="width: 60%;">Title</th>
                                    <th style="width: 15%;">Status</th>
                                    <th style="width: 15%;">Action</th>
                                </tr>
                            </thead>
                            <?php
                            $i = 0;
                            foreach ($list as $row) : $i++;
                            ?>
                                <tr>
                                    <td style="text-align: center"><?php echo $i; ?></td> <!-- php 5.6 version -->
                                    <td class="cke_kc_content_old"><?php echo $row->title; ?></td>
                                    <td class="cke_kc_content_old"><?php echo $row->status; ?></td>
                                    <td>
                                        <span><a href="#" class="programedit" title="Edit" data-pid="<?= $row->id ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                        <span><a href="#" class="delete" title="Delete" onclick="deleteprogram('<?php echo base_url() ?>upcoming_events/delete/<?php echo $row->id ?>/<?php echo $this->uri->segment(3)?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                    </td>
                                </tr><?php endforeach; ?>
                        </table>
                    </div>

                </div>
                <!-- /.container-fluid-->
                <!-- /.content-wrapper-->
                <footer class="sticky-footer">
                    <div class="container">
                        <div class="text-center">
                            <small>Copyright © 2018 e2e People Practices</small>
                        </div>
                    </div>
                </footer>
                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fa fa-angle-up"></i>
                </a>
                <!-- Logout Modal-->
            </div>
        <?php include_once('footer.php'); ?>
        </div>


        <div class=" modal fade" id="addEvents" tabindex="-1" role="dialog" aria-labelledby="eventModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:800px;max-width: 800px;" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Add Event</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
					<?php $org_id = $_SESSION['org_id']; ?>
                    <div class="modal-body">
                        <form action="<?php echo base_url() ?>upcoming_events/events/<?php echo $org_id; ?>" method="post" class="kedit" id="usersform">
                            <table>
                                <tr>
                                    <td class="keditfirst"><span style="padding: 1px 3px 10px 30px;">Title:</span></td>
                                    <td>
                                        <div>
                                            <input type="text" name="evnt_name" placeholder="Event Title" required>
                                            <?php echo form_open('evnt_name'); ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="keditfirst"><span style="padding: 1px 3px 10px 30px;">Description:</span></td>
                                    <td colspan="2">
                                        <div class="form-group">
                                            <textarea id="evnt_desc" name="evnt_desc" required></textarea>
                                            <?php echo form_open('evnt_desc'); ?>
                                        </div>
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td class="keditfirst"><span style="padding: 1px 3px 10px 30px;">Status:</span></td>
                                    <td>
                                        <div>
                                            <select name="evnt_status" id="status1" required>
                                            <option selected="" value="">Select Status</option>
                                            <option value="active">active</option>
                                            <option value="inactive">inactive</option>
                                            </select>																	
                                        </div>
                                    </td>
                                </tr>
                            </table> 
                            <input type="hidden" name="org_id" value="<?php echo $this->uri->segment(3)?>" />
                            <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
            <div class="modal-dialog" style="width:800px;max-width: 800px;" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Event</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo base_url() ?>upcoming_events/update" method="post" class="kedit" id="usersform">
                            <table>
                                <tr>
                                    <td class="keditfirst"><span style="padding: 1px 3px 10px 30px;">Title:</span></td>
                                    <td colspan="2">
                                        <div class="form-group">
                                            <input type="text" name="prg_name1" placeholder="Event Title" id="prg_name1" value="" required>
                                            <input type="hidden" name="prg_id1" placeholder="Event Title" id="prg_id1" value="" required>
                                            <input type="hidden" name="org_id" value="<?php echo $this->uri->segment(3)?>">
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="keditfirst"><span style="padding: 1px 3px 10px 30px;">Description:</span></td>
                                    <td colspan="2">
                                        <div class="form-group">
                                            <textarea id="prg_desc1" name="prg_desc1" required><?= $kc[0]->description; ?></textarea>
                                            <?php echo form_error('prg_desc1'); ?>
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td class="keditfirst"><span style="padding: 1px 3px 10px 30px;">Status:</span></td>
                                    <td>
                                        <div>
                                            <select name="prg_status" id="prg_status1" required style="width: 100%; margin: 5px 0px; padding: 8px 10px;">
                                            <option selected="" value="">Select Status</option>
                                            <option value="active">active</option>
                                            <option value="inactive">inactive</option>
                                            </select>																	
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>


        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- Core plugin JavaScript-->
        <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
        <!-- Page level plugin JavaScript-->
        <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
        <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
        <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
        <!-- Custom scripts for all pages-->
        <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
        <!-- Custom scripts for this page-->
        <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
        <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>

        <script type="text/javascript">
            // Define the toolbar groups as it is a more accessible solution.
            CKEDITOR.replace('evnt_desc', {            
                toolbar: [{
                        "name": "basicstyles",
                        "items": ['Bold']
                    },
                    {
                        "name": 'paragraph',
                        "groups": ['list'],
                        "items": ['BulletedList']
                    },
                ]
            });

            $(document).on('click', '.programedit',function (e) {
               
                    var pid = $(this).data('pid');
                    $.post('<?php echo base_url() ?>upcoming_events/edit', 'pid=' + pid, function(rs) {
                        if (rs) {
                            rs = JSON.parse(rs);
                            $('#prg_id1').val(rs[0].id);
                            $('#prg_name1').val(rs[0].title);                       
                            $('#prg_status1').val(rs[0].status);
                            $('#myModal').modal('show');
                            
                            if(CKEDITOR.instances['prg_desc1']){
                                CKEDITOR.instances['prg_desc1'].destroy();
                            }						
        
                            CKEDITOR.replace('prg_desc1', {
                                // Define the toolbar groups as it is a more accessible solution.
                                toolbar: [{
                                        "name": "basicstyles",
                                        "items": ['Bold']
                                    },
                                    {
                                        "name": 'paragraph',
                                        "groups": ['list'],
                                        "items": ['BulletedList']
                                    },
                                ]
                            });
                            $('#prg_desc1').val(rs[0].description);
                        } else {
                            alert("No record found")
                        }
                    });
                });
        

            function deleteprogram(url) {
                a = confirm("Are you sure to delete?");
                if (a) {
                    window.location.href = url;
                }
            }
            
            function redirect() {
                    var orgid = $('#organization_id').val();
                    window.location.href =  ' <?php echo base_url()?>upcoming_events/events/'+orgid;
                 
                };
        </script>
    </body>
</html>
<!-- <?php } ?> -->
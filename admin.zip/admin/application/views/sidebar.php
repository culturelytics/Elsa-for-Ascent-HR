<?php include(APPPATH.'config/config.php');?>
 <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top" id="mainNav">
     <?php if($_SESSION['role'] === 'org_admin'){ ?>
	 <a class="navbar-brand" href="<?php echo base_url() ?>">HR Leader Panel </a> 
	 <?php } ?>
	 <?php if($_SESSION['role'] === 'super_admin'){ ?>
	 <a class="navbar-brand" href="<?php echo base_url() ?>"> Elsa Admin Panel </a> 
	 <?php } ?>
	 <?php if($_SESSION['role'] === 'group_admin'){ ?>
	 <a class="navbar-brand" href="<?php echo base_url() ?>">  Trainer Panel </a> 
	 <?php } ?>
	 
    <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarResponsive">
      <ul class="navbar-nav navbar-sidenav" id="exampleAccordion">
        <li class="nav-item  <?= $this->uri->segment(1)=='' || $this->uri->segment(1)=='dashboard' || $this->uri->segment(1)=='dashboard_company' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Dashboard">
          <a class="nav-link" title="Dashboard" href="<?php echo base_url('dashboard/index'); ?>">
            <i class="fa fa-fw fa-dashboard"></i>
            <span class="nav-link-text">Dashboard</span>
          </a>
        </li>
        <li class="nav-item <?=$this->uri->segment(1)=='add_new_users' || $this->uri->segment(1)=='addmodulecontent' || $this->uri->segment(1)=='edituser' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Charts">
          <a class="nav-link" title="User Management" href="<?php echo base_url('add_new_users');?>/users/1">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">User Management</span>
          </a>
        </li>
        <?php if($_SESSION['role'] === 'org_admin' || $_SESSION['role'] === 'group_admin') { ?>
        <li class="nav-item <?=$this->uri->segment(1)=='groups' || $this->uri->segment(1)=='editgroup' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Groups">
          <a class="nav-link" title="Group Management" href="<?php echo base_url('groups');?>">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">Group Management</span>
          </a>
        </li>
        <?php } ?>
        <?php $org_id = $_SESSION['org_id']; ?>
        <?php if($_SESSION['role'] === 'super_admin') { ?>
        <li class="nav-item <?=$this->uri->segment(1)=='org_admins' || $this->uri->segment(1)=='editgroup' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Groups">
          <a class="nav-link" title="Group Management" href="<?php echo base_url('org_admins');?>">
            <i class="fa fa-fw fa-users"></i>
            <span class="nav-link-text">Group Management</span>
          </a>
        </li>
				<?php if($_SESSION['role'] != 'super_admin') { ?>
        <li class="nav-item <?=$this->uri->segment(1)=='program_register_list' || $this->uri->segment(1)=='edit_program_register' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" title="Dashboard" href="<?php echo base_url('program_register_list'); ?>">
            <i class="fa fa-fw fa-list-ul"></i>
            <span class="nav-link-text">Program Register List</span>
          </a>
				</li>
				<?php } ?>
        <?php } ?>
        <li class="nav-item  <?=$this->uri->segment(1)=='clients_query_list' || $this->uri->segment(1)=='edit_query_list' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="<?php echo base_url('clients_query_list');?>">
            <i class="fa fa-fw fa-question-circle-o"></i>
            <span class="nav-link-text">MLP Log</span>
          </a>
        </li>
        <?php if($_SESSION['role'] === 'super_admin') { ?>
        <li class="nav-item <?=(($this->uri->segment(1)=='knowledge_center' && $this->uri->segment(2)!=='client' && $this->uri->segment(4)== null) ||($this->uri->segment(1)=='programs' && $this->uri->segment(2)=='aggregator') ||($this->uri->segment(1)=='idp_content' && $this->uri->segment(2)=='aggregator')||($this->uri->segment(2)=='add_content' && $this->uri->segment(4)!=='client') || ($this->uri->segment(1)=='idp_content' && $this->uri->segment(2)=='add' && $this->uri->segment(3)=='aggregator') || ($this->uri->segment(1)=='edit_idp_content' && $this->uri->segment(2)=='aggregator'))?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">
            <a class="nav-link" href="<?php echo base_url('knowledge_center/aggregator');?>">
            <i class="fa fa-fw fa-university"></i>
            <span class="nav-link-text">Aggregator Knowledge Center</span>
          </a>
        </li>
				<?php } ?>
				<?php if($_SESSION['role'] != 'super_admin') { ?>
        <li class="nav-item <?=(($this->uri->segment(1)=='knowledge_center' && $this->uri->segment(2)=='client') ||($this->uri->segment(1)=='programs' && $this->uri->segment(2)=='client') ||($this->uri->segment(1)=='idp_content' && $this->uri->segment(2)=='client')||($this->uri->segment(2)=='add_content' && $this->uri->segment(4)=='client') || ($this->uri->segment(1)=='idp_content' && $this->uri->segment(2)=='add' && $this->uri->segment(3)=='client') || ($this->uri->segment(1)=='edit_idp_content' && $this->uri->segment(2)=='client'))?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="<?php echo base_url() ?>knowledge_center/client/<?php echo $org_id; ?>">
            <i class="fa fa-fw fa-briefcase"></i>
            <span class="nav-link-text">Client Knowledge Center</span>
          </a>
				</li>
				<?php } ?>
        <?php if($_SESSION['role'] === 'super_admin') { ?>
         <li class="nav-item <?=$this->uri->segment(1)=='competencies'?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="<?php echo base_url('competencies');?>">
            <i class="fa fa-fw fa-shield"></i>
            <span class="nav-link-text">Competencies Center</span>
          </a>
        </li>
				<?php } ?>
				
        <li class="nav-item <?=$this->uri->segment(1)=='upcoming_events' || $this->uri->segment(1)=='edit_upcoming_events' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Upcoming Events">
          <a class="nav-link " href="<?php echo base_url() ?>upcoming_events/events/<?php echo $org_id; ?>">
            <i class="fa fa-fw fa-calendar"></i>
            <span class="nav-link-text">Upcoming Events</span>
          </a>
				</li>
	
          <li class="nav-item <?=$this->uri->segment(1)=='competencies'?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="<?php echo base_url('mis_tracker');?>">
            <i class="fa fa-table"></i>
            <span class="nav-link-text">MIS Tracker</span>
          </a>
        </li>


         <!--<li class="nav-item <?=$this->uri->segment(1)=='programs'?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">-->
          <!--<a class="nav-link" href="<?php // echo base_url('programs');?>">-->
            <!--<i class="fa fa-fw fa-table"></i>-->
            <!--<span class="nav-link-text">Module</span>-->
          <!--</a>-->
        <!--</li>-->

        <!--<li class="nav-item <?=$this->uri->segment(1)=='idp_content'|| $this->uri->segment(1)=='edit_idp_content'?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">-->
          <!--<a class="nav-link" href="<?php // echo base_url('idp_content');?>">-->
            <!--<i class="fa fa-fw fa-table"></i>-->
            <!--<span class="nav-link-text">IDP Page content</span>-->
          <!--</a>-->
        <!--</li>-->
        <?php if($_SESSION['role'] === 'super_admiNNOTNEEDED') { ?>
		  <li class="nav-item <?=$this->uri->segment(1)=='feedbackContent'?'active':''?>" data-toggle="tooltip" data-placement="right" title="Tables">
          <a class="nav-link" href="<?php echo base_url('feedbackContent');?>">
            <i class="fa fa-fw fa-envelope"></i>
            <span class="nav-link-text">Online Feedback</span>
          </a>
        </li>
        <?php if ($_SESSION['role'] === 'super_adminNOTNEEDED' && $config['show_admin_banner'] !== null && $config['show_admin_banner'] !== false ){?>
        <li class="nav-item <?=$this->uri->segment(1)=='update_banner_images' || $this->uri->segment(1)=='editbanner' ?'active':''?>" data-toggle="tooltip" data-placement="right" title="Banner Images">
          <a class="nav-link " href="<?php echo base_url('update_banner_images'); ?>">
            <i class="fa fa-fw fa-image"></i>
            <span class="nav-link-text">Banner images</span>
          </a>
        </li>
        <?php }?>
        <?php } ?>
		  
		  
      </ul>

      <ul class="navbar-nav ml-auto">
        <li class="nav-item navuserinfo">
          <span class="welcome">Welcome,&nbsp;</span><font><?php echo $_SESSION['user_name']; ?></font>
        </li>
        <li class="nav-item">
          <a class="nav-link" data-toggle="modal" data-target="#exampleModal">
            <i class="fa fa-fw fa-sign-out"></i>Logout</a>
        </li>
      </ul>
    </div>
  </nav>

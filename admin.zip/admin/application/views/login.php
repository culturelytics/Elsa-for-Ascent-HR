<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>/assets/css/sb-admin.css" rel="stylesheet">
</head>
  <body>
    <div class="col-lg-12  col-sm-12 col-xs-12">
  <div class="logincontainer loginfields">
    <div id='login_form'>
    <div class="loginrow">
      <form action="<?php echo base_url();?>login/process" method='post' name='process' enctype="multipart/form-data">
        <center><h2>Admin Login</h2></center>
        <br />  
        <?php if(! is_null($msg)) echo $msg;?>   
        <label for='username'>Username</label>
        <input type='email' name='email' id='username' size='25' /><br />
        <label for='password'>Password</label>
        <input type='password' name='password' id='password' size='25' /><br />                            
        <input type='Submit' value='Login' />            
     </form>
     </div>
    </div>
    </div>
    </div>
  </body>
</html>
<!-- <?php
if(!isset($_SESSION["email"])){
 header("Location: login1");
}
else
{
?> -->

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
<?php include "sidebar.php"; ?>
  <div class="content-wrapper admpage2">
    <div class="container-fluid rgpage">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <li class="breadcrumb-item active">My Dashboard</li>
      </ol>
      <!-- Icon Cards-->
      
       <center><h3>Add new Users</h3></center>

       <div class="container">
       <hr>
        <form action="<?php echo base_url() ?>add_new_users/adduser" method="post" id="usersform">
           <div>
               
                <input type="text" name="name" placeholder="Name" required>
           </div>
            <div>
    
                <input type="email" name="email" placeholder="Email id" required>
             </div>
            <div>
               
                <input type="text" name="password" placeholder="Password" required>
            </div>
            <div>
                <input type="text" name="phone" placeholder="Contact No" required>
            </div>
            <div>
                <select name="status" id="status1" required>
                  <option selected="" value="">Select Status</option>
                  <option value="active">active</option>
                  <option value="inactive">inactive</option>
                </select>  
              </div>
            
            <div>
              <h5> Type of access to user</h5>
              <input type="checkbox" name="access[]" value="Knowledge" id="myCheck" >Knowledge Center Pages<br>
              <input type="checkbox" name="access[]" value="Client" id="myCheck" >Clients Page 
            </div>
              <input type="submit" name="submit" value="submit" id="checkBtn">
            
        </form>
<hr>
<div>
  <p>List of all Login access users</p>
    <table class="table table-bordered dataTable" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
  <thead>
    <tr>
      <th>S.no</th>
      <th>Name</th>
      <th>Email</th>
      <th>Contact</th>
      <th>Status</th>
       <th>Access Type</th>
      <th>Action</th>
    </tr>
    </thead>
    <?php $i=0; foreach ($list as $row): $i++;  ?> 
       
    <tr>
      <td><?php echo $i;?></td> <!-- php 5.6 version -->
      <td><?php echo $row->name?></td>
     <td><?php echo $row->email?></td>
     <td><?php echo $row->password?></td>
     <td><?php echo $row->status?></td>
     <td><?php echo $row->access_type?></td>
     
      <td><span class="e1"><a href="<?php echo base_url() ?>edituser/<?php  echo $row->id?>">edit</a></span><span class="d1"> <a href="<?php echo base_url() ?>add_new_users/delete/<?php  echo $row->id?>">delete</a></span></td>
    </tr>
    </form>
    <?php endforeach; ?>
  </table>
</div>
       
    </div>
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © 2018 e2e People Practices</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
           
             <a class="btn btn-primary" href="<?php echo base_url('login/logout')?>" ">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>
  </div>
<script type="text/javascript">
$(document).ready(function () {
    $('#checkBtn').click(function() {
      checked = $("input[type=checkbox]:checked").length;

      if(!checked) {
        alert("Select atleast one access pages condition.");
        return false;
      }

    });
});
</script>


</body>

</html>
<!-- <?php } ?> -->
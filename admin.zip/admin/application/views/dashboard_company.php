<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>/assets/css/sb-admin.css" rel="stylesheet">
  <link href=" <?php echo base_url() ?>/assets/vendor/loading-bar/loading-bar.min.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper cdb">
    <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <li class="breadcrumb-item active">Dashboard</li>
      </ol>
      <!-- Icon Cards-->
<?php if($_SESSION['role'] === 'super_admin') { ?>
		       <div class="clearfix">
          <form action="/ascent/admin/dashboard/index" method="GET" class="form form-horizontal form-inline">
			   <div class="row full-width">
              <div class="col-md-4 col-sm-4">
                <label for="organization" class="text-right pull-right form-label cdb-lbl">Select Organisation</label>
              </div>
              <div class="col-md-8 col-sm-8">
                <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="form-control">
                    <option value="">All Organisations</option>
                    <?php foreach ($organizations as $k => $org) : ?>
                      <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                    <?php endforeach; ?>
                  </select>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->

              </div>
<?php } ?>

      <?php if($_SESSION['role'] === 'group_admin' || $_SESSION['role'] === 'org_admin') { ?>
	<?php if($_SESSION['role'] === 'org_admin') { ?>
				   <h3 style="text-align:center">Demo Organization</h3>
			<div class="row full-width" style="margin-left:60px">
			<div class="col-md-3 col-sm-3">	  
			<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module ">
                      <div class="number counternew">2</div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 trainer"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">Total Trainers</div>
                      </div>
                    </div>
			</div>
			<div class="col-md-3 col-sm-3">	  
			<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module">
                      <div class="number counternew">10</div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 user"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">Total Locations</div>
                      </div>
                    </div>
			</div>
			<div class="col-md-3 col-sm-3">	  
				<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module">
                      <div class="number counternew">6</div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 user"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">Total Departments</div>
                      </div>
                    </div>
			</div>
			<div class="col-md-3 col-sm-3 pull-left">	  
				<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module ">
                      <div class="number counternew"><?= $cntdata['Module'] ?></div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 modules"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">MODULES</div>
                      </div>
                    </div>
			</div>
		</div>
<?php }?>
<?php if($_SESSION['role'] === 'group_admin') { ?>
	   <h3 style="text-align:center">Overall Group Demographics</h3>
			<div class="row full-width" style="margin-left:60px">
			<div class="col-md-3 col-sm-3">	  
			<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module ">
                      <div class="number counternew">1</div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 trainer"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">Total Trainers</div>
                      </div>
                    </div>
			</div>
			<div class="col-md-3 col-sm-3">	  
			<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module">
                      <div class="number counternew">3</div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 user"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">Total Locations</div>
                      </div>
                    </div>
			</div>
			<div class="col-md-3 col-sm-3">	  
				<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module">
                      <div class="number counternew">3</div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 user"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">Total Departments</div>
                      </div>
                    </div>
			</div>
		<div class="col-md-3 col-sm-3 pull-left">	  
				<div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module ">
                      <div class="number counternew"><?= $cntdata['Module'] ?></div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 modules"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">MODULES</div>
                      </div>
                    </div>
			</div>
		</div>
<?php }?>
        <div class="clearfix">
          <form action="/ascent/admin/dashboard/index" method="GET" class="form form-horizontal form-inline">
			 <div class="row full-width" style="margin-left:60px">
			 
			  <div class="col-md-3 col-sm-3">
			  &nbsp; 
			  </div>
				
			  <div class="col-md-3 col-sm-3">
				 <label for="organization" class="text-right pull-left form-label cdb-lbl">Select Location</label>
				 </div>
				 
		     <div class="col-md-3 col-sm-3">
		      <label for="organization" class="text-right pull-left form-label cdb-lbl">Select Department</label>
				 </div>
				 <div class="col-md-3 col-sm-3">
				 <label for="organization" class="text-right pull-left form-label cdb-lbl">Select Modules</label>
				 </div>
           </div>	
	<?php if($_SESSION['role'] === 'org_admin') { ?>		 
		<div class="row full-width" style="margin-left:80px">
			 
			<div class="col-md-3 col-sm-3">
				 <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="">
                    <option value="">All Trainers      </option>
					<option value="">Sukumar</option>
					 <option value="">Deepak</option>
                    <!--php foreach ($organizations as $k => $org) : ?>
                      <option value="<php echo $org['id'] ?>" <php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><php echo $org['org_name'] ?></option>
                    <php endforeach; -->
                  </select>
					<br>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div>
			
			<div class="col-md-3 col-sm-3">
				 <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="form-control">
                    <option value="">All Locations</option>
					 <option value="">Bangalore</option>
					  <option value="">Mumbai</option>
					   <option value="">Delhi</option>
					  <option value="">chennai</option>
					  <option value="">Kolkata</option>
					  <option value="">Bhopal</option>
					  <option value="">Ahmedabad</option>
					  <option value="">Hyderabad</option>
					  <option value="">Visakhapatnam</option>
					  <option value="">Mysore</option>
                    <!--php foreach ($organizations as $k => $org) : ?>
                      <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                    <php endforeach; ?-->
                  </select>
					 <br>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div>
			<div class="col-md-3 col-sm-3">
				 <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="form-control">
                    <option value="">All Departments</option>
					  <option value="">IT</option>
					  <option value="">Manufacturing</option>
					  <option value="">Sales</option>
					  <option value="">Marketing</option>
					  <option value="">R&D</option>
					  <option value="">Finance</option>
                    <!--php foreach ($organizations as $k => $org) : ?>
                      <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                    <php endforeach; -->
                  </select>
					 <br>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div>
			<div class="col-md-3 col-sm-3">
				 <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="form-control">
                    <option value="">All Modules</option>
					  <option value="">Induction Module</option>
					  <option value="">Business Communication</option>
					  <option value="">Stake Holder</option>
					  <option value="">Induction 123</option>
					  <option value="">Test</option>
					  <option value="">How do I solve an issue?</option>
					  <option value="">How do to talk to a stranger?</option>
                    <!--php foreach ($organizations as $k => $org) : ?>
                      <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                    <php endforeach; -->
                  </select>
					 <br>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div>
		</div>
  <?php }?> 
<?php if($_SESSION['role'] === 'group_admin') { ?>		 
		<div class="row full-width" style="margin-left:60px">
			<div class="col-md-3 col-sm-3">
				&nbsp; 
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div> 
			
			<div class="col-md-3 col-sm-3">
				 <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="form-control">
                    <option value="">All Locations</option>
					 <option value="">Bangalore</option>
					  <option value="">Mumbai</option>
					   <option value="">Delhi</option>
                    <!--php foreach ($organizations as $k => $org) : ?>
                      <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                    <php endforeach; ?-->
                  </select>
					 <br>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div>
			<div class="col-md-3 col-sm-3">
				 <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="form-control">
                    <option value="">All Departments</option>
					  <option value="">Information Technology</option>
					  <option value="">Business Intelligence</option>
					  <option value="">Sales</option>
                    <!--php foreach ($organizations as $k => $org) : ?>
                      <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                    <php endforeach; -->
                  </select>
					 <br>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div>
				<div class="col-md-3 col-sm-3">
				 <div class="form-group" style="display: inline">
                  <select name="organization_id" id="organization_id" class="form-control">
                    <option value="">All Modules</option>
					  <option value="">Induction Module</option>
					  <option value="">Business Communication</option>
					  <option value="">Stake Holder</option>
					  <option value="">Induction 123</option>
					  <option value="">Test</option>
					  <option value="">How do I solve an issue?</option>
					  <option value="">How do to talk to a stranger?</option>
                    <!--php foreach ($organizations as $k => $org) : ?>
                      <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                    <php endforeach; -->
                  </select>
					 <br>
                  &nbsp;<input type="submit" value="Submit" class="btn btn-primary btn-sm" />
                  &nbsp;&nbsp;
                </div>
                <!--div class="pull-right" style="display: inline"><a href="<php echo base_url() ?>dashboard/report/<php echo $organization_id ?>" target="_blank" title="Location based trainer report">Location based trainer report</a></div-->
			</div>
		</div>
  <?php }?>         
			  
          </form>
        </div>
      <?php } else { ?>
        
        <div class="clearfix">
          <center><h3><?php echo $_SESSION['org_name'] ?></h3></center>
          <!--div class="pull-right" style="display: inline"><a href="<?php echo base_url() ?>dashboard/report/" target="_blank" title="Overall Industry Report">Location based trainer report</a></div-->
        </div>
      <?php } ?>
    </div>
    <div class="container-fluid">
      <div class="container cdbcontent">
        <?php if (count($tsdata['users']) == 0) : ?>
          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
            <br><font class="nodata">No data available!</font><br><br><br>
          </div>
        <?php endif; ?>
        <?php
        function numf($number, $decimals = 0) {
          if ($number < 1000) {
            // Anything less than a million
            $format = number_format($number, $decimals);
          } else if ($number < 1000000) {
            // Anything less than a million
            $format = number_format($number / 1000, $decimals) . 'K';
          } else if ($number < 1000000000) {
              // Anything less than a billion
              $format = number_format($number / 1000000, $decimals) . 'M';
          } else {
              // At least a billion
              $format = number_format($number / 1000000000, $decimals) . 'B';
          }
          echo $format;
        }

        if (count($tsdata['users']) > 0) {
        ?>
          <div class="page-light">
            <div class="row page-light">
              <div class="col-md-6 half-box halfboxNone">
                <div class="panel">
                  <div class="panel-heading main-heading text-center">
                    <h4>Online Learning Overview </h4>
                  </div>
                  <div class="panel-body pad-10">
                    <div class="row clearfix wpn">
                      <?php foreach ($oloverview as $olo) { ?>
                        <div class="pnl-olobox">
                          <div class="info-box infbv infb-1 bg-pink hover-expand-effect1">
                            <div class="number counternew"><?php echo $olo['number'] ?></div>
                            <div class="info-icon">
                              <div class="olo-icon oloi-46 <?php echo $olo['icon'] ?>"></div>
                            </div>
                            <div class="content">
                              <div class="info-text"><?php echo $olo['label'] ?></div>
                            </div>
                          </div>
                        </div>
                      <?php } ?>
                    </div>
                  </div>
                </div>
                <div class="row clearfix wpn">
                  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                    <div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module">
                      <div class="number counternew"><?= $cntdata['Module'] ?></div>
                      <div class="info-icon">
                        <div class="olo-icon oloi-46 modules"></div>
                      </div>
                      <div class="content">
                        <div class="info-text">MODULES</div>
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 topmod"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Top Modules Learnt</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['modules']) || count($tsdata['modules']) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                  <br><font class="nodata">No data available!</font><br><br><br>
                                </div>
                              <?php else : ?>
                                <?php foreach (array_slice($tsdata['modules'], 0, 3, true) as $km => $module) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                        <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 half-box">
                <div class="panel">
                  <div class="panel-heading main-heading text-center">
                    <h4>Demographics</h4>
                  </div>
                  <div class="panel-body">
                    <div class="row wpn">
                      <div class="col-md-3 no-p-r">
                        <div class="clearfix" style="margin-bottom: 15px;">
                          <div class="info-box infb-hl wbg no-margin">
                            <div class="icon">
                              <div class="olo-icon oloi-30 aboveage"></div>
                            </div>
                            <div class="content full-width">
                              <div class="text col-pri font-bold"><span class="number counternew"><?php echo ($tsdata['aapercent']) ?></span>%</div>
                              <div class="text col-dark-grey"><small>ABOVE 36</small></div>
                            </div>
                          </div>
                        </div>
                        <div class="clearfix" style="margin-bottom: 15px;">
                          <div class="info-box infb-hl wbg no-margin">
                            <div class="icon">
                              <div class="olo-icon oloi-30 belowage"></div>
                            </div>
                            <div class="content full-width">
                              <div class="text col-pri font-bold"><span class="number counternew"><?php echo ($tsdata['abpercent']) ?></span>%</div>
                              <div class="text col-dark-grey small"><small>BELOW 36</small></div>
                            </div>
                          </div>
                        </div>
                        <hr>
                        <div class="clearfix" style="margin-bottom: 15px; text-align: center">
                          <div class="info-box infb-hl genderbox">
                            <div class="icon">
                              <div class="olo-icon oloi-30 male"></div>
                            </div>
                            <div class="content full-width">
                              <div class="text col-pri font-bold"><span class="number counternew"><?php echo ($tsdata['mpercent']) ?></span>%</div>
                            </div>
                          </div>
                        </div>
                        <div class="clearfix" style="margin-bottom: 15px; text-align: center">
                          <div class="info-box infb-hl genderbox">
                            <div class="icon">
                              <div class="olo-icon oloi-30 female"></div>
                            </div>
                            <div class="content full-width">
                              <div class="text col-pri font-bold"><span class="number counternew"><?php echo ($tsdata['fpercent']) ?></span>%</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-9">
                        <div class="row clearfix">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon">
                                <div class="olo-icon oloi-62 lts"></div>
                              </div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">LEARNING TIME SPENT</div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <!--div class="progress-bar bg-yellow" role="progressbar" style="width: <?php echo ($tsdata['lts_ind'] == 0 && $tsdata['lts'] == 0 ? 0 : 100) ?>%"></div>
                                  </div-->
                                  <span><?php echo ($tsdata['lts_ind'] < 60 ?  round($tsdata['lts_ind'], 0) . ' Minutes' : numf($tsdata['lts_ind'] / 60, 2) . ' Hours'); ?></span>

                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" style="width: <?php echo round(($tsdata['lts_ind'] == $tsdata['lts'] ? ( $tsdata['lts_ind'] == 0 ? 0 : 100 ) : ($tsdata['lts']*100) / $tsdata['lts_ind']), 2) ?>%"></div>
                                  </div>
                                  <span><?php echo ($tsdata['lts'] < 60 ? round($tsdata['lts'], 0) . ' Minutes' : numf($tsdata['lts'] / 60, 2) . ' Hours'); ?></span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon">
                                <div class="olo-icon oloi-62 ats"></div>
                              </div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">AVERAGE TIME SPENT</div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <!--div class="progress-bar bg-yellow" role="progressbar" style="width: <?php echo ($tsdata['ats_ind'] == 0 && $tsdata['ats'] == 0 ? 0 : 100) ?>%"></div-->
                                  </div>
                                  <!--span><?php echo ($tsdata['ats_ind'] < 60 ? round($tsdata['ats_ind']) . ' Minutes' : numf($tsdata['ats_ind'] / 60,2) . ' Hours') ?></span-->
                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" style="width: <?php echo round(($tsdata['ats_ind'] == $tsdata['ats'] ? ( $tsdata['ats_ind'] == 0 ? 0 : 100 ) : ($tsdata['ats']*100)/$tsdata['ats_ind']),0) ?>%"></div>
                                  </div>
                                  <span><?php echo ($tsdata['ats'] < 60 ? round($tsdata['ats']) . ' Minutes' : numf($tsdata['ats'] / 60,2) . ' Hours') ?></span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon">
                                <div class="olo-icon oloi-62 tp"></div>
                              </div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">TOTAL PARTICIPANTS</div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <!--div class="progress-bar bg-yellow" role="progressbar" style="width: <?php echo ($tsdata['ucount_ind'] == 0 ? 0 : 100) ?>%"></div-->
                                  </div>
                                  <!--span><?php echo numf($tsdata['ucount_ind'],0) ?></span-->
                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" style="width: <?php echo round(($tsdata['ucount_ind'] == $tsdata['ucount'] ? ( $tsdata['ucount_ind'] == 0 ? 0 : 100 ) : ($tsdata['ucount']*100)/$tsdata['ucount_ind']),0) ?>%"></div>
                                  </div>
                                  <span><?php echo numf($tsdata['ucount'],0) ?></span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon">
                                <div class="olo-icon oloi-62 nod"></div>
                              </div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">NO. OF DEPARTMENTS</div>
                                <div class="pbar">
                                  <!--div class="progress col-transparent"-->
                                    <!--div class="progress-bar bg-yellow" role="progressbar" style="width: 100%"></div>
                                  </div> -->
                                  <!--span><?php echo 1; ?></span-->
                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" style="width: 100%"></div>
                                  </div>
                                  <span><?php echo 1; ?></span>
                                </div>
                              </div>
                            </div>
                          </div>


                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <!--span class="icn bg-yellow dgicn">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small class="dgleg">Industry Statistics</small-->
                            <span class="icn bg-purple dgicn">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small class="dgleg">Organization Statistics</small>
                          </div>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix">
              <hr>
            </div>

            <div class="row  wpn wpgroup1">
              <div class="col-md-12">
                <h4 class="text-center main-head">
                  <div class="olo-icon oloi-30 gwdg"></div>Gender Wise Demographics
                </h4>
              </div>
              <div class="col-md-6 half-box halfboxNone ">
                <div class="panel">
                  <div class="panel-heading main-heading">
                    <h4 class="text-center">
                      <div class="olo-icon oloi-30 male"></div><span class="number counternew"><?php echo ($udata['mucount']) ?></span> Male Learners
                    </h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc <?php echo ($tsdata['muminp'] >= 70) ? 'green' : (($tsdata['muminp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['mumin'] / 60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1 ld-bounce paused f06" data-preset="circle" rel="<?php echo $tsdata['muminp'] ?>"></div>
                          </div>
                          <div class="rc-label">Min Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['muavgp'] >= 70) ? 'green' : (($tsdata['muavgp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['muavg'] / 60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1 ld-bounce paused f06" data-preset="circle" rel="<?php echo $tsdata['muavgp'] ?>"></div>
                          </div>
                          <div class="rc-label">Average Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['mumaxp'] >= 70) ? 'green' : (($tsdata['mumaxp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['mumax'] / 60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1 ld-bounce paused f10" data-preset="circle" rel="<?php echo $tsdata['mumaxp'] ?>"></div>
                          </div>
                          <div class="rc-label">Max Time Spent</div>
                        </div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <!-- <div class="row1 clearfix text-center small"><span class="col-pri"><?php echo $tt_all_male ?></span> Male Learners</div> -->
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 topmod"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Top Modules Learnt</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['mmodules']) || count($tsdata['mmodules']) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                  <br><font class="nodata">No data available!</font><br><br><br>
                                </div>
                              <?php else : ?>
                                <?php foreach (array_slice($tsdata['mmodules'] , 0, 3, true) as $km => $module) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                      <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 pop"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Popular Learners</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['musers']) || count($tsdata['musers']) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                  <br><font class="nodata">No data available!</font><br><br><br>
                                </div>
                              <?php else : ?>
                                <?php foreach (array_slice($tsdata['musers'] , 0, 3, true) as $km => $user) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                      <div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><?php echo $udata['usernames'][$km]; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6 half-box">
                <div class="panel">
                  <div class="panel-heading main-heading">
                    <h4 class="text-center">
                      <div class="olo-icon oloi-30 female"></div><span class="number counternew"><?php echo ($udata['fucount']) ?></span> Female Learners
                    </h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc <?php echo ($tsdata['fuminp'] >= 70) ? 'green' : (($tsdata['fuminp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['fumin']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['fuminp'] ?>"></div>
                          </div>
                          <div class="rc-label">Min Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['fuavgp'] >= 70) ? 'green' : (($tsdata['fuavgp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['fuavg']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['fuavgp'] ?>"></div>
                          </div>
                          <div class="rc-label">Average Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['fumaxp'] >= 70) ? 'green' : (($tsdata['fumaxp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['fumax']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['fumaxp'] ?>"></div>
                          </div>
                          <div class="rc-label">Max Time Spent</div>
                        </div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <br>

                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 topmod"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Top Modules Learnt</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['fmodules']) || count($tsdata['fmodules']) == 0) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                    <br><font class="nodata">No data available!</font><br><br><br>
                                  </div>
                                <?php else : ?>
                                  <?php foreach (array_slice($tsdata['fmodules'] , 0, 3, true) as $km => $module) : ?>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                      <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                        <div class="content">
                                        <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                        </div>
                                      </div>
                                    </div>
                                  <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 pop"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Popular Learners</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['fusers']) || count($tsdata['fusers']) == 0) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                    <br><font class="nodata">No data available!</font><br><br><br>
                                  </div>
                                <?php else : ?>
                                  <?php foreach (array_slice($tsdata['fusers'] , 0, 3, true) as $km => $user) : ?>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                      <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                        <div class="content">
                                        <div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><?php echo $udata['usernames'][$km]; ?></div>
                                        </div>
                                      </div>
                                    </div>
                                  <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix">
              <hr>
            </div>

            <div class="row  wpgroup2">
              <div class="col-md-12">
                <h4 class="text-center main-head">
                  <div class="olo-icon oloi-30 awdg"></div>Age Wise Demographics
                </h4>
              </div>
              <div class="col-md-6 half-box halfboxNone">
                <div class="panel">
                  <div class="panel-heading main-heading">
                    <h4 class="text-center">
                      <div class="olo-icon oloi-30 aboveage"></div><span class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?php echo round($udata['aaucount']) ?>"><?php echo round($udata['aaucount']) ?></span> Learners Above 36
                    </h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc <?php echo ($tsdata['aauminp'] >= 70) ? 'green' : (($tsdata['aauminp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['aaumin']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['aauminp'] ?>"></div>
                          </div>
                          <div class="rc-label">Min Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['aauavgp'] >= 70) ? 'green' : (($tsdata['aauavgp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['aauavg']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['aauavgp'] ?>"></div>
                          </div>
                          <div class="rc-label">Average Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['aaumaxp'] >= 70) ? 'green' : (($tsdata['aaumaxp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['aaumax']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['aaumaxp'] ?>"></div>
                          </div>
                          <div class="rc-label">Max Time Spent</div>
                        </div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <!-- <div class="row1 clearfix text-center small"><span class="col-pri"><?php echo $tt_all_male ?></span> Male Learners</div> -->
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 topmod"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Top Modules Learnt</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['aamodules']) || count($tsdata['aamodules']) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                  <br><font class="nodata">No data available!</font><br><br><br>
                                </div>
                              <?php else : ?>
                                <?php foreach (array_slice($tsdata['aamodules'] , 0, 3, true) as $km => $module) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                      <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 pop"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Popular Learners</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['aausers']) || count($tsdata['aausers']) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                  <br><font class="nodata">No data available!</font><br><br><br>
                                </div>
                              <?php else : ?>
                                <?php foreach (array_slice($tsdata['aausers'] , 0, 3, true) as $km => $user) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                      <div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><?php echo $udata['usernames'][$km]; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6 half-box">
                <div class="panel">
                  <div class="panel-heading main-heading">
                    <h4 class="text-center">
                      <div class="olo-icon oloi-30 belowage"></div><span class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?php echo round($udata['abucount']) ?>"><?php echo round($udata['abucount']) ?></span> Learners Below 36
                    </h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc <?php echo ($tsdata['abuminp'] >= 70) ? 'green' : (($tsdata['abuminp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['abumin']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['abuminp'] ?>"></div>
                          </div>
                          <div class="rc-label">Min Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['abuavgp'] >= 70) ? 'green' : (($tsdata['abuavgp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['abuavg']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['abuavgp'] ?>"></div>
                          </div>
                          <div class="rc-label">Average Time Spent</div>
                        </div>
                      </div>

                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['abumaxp'] >= 70) ? 'green' : (($tsdata['abumaxp'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo numf($tsdata['abumaxp']/60, 2) ?></span> <span class="lbl">Hours</span></div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['abumaxp'] ?>"></div>
                          </div>
                          <div class="rc-label">Max Time Spent</div>
                        </div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <br>

                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 topmod"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Top Modules Learnt</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['abmodules']) || count($tsdata['abmodules']) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                  <br><font class="nodata">No data available!</font><br><br><br>
                                </div>
                              <?php else : ?>
                                <?php foreach (array_slice($tsdata['abmodules'] , 0, 3, true) as $km => $module) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                      <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 pop"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Popular Learners</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['abusers']) || count($tsdata['abusers']) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                  <br><font class="nodata">No data available!</font><br><br><br>
                                </div>
                              <?php else : ?>
                                <?php foreach (array_slice($tsdata['abusers'] , 0, 3, true) as $km => $user) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                      <div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><?php echo $udata['usernames'][$km]; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix">
              <hr>
            </div>

            <div class="row wpgroup3">
              <div class="col-md-12">
                <h4 class="text-center main-head">
                  <div class="olo-icon oloi-30 mol"></div>Preferred Mode of Learning
                </h4>
              </div>
              <div class="col-md-12">
                <div class="panel">
                  <div class="panel-body">
                    <div class="row clearfix">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="rc  <?php echo ($tsdata['acpercent'] >= 70) ? 'green' : (($tsdata['acpercent'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo round($tsdata['acpercent'], 2) ?></span>%</div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo $tsdata['acpercent'] ?>"></div>
                          </div>
                          <div class="rc-label">Articles</div>
                        </div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="rc <?php echo ($tsdata['vcpercent'] >= 70) ? 'green' : (($tsdata['vcpercent'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo round($tsdata['vcpercent'], 2) ?></span>%</div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo round($tsdata['vcpercent'], 2) ?>"></div>
                          </div>
                          <div class="rc-label">Videos</div>
                        </div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="rc  <?php echo ($tsdata['bcpercent'] >= 70) ? 'green' : (($tsdata['bcpercent'] >= 35) ? 'yellow' : 'red') ?>">
                          <div class="rc-val">
                            <div class="rc-tail"><i class="fa fa-circle"></i></div>
                          </div>
                          <div class="rc-case">
                            <div class="rc-icon"><span class="number counternew"><?php echo round($tsdata['bcpercent'], 2) ?></span>%</div>
                            <div class="ldBar1" data-preset="circle" rel="<?php echo round($tsdata['bcpercent'], 2) ?>"></div>
                          </div>
                          <div class="rc-label">Book Suggestions</div>
                        </div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div>
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-4">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 popart"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Popular Articles</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['acontent']) || count($tsdata['acontent']) == 0|| $tsdata['acpercent'] == 0) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                    <br><font class="nodata">No data available!</font><br><br><br>
                                  </div>
                                <?php else : ?>
                                  <?php foreach (array_slice($tsdata['acontent'] , 0, 3, true) as $km => $module) : ?>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                      <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                        <div class="content">
                                        <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                        </div>
                                      </div>
                                    </div>
                                  <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">

                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 popvid"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Popular Videos</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['vcontent']) || count($tsdata['vcontent']) == 0|| $tsdata['vcpercent'] == 0) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                    <br><font class="nodata">No data available!</font><br><br><br>
                                  </div>
                                <?php else : ?>
                                  <?php foreach (array_slice($tsdata['vcontent'] , 0, 3, true) as $km => $module) : ?>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                      <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                        <div class="content">
                                        <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                        </div>
                                      </div>
                                    </div>
                                  <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">


                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon">
                              <div class="olo-icon oloi-30 popbook"></div>
                            </div>
                            <div class="panel-title">
                              <h6>Popular Book Suggestions</h6>
                            </div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($tsdata['bcontent']) || count($tsdata['bcontent']) == 0 || $tsdata['bcpercent'] == 0) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br>
                                    <br><font class="nodata">No data available!</font><br><br><br>
                                  </div>
                                <?php else : ?>
                                  <?php foreach (array_slice($tsdata['bcontent'] , 0, 3, true) as $km => $module) : ?>
                                    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-left top-module">
                                      <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                        <div class="content">
                                        <div class="text" title="<?php echo round($module / 60, 2) . ' Hours'; ?>"><?php echo $km; ?></div>
                                        </div>
                                      </div>
                                    </div>
                                  <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div class="clearfix">
              <hr>
            </div>

            <br><br><br><br><br>
			  </div>
          </div>
        <?php
        }
        ?>
      </div>
      <?php include_once('footer.php'); ?>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>/assets/vendor/jquery/jquery.min.js"> </script>
    <!--<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>-->
    <script src="<?php echo base_url() ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>/assets/vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>/assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>/assets/js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/sb-admin-charts.min.js"></script>
    <!--<script src="<?php echo base_url() ?>/assets/vendor/loading-bar/loading-bar.min.js"></script>-->
    <!--<script src="<?php echo base_url() ?>/assets/vendor/jquery-countto/jquery.countTo.js"></script>
    <script type="text/javascript">
      //$('.counternew').countTo();
    </script>-->

    <script src="//cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
    <script src="<?php echo base_url() ?>/assets/vendor/counterup/jquery.counterup.js"></script>    
    <script src="<?php echo base_url() ?>/assets/vendor/loading-bar/loading-bar.js"></script>
    <script type="text/javascript">
      var wpns = []; var wIndex = 0;
      // $('.wpn').each(function(i, el){ 
      //   console.log("setting up wpn " + wIndex);
      //   wpns[wIndex++] = new Waypoint({
      //     element: el,
      //     handler: function(direction) {
      //       // console.log('Scrolled to wpn!', $(el).find('.counternew').length);
      //       // setTimeout(function() { 
      //       //     $(el).find('.counternew').each(function(j, ele) { 
      //       //       $(ele).counterUp({delay: 10, time: 1000});
      //       //       $(ele).removeClass('counternew');
      //       //   });
      //       // },100);
            
      //     },
      //     offset: 600 
      //   });

      // });
      jQuery(document).ready(function($) {
            $('.counternew').counterUp({
                delay: 10,
                time: 1000
            });
        });
        // $(document).ready(function() { 
        //   $('.counternew').counterUp({delay: 10, time: 1000});
        // });
      
        var initLoad1 = true; 
        var waypoint1 = new Waypoint({
          element: document.getElementsByClassName('wpgroup1'),
          handler: function(direction) {
            if(initLoad1) {
              setTimeout(function(){
                $('.wpgroup1').find('.ldBar1').each(function(k,v){
                  $(v).addClass('ldBar');
                var bar1 = new ldBar(v);
                bar1.set($(this).attr('rel'));
              })
              }, 200);
              initLoad1 = false;
            }
            //this.element.ldBar = new ldBar(this.element);
          },
          offset: 600 
        });

        var initLoad2 = true;
        var waypoint2 = new Waypoint({
          element: document.getElementsByClassName('wpgroup2'),
          handler: function(direction) {
            if(initLoad2) {
              setTimeout(function(){
                $('.wpgroup2').find('.ldBar1').each(function(k,v){
                  $(v).addClass('ldBar');
                var bar1 = new ldBar(v);
                bar1.set($(this).attr('rel'));
              })
              }, 200);
              initLoad2 = false;
            }
            //this.element.ldBar = new ldBar(this.element);
          },
          offset: 600 
        });

        var initLoad3 = true;
        var waypoint3 = new Waypoint({
          element: document.getElementsByClassName('wpgroup3'),
          handler: function(direction) {
            if(initLoad3) {
              setTimeout(function(){
                $('.wpgroup3').find('.ldBar1').each(function(k,v){
                  $(v).addClass('ldBar');
                  var bar1 = new ldBar(v);
                  bar1.set($(this).attr('rel'));
              })
              }, 200);
              initLoad3 = false;
            }
            //this.element.ldBar = new ldBar(this.element);
          },
          offset: 600 
        });
  /*var waypoint = new Waypoint({
    element: document.getElementsByClassName('ldBr'),
    handler: function(direction) {
      console.log('Scrolled to waypoint!', direction, this, this.element)
      setTimeout(function(){
        console.log('settimeout', $('.ldBr').length)
        $('.ldBr').each(function(k,v){
          //$(v).addClass('ldBar');
        bar1 = ldBar(v);
        bar1.set($(this).attr('rel'));
        console.log('bar1', bar1, v)
      })
      }, 1000)
      //this.element.ldBar = new ldBar(this.element);
    },
  offset: 300 
  })
  
  var waypoint = new Waypoint({
    element: document.getElementsByClassName('ldBr'),
    handler: function(direction) {
      console.log('Scrolled to waypoint!', direction, this, this.element)
      var bar1 = ldBar($('.ldBr'));
      bar1.set(0);
      setTimeout(function(){
        console.log('settimeout', this.element, this)
          //$(this.element).addClass('ldBar');
        //var bar1 = new ldBar(this.element);
        bar1.set($(this.element).attr('data-value'));
        //console.log('bar1', bar1, v)
      }, 3000);
      //this.element.ldBar = new ldBar(this.element);
    },
  offset: 300 
  });*/

  
    </script>
  </div>
</body>

</html>

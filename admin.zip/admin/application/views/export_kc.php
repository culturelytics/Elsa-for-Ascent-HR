<!-- <?php
      if (!isset($_SESSION["email"])) {
        header("Location: login");
      } else {
      ?> -->

<?php
        defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/select2/select2.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url() ?>assets/select2/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />

</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper admpage2">
    <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>knowledge_center/">Knowledge Center</a>
        </li>
        <li class="breadcrumb-item active">Export</li>
      </ol>
      <!-- Icon Cards-->

      <div class="clearfix">
        <center>
          <h3>EXPORT</h3>
        </center>
      </div>
    </div>
    <div class="container-fluid rgpage">
      <div class="container">
        <form action="<?php echo current_url() ?>" method="post" id="usersform">

          <div class="alab">
            <h5>User Status</h5>
            <select name="user" id="" required class="form-control">
              <option value="ALL">All</option>
              <?php
              foreach ($user as $row) { ?>
                <option value="<?= $row->id ?>"><?php echo $row->name . "==" . $row->email ?></option>
              <?php } ?>

            </select>
            <?php echo form_error('status'); ?>
          </div>
          <input type="submit" name="submit" class="btn btn-primary" value="submit">

        </form>


      </div>
      <?php include_once('footer.php'); ?>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url() ?>assets/select2/select2.full.min.js" type="text/javascript"></script>
  </div>
</body>

</html>
<!-- <?php } ?> -->
<!-- <?php
if (!isset($_SESSION["email"])) {
    header("Location: login1");
} else {
    ?> -->

    <?php
    defined('BASEPATH') or exit('No direct script access allowed');
    ?>
    <!DOCTYPE html>
    <html lang="en">

        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="description" content="">
            <meta name="author" content="">
            <title><?php echo $this->config->item('page_title') ?></title>
            <!-- Bootstrap core CSS-->
            <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
            <!-- Custom fonts for this template-->
            <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
            <!-- Page level plugin CSS-->
            <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
            <!-- Custom styles for this template-->
            <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
        </head>

        <body class="fixed-nav sticky-footer bg-dark" id="page-top">
            <!-- Navigation-->
            <?php include "sidebar.php"; ?>


            <div class="content-wrapper admpage2 moduleidp">
                <div class="container-headbox">
                    <!-- Breadcrumbs-->
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo base_url() ?>dashboard/">Home</a>
                        </li>
                        <?php if ($this->uri->segment(2) == 'client') { ?>
                            <li class="breadcrumb-item">
                                <a href="<?php echo base_url() ?>knowledge_center/client/<?php echo $this->uri->segment(3) ?>">Client Knowledge Center</a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo $orgdetails[0]->org_name; ?> - Modules</li>
                        <?php } else { ?>
                            <li class="breadcrumb-item">
                                <a href="<?php echo base_url() ?>knowledge_center/aggregator">Aggregator Knowledge Center</a>
                            <li class="breadcrumb-item active">Modules</li>
                            </li>
                        <?php } ?>

                    </ol>
                    <!-- Icon Cards-->

                    <div class="clearfix">
                        <center>
                            <h3>MLP MODULES</h3>
                        </center>
                    </div>
                </div>
                <div class="container-fluid rgpage">
                    <div style="float: right;position: relative; z-index: 1000;">
                        <a data-toggle="modal" data-target="#addidpprogramModal" class="btn btn-primary btn-condensed" style="color: #fff;margin-right: 10px; float:right">Add New MLP Module</a>
                     </div>
                       
                    <div class="container" style="padding-right: 0px !important;padding-left: 0px !important;margin-top: -35px;float: left;position: relative; z-index: 1;">
                       
                        <div class="table-responsive">

                            <table class="table table-bordered dataTable" id="dataTable" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                                <thead>
                                    <tr>
                                        <th style="width: 5%;min-width: 40px; text-align:left;">S.no</th>
                                        <th style="width: 85%;min-width: 250px; text-align:left;">Name</th>
                                        <th style="width: 10%;min-width: 80px; text-align:left;">Action</th>
                                    </tr>
                                </thead>
                                <?php
                                $i = 0;
                                foreach ($list as $row) : $i++;
                                    ?>

                                    <tr>
                                        <td style="text-align: center;" ><?php echo $i; ?></td> <!-- php 5.6 version -->
                                        <td><?php echo $row->prg_name ?></td>

                                        <td><span><a href="#" class="programedit" data-pid="<?= $row->prg_id ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span><span> <a href="#" class="delete" onclick="deleteprogram('<?php echo base_url() ?>programs/delete/<?php echo $row->prg_id ?>/<?php echo $this->uri->segment(2) ?>/<?php echo $this->uri->segment(3) ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span></td>
                                    </tr>

                            <?php endforeach; ?>
                            </table>
                        </div>

                    </div>
                    <?php include_once('footer.php'); ?>
                </div>
            </div>

            <div class=" modal fade" id="addidpprogramModal" tabindex="-1" role="dialog" aria-labelledby="idpprogramModalLabel" aria-hidden="true">
                <div class="modal-dialog" style="width:800px;max-width: 800px;" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Add Module</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <div class="modal-body">
                           <form action="<?= ($this->uri->segment(2) == 'client') ? base_url() . 'programs/client/' . $this->uri->segment(3) : base_url() . 'programs/aggregator/' . $this->uri->segment(3) ?>" method="post" id="usersform">
                            <div>
                                <input type="text" name="prg_name" placeholder="Module Name" required>
                                <input type="hidden" name="org_id" value="<?php echo $this->uri->segment(3) ?>">
                                <?php echo form_open('prg_name'); ?>
                            </div>
                            <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">

                        </form>
                        </div>
                    </div>
                </div>
            </div>

            <div class=" modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLabel">Edit Module</h5>
                            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">×</span>
                            </button>
                        </div>
                        <form action="<?php echo base_url() ?>programs/update/<?php echo $this->uri->segment(2) ?>/<?php echo $this->uri->segment(3) ?>" method="post">
                            <div class="modal-body"> <input type="text" name="prg_name1" placeholder="Module Name" id="prg_name1" value="" required>
                                <input type="hidden" name="prg_id1" id="prg_id1" value="" required>
                            </div>

                            <div class="modal-footer">
                                <button class="btn btn-primary" type="submit">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>


            <!-- Bootstrap core JavaScript-->
            <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
            <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
            <!-- Core plugin JavaScript-->
            <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
            <!-- Page level plugin JavaScript-->
            <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
            <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
            <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
            <!-- Custom scripts for all pages-->
            <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
            <!-- Custom scripts for this page-->
            <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
            <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>

            <script type="text/javascript">
//                                            $(document).ready(function () {
                                                $(document).on('click', '.programedit',function () {
                                                    var pid = $(this).data('pid');
                                                    $.post('<?php echo base_url() ?>programs/edit', 'pid=' + pid, function (rs) {
                                                        if (rs) {
                                                            rs = JSON.parse(rs);
                                                            console.log(rs);
                                                            $('#prg_id1').val(rs[0].prg_id);
                                                            $('#prg_name1').val(rs[0].prg_name);
                                                            $('#myModal').modal('show');
                                                        } else {
                                                            alert("No record found")
                                                        }
                                                    });
                                                });
//                                            });

                                            function deleteprogram(url) {
                                                a = confirm("Are you sure to delete?");
                                                if (a) {
                                                    window.location.href = url;
                                                }
                                            }
            </script>


        </body>

    </html>
    <!-- <?php } ?> -->
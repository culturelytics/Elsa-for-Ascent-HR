<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>/assets/css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper  cdb">
    <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <li class="breadcrumb-item active">Company Dashboard</li>
      </ol>
      <!-- Icon Cards-->

      
      <div class="clearfix">
        <form action="/admin/dashboard/index" method="GET" class="form form-horizontal form-inline">
          <div class="row full-width">
            <div class="col-md-4 col-sm-4">
              <label for="organization" class="text-right pull-right form-label cdb-lbl">COMPANY NAME</label>
            </div>
            <div class="col-md-8 col-sm-8">
              <div class="form-group">
                <select name="organization_id" id="organization_id" class="form-control">
                  <option value="">Select Organization</option>
                  <?php foreach ($organizations as $k => $org) : ?>
                    <option value="<?php echo $org['id'] ?>" <?php echo ($org['id'] == $organization_id ? 'selected="true"' : '') ?>><?php echo $org['org_name'] ?></option>
                  <?php endforeach; ?>
                </select>
                &nbsp;<input type="submit" value="Submit" class="btn btn-default btn-sm" />
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
    <div class="container-fluid">
      <div class="container cdbcontent">
        <?php

        /*if(!isset($_SESSION["sess_email_kaccess"]) && !isset($_SESSION["sess_email_caccess"])){
header("Location: login.php");
}
else*/
        if (1) {

          //t_ts => total time spent
          //t_mdl => total modules
          //a_mdl => array of modules
          $t_ts_m = $t_ts_h = $t_mdl_learnt = $t_mdl_total = $p_modules_learnt = $t_ppl = 0;
          $a_mdl_learnt = [];
          $a_mdl_ts = [];
          $t_ts_male_m = $t_ts_male_h = $t_ts_female_m = $t_ts_male_h = 0;
          $a_ts_male = $a_ts_female = [];
          $a_age_male = [];
          $a_age_female = [];

          // Top 3 modules learnt by male/female
          $a_mdl_male = $a_mdl_female = [];

          // Popular learners
          $a_mdl_pl_male = [];
          $a_mdl_pl_female = [];

          $a_mdl_below_35 = [];
          $a_mdl_above_35 = [];

          // Popular learners
          $a_mdl_pl_below_35 = [];
          $a_mdl_pl_above_35 = [];

          // Popular learners
          $a_mdl_pl_below_35_male = [];
          $a_mdl_pl_above_35_male = [];
          $a_mdl_pl_below_35_female = [];
          $a_mdl_pl_above_35_female = [];

          $a_mdl_cat = $a_mdl_cat_video = $a_mdl_cat_article = $a_mdl_cat_book = [];

          $newline = "\n";
          $newtab = "\t";
          $columnHeader = "" . $newtab . $newtab . $newtab . "Analytical Report" . $newtab . "" . "\t \n \n";
          $columnHeader = $columnHeader . "Sl.NO" . $newtab . "Date" . $newtab . "User ID" . $newtab . "First Name " . "$newtab" . "Last Name" . "$newtab" . "Email ID" . "$newtab" . "Phone No" . "$newtab" . "Organization" . "$newtab" . "Sex" . "$newtab" . "Age" . "$newtab" . "Linked IN" . "$newtab" . "Twitter" . "$newtab" . "Date" . "$newtab" . "Login Time" . "$newtab" . "Logout Time" . "$newtab" . "Page Name" . "$newtab" . "Links" . "$newtab" . "Page Link Open Time" . "$newtab" . "Module" . "$newtab" . "\t \n";
          $setData = '';
          
          //if ($result != null) {
            $old_id = 0;
            $i = 0;
            foreach ($result as $k => $row) {
              //var_dump($row);die;
              $age = $row->age == "1" ? '21-36' : ($row->age == "2" ? '37-50' : '50+');
              if ($old_id != $row->eh_ul_id) {
                $i++;
                $t_ppl++;
                $Startdate = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                $Starttime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_start_time)));
                $endtime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_end_time)));
                $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                $date = date('Y-m-d', strtotime('+0 minutes', strtotime($row->ulh_start_time)));
                $setData = $setData . "$i" . $newtab . date('Y-m-d', strtotime($Startdate)) . $newtab . "E2E" . sprintf("%06d", $row->id) . $newtab . "$row->name" . "$newtab" . "$row->last_name" . "$newtab" . "$row->email" . "$newtab" . "$row->contact" . "$newtab" . "$row->organization" . "$newtab" . "$row->gender" . "$newtab" . "$age" . "$newtab" . "$row->linkedin" . "$newtab" . "$row->twitter" . "$newtab" . "$date" . "$newtab" . "$Starttime" . "$newtab" . "$endtime" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";

                $start_date = new DateTime($Startdate);
                $ts = $start_date->diff(new DateTime($endtime));
                $t_ts_m += $ts->m;
                $t_ts_h += $ts->h;
                //var_dump($since_start, $t_ts);

                if (!array_key_exists($row->kc_title, $a_mdl_ts)) {
                  $a_mdl_ts[$row->kc_title] = (float) $ts->m;
                } else {
                  $a_mdl_ts[$row->kc_title] = $a_mdl_ts[$row->kc_title] + (float) $ts->m;
                }
                
                if (!array_key_exists($row->kl_cat, $a_mdl_cat)) {
                  $a_mdl_cat[$row->kl_cat] = 1;
                } else {
                  $a_mdl_cat[$row->kl_cat] = $a_mdl_cat[$row->kl_cat] + 1;
                }
                
                /* preferred mode of learning -start */
                
                if($row->kl_cat == 'Article') {
                  if (!array_key_exists($row->kc_title, $a_mdl_cat_article)) {
                    $a_mdl_cat_article[$row->kc_title] = 1;
                  } else {
                    $a_mdl_cat_article[$row->kc_title] = $a_mdl_cat_article[$row->kc_title] + 1;
                  }
                }
                if($row->kl_cat == 'Video') {
                  if (!array_key_exists($row->kc_title, $a_mdl_cat_video)) {
                    $a_mdl_cat_video[$row->kc_title] = 1;
                  } else {
                    $a_mdl_cat_video[$row->kc_title] = $a_mdl_cat_video[$row->kc_title] + 1;
                  }
                }
                if($row->kl_cat == 'Booksuggestion') {
                  if (!array_key_exists($row->kc_title, $a_mdl_cat_book)) {
                    $a_mdl_cat_book[$row->kc_title] = 1;
                  } else {
                    $a_mdl_cat_book[$row->kc_title] = $a_mdl_cat_book[$row->kc_title] + 1;
                  }
                }
                
                /* preferred mode of learning -end */

                if ($row->age == "1") {
                  if (!array_key_exists($row->name, $a_mdl_pl_below_35)) {
                    $a_mdl_pl_below_35[$row->name] = (float) $ts->m;
                  } else {
                    $a_mdl_pl_below_35[$row->name] = $a_mdl_pl_below_35[$row->name] + (float) $ts->m;
                  }
                } else {
                  if(!($row->eh_u_id == '' || $row->eh_u_id == null || $row->eh_u_id == 0)){                  
                    if (!array_key_exists($row->name, $a_mdl_pl_above_35)) {
                      $a_mdl_pl_above_35[$row->name] = (float) $ts->m;
                    } else {
                      $a_mdl_pl_above_35[$row->name] = $a_mdl_pl_above_35[$row->name] + (float) $ts->m;
                    }
                  } else {
                    //var_dump($row);
                  }
                }

                if ($row->gender == 'male') {
                  if (!array_key_exists($row->eh_u_id, $a_ts_male)) {
                    $a_ts_male[$row->eh_u_id] = (float) $ts->m;
                  } else {
                    $a_ts_male[$row->eh_u_id] = $a_ts_male[$row->eh_u_id] + (float) $ts->m;
                  }
                  //$a_age_male[$row->age] += (isset($a_age_male[$row->age]) ? $a_age_male[$row->age] : $a_age_male[$row->age]);
                  if (!array_key_exists($row->age, $a_age_male)) {
                    $a_age_male[$row->age] = 1;
                  } else {
                    $a_age_male[$row->age] += 1;
                  }

                  // popular learners male
                  if (!array_key_exists($row->name, $a_mdl_pl_male)) {
                    $a_mdl_pl_male[$row->name] = (float) $ts->m;
                  } else {
                    $a_mdl_pl_male[$row->name] = $a_mdl_pl_male[$row->name] + (float) $ts->m;
                  }

                  // popular learners male below/above 35 by time spent
                  if ($row->age == "1") {
                    if (!array_key_exists($row->name, $a_mdl_pl_below_35_male)) {
                      $a_mdl_pl_below_35_male[$row->name] = (float) $ts->m;
                    } else {
                      $a_mdl_pl_below_35_male[$row->name] = $a_mdl_pl_below_35_male[$row->name] + (float) $ts->m;
                    }
                  } else {
                    if (!array_key_exists($row->name, $a_mdl_pl_above_35_male)) {
                      $a_mdl_pl_aa_mdl_pl_above_35_malebove_35[$row->name] = (float) $ts->m;
                    } else {
                      $a_mdl_pl_above_35_male[$row->name] = $a_mdl_pl_above_35_male[$row->name] + (float) $ts->m;
                    }
                  }
                } else {
                  // TODO - what id age is empty
                  if (is_null($row->age) || $row->age == 0) {
                    $row->age = 3;
                  }
                  if (!array_key_exists($row->eh_u_id, $a_ts_female)) {
                    $a_ts_female[$row->eh_u_id] = (float) $ts->m;
                  } else {
                    $a_ts_female[$row->eh_u_id] = $a_ts_female[$row->eh_u_id] + (float) $ts->m;
                  }
                  if (!array_key_exists($row->age, $a_age_female)) {
                    $a_age_female[$row->age] = 1;
                  } else {
                    $a_age_female[$row->age] += 1;
                  }
                  //$a_age_female[$row->age] += (isset($a_age_female[$row->age]) ? $a_age_female[$row->age] : $a_age_female[$row->age]);


                  // popular learners female
                  if (!array_key_exists($row->name, $a_mdl_pl_female)) {
                    $a_mdl_pl_female[$row->name] = (float) $ts->m;
                  } else {
                    $a_mdl_pl_female[$row->name] = $a_mdl_pl_female[$row->name] + (float) $ts->m;
                  }

                  // popular learners male below/above 35 by time spent
                  if ($row->age == "1") {
                    if (!array_key_exists($row->name, $a_mdl_pl_below_35_female)) {
                      $a_mdl_pl_below_35_female[$row->name] = (float) $ts->m;
                    } else {
                      $a_mdl_pl_below_35_female[$row->name] = $a_mdl_pl_below_35_female[$row->name] + (float) $ts->m;
                    }
                  } else {
                    if (!array_key_exists($row->name, $a_mdl_pl_above_35_female)) {
                      $a_mdl_pl_above_35_female[$row->name] = (float) $ts->m;
                    } else {
                      $a_mdl_pl_above_35_female[$row->name] = $a_mdl_pl_above_35_female[$row->name] + (float) $ts->m;
                    }
                  }
                }
              } else {
                if ($old_id1 != $row->kc_title) {
                  $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                  $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";
                  $t_mdl_learnt++;
                  //var_dump($old_id1, $row->kc_title);
                  //var_dump($row);
                  if (!array_key_exists($row->prg_name, $a_mdl_learnt)) {
                    $a_mdl_learnt[$row->prg_name] = 1;
                  } else {
                    $a_mdl_learnt[$row->prg_name] = $a_mdl_learnt[$row->prg_name] + 1;
                  }

                  if ($row->gender == 'male') {
                    if (!array_key_exists($row->kc_title, $a_mdl_male)) {
                      $a_mdl_male[$row->kc_title] = 1;
                    } else {
                      $a_mdl_male[$row->kc_title] = $a_mdl_male[$row->kc_title] + 1;
                    }
                  } else {
                    if (!array_key_exists($row->kc_title, $a_mdl_female)) {
                      $a_mdl_female[$row->kc_title] = 1;
                    } else {
                      $a_mdl_female[$row->kc_title] = $a_mdl_female[$row->kc_title] + 1;
                    }
                  }

                  if ($row->age == "1") {
                    if (!array_key_exists($row->kc_title, $a_mdl_below_35)) {
                      $a_mdl_below_35[$row->kc_title] = 1;
                    } else {
                      $a_mdl_below_35[$row->kc_title] = $a_mdl_below_35[$row->kc_title] + 1;
                    }
                  } else {
                    if (!array_key_exists($row->kc_title, $a_mdl_above_35)) {
                      $a_mdl_above_35[$row->kc_title] = 1;
                    } else {
                      $a_mdl_above_35[$row->kc_title] = $a_mdl_above_35[$row->kc_title] + 1;
                    }
                  }
                } else {
                  $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                  $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "\n";
                }
              }
              $old_id = $row->eh_ul_id;
              $old_id1 = $row->kc_title;
            }

            /* industry data -start */
            $t_ts_m_ind = $t_ts_h_ind = $t_ppl_ind = 0;
            $a_mdl_ts_ind = [];
            $a_mdl_learnt_ind = [];
            $t_mdl_learnt_ind = 0;
            $old_id1 = '';

            if ($resultind != null) {
              $old_id = 0;
              $i = 0;
              foreach ($resultind as $k => $row) {
                //var_dump($row);die;
                $age = $row->age == "1" ? '21-36' : ($row->age == "2" ? '37-50' : '50+');
                if ($old_id != $row->eh_ul_id) {
                  $i++;
                  $t_ppl_ind++;
                  $Startdate = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                  $Starttime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_start_time)));
                  $endtime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_end_time)));
                  $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                  $date = date('Y-m-d', strtotime('+0 minutes', strtotime($row->ulh_start_time)));
                  $setData = $setData . "$i" . $newtab . date('Y-m-d', strtotime($Startdate)) . $newtab . "E2E" . sprintf("%06d", $row->id) . $newtab . "$row->name" . "$newtab" . "$row->last_name" . "$newtab" . "$row->email" . "$newtab" . "$row->contact" . "$newtab" . "$row->organization" . "$newtab" . "$row->gender" . "$newtab" . "$age" . "$newtab" . "$row->linkedin" . "$newtab" . "$row->twitter" . "$newtab" . "$date" . "$newtab" . "$Starttime" . "$newtab" . "$endtime" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";

                  $start_date = new DateTime($Startdate);
                  $ts = $start_date->diff(new DateTime($endtime));
                  $t_ts_m_ind += $ts->m;
                  $t_ts_h_ind += $ts->h;
                  //var_dump($since_start, $t_ts);

                  if (!array_key_exists($row->kc_title, $a_mdl_ts_ind)) {
                    $a_mdl_ts_ind[$row->kc_title] = (float) $ts->m;
                  } else {
                    $a_mdl_ts_ind[$row->kc_title] = $a_mdl_ts_ind[$row->kc_title] + (float) $ts->m;
                  }
                } else {
                  if ($old_id1 != $row->kc_title) {
                    $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                    $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";
                    $t_mdl_learnt_ind++;
                    //var_dump($old_id1, $row->kc_title);
                    if (!array_key_exists($row->prg_name, $a_mdl_learnt_ind)) {
                      $a_mdl_learnt_ind[$row->prg_name] = 1;
                    } else {
                      $a_mdl_learnt_ind[$row->prg_name] = $a_mdl_learnt_ind[$row->prg_name] + 1;
                    }
                  } else {
                    $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                    $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "\n";
                  }
                }
                $old_id = $row->eh_ul_id;
                $old_id1 = $row->kc_title;
              }
            }

            /* industry data -end */

            $t_mdl_learnt = count($a_mdl_learnt);
            $tperc = $t_mdl_total > 0 ? (($t_mdl_learnt / (float) $t_mdl_total) * 100) : 0;
            $p_modules_learnt = number_format($tperc, 2, '.', '');
            //var_dump($t_mdl_learnt, $t_mdl_total, $p_modules_learnt, $tperc);
            //var_dump($a_mdl_learnt);

            // Top 3 modules by count
            arsort($a_mdl_learnt);
            $a_mdl_top3 = array_reverse(array_slice($a_mdl_learnt, 0, 3));
            arsort($a_mdl_top3);

            // Top 3 modules by time spent
            arsort($a_mdl_ts);
            $a_mdl_ts_top3 = array_reverse(array_slice($a_mdl_ts, 0, 3));
            arsort($a_mdl_ts_top3);

            // Top 3 time spen male
            arsort($a_ts_male);
            $a_ts_male_top3 = array_reverse(array_slice($a_ts_male, 0, 3));
            arsort($a_ts_male_top3);

            // Top 3 time spen female
            arsort($a_ts_female);
            $a_ts_female_top3 = array_reverse(array_slice($a_ts_female, 0, 3));
            arsort($a_ts_female_top3);

            $t_ts_gw = array('male' => array(
              'min' => (count(array_slice($a_ts_male, (count($a_ts_male) - 1), 1)) > 0 ? array_slice($a_ts_male, (count($a_ts_male) - 1), 1)[0] : 0),
              'max' => (count(array_slice($a_ts_male, 0, 1)) > 0 ? array_slice($a_ts_male, 0, 1)[0] : 0),
              'avg' => (count($a_ts_male) > 0 ? round(array_sum($a_ts_male) / count($a_ts_male), 2) : 0),
            ), 'female' => array(
              'min' => (count(array_slice($a_ts_female, (count($a_ts_female) - 1), 1)) > 0 ? array_slice($a_ts_female, (count($a_ts_female) - 1), 1)[0] : 0),
              'max' => (count(array_slice($a_ts_female, 0, 1)) > 0 ? array_slice($a_ts_female, 0, 1)[0] : 0),
              'avg' => (count($a_ts_female) > 0 ? round(array_sum($a_ts_female) / count($a_ts_female), 2) : 0),
            ));

            // Top 3 modules learnt by male
            arsort($a_mdl_male);
            $a_mdl_top3_male = array_reverse(array_slice($a_mdl_male, 0, 3));
            arsort($a_mdl_top3_male);

            // Top 3 modules learnt by female
            arsort($a_mdl_female);
            $a_mdl_top3_female = array_reverse(array_slice($a_mdl_female, 0, 3));
            arsort($a_mdl_top3_female);

            // Top 3 popular learners male
            arsort($a_mdl_pl_male);
            $a_mdl_top3_pl_male = array_reverse(array_slice($a_mdl_pl_male, 0, 3));
            arsort($a_mdl_top3_pl_male);

            // Top 3 popular learners female
            arsort($a_mdl_pl_female);
            $a_mdl_top3_pl_female = array_reverse(array_slice($a_mdl_pl_female, 0, 3));
            arsort($a_mdl_top3_pl_female);

            // Top 3 modules by count for age below 35
            arsort($a_mdl_below_35);
            $a_mdl_top3_below_35 = array_reverse(array_slice($a_mdl_below_35, 0, 3));
            arsort($a_mdl_top3_below_35);

            // Top 3 modules by count for age above 35
            arsort($a_mdl_above_35);
            $a_mdl_top3_above_35 = array_reverse(array_slice($a_mdl_above_35, 0, 3));
            arsort($a_mdl_top3_above_35);


            // Top 3 popular learners below 35 by time spent
            arsort($a_mdl_pl_below_35);
            $a_mdl_top3_pl_below_35 = array_reverse(array_slice($a_mdl_pl_below_35, 0, 3));
            arsort($a_mdl_top3_pl_below_35);

            // Top 3 popular learners above 35 by time spent
            arsort($a_mdl_pl_above_35);
            $a_mdl_top3_pl_above_35 = array_reverse(array_slice($a_mdl_pl_above_35, 0, 3));
            arsort($a_mdl_top3_pl_above_35);
            //var_dump($a_mdl_pl_above_35, $a_mdl_top3_pl_above_35);


            // Top 3 popular learners male below 35 by time spent
            arsort($a_mdl_pl_below_35_male);
            $a_mdl_top3_pl_below_35_male = array_reverse(array_slice($a_mdl_pl_below_35_male, 0, 3));
            arsort($a_mdl_top3_pl_below_35_male);

            // Top 3 popular learners female below 35 by time spent
            arsort($a_mdl_pl_below_35_female);
            $a_mdl_top3_pl_below_35_female = array_reverse(array_slice($a_mdl_pl_below_35_female, 0, 3));
            arsort($a_mdl_top3_pl_below_35_female);


            // Top 3 popular learners male above 35 by time spent
            arsort($a_mdl_pl_above_35_male);
            $a_mdl_top3_pl_above_35_male = array_reverse(array_slice($a_mdl_pl_above_35_male, 0, 3));
            arsort($a_mdl_top3_pl_above_35_male);

            // Top 3 popular learners female below 35 by time spent
            arsort($a_mdl_pl_above_35_female);
            $a_mdl_top3_pl_above_35_female = array_reverse(array_slice($a_mdl_pl_above_35_female, 0, 3));
            arsort($a_mdl_top3_pl_above_35_female);

            
            // Top 3 preferred mode of learning - articles
            arsort($a_mdl_cat_article);
            $a_mdl_top3_cat_article = array_reverse(array_slice($a_mdl_cat_article, 0, 3));
            arsort($a_mdl_top3_cat_article);
            
            // Top 3 preferred mode of learning - book suggestions
            arsort($a_mdl_cat_book);
            $a_mdl_top3_cat_book = array_reverse(array_slice($a_mdl_cat_book, 0, 3));
            arsort($a_mdl_top3_cat_book);
            
            // Top 3 preferred mode of learning - videos
            arsort($a_mdl_cat_video);
            $a_mdl_top3_cat_video = array_reverse(array_slice($a_mdl_cat_video, 0, 3));
            arsort($a_mdl_top3_cat_video);
          
            //var_dump($a_mdl_cat_article, $a_mdl_top3_cat_article);
          
          //}
          /* analytics -end */
          
            //var_dump($a_age_male, $a_age_female);
            $a_age_male[1] = isset($a_age_male[1]) ? $a_age_male[1] : 0;
            $a_age_male[2] = isset($a_age_male[2]) ? $a_age_male[2] : 0;
            $a_age_male[3] = isset($a_age_male[3]) ? $a_age_male[3] : 0;
            $tt_all_male = $a_age_male[1] + $a_age_male[2] + $a_age_male[3];
            $tt_below_35_male = $a_age_male[1];
            $tt_above_35_male = $a_age_male[2] + $a_age_male[3];

            $a_age_female[1] = isset($a_age_female[1]) ? $a_age_female[1] : 0;
            $a_age_female[2] = isset($a_age_female[2]) ? $a_age_female[2] : 0;
            $a_age_female[3] = isset($a_age_female[3]) ? $a_age_female[3] : 0;
            $tt_all_female = $a_age_female[1] + $a_age_female[2] + $a_age_female[3];
            $tt_below_35_female = $a_age_female[1];
            $tt_above_35_female = $a_age_female[2] + $a_age_female[3];

            $tt_below_35_perc = ($tt_all_male + $tt_all_female) > 0 ? ($tt_below_35_male + $tt_below_35_female) * 100 / ($tt_all_male + $tt_all_female) : 0;
            $tt_above_35_perc = ($tt_all_male + $tt_all_female) > 0 ? ($tt_above_35_male + $tt_above_35_female) * 100 / ($tt_all_male + $tt_all_female) : 0;

            $tt_male_perc = ($tt_all_male + $tt_all_female) > 0 ? ($tt_all_male * 100 / ($tt_all_male + $tt_all_female)) : 0;
            $tt_female_perc = ($tt_all_male + $tt_all_female) > 0 ? ($tt_all_female * 100 / ($tt_all_male + $tt_all_female)) : 0;
            
            $oloverview = array(
              0 => array("label" => "ARTICLES", "icon" => "articles", "number" => $cntdata['Article']),
              1 => array("label" => "VIDEOS", "icon" => "videos", "number" => $cntdata['Video']),
              2 => array("label" => "ASSESSMENTS", "icon" => "assessments", "number" => $cntdata['Assessment']),
              3 => array("label" => "BOOK SUGGESTIONS", "icon" => "books", "number" => $cntdata['Booksuggestion'])
            );
            
            //var_dump($tt_all, $tt_below_35, $tt_above_35);
            ?>
          <div class="page-light">
            <div class="row page-light">
              <div class="col-md-6 half-box">
                <div class="panel">
                  <div class="panel-heading main-heading text-center">
                    <h4>Online Learning Overview</h4>
                  </div>
                  <div class="panel-body pad-10">
                    <div class="row clearfix">
                      <?php foreach($oloverview as $olo) { ?>
                      <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                        <div class="info-box infbv infb-1 bg-pink hover-expand-effect1">
                          <div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?php echo $olo['number'] ?>"><?php echo $olo['number'] ?></div>
                          <div class="info-icon">   
                            <div class="olo-icon oloi-46 <?php echo $olo['icon'] ?>"></div>
                          </div>
                          <div class="content">
                            <div class="info-text"><?php echo $olo['label'] ?></div>
                          </div>
                        </div>
                      </div>
                      <?php } ?>
                    </div>
                  </div>
                </div>
                <div class="row clearfix">
                  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
                      <div class="info-box infbv infb-1 bg-pink hover-expand-effect1 ib-module">
                        <div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?= $t_mdl_learnt ?>"><?= $t_mdl_learnt ?></div>
                        <div class="info-icon">   
                          <div class="olo-icon oloi-46 modules"></div>
                        </div>
                        <div class="content">
                          <div class="info-text">MODULES</div>
                        </div>
                      </div>
                  </div>
                  <div class="col-lg-9 col-md-9 col-sm-9 col-xs-12">
                    <div class="row">
                      <div class="col-md-12">
                        <div class="panel">
                          <div class="panel-heading no-border flexbox">
                            <div class="panel-icon"><div class="olo-icon oloi-30 topmod"></div></div>
                            <div class="panel-title"><h5>Top Modules Learnt</h5></div>
                          </div>
                          <div class="panel-body pad-10 bg">
                            <div class="row clearfix">
                              <?php if (!isset($a_mdl_ts_top3) || count($a_mdl_ts_top3) == 0) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center"><br><br><br>No data found!</div>
                              <?php else : ?>
                                <?php foreach ($a_mdl_ts_top3 as $km => $module) : ?>
                                  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center top-module">
                                    <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                      <div class="content">
                                        <div class="text" title="<?php echo round($module / 60, 2) . 'hours'; ?>"><?php echo $km; ?></div>
                                      </div>
                                    </div>
                                  </div>
                                <?php endforeach; ?>
                              <?php endif; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="col-md-6 half-box">
                <div class="panel">
                  <div class="panel-heading main-heading text-center">
                    <h4>Demographics</h4>
                  </div>
                  <div class="panel-body">
                    <div class="row">
                      <div class="col-md-3 no-p-r">
                        <div class="clearfix" style="margin-bottom: 15px;">
                          <div class="info-box infb-hl wbg no-margin">
                            <div class="icon"><div class="olo-icon oloi-30 aboveage"></div></div>
                            <div class="content full-width">
                              <div class="text col-green font-bold"><?php echo round($tt_above_35_perc) ?>%</div>
                              <div class="text col-dark-grey"><small>ABOVE 36</small></div>
                            </div>
                          </div>
                        </div>
                        <div class="clearfix" style="margin-bottom: 15px;">
                          <div class="info-box infb-hl wbg no-margin">
                            <div class="icon"><div class="olo-icon oloi-30 belowage"></div></div>
                            <div class="content full-width">
                              <div class="text col-green font-bold"><?php echo round($tt_below_35_perc) ?>%</div>
                              <div class="text col-dark-grey small"><small>BELOW 36</small></div>
                            </div>
                          </div>
                        </div>
                        <hr>
                        <div class="clearfix" style="margin-bottom: 15px; text-align: center">
                          <div class="info-box infb-hl genderbox">
                            <div class="icon"><div class="olo-icon oloi-30 male"></div></div>
                            <div class="content full-width">
                              <div class="text col-green font-bold"><?php echo round($tt_male_perc) ?>%</div>
                            </div>
                          </div>
                        </div>
                        <div class="clearfix" style="margin-bottom: 15px; text-align: center">
                          <div class="info-box infb-hl genderbox">
                            <div class="icon"><div class="olo-icon oloi-30 female"></div></div>
                            <div class="content full-width">
                              <div class="text col-green font-bold"><?php echo round($tt_female_perc) ?>%</div>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-9">
                        <div class="row clearfix">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon"><div class="olo-icon oloi-62 lts"></div></div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">LEARNING TIME SPENT</div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-yellow" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
                                  </div>
                                  <span><?php echo ($t_ts_h_ind < 1 ? round($t_ts_m_ind, 0) . ' Minutes' : round($t_ts_h_ind,0) . ' Hours'); ?></span>
                                  
                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="62" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round(($t_ts_m * 100 / $t_ts_m_ind), 2) ?>%"></div>
                                    </div>
                                    <span><?php echo ($t_ts_h < 1 ? round($t_ts_m,0) . ' Minutes' : round($t_ts_h,0) . ' Hours'); ?></span>
                                </div>
                              </div>
                            </div>
                          </div>
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon"><div class="olo-icon oloi-62 ats"></div></div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">AVERAGE TIME SPENT</div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-yellow" role="progressbar" aria-valuenow="<?php echo round($t_ts_m_ind / $t_ppl_ind,0) ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round($t_ts_m_ind / $t_ppl_ind,0) ?>%"></div>
                                  </div>
                                  <span><?php echo round($t_ts_m_ind / $t_ppl_ind,0) ?> Minutes</span>
                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="<?php echo round($t_ts_m / $t_ppl,0) ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round($t_ts_m / $t_ppl,0) ?>%"></div>
                                  </div>
                                  <span><?php echo round($t_ts_m / $t_ppl,0) ?> Minutes</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon"><div class="olo-icon oloi-62 tp"></div></div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">TOTAL PARTICIPANTS</div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-yellow" role="progressbar" aria-valuenow="<?php echo round(($t_ppl_ind * 100 / ($t_ppl + $t_ppl_ind)), 0) ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round(($t_ppl_ind * 100 / ($t_ppl + $t_ppl_ind)), 0) ?>%"></div>
                                  </div>
                                  <span><?php echo $t_ppl_ind ?> Participants</span>
                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="<?php echo round(($t_ppl * 100 / ($t_ppl + $t_ppl_ind)), 0) ?>" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round(($t_ppl * 100 / ($t_ppl + $t_ppl_ind)), 0) ?>%"></div>
                                  </div>
                                  <span><?php echo $t_ppl ?> Participants</span>
                                </div>
                              </div>
                            </div>
                          </div>

                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
                            <div class="info-box dgbox">
                              <div class="icon"><div class="olo-icon oloi-62 nod"></div></div>
                              <div class="content full-width">
                                <div class="text col-dark-grey">NO. OF DEPARTMENTS</div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-yellow" role="progressbar" aria-valuenow="<?php echo $p_modules_learnt; ?>" aria-valuemin="0" aria-valuemax="<?php echo $p_modules_learnt; ?>" style="width: <?php echo $p_modules_learnt; ?>%"></div>
                                  </div>
                                  <span><?php echo $t_mdl_learnt; ?></span>
                                </div>
                                <div class="pbar">
                                  <div class="progress col-transparent">
                                    <div class="progress-bar bg-purple" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%"></div>
                                  </div>
                                  <span><?php echo $t_mdl_total; ?></span>
                                </div>
                              </div>
                            </div>
                          </div>

                          
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <span class="icn bg-yellow dgicn">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small class="dgleg">INDUSTRY STATISTICS</small>&nbsp;&nbsp;&nbsp;
                            <span class="icn bg-purple dgicn">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small class="dgleg">COMPANY STATISTICS</small>
                          </div>

                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix">
              <hr>
            </div>

            <div class="row">
              <div class="col-md-12">
                <h4 class="text-center">GENDER WISE DEMOGRAPFICS</h4>
              </div>
              <div class="col-md-6">
                <div class="panel">
                  <div class="panel-heading">
                    <h4 class="text-center"><i class="fa fa-male col-green"></i>&nbsp;MALE</h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['male']['min'] ?>s"><span><?php echo $t_ts_gw['male']['min'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">MIN TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['male']['avg'] ?>s"><span><?php echo $t_ts_gw['male']['avg'] ?></span></div>
                        </div>

                        <div class="row1 clearfix text-center small">AVERAGE TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['male']['max'] ?>s"><span><?php echo $t_ts_gw['male']['max'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">MAX TIME SPENT</div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <div class="row1 clearfix text-center small"><span class="col-green"><?php echo $tt_all_male ?></span> Male Learners</div>
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Top 3 Modules Learnt</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_male as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Popular Learners</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_pl_male as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="panel">
                  <div class="panel-heading">
                    <h4 class="text-center"><i class="fa fa-female col-blue"></i>&nbsp;FEMALE</h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['male']['min'] ?>s"><span><?php echo $t_ts_gw['female']['min'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">MIN TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['female']['avg'] ?>s"><span><?php echo $t_ts_gw['female']['avg'] ?></span></div>
                        </div>

                        <div class="row1 clearfix text-center small">AVERAGE TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['female']['max'] ?>s"><span><?php echo $t_ts_gw['female']['max'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">MAX TIME SPENT</div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <div class="row1 clearfix text-center small"><span class="col-blue"><?php echo $tt_all_female ?></span> Female Learners</div>
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Top 3 Modules Learnt</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_female as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Popular Learners</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_pl_female as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix">
              <hr>
            </div>

            <div class="row">
              <div class="col-md-12">
                <h4 class="text-center"><span class="col-red">Above 36</span>&nbsp;AGE WISE DEMOGRAPFICS&nbsp;<span class="col-orange">Below 36</span></h4>
              </div>
              <div class="col-md-6">
                <div class="panel">
                  <div class="panel-heading">
                    <h4 class="text-center">Above 36</h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="doghnutwrap">

                        </div>
                        <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['male']['min'] ?>s"><span><?php echo $t_ts_gw['male']['min'] ?></span></div>

                        <div class="row1 clearfix text-center small">MIN TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['male']['avg'] ?>s"><span><?php echo $t_ts_gw['male']['avg'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">AVERAGE TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['male']['max'] ?>s"><span><?php echo $t_ts_gw['male']['max'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">MAX TIME SPENT</div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <div class="row1 clearfix text-center small"><span class="col-red">4</span> Learners
                    </div>
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Top 3 Modules Learnt</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_above_35 as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Popular Learners</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_pl_above_35 as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div class="col-md-6">
                <div class="panel">
                  <div class="panel-heading">
                    <h4 class="text-center">Below 36</h4>
                  </div>
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['female']['min'] ?>s"><span><?php echo $t_ts_gw['female']['min'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">MIN TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['female']['avg'] ?>s"><span><?php echo $t_ts_gw['female']['avg'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">AVERAGE TIME SPENT</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo $t_ts_gw['female']['max'] ?>s"><span><?php echo $t_ts_gw['female']['max'] ?></span></div>
                        </div>
                        <div class="row1 clearfix text-center small">MAX TIME SPENT</div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div><br><br>
                    <div class="row1 clearfix text-center small"><span class="col-orange">25</span> Learners
                    </div>
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Top 3 Modules Learnt</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_below_35 as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-6">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Popular Learners</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_pl_below_35 as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="clearfix">
              <hr>
            </div>

            <div class="row">
              <div class="col-md-12">
                <h4 class="text-center">PREFERRED MODE OF LEARNING</h4>
              </div>
              <div class="col-md-12">
                <?php
                  $tt_cat_article = (isset($a_mdl_cat['Article']) ? $a_mdl_cat['Article'] : 0);
                  $tt_cat_video = (isset($a_mdl_cat['Video']) ? $a_mdl_cat['Video'] : 0);
                  $tt_cat_book = (isset($a_mdl_cat['Booksuggestion']) ? $a_mdl_cat['Booksuggestion'] : 0);
                  $tt_cat_total = $tt_cat_article + $tt_cat_video + $tt_cat_book;

                ?>
              <div class="panel">
                  <div class="panel-body">
                    <div class="row clearfix" style="height: 70px">
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo ($tt_cat_total > 0 ? round($tt_cat_article * 100 / $tt_cat_total, 0) : 0) ?>s"><span><?php echo ($tt_cat_total > 0 ? round($tt_cat_article * 100 / $tt_cat_total, 0) : 0) ?>%</span></div>
                        </div>
                        <div class="row1 clearfix text-center small">ARTICLES</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo ($tt_cat_total > 0 ? round($tt_cat_video * 100 / $tt_cat_total, 0) : 0) ?>s"><span><?php echo ($tt_cat_total > 0 ? round($tt_cat_video * 100 / $tt_cat_total, 0) : 0) ?>%</span></div>
                        </div>

                        <div class="row1 clearfix text-center small">VIDEOS</div>
                      </div>
                      <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 doghnutwrap">
                        <div class="doghnutwrap">
                          <div class="doghnut" style="animation-delay: -<?php echo ($tt_cat_total > 0 ? round($tt_cat_book * 100 / $tt_cat_total, 0) : 0) ?>s"><span><?php echo ($tt_cat_total > 0 ? round($tt_cat_book * 100 / $tt_cat_total, 0) : 0) ?>%</span></div>
                        </div>
                        <div class="row1 clearfix text-center small">BOOK SUGGESTIONS</div>
                      </div>
                    </div>
                    <div class="row clearfix">&nbsp;</div>
                    <br>
                    <div class="row clearfix pad-10">
                      <div class="col-md-4">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Most popular Articles</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_cat_article as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Most popular Videos</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_cat_video as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div class="col-md-4">
                        <div class="panel bx-202">
                          <div class="panel-heading">
                            <h4 class="text-center">Most popular Book Suggestions</h4>
                          </div>
                          <div class="panel-body pad-10">
                            <div class="row clearfix">
                              <?php foreach ($a_mdl_top3_cat_book as $km => $module) : ?>
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                  <div class="info-box1 infb-hl1 hover-expand-effect no-margin">
                                    <div class="content pad-5">
                                      <div class="text list-item"><?php echo $km; ?></div>
                                    </div>
                                  </div>
                                </div>
                              <?php endforeach; ?>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

            </div>

            <div class="clearfix">
              <hr>
            </div>
          </div>
        <?php
        }
        ?>
      </div>
      <!-- /.container-fluid-->
      <!-- /.content-wrapper-->
      <footer class="sticky-footer">
        <div class="container">
          <div class="text-center">
            <small>Copyright © 2018 e2e People Practices</small>
          </div>
        </div>
      </footer>
      <!-- Scroll to Top Button-->
      <a class="scroll-to-top rounded" href="#page-top">
        <i class="fa fa-angle-up"></i>
      </a>
      <!-- Logout Modal-->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
              <a class="btn btn-primary" href="<?php echo base_url('login/logout') ?>" ">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src=" <?php echo base_url() ?>/assets/vendor/jquery/jquery.min.js"> </script> <script src="<?php echo base_url() ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                <!-- Core plugin JavaScript-->
                <script src="<?php echo base_url() ?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>
                <!-- Page level plugin JavaScript-->
                <script src="<?php echo base_url() ?>/assets/vendor/chart.js/Chart.min.js"></script>
                <script src="<?php echo base_url() ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
                <script src="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>
                <!-- Custom scripts for all pages-->
                <script src="<?php echo base_url() ?>/assets/js/sb-admin.min.js"></script>
                <!-- Custom scripts for this page-->
                <script src="<?php echo base_url() ?>/assets/js/sb-admin-datatables.min.js"></script>
                <script src="<?php echo base_url() ?>/assets/js/sb-admin-charts.min.js"></script>
            </div>
</body>

</html>
<!-- <?php
if(!isset($_SESSION["email"])){
 header("Location: login");
}
else
{
?> -->

<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
   <link href="<?php echo base_url()?>assets/select2/select2.min.css" rel="stylesheet" type="text/css" />
 <link href="<?php echo base_url()?>assets/select2/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
<?php include "sidebar.php"; ?>
  <div class="content-wrapper admpage2">
    <div class="container-fluid rgpage">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
		<li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>add_new_users/users/<?php echo $this->uri->segment(3)?>">User Management</a>
        </li>
		<li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>addmodulecontent/<?php echo $this->uri->segment(2)?>/<?php echo $this->uri->segment(3)?>">Add Module Content</a>
        </li>
        <li class="breadcrumb-item active"><?php echo $data->prg_name ?></li>
      </ol>
      <!-- Icon Cards-->
		<?php if ($this->session->flashdata('successmsg')) { ?>
			<div class="alert alert-success"> <?= $this->session->flashdata('successmsg') ?> </div>
		<?php } ?>
		<?php if ($this->session->flashdata('failuremessage')) { ?>
			<div class="alert alert-danger"> <?= $this->session->flashdata('failuremessage') ?> </div>
		<?php } ?>
     
    <center><h3>Add Module Content</h3></center>
	
	<?php //print_r($data); ?>
	
	
	
	<div class="container">
		<form action="<?php echo base_url() ?>modcontentbyuser/addinfo" method="post" enctype="multipart/form-data" id="">
			<div class="col-sm-12" style="margin-bottom:30px">
				<input type="hidden" name="userid" value="<?php echo $this->uri->segment(2); ?>">
				<input type="hidden" name="orgid" value="<?php echo $this->uri->segment(3); ?>">
				<input type="hidden" name="idpid" value="<?php echo $this->uri->segment(4); ?>">
				<input type="hidden" name="idpmoduleid" value="<?php echo $this->uri->segment(5); ?>">
				<p style=" margin-bottom: 2px;">Descriptions</p>
				<textarea name="description" id="summernote"><?php if(!empty($data->description)){echo $data->description; } ?></textarea>
			</div>
			<div class="col-sm-12" style="margin-bottom:30px">
				<p style=" margin-bottom: 2px;">Docs</p>
				<input type="file" name="docs">
				<p>
					<?php //print_r($data->docs); ?>
					<?php if(empty($data->docs)){
								echo "";
							}else {
								echo "<span id=\"uploadedfile\"><b>Uploaded Docs:</b>
							  <a href=\"".base_url()."uploads/usermoduledocs/$data->docs\">$data->docs</a>
							  <span><a id=\"deletedoc\" style=\"color:red\">Remove</a></span></span>";
							}
					?></p>
				<div id="result"><span id="value"></span></div>
			</div>
			<div class="col-sm-12" style="margin-bottom:30px;text-align: center;">
				<input type="submit" name="submit" style="background: #0088C7;border: solid 2px #0088C7;color: #fff;padding: 10px 25px;cursor: pointer;">
			</div>
		</form>
	</div>
	
    <!-- /.container-fluid-->
    <!-- /.content-wrapper-->
    <footer class="sticky-footer">
      <div class="container">
        <div class="text-center">
          <small>Copyright © 2018 e2e People Practices</small>
        </div>
      </div>
    </footer>
    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fa fa-angle-up"></i>
    </a>
    <!-- Logout Modal-->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
             <a class="btn btn-primary" href="<?php echo base_url('login/logout')?>">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url()?>assets/select2/select2.full.min.js" type="text/javascript"></script>
  <!--   <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script> -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
  </div>
<script type="text/javascript">
	$(document).ready(function() {
		
		$("#deletedoc").click(function(event) {
		
		event.preventDefault();
		var docs = '<?php echo $data->docs; ?>';
		var userid = '<?php echo $data->userid;  ?>';
		var idpid = '<?php echo $data->idpid;  ?>';
		var idpmoduleid = '<?php echo $data->idpmoduleid;  ?>';
		//var password = $("input#pwd").val();
		jQuery.ajax({
		type: "POST",
		url: "<?php echo base_url(); ?>" + "modcontentbyuser/deletedoc",
		dataType: 'json',
		data: {docs: docs, userid: userid, idpid: idpid, idpmoduleid: idpmoduleid},
		success: function(data) {
			//alert(data);
			if (data) {
				
				//alert(data);
				// // Show Entered Value
				//jQuery("div#result").show();
				$("#value").html(data);
				if(data == 'Successfully deleted the files'){
					setTimeout(function() {
					  $('#value, #uploadedfile').fadeOut('fast');
					}, 3000);
				}
				
				
				// // jQuery("div#value").html(res.username);
				// // jQuery("div#value_pwd").html(res.pwd);
			// }else {
				// alert('no values are coming');
			 }
			 
		}
		
		
		});
		});
		
		
		$('#summernote').summernote();
	});
	$('#summernote').summernote({
		height: 300,
		
	});
	
	
	
</script>

</body>

</html>
<!-- <?php } ?> -->
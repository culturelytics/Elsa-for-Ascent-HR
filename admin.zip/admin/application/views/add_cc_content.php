<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title><?php echo $this->config->item('page_title') ?></title>
        <!-- Bootstrap core CSS-->
        <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <!-- Custom fonts for this template-->
        <link href="<?php echo base_url() ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
        <!-- Page level plugin CSS-->
        <link href="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
        <!-- Custom styles for this template-->
        <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
    </head>

    <body class="fixed-nav sticky-footer bg-dark" id="page-top">
        <!-- Navigation-->
        <?php include "sidebar.php"; ?>


        <div class="content-wrapper admpage2">
            <div class="container-fluid rgpage">
                <!-- Breadcrumbs-->
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo base_url() ?>">home</a>
                    </li>
                    <li class="breadcrumb-item active">Knowledge Center</li>
                </ol>
                <!-- Icon Cards-->

                <center><h3><?= $kc[0]->prg_name ?> Content</h3></center>

                <div class="container kccontent">
                    <hr>

                    <form action="<?php echo current_url() ?>" method="post" id="kcctop">
                        <table>
                            <tr>
                                <td style="text-align: right;vertical-align: top;    float: right;padding-right: 5px;min-width: 156px;">Module Name : </td>
                                <td colspan="4"  style="width: 85%;"><div>
                                        <input type="text" name="kc_title_old" class="form-control" placeholder="KC Name" disabled required value="<?= $kc[0]->prg_name ? $kc[0]->prg_name : set_value('kc_title_old') ?>">
                                        <?php echo form_error('kc_title_old'); ?>
                                    </div>
                                </td>
                            </tr>
                            <tr><td style="text-align: right;vertical-align: top; float: right;padding-right: 5px;min-width: 156px;">Module Description : </td>
                                <td colspan="4"  style="width: 85%;"><div>
                                        <span name="kc_content_old" disabled><?= $kc[0]->prg_desc ?></span>

                                    </div>
                                </td>
                            </tr>
                        </table>
                        <div class="gprntdiv"> 
                            <div class="panel-heading gprnt">
                                <div style="padding: 3px 10px 3px 10px;" class="btn btn-primary expandCollapseGrandParent1"  data-toggle="collapse" data-target="#collapse1" aria-expanded="false" aria-controls="collapse1">
                                    <i class="fa fa-caret-right caret rightgp1" aria-hidden="true"></i>
                                    <i class="fa fa-caret-down caret downgp1 hideCaret" aria-hidden="true"></i>
                                    &nbsp;<span> Topics and Content </span>
                                     
                               
                                    <!--<a data-toggle="modal" data-target="#addTopicModal"  class="btn btn-primary btn-condensed" style="color: #fff;">Add New</a>&nbsp;&nbsp;-->
                                    <input style="float: right;padding: 4px 10px 4px 10px;font-size: 13px;min-width: 100px;" class="btn btn-primary new_row" type="button" name="Add Topics" value="Add Topics" data-toggle="modal" data-target="#addTopicModal"  id="checkBtn">
                                </div>
                            </div>

                            <div id="collapse1" class="panel-collapse collapse">
                                <div class="tablemain">
                                    <table class="table table-border">
                                        <tbody id="kc_tbody" class="contentTable">
                                            <?php
                                            $cnt = 0;
                                            $i = 0;
                                            $old_id = '';
                                            $ctnr = 0;
                                            $ctnr2 = 0;
                                            $obj1 = array();
                                             foreach ($list as $klist) {
                                                        if ($obj1[$klist->kl_kc_id] == 'undefined') {
                                                            $obj1[$klist->kl_kc_id] = 0;
                                                        }
                                                        $obj1[$klist->kl_kc_id] += $klist->kl_credits;
                                                    }
//                                                    var_dump($obj1);
                                            foreach ($list as $row) {
                                                $i++;
                                                $next_id = isset($list[$i]->kl_kc_id) ? $list[$i]->kl_kc_id : '';
                                                $cnt++;
                                                if ($row->kl_kc_id != $old_id) {
                                                    $ctnr++;
                                                    $ctnr2 = 0;

                                                   
                                                    ?>
                                                    <tr id="parent_<?= $cnt ?>" class="contenttr" name="<?= $ctnr2 ?>" data-toggle="collapse" data-target=".child_<?= $row->kl_kc_id ?>" aria-expanded="false" aria-controls="child_<?= $row->kl_kc_id ?>">
                                                        <td colspan="6">
                                                            <div class="btn btn-primary expandCollapseParent" >
                                                                <i class="fa fa-caret-right caret rightp_parent_<?= $cnt ?>" aria-hidden="true"></i>
                                                                <i class="fa fa-caret-down caret downp_parent_<?= $cnt ?> hideCaret" aria-hidden="true"></i>&nbsp;&nbsp;<?= $ctnr ?> &nbsp;<span> <?= $row->kc_title ?> </span>
                                                                <span><a href="#" class="contentedit" data-pid="<?= $row->kc_prg_id ?>" data-kc-id="<?= $row->kl_kc_id ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                                                <!--<button style="float: right;padding: 1px 10px 1px 10px;" class="btn btn-primary inside_new_row" name="Add Content" >Add Content</button>-->
                                                                <div style='float: right'>
                                                                    <span>Total Credits : </span>
                                                                    <input style="font-size: 13px;width: 45px;border-radius: 5px;padding: 2px 10px 2px 10px;"  type="text" value='<?= $obj1[$row->kl_kc_id]?>' name="credits" disabled  >
                                                                    <input style="padding: 3px 10px 3px 10px;font-size: 13px;min-width: 100px;" class="btn btn-primary inside_new_row addContent" data-kc-id="<?= $row->kl_kc_id ?>"  data-contentname="<?= $row->kc_title ?>" type="button" name="Add Content" value="Add Content" id="checkBtn">
                                                            </div>
                                                                </div>
                                                        </td> 
                                                    </tr>
                                                    <tr class="panel-collapse collapse child_<?= $row->kl_kc_id ?>" style='height: 30px;'>
                                                        <td></td>
                                                        <td style="font-weight: 600;font-size: 15px;"><span style='padding: 5px;'>Content Title</span></td>
                                                        <td style="font-weight: 600;font-size: 15px;"><span style='padding: 5px;'>Content Type</span></td>
                                                        <td style="font-weight: 600;font-size: 15px;"><span style='padding: 5px;'>Content URL</span></td>
                                                        <td style="font-weight: 600;font-size: 15px;    text-align: center;"><span style='padding: 5px;'>Credits</span></td>
                                                        <td></td>
                                                    </tr>
                                                    <?php
                                                }$ctnr2++;
                                                $old_id = $row->kl_kc_id;
                                                ?>

                                                <tr id="child_<?= $cnt ?>" class="panel-collapse collapse child_<?= $row->kl_kc_id ?> kcsubcontent" style='font-size: 14px;'>
                                                    <td style="width: 8%;min-width: 13px;padding: 10px 0px 10px 0px;"><div><?= $ctnr ?> . <?= $ctnr2 ?></div></td>
                                                    <td style="width:25%;padding: 10px 0px 10px 0px;"><div><span><?= $row->kl_list ?></span></div></td>
                                                    <td style="width: 12%;min-width: 120px;padding: 10px 0px 10px 0px;"><div class="form-group"><div><span><?= $row->kl_cat ?></span></div></div>
                                                    </td>
                                                    <td style="width:35%;max-width: 250px !important;padding: 10px 0px 10px 0px;"><div style='width: 98%; overflow: hidden;'><span><?= $row->kl_link ?></span></div></td>
                                                    <td style="width: 10%;min-width: 13px;text-align: center;padding: 10px 0px 10px 0px;"><div><?= $row->kl_credits ?></div></td>
                                                    <td class="" style="padding: 10px;width: 10%;min-width: 26px;">
                                                        <span><a href="#" class="editsubcontent" data-klid="<?= $row->kl_id ?>" data-kc-id="<?= $row->kl_kc_id ?>" data-contentname="<?= $row->kc_title ?>" data-kllist="<?= $row->kl_list ?>"  data-kltype="<?= $row->kl_cat ?>" data-kllink="<?= $row->kl_link ?>"  data-klcredits="<?= $row->kl_credits ?>" ><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                                        <span><a href="#" class="delete_row_1" onclick="deleteprogram('<?php echo base_url() ?>knowledge_center/deleteSubContent/<?php echo $this->uri->segment(3) ?>/<?php echo $row->kl_id ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                                    </td>
                                                </tr>  
                                                <?php
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                        <div class="gprntdiv"> 
                            <div class="panel-heading gprnt">
                                <button class="btn btn-primary expandCollapseGrandParent2" type="button" data-toggle="collapse" data-target="#collapse2" aria-expanded="false" aria-controls="collapse2">
                                    <i class="fa fa-caret-right caret rightgp2" aria-hidden="true"></i> 
                                    <i class="fa fa-caret-down caret downgp2 hideCaret" aria-hidden="true"></i>&nbsp;<span> Books/Images </span>
                                    <input style="float: right;padding: 4px 10px 4px 10px;font-size: 13px;min-width: 100px;" class="btn btn-primary new_row" type="button" name="Add Image" value="Add Image" data-toggle="modal" data-target="#addImageModal" id="checkBtn">
                                </button>
                            </div>
                        </div>
                        <div id="collapse2" class="panel-collapse collapse">
                            <div class="table-responsive">
                                <table class="table table-border">
                                    <tbody id="kc_tbody" class="contentTable">
                                        <tr  style='font-size: 14px;'>
                                            <td></td>
                                            <td style="font-weight: 600;"><span>Image Name</span></td>
                                            <td style="font-weight: 600;"><span>Image</span></td>
                                            <td style="font-weight: 600;"><span>Image Link</span></td>
                                            <td style="font-weight: 600;"><span>Image Credits</span></td>
                                            <td></td>
                                        </tr>
                                        <?php
                                        $i = 0;
                                        foreach ($kcimage as $row): $i++;
                                            ?> 
                                            <tr style='font-size: 14px;'>
                                                <td style="width: 8%;min-width: 13px;padding: 10px 0px 10px 0px;"><?php echo '1.' . $i; ?></td>
                                                <td style="width:25%;padding: 10px 0px 10px 0px;"><div><span><?php echo $row->img_title ?></span></div></td>
                                                <td style="width: 12%;min-width: 120px;padding: 10px 0px 10px 0px;">
                                                    <!--<input type="text" class="form-control ctype" name="kc_type[<?= $cnt ?>][]" value="<?= $row->kl_cat ?>" required>-->
                                                    <div class="form-group">
                                                        <img src="<?php echo base_url() ?>uploads/content_images/<?= $row->img_name ?>" style="width: 50px;height: 50px">
                                                    </div>
                                                </td>
                                                <td style='width:40%;max-width: 250px !important;'><div style='width: 98%; overflow: hidden;'><span><?php echo $row->img_link ?></span></div></td>
                                                <td style="width: 10%;min-width: 13px;text-align: center;padding: 10px 0px 10px 0px;"><div><?= $row->kl_credits ?></div></td>
                                                    
                                                <td style="padding: 10px;width: 10%;min-width: 26px;"><span><a href="#" class="editsubimage" data-klid="<?= $row->kl_id ?>" data-kc-id="<?= $row->kl_kc_id ?>" data-imgtitle="<?= $row->img_title ?>" data-imgid="<?= $row->img_id ?>" data-imglink="<?= $row->img_link ?>" ><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                                    <span><a href="#" class="delete_row_1" onclick="deleteprogram('<?php echo base_url() ?>knowledge_center/delete_image/<?php echo $row->img_id ?>/<?php echo $this->uri->segment(3) ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                                </td> 
    <!--                                                <td class="delete_row" style="color: gray;padding: 0px 10px 0px 10px;"><br>
                                                  <i class="fa fa-trash delete" aria-hidden="true" onclick="deleteprogram('<?php echo base_url() ?>knowledge_center/delete_image/<?php echo $row->img_id ?>/<?php echo $this->uri->segment(3) ?>')"></i>
                                              </td>-->
                                            </tr>  
                                        <?php endforeach; ?>
                                    </tbody>     
                                </table>
                            </div>
                        </div>
                        <br><br>
                    </form>
                </div> 
                <!-- /.container-fluid-->
                <!-- /.content-wrapper-->
                <footer class="sticky-footer">
                    <div class="container">
                        <div class="text-center">
                            <small>Copyright © 2018 e2e People Practices</small>
                        </div>
                    </div>
                </footer>
                <!-- Scroll to Top Button-->
                <a class="scroll-to-top rounded" href="#page-top">
                    <i class="fa fa-angle-up"></i>
                </a>
                <!-- Logout Modal-->
            </div>
        </div>
        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                    <div class="modal-footer">
                        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                        <a class="btn btn-primary" href="<?php echo base_url('login/logout') ?>">Logout</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="addTopicModal" tabindex="-1" role="dialog" aria-labelledby="TopicModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel" style="color: #0069d9;text-align: center;margin-left: 22%;">Add Topic - Topics and Content</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">

                        <form action="<?php echo base_url() ?>knowledge_center/add_topic/<?= $this->uri->segment(3) ?>" method="post">
                            <table>
<!--                                <tr><td><span style="padding: 10px 30px 10px 30px;">Topic Name - Topics and Content </span></td>
                                    <td> 
                                        <div class="form-group">
                                            <input type="text" id='editcontent' class="form-control" value="Topics and Content " required readonly>                                           
                                        </div>
                                    </td>
                                </tr>-->
                                <tr><td><span style="padding: 10px 30px 10px 30px;">Topic Title</span></td>
                                    <td>
                                        <div class="form-group">
                                            <textarea style="width: 350px;" id='topicName' class="form-control" name="kc_content[<?= $cnt ?>][]" required></textarea>   
                                            <input type="hidden" name='topicId' class="form-control" id='topicId' name="hidden" value=''>    
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <input class="btn btn-primary" type="submit" name="Save" value="Save" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;" id="checkBtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="addContentModal" tabindex="-1" role="dialog" aria-labelledby="ContentModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                <div class="modal-content">
                    <div class="modal-header" style="border-bottom: none;padding: 10px 10px 2px 10px;">
                        <h5 class="modal-title" id="exampleModalLabel" style="color: #0069d9;text-align: center;margin-left: 40%;">Add Content</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body" style="padding-top: 5px;">

                        <form action="<?php echo base_url() ?>knowledge_center/add_cc_content/<?= $this->uri->segment(3) ?>" method="post">
                            <table>
                                <tr><td><span style="padding: 1px 3px 10px 30px;">Topic Name:</span></td>
                                    <td> 
                                        <div class="form-group">
                                            <input type="text" class="form-control" id='content_title' value="" required readonly>                                           
                                        </div>
                                    </td>
                                </tr>
                                <tr><td><span style="padding: 1px 3px 10px 30px;">Content Title:</span></td>
                                    <td>
                                        <div class="form-group">
                                            <textarea style="width: 400px;" id='ctitle' class="form-control" name="kc_content[<?= $cnt ?>][]" required></textarea>   
                                        </div>
                                    </td>
                                </tr>
                                <tr>
                                    <td><span style="padding: 1px 3px 10px 30px;">Content Type:</span></td>
                                    <td>
                                        <div class="form-group">  
                                            <select class="form-control" name="kc_content[<?= $cnt ?>][]" id='kctype' >
                                                <option value="Book Suggestions" selected>Book Suggestions</option>
                                                <option value="Video">Video</option>
                                                <option value="Assessments">Assessments</option>
                                                <option value="Article">Article</option>
                                                <option value="SelfAssessment">Self Assessment</option>
                                            </select>
                                        </div>
                                    </td>
                                </tr>
                                <tr><td><span style="padding: 1px 3px 10px 30px;">Content URL:</span></td>
                                    <td>
                                        <div class="form-group">
                                            <textarea class="form-control" id='kcURL' style="width: 400px;" name="kc_content[<?= $cnt ?>][]" required></textarea>

                                            <input type="hidden" name='contentid' id='contentid' class="form-control" value="">    
                                            <input type="hidden" name='subcontentid' id='subcontentid' class="form-control" value="">    

                                        </div>
                                    </td>
                                </tr>
                                <tr><td><span style="padding: 1px 3px 10px 30px;">Content Credits:</span></td>
                                    <td> 
                                        <div class="form-group">
                                            <input id='content_credits' type="number" class="form-control" name="kc_content[<?= $cnt ?>][]" required >      
                                            
                                        </div>
                                    </td>
                                </tr>
                            </table>
                            <input class="btn btn-primary savetopic" type="submit" name="Save" value="Save" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;" id="checkBtn">
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="addImageModal" tabindex="-1" role="dialog" aria-labelledby="ImageModalLabel" aria-hidden="true">
            <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel" style="color: #0069d9;text-align: center;margin-left: 40%;">Add Image</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo base_url() ?>knowledge_center/add_attribute/<?= $this->uri->segment(3) ?>" method="post">
                            <div class="container">
                                <form action="<?php echo current_url() ?>"  enctype="multipart/form-data"  method="post" id="usersform">
                                    <table>
                                        <tr><td><span style="padding: 1px 3px 10px 30px;">Image Title:</span></td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" name="img_title" style="width: 350px;" placeholder="image title" required> 
                                                    <?php echo form_error('img_title') ?>
                                                </div>
                                            </td>
                                        </tr>
                                        <tr><td><span style="padding: 1px 3px 10px 30px;">Image:</span></td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="file" style="max-width: 350px;" name="img_name" required> 
                                                    <?php echo isset($error) ? $error['error'] : '' ?> 
                                                </div>
                                            </td>
                                        </tr>
                                        <tr><td><span style="padding: 1px 3px 10px 30px; float: right;">Image URL:</span></td>
                                            <td>
                                                <div class="form-group">
                                                    <input type="text" name="img_link" style="width: 350px;" placeholder="image link" required> 
                                                    <?php echo form_error('img_link') ?>
                                                </div>
                                            </td>
                                        </tr>
                                    </table>
                                    <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;">
                                </form>
                            </div>
                            <!--<input class="btn btn-primary" type="submit" name="Save" value="Save" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px;" id="checkBtn">-->
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="exampleModalLabel">Edit Program</h5>
                        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <form action="<?php echo base_url() ?>knowledge_center/add_attribute/<?= $this->uri->segment(3) ?>" method="post" enctype="multipart/form-data">
                        <div class="modal-body">
                            <input type="text" name="prg_name1" placeholder="knowledge Center Name" id="prg_name1" value="" required>
                            <input type="hidden" name="prg_id1" placeholder="Program Name" id="prg_id1" value="" required><br>
                            <input type="text" name="img_link1" placeholder="image link" required> 
                            <input type="file" name="prg_image" placeholder="knowledge Center Name" >
                            <div id='prg_image'></div>
                        </div>
                        <div class="modal-footer">
                            <button class="btn btn-secondary" type="submit" >Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>




        <!-- Bootstrap core JavaScript-->
        <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"></script>
        <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
        <!-- Core plugin JavaScript-->
        <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
        <!-- Page level plugin JavaScript-->
        <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
        <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
        <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
        <!-- Custom scripts for all pages-->
        <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
        <!-- Custom scripts for this page-->
        <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
        <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>
        <script src="https://cdn.ckeditor.com/4.9.2/standard/ckeditor.js"></script>

        <script>
            CKEDITOR.replace('kc_content_old', {
                // Define the toolbar groups as it is a more accessible solution.
                toolbar: [
                    {"name": 'paragraph', "groups": ['list'], "items": ['BulletedList']},
                ]
            });
        </script>

        <script type="text/javascript">
            $(document).ready(function () {
                $('.addContent').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    var kcid = $(this).data('kc-id');
                    var contentname = $(this).data('contentname');
                    $('#content_title').val(contentname);
                    $('#contentid').val(kcid);
                    $('#addContentModal').modal('show');
                });
                $('.editsubcontent').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    var kl_list = $(this).data('kllist');
                    var kl_type = $(this).data('kltype');
                    var kl_link = $(this).data('kllink');
                    var kcid = $(this).data('kc-id');
                    var contentname = $(this).data('contentname');
                    var klsubcontentid = $(this).data('klid');
                    var klklcredits = $(this).data('klcredits');
                    

                    $('#content_title').val(contentname);
                    $('#ctitle').val(kl_list);
                    $('#kcURL').val(kl_link);
                    $('#kctype').val(kl_type);
                    $('#subcontentid').val(klsubcontentid);
                    $('#contentid').val(kcid);
                    $('#content_credits').val(klklcredits);
                    $('#addContentModal').modal('show');
                });

                $('.contentedit').click(function (e) {
                    e.stopPropagation();
                    e.preventDefault();
                    var kcid = $(this).data('kc-id');
                    $.post('<?php echo base_url() ?>knowledge_center/edit_content', 'kcid=' + kcid, function (rs) {
                        if (rs) {
                            rs = JSON.parse(rs);
                            $('#topicId').val(rs[0].kc_id);
                            $('#topicName').val(rs[0].kc_title);
                            $('#addTopicModal').modal('show');
                        } else {
                            alert("No record found")
                        }
                    });
                });
                $('.programedit').click(function () {
                    var pid = $(this).data('pid');
                    $.post('<?php echo base_url() ?>knowledge_center/edit_image', 'pid=' + pid, function (rs) {
                        if (rs) {
                            rs = JSON.parse(rs);
                            console.log(rs);
                            $('#prg_id1').val(rs[0].img_id);
                            $('#prg_name1').val(rs[0].img_title);
                            $('input[name="prg_image"]').val('');
                            $('input[name="img_link1"]').val(rs[0].img_link);

                            $('#prg_image').html('<img src="<?php echo base_url() ?>uploads/content_images/' + rs[0].img_name + '" style="width: 50px;height: 50px">');
                            $('#myModal').modal('show');
                        } else {
                            alert("No record found")
                        }
                    });
                });
            });

            var cnt1 = '<?php echo $cnt ?>';
            $(document).on('click', '.expandCollapseGrandParent1', function (e) {
                setTimeout(function () {
                    if ($(".caret").closest(".rightgp1").hasClass('hideCaret')) {
                        $(".rightgp1").removeClass('hideCaret');
                        $(".downgp1").addClass('hideCaret');
                        $(".expandCollapseGrandParent1").removeClass('active');
                    } else {
                        $(".downgp1").removeClass('hideCaret');
                        $(".rightgp1").addClass('hideCaret');
                        $(".expandCollapseGrandParent1").addClass('active');
                    }
                }, 200);
            });
            $(document).on('click', '.expandCollapseGrandParent2', function (e) {
                setTimeout(function () {
                    if ($(".caret").closest(".rightgp2").hasClass('hideCaret')) {
                        $(".rightgp2").removeClass('hideCaret');
                        $(".downgp2").addClass('hideCaret');
                        $(".expandCollapseGrandParent2").removeClass('active');

                    } else {
                        $(".downgp2").removeClass('hideCaret');
                        $(".rightgp2").addClass('hideCaret');
                        $(".expandCollapseGrandParent2").addClass('active');
                    }
                }, 200);

            });
            $(document).on('click', '.contenttr', function (e) {
                var cnt = $(this).closest("id");
                setTimeout(function () {
                    if ($(".caret").closest(".rightp_" + cnt.prevObject[0].id).hasClass('hideCaret')) {
                        setTimeout(function () {
                            $(".rightp_" + cnt.prevObject[0].id).removeClass('hideCaret');
                            $(".downp_" + cnt.prevObject[0].id).addClass('hideCaret');
                        }, 200);
                    } else {
                        $(".downp_" + cnt.prevObject[0].id).removeClass('hideCaret');
                        $(".rightp_" + cnt.prevObject[0].id).addClass('hideCaret');
                    }
                }, 100);
            });


            $(document).on('click', '.savetopic', function (e) {

                $(".savebtn").removeAttr("disabled");
                $("#cancelbtn").removeAttr("disabled");
            });
            $(document).on('click', '.btn', function (e) {

                $(".savebtn").removeAttr("disabled");
                $("#cancelbtn").removeAttr("disabled");
            });

            $(document).on('click', '.new_row', function (e) {
                e.stopPropagation();
                e.preventDefault();
            });
//            $(document).on('click', '.delete_row', function (e) {
//                $(this).closest('tr').remove();
////                add_numbers_td();
//            });
            $(document).on('click', '.inside_new_row', function (e) {
                e.stopPropagation();
                e.preventDefault();
            });
            $(document).on('click', '.inside_delete_row', function (e) {
                $(this).closest('p').remove();
            });
            function add_numbers_td() {
                $('#kc_tbody > tr').each(function (i) {
                    cnt = i + 1;
                    $(this).find("td:first").text(i + 1);
                });
            }
            function deleteprogram(url) {
                a = confirm("Are you sure to delete?");
                console.log(a);
                if (a) {
                    window.location.href = url;
                }
            }

        </script>
    </body>
</html>

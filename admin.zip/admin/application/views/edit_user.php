<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>/assets/css/sb-admin.css" rel="stylesheet">
  <link href="<?php echo base_url() ?>assets/select2/select2.min.css" rel="stylesheet" type="text/css" />
  <link href="<?php echo base_url() ?>assets/select2/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper">
    <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>add_new_users/users/<?php echo $this->uri->segment(4)?>">User Management</a>
        </li>
        <li class="breadcrumb-item active">Edit User</li>
      </ol>
      <!-- Icon Cards-->

      <div class="clearfix">
        <center>
          <h3>EDIT USER</h3>
        </center>
      </div>
    </div>

    <div class="container-fluid">

      <div class="container">


        <form action="<?php echo base_url() ?>edituser/users/<?= $this->uri->segment(3) ?>/<?= $this->uri->segment(4) ?>" method="post" id="edituserform">

          <div>
            <input type="text" name="name" value="<?php echo set_value('name') ? set_value('name') : $row->name ?>" placeholder="Name">
            <?php echo form_error('name') ?>
          </div>

          <div>
            <input type="text" name="last_name" placeholder="Last Name" value="<?= $row->last_name != '' ? $row->last_name : set_value('last_name') ?>" required>
            <?php echo form_error('last_name'); ?>
          </div>

          <!--<div>
                <input type="text" name="organization" placeholder="Organization"  value="<?= $row->organization != '' ? $row->organization : set_value('organization') ?>" required>
                 <?php echo form_error('organization'); ?>
           </div>-->
          <div>
            <select style="margin: 10px 0" name="organization_id" id="organization_id" class="form-control full-width required" required>
              <?php foreach ($organizations as $k => $org) : ?>
                <option value="<?php echo $org->id ?>" <?php echo ($org->id == $row->organization_id ? 'selected="true"' : '') ?>><?php echo $org->org_name ?></option>
              <?php endforeach; ?>
            </select>
            <?php echo form_error('organization_id'); ?>
          </div>
          <div>
            <input type="text" name="linkedin" placeholder="Linked In" value="<?= $row->linkedin != '' ? $row->linkedin : set_value('linkedin') ?>">
          </div>
          <div>
            <input type="text" name="twitter" placeholder="Twitter" value="<?= $row->twitter != '' ? $row->twitter : set_value('twitter') ?>">
          </div>
          <div class="eph">
            <select class="required form-control" name="age" required>
              <option value="">Select Age</option>
              <option value="1" <?php echo $row->age == '1' ? 'selected' : '' ?>>21-36</option>
              <option value="2" <?php echo $row->age == '2' ? 'selected' : '' ?>>37-50</option>
              <option value="3" <?php echo $row->age == '3' ? 'selected' : '' ?>>50+</option>
            </select>
            <?php echo form_error('age'); ?>
          </div>
          <div class="methods">Gender:
            <input type="radio" name="gender" value="male" <?php echo  $row->gender == '1' ? 'checked' : 'checked' ?>>Male&nbsp;&nbsp;
            <input type="radio" name="gender" value="female" <?php echo  $row->gender == '1' ? 'checked' : '' ?>>Female<br>
            <?php echo form_error('gender'); ?>
          </div>





          <input type="hidden" name="id" value="<?php echo $row->id ?>">
          <div> <input type="email" name="email" value="<?php echo $row->email ?>" readonly placeholder="Email"> </div> <!-- php above 7 version -->
          <?php $aa_status = $row->status; ?>
          <div>

            <input type="text" name="password" value="<?php echo $row->password ?> " placeholder="Password">

            <?php echo form_error('name') ?>
          </div>
          <div> <input type="text" name="phone" value="<?php echo $row->contact ?>" placeholder="Phone no"></div>

          <div>
            <h5 class="aeu">Access for Aggregator Knowledge Center</h5>
            <select name="kaccess" id="status2">
              <option value="no" <?php if ($row->kaccess == 'no' || set_value('kaccess') == 'no') {
                                    echo "selected";
                                  } ?>>No</option>
              <option value="yes" <?php if ($row->kaccess == 'yes' ||  set_value('kaccess') == 'yes') {
                                    echo "selected";
                                  } ?>>Yes</option>
            </select>
          </div>

          <div class="alab" id="mdl-kaccess" style="display:<?php echo $row->kaccess == 'yes' ? '' : 'none' ?>">
            <div class="col-lg-12">
              <div class="col-lg-9">
                <select class="col-lg-3 select2me kca_a_list" name="kca[]" multiple>
                  <option value=""></option>
                  <?php
                  $kca_a_list = json_decode(json_encode($kca_a_list), true);
                  $kca_kc_id = array_column($kca_a_list, 'kca_kc_id');
                  foreach ($kc_a_list as $row1) {
                  ?>
                    <option value="<?= $row1->prg_id ?>" <?php if (in_array($row1->prg_id, $kca_kc_id)) {
                                                          echo 'selected';
                                                        } ?>><?= $row1->prg_name ?></option>
                  <?php } ?>
                </select>
                <?php echo form_error('kca[]'); ?>
              </div>
            </div>
          </div>

          <div>
            <h5 class="aeu">Access for Client Knowledge Center</h5>
            <select name="kc_c_access" id="kc_c_access">
              <option value="no" <?php if ($row->kc_c_access == 'no' || set_value('kc_c_access') == 'no') {
                                    echo "selected";
                                  } ?>>No</option>
              <option value="yes" <?php if ($row->kc_c_access == 'yes' ||  set_value('kc_c_access') == 'yes') {
                                    echo "selected";
                                  } ?>>Yes</option>
            </select>
          </div>

          <div class="alab" id="mdl-kc_c_access" style="display:<?php echo $row->kc_c_access == 'yes' ? '' : 'none' ?>">
            <div class="col-lg-12">
              <div class="col-lg-9">
                <select class="col-lg-3 select2me kca_c_list" name="kca_c[]" multiple>
                  <option value=""></option>
                  <?php
                  $kca_c_list = json_decode(json_encode($kca_c_list), true);
                  $kca_kc_id = array_column($kca_c_list, 'kca_kc_id');
                  foreach ($kc_c_list as $row2) {
                  ?>
                    <option value="<?= $row2->prg_id ?>" <?php if (in_array($row2->prg_id, $kca_kc_id)) {
                                                          echo 'selected';
                                                        } ?>><?= $row2->prg_name ?></option>
                  <?php } ?>
                </select>
                <?php echo form_error('kca_c[]'); ?>
              </div>
            </div>
          </div>

          <div>
            <h5 class="aeu">Access for Aggregator IDP</h5>
            <select name="caccess" id="status2">
              <option value="no" <?php if ($row->caccess == 'no' || set_value('caccess') == 'no') {
                                    echo "selected";
                                  } ?>>No</option>
              <option value="yes" <?php if ($row->caccess == 'yes' || set_value('caccess') == 'yes') {
                                    echo "selected";
                                  } ?>>Yes</option>
            </select>
          </div>
          <?php
          if (set_value('caccess') &&  set_value('caccess') == 'yes') {
            // print_r(set_value('caccess'));
          ?>
            <div class="alab" id="module" style="display:<?php echo set_value('caccess') == 'yes' ? '' : 'none' ?>">
              <div class="col-lg-12">
                <div class="col-lg-9">
                  <select class="col-lg-3 select2me idp_program" name="idp[]" multiple>
                    <option value=""></option>
                    <?php
                    $sel_data = array();
                    foreach ($idp as $rowidp) { ?>
                      <option value="<?= $rowidp->id ?>" <?php if (in_array($rowidp->id, set_value('idp'))) {
                                                          echo 'selected';
                                                          $sel_data[$rowidp->id] = $rowidp->title;
                                                        } ?>><?= $rowidp->title ?></option>
                    <?php } ?>
                  </select>
                  <?php echo form_error('idp[]'); ?>
                </div>

                <?php
                foreach (set_value('idp') as $rowidp2) {
                ?>
                  <div class="col-lg-12 div_<?= $rowidp2 ?>"><?= $sel_data[$rowidp2] ?><div class="col-lg-9">
                      <select class="col-lg-3 select2me idp_program1" name="selected_<?= $rowidp2 ?>[]" multiple>
                        <option value=""></option>
                        <?php foreach (json_decode($programs) as $row1) { ?>
                          <option value="<?= $row1->id ?>" <?php echo in_array($row1->id, set_value('selected_' . $rowidp2)) ? 'selected' : '' ?>><?= $row1->text ?></option>
                        <?php } ?>
                      </select>
                      <?php echo form_error('selected_' . $rowidp2 . '[]'); ?>
                    </div>
                  </div>
                <?php } ?>
              </div>
            </div>
          <?php } else if (set_value('caccess') &&  set_value('caccess') == 'no') { ?>
            <div class="alab" id="module" style="display:none">
            </div>
          <?php
          } else {
          ?>
            <div class="alab" id="module" style="display:<?php echo $row->caccess == 'yes' ? '' : 'none' ?>">
              <div class="col-lg-12">
                <div class="col-lg-9">
                  <select class="col-lg-3 select2me idp_program" name="idp[]" multiple>
                    <option value=""></option>
                    <?php
                    $sel_data = array();
                    $array = json_decode(json_encode($ui_idp_id), true);
                    $get_ui_idp_id = array_column($array, 'ui_idp_id');
                    foreach ($idp as $rowidp1) {
                    ?>
                      <option value="<?= $rowidp1->id ?>" <?php if (in_array($rowidp1->id, $get_ui_idp_id)) {
                                                          echo 'selected';
                                                          $sel_data[$rowidp1->id] = $rowidp1->title;
                                                        } ?>><?= $rowidp1->title ?></option>
                    <?php } ?>
                  </select>
                  <?php echo form_error('idp[]'); ?>
                </div>

                <?php
                foreach ($ui_idp_id as $rowidp2) {
                  $arr = unserialize($rowidp2->ui_module_ids);
                ?>
                  <div class="col-lg-12 div_<?= $rowidp2->ui_idp_id ?>"><?= $sel_data[$rowidp2->ui_idp_id] ?><div class="col-lg-9">
                      <select class="col-lg-3 select2me idp_program1" name="selected_<?= $rowidp2->ui_idp_id ?>[]" multiple>
                        <option value=""></option>
                        <?php foreach (json_decode($programs) as $row1) { ?>
                          <option value="<?= $row1->id ?>" <?php echo in_array($row1->id, $arr) ? 'selected' : '' ?>><?= $row1->text ?></option>
                        <?php } ?>
                      </select>
                      <?php echo form_error('selected_' . $rowidp2->ui_idp_id . '[]'); ?>
                    </div>
                  </div>
                <?php } ?>

              </div>
            </div>
          <?php  } ?>


          <div>
            <h5 class="aeu">Access for Client IDP</h5>
            <select name="idp_c_access" id="idp_c_access">
              <option value="no" <?php if ($row->idp_c_access == 'no' || set_value('idp_c_access') == 'no') {
                                    echo "selected";
                                  } ?>>No</option>
              <option value="yes" <?php if ($row->idp_c_access == 'yes' || set_value('idp_c_access') == 'yes') {
                                    echo "selected";
                                  } ?>>Yes</option>
            </select>
          </div>
          <?php
          if (set_value('idp_c_access') &&  set_value('idp_c_access') == 'yes') {
            // print_r(set_value('caccess'));
          ?>
            <div class="alab" id="mdl-idp_c_access" style="display:<?php echo set_value('idp_c_access') == 'yes' ? '' : 'none' ?>">
              <div class="col-lg-12">
                <div class="col-lg-9">
                  <select class="col-lg-3 select2me idp_program_c" name="idp_c[]" multiple>
                    <option value=""></option>
                    <?php
                    $sel_data = array();
                    foreach ($idp_c as $rowidp_c) { ?>
                      <option value="<?= $rowidp_c->id ?>" <?php if (in_array($rowidp_c->id, set_value('idp_c'))) {
                                                            echo 'selected';
                                                            $sel_data[$rowidp_c->id] = $rowidp_c->title;
                                                          } ?>><?= $rowidp_c->title ?></option>
                    <?php } ?>
                  </select>
                  <?php echo form_error('idp_c[]'); ?>
                </div>

                <?php
                foreach (set_value('idp_c') as $rowidp_c2) {
                ?>
                  <div class="col-lg-12 div_c_<?= $rowidp_c2 ?>"><?= $sel_data[$rowidp_c2] ?><div class="col-lg-9">
                      <select class="col-lg-3 select2me idp_program_c1" name="selected_c_<?= $rowidp_c2 ?>[]" multiple>
                        <option value=""></option>
                        <?php foreach (json_decode($programs) as $row1) { ?>
                          <option value="<?= $row1->id ?>" <?php echo in_array($row1->id, set_value('selected_c_' . $rowidp_c2)) ? 'selected' : '' ?>><?= $row1->text ?></option>
                        <?php } ?>
                      </select>
                      <?php echo form_error('selected_c_' . $rowidp_c2 . '[]'); ?>
                    </div>
                  </div>
                <?php } ?>
              </div>
            </div>
          <?php } else if (set_value('idp_c_access') &&  set_value('idp_c_access') == 'no') { ?>
            <div class="alab" id="mdl-idp_c_access" style="display:none">
            </div>
          <?php
          } else {
          ?>
            <div class="alab" id="mdl-idp_c_access" style="display:<?php echo $row->idp_c_access == 'yes' ? '' : 'none' ?>">
              <div class="col-lg-12">
                <div class="col-lg-9">
                  <select class="col-lg-3 select2me idp_program_c" name="idp_c[]" multiple>
                    <option value=""></option>
                    <?php
                    $sel_data_c = array();
                    $array_c = json_decode(json_encode($ui_idp_id_c), true);
                    $get_ui_idp_id_c = array_column($array_c, 'ui_idp_id');
                    foreach ($idp_c as $rowidpc6) {
                    ?>
                      <option value="<?= $rowidpc6->id ?>" <?php if (in_array($rowidpc6->id, $get_ui_idp_id_c)) {
                                                            echo 'selected';
                                                            $sel_data_c[$rowidpc6->id] = $rowidpc6->title;
                                                          } ?>><?= $rowidpc6->title ?></option>
                    <?php } ?>
                  </select>
                  <?php echo form_error('idp_c[]'); ?>
                </div>

                <?php
                foreach ($ui_idp_id_c as $rowidpc7) {
                  $arr_c = unserialize($rowidpc7->ui_module_ids);
                ?>
                  <div class="col-lg-12 div_c_<?= $rowidpc7->ui_idp_id ?>"><?= $sel_data[$rowidpc7->ui_idp_id] ?><div class="col-lg-9">
                      <select class="col-lg-3 select2me idp_program_c1" name="selected_c_<?= $rowidpc7->ui_idp_id ?>[]" multiple>
                        <option value=""></option>
                        <?php foreach (json_decode($programs) as $row12) { ?>
                          <option value="<?= $row12->id ?>" <?php echo in_array($row12->id, $arr_c) ? 'selected' : '' ?>><?= $row12->text ?></option>
                        <?php } ?>
                      </select>
                      <?php echo form_error('selected_c_' . $rowidpc7->ui_idp_id . '[]'); ?>
                    </div>
                  </div>
                <?php } ?>

              </div>
            </div>
          <?php  } ?>

          <div>
            <h5 class="aeu">User activation</h5>
            <select name="status" id="status2">
              <option value="inactive" <?php if ($aa_status == 'inactive') {
                                          echo "selected";
                                        } ?>>inactive</option>
              <option value="active" <?php if ($aa_status == 'active') {
                                        echo "selected";
                                      } ?>>active</option>
            </select>
          </div>
          <input type="submit" name="submit" class="btn btn-primary" value="submit"></td>

        </form>




      </div>
      <!-- /.container-fluid-->
      <!-- /.content-wrapper-->
      <footer class="sticky-footer">
        <div class="container">
          <div class="text-center">
            <small>Copyright © 2018 e2e People Practices</small>
          </div>
        </div>
      </footer>
      <!-- Scroll to Top Button-->
      <a class="scroll-to-top rounded" href="#page-top">
        <i class="fa fa-angle-up"></i>
      </a>
      <!-- Logout Modal-->
      <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">×</span>
              </button>
            </div>
            <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
            <div class="modal-footer">
              <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
              <a class="btn btn-primary" href="<?php echo base_url('login/logout') ?>" ">Logout</a>
          </div>
        </div>
      </div>
    </div>
    <!-- Bootstrap core JavaScript-->
    <script src=" <?php echo base_url() ?>/assets/vendor/jquery/jquery.min.js"> </script> <script src="<?php echo base_url() ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                <!-- Core plugin JavaScript-->
                <script src="<?php echo base_url() ?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>
                <!-- Page level plugin JavaScript-->
                <script src="<?php echo base_url() ?>/assets/vendor/chart.js/Chart.min.js"></script>
                <script src="<?php echo base_url() ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
                <script src="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>
                <!-- Custom scripts for all pages-->
                <script src="<?php echo base_url() ?>/assets/js/sb-admin.min.js"></script>
                <!-- Custom scripts for this page-->
                <script src="<?php echo base_url() ?>/assets/js/sb-admin-datatables.min.js"></script>
                <script src="<?php echo base_url() ?>/assets/js/sb-admin-charts.min.js"></script>
                <script src="<?php echo base_url() ?>assets/select2/select2.full.min.js" type="text/javascript"></script>


                <script type="text/javascript">
                  $(".kca_a_list").select2({
                    placeholder: "Select Knowlege Center",
                    width: '400px'
                  });

                  $('select[name="kaccess"]').on('change', function(e) {
                    if (this.value == 'yes') {
                      $('#mdl-kaccess').css('display', '');
                    } else {
                      $('#mdl-kaccess').css('display', 'none');
                    }
                  });

                  $(".kca_c_list").select2({
                    placeholder: "Select Knowlege Center",
                    width: '400px'
                  });

                  $('select[name="kc_c_access"]').on('change', function(e) {
                    if (this.value == 'yes') {
                      $('#mdl-kc_c_access').css('display', '');
                    } else {
                      $('#mdl-kc_c_access').css('display', 'none');
                    }
                  });

                  $(".idp_program").select2({
                    placeholder: "Select Categories",
                    width: '400px'
                  });
                  $(".idp_program1").select2({
                    placeholder: "Select Categories",
                    width: '400px'
                  });


                  $('select[name="caccess"]').on('change', function(e) {
                    if (this.value == 'yes') {
                      $('#module').css('display', '');
                    } else {
                      $('#module').css('display', 'none');
                    }
                  });

                  var programs = <?php echo isset($programs) ? $programs : 'null' ?>;

                  $('.idp_program').on('select2:select', function(e) {
                    var cat_name = e.params.data.text;
                    var cat_id = e.params.data.id;

                    $("#module").append('<div class="col-lg-12 div_' + cat_id + '">' + cat_name + '<div class="col-lg-9"><select class="col-lg-3 select2me" name="selected_' + cat_id + '[]" multiple></select></div></div>');

                    $.ajax({
                      url: "<?php echo base_url() ?>add_new_users/get_already_selected_value/" + cat_id,
                      success: function(result) {
                        data = JSON.parse(result);
                        var aa = [];
                        $.each(data, function(index, value) {
                          aa.push(value.id);
                        });
                        $('select[name="selected_' + cat_id + '[]"]').select2({
                          placeholder: "Select Programs",
                          width: 'auto',
                          data: programs
                        }).val(aa).trigger("change");
                      }
                    });
                  });

                  $('.idp_program').on('select2:unselect', function(e) {
                    var b = e.params.data.id;

                    $('.div_' + b).remove();
                  });

                  /////

                  $(".idp_program_c,.idp_program_c1").select2({
                    placeholder: "Select Categories",
                    width: '400px'
                  });

                  $('select[name="idp_c_access"]').on('change', function(e) {
                    if (this.value == 'yes') {
                      $('#mdl-idp_c_access').css('display', '');
                    } else {
                      $('#mdl-idp_c_access').css('display', 'none');
                    }
                  });

                  var programs_c = <?php echo isset($programs) ? $programs : 'null' ?>;

                  $('.idp_program_c').on('select2:select', function(e) {
                    var cat_name = e.params.data.text;
                    var cat_id = e.params.data.id;

                    $("#mdl-idp_c_access").append('<div class="col-lg-12 div_c_' + cat_id + '">' + cat_name + '<div class="col-lg-9"><select class="col-lg-3 select2me" name="selected_c_' + cat_id + '[]" multiple></select></div></div>');

                    $.ajax({
                      url: "<?php echo base_url() ?>add_new_users/get_already_selected_value/" + cat_id,
                      success: function(result) {
                        data = JSON.parse(result);
                        var aa = [];
                        $.each(data, function(index, value) {
                          aa.push(value.id);
                        });
                        $('select[name="selected_c_' + cat_id + '[]"]').select2({
                          placeholder: "Select Programs",
                          width: 'auto',
                          data: programs_c
                        }).val(aa).trigger("change");
                      }
                    });
                  });

                  $('.idp_program_c').on('select2:unselect', function(e) {
                    var b = e.params.data.id;

                    $('.div_c_' + b).remove();
                  });
                </script>

            </div>
</body>

</html>
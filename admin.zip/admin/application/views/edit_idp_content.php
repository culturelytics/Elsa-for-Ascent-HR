<?php
defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
  <title><?php echo $this->config->item('page_title') ?></title>
  <!-- Bootstrap core CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <!-- Custom fonts for this template-->
  <link href="<?php echo base_url() ?>/assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
  <!-- Page level plugin CSS-->
  <link href="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="<?php echo base_url() ?>/assets/css/sb-admin.css" rel="stylesheet">
  <link href="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.css" rel="stylesheet">

</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
  <!-- Navigation-->
  <?php include "sidebar.php"; ?>
  <div class="content-wrapper">
    <div class="container-headbox">
      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>dashboard/">Home</a>
        </li>
        
        <?php if($this->uri->segment(2) == 'aggregator'){?>
        <li class="breadcrumb-item">
          <a href="<?php echo base_url() ?>knowledge_center/aggregator/0">Aggregator Knowledge Center</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?php echo base_url() ?>idp_content/aggregator/0">MLP Page Content</a>
        </li>
         <?php }else {?>
        <li class="breadcrumb-item">
            <a href="<?php echo base_url() ?>knowledge_center/client/<?php echo $this->uri->segment(3) ?>">Client Knowledge Center</a>
        </li>
        <li class="breadcrumb-item">
            <a href="<?php echo base_url() ?>idp_content/client/<?php echo $this->uri->segment(3)?>">MLP Page Content</a>
        </li>
         <?php }?>
        <li class="breadcrumb-item active">Edit MLP Page Content</li>
      </ol>
      <!-- Icon Cards-->

      <div class="clearfix">
        <center>
          <h3>EDIT MLP PAGE CONTENT</h3>
        </center>
      </div>
    </div>

    <div class="container-fluid">
      <div class="col-md-12" align="right">
            <?php if($this->uri->segment(2)=='client') { ?>
          <a href="<?php echo base_url() ?>idp_content/client/<?php echo $this->uri->segment(3)?>">Back</a>
         <?php } else{ ?>
            <a href="<?php echo base_url() ?>idp_content/aggregator/0">Back</a>
         <?php } ?>
        
      </div>
      <div class="container">
        <form action="<?php echo base_url() ?>edit_idp_content/update_data" method="post" id="editidpform">
            <div>
                <input type="text" name="title" value="<?php echo $row->title ?>" placeholder="Title">
                <?php echo form_error('title') ?>
            </div>
            <div>
                <input type="text" name="subtitle" value="<?php echo $row->subtitle ?>" placeholder="Sub Title">
                <?php echo form_error('subtitle') ?>
            </div>
            <input type="hidden" name="id" value="<?php echo $row->id ?>">
             <input type="hidden" name="orgid" value="<?php echo $this->uri->segment(3)?>">
            <input type="hidden" name="urlsegment" value="<?php echo $urlsegment ?>">
            
            <div>   
                <textarea class="form-control" autocomplete="off" name="description" id="summernote"><?php echo $row->description ?></textarea>
                <?php echo form_error('description') ?>
                <br>
                <?php if(count($programs) > 0){ ?>
                <label><b>Add Programs : </b></label><br>
                <?php }foreach ($programs as $row) { ?>
                <input type="checkbox" name="programs[]" value="<?= $row->prg_id ?>" multiple <?php if (in_array($row->prg_id, $row1)) {echo 'checked';} else {echo '';} ?>><?= $row->prg_name ?><br>
                <?php } ?>
                <?php echo isset($error) ? $error : '' ?>
                <input type="submit" name="submit" class="btn btn-primary" value="submit"></td>
            </div>

        </form>
      <?php include_once('footer.php'); ?>
      <!-- Bootstrap core JavaScript-->
      <script src=" <?php echo base_url() ?>/assets/vendor/jquery/jquery.min.js"> </script>
      <script src="<?php echo base_url() ?>/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
      <!-- Core plugin JavaScript-->
      <script src="<?php echo base_url() ?>/assets/vendor/jquery-easing/jquery.easing.min.js"></script>
      <!-- Page level plugin JavaScript-->
      <script src="<?php echo base_url() ?>/assets/vendor/chart.js/Chart.min.js"></script>
      <script src="<?php echo base_url() ?>/assets/vendor/datatables/jquery.dataTables.js"></script>
      <script src="<?php echo base_url() ?>/assets/vendor/datatables/dataTables.bootstrap4.js"></script>
      <!-- Custom scripts for all pages-->
      <script src="<?php echo base_url() ?>/assets/js/sb-admin.min.js"></script>
      <!-- Custom scripts for this page-->
      <script src="<?php echo base_url() ?>/assets/js/sb-admin-datatables.min.js"></script>
      <script src="<?php echo base_url() ?>/assets/js/sb-admin-charts.min.js"></script>
      <script src="http://cdnjs.cloudflare.com/ajax/libs/summernote/0.8.9/summernote.js"></script>
      <script type="text/javascript">
        $(document).ready(function() {
          $('#summernote').summernote();
        });
        $('#summernote').summernote({
          height: 200,
          toolbar: [

            ['style', ['bold', 'italic', 'underline', 'clear']],
            ['color', ['color']]
          ]
        });
      </script>
    </div>
</body>

</html>
<?php
    defined('BASEPATH') or exit('No direct script access allowed');

    //var_dump(config_item('base_url'), base_url());die;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $this->config->item('page_title') ?></title>
    <!-- Bootstrap core CSS-->
    <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url() ?>vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
</head>
<body class="fixed-nav sticky-footer bg-dark" id="page-top">
    <!-- Navigation-->
    <?php include "sidebar.php"; ?>
    <div class="content-wrapper admpage2 ccntr">
        <div class="container-headbox">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo base_url() ?>dashboard/">Home</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo base_url() ?>competencies/">Competencies Center</a>
                </li>
                <li class="breadcrumb-item active">Competency Attributes</li>
            </ol>
            <!-- Icon Cards-->

            <div class="clearfix">
                <center>
                    <h3>Competency Attributes For <?php echo $kc->prg_name ?></h3>
                </center>
            </div>
        </div>
        <div class="container-fluid rgpage">
            <div>
                <!--<center><h3>Competency Center</h3></center>-->
                <p align="right">
                    <a data-toggle="modal" data-target="#mdl-add" class="btn btn-primary btn-condensed" style="color: #fff;">Add New</a>&nbsp;&nbsp;
                </p>
            </div>
            <!--<hr>-->
            <div class="container cmptcycntr" style="padding-right: 0px !important;padding-left: 0px !important;margin-top: -50px;">
                <!--<p>List of all Module</p>-->
                <div class="table-responsive">
                    <table class="table table-bordered dataTable" id="dataTable">
                        <thead>
                            <tr>
                               <th style="width: 7%; min-width: 40px; text-align:left;">S.no</th>
                                <th style="width: 35%; min-width: 150px; text-align:left;">Name</th>
                                <th style="width: 45%; min-width: 150px; text-align:left;">Description</th>
                                <th style="width: 13%; min-width: 80px; text-align:left;">Action</th>
                            </tr>
                        </thead>
                        <?php $i = 0;
                        foreach ($list as $row) : $i++;
                        ?>
                            <tr>
                                <td style="text-align:center;"><?php echo $i; ?></td>
                                <td><?php echo $row->attr_name ?></td>
                                <td><?php echo $row->attr_desc ?></td>
                                <td>
                                    <span><a href="#" class="programeditccenter" data-pid="<?= $row->id ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                    <span><a href="#" class="delete" onclick="deleteprogram('<?php echo base_url() ?>competencies/deleteattribute/<?php echo $row->id ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                    <span><a href="<?php echo base_url() ?>competencies/attrmodules/<?= $row->id ?>" title="Manage Modules"><i class="fa fa-list-ul" aria-hidden="true"></i></a></span>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>
            <?php include_once('footer.php'); ?>
        </div>
    </div>
    <div class="modal fade" id="mdl-add" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Attribute</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url() ?>competencies/addattribute/<?php echo $kc->prg_id ?>" method="post" id="frm-add">
                        <div class="form-group">
                            <label for="attr_name" class="control-label">Name</label>
                            <input type="text" class="form-control" name="attr_name" placeholder="Attribute Name" required>
                        </div>
                        <div class="form-group">
                            <label for="attr_desc" class="control-label">Description</label>
                            <textarea class="form-control" id="attr_desc" name="attr_desc" required></textarea>   
                        </div>
                        <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class=" modal fade" id="mdl-edit" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
        <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Attribute</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url() ?>competencies/updateattribute" method="post" id="frm-edit">
                        <div class="modal-body">
                            <div class="form-group">
                                <label for="attr_name" class="control-label">Name</label>
                                <input type="text" class="form-control" id="attr_name" name="attr_name" placeholder="Attribute Name" required>
                            </div>
                            <div class="form-group">
                                <label for="attr_desc" class="control-label">Description</label>
                                <textarea class="form-control" id="attr_desc" name="attr_desc" required></textarea>   
                            </div>
                            <input type="hidden" id="id" name="id" />
                        </div>
                            <input type="hidden" id="competency_id" name="competency_id" value="<?php echo $kc->prg_id ?>" />

                        <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery/jquery.min.js"> </script>
    <script src="<?php echo base_url() ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>

    <script type="text/javascript">
            $(document).on('click', '.programeditccenter',function (e) {
                var pid = $(this).data('pid');
                $.post('<?php echo base_url() ?>competencies/editattribute', {'id': pid}, function(rs) {
                    if (rs) {
                        rs = JSON.parse(rs);
                        console.log(rs);
                        $('#mdl-edit .modal-body #id').val(rs.id);
                        $('#mdl-edit .modal-body #attr_name').val(rs.attr_name);
                        $('#mdl-edit .modal-body #attr_desc').text(rs.attr_desc);
                        $('#mdl-edit').modal('show');
                    } else {
                        alert("No record found")
                    }
                });
            });

        function deleteprogram(url) {
            a = confirm("Are you sure to delete?");
            if (a) {
                window.location.href = url;
            }
        }
    </script>
</body>
</html>
<?php
if (!isset($_SESSION["email"])) {
    header("Location: login");
} else {
    ?> 

    <?php
    defined('BASEPATH') or exit('No direct script access allowed');
    ?>
    <!DOCTYPE html>
    <html lang="en">

        <head>
            <meta charset="utf-8">
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
            <meta name="description" content="">
            <meta name="author" content="">
            <title><?php echo $this->config->item('page_title') ?></title>
            <!-- Bootstrap core CSS-->
            <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
            <!-- Custom fonts for this template-->
            <link href="<?php echo base_url() ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
            <!-- Page level plugin CSS-->
            <link href="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
            <!-- Custom styles for this template-->
            <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
            <link href="<?php echo base_url() ?>assets/select2/select2.min.css" rel="stylesheet" type="text/css" />
            <link href="<?php echo base_url() ?>assets/select2/select2-bootstrap.min.css" rel="stylesheet" type="text/css" />

        </head>

        <body class="fixed-nav sticky-footer bg-dark" id="page-top">
            <!-- Navigation-->
            <?php include "sidebar.php"; ?>
            <div class="content-wrapper admpage2 user">
                <div class="container-headbox">
                    <!-- Breadcrumbs-->
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo base_url() ?>dashboard/">Home</a>
                        </li>
                        <li class="breadcrumb-item active">User Management</li>
                    </ol>
                    <!-- Icon Cards-->
                    
                    <div class="clearfix">
                        <?php if($_SESSION['role'] === 'super_admin') { ?>
                        <center>
                            <h3>Employee View</h3>
                        </center>
                        <div class="row full-width">
                            <div class="col-md-4 col-sm-4">
                                <label for="organization" class="text-right pull-right form-label cdb-lbl">Select Organization</label>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <div class="form-group" style="display: inline">
                                    <select name="org_id" id="org_id" class="form-control user_org select2me">
                                        <option value="0">All USERS</option>
                                        <?php foreach ($organizations as $k => $org) : ?>                          
                                            <option value="<?php echo $org->id ?>" <?php echo ($org->id == $org_id ? 'selected="true"' : '') ?>><?php echo $org->org_name; ?></option>
                                        <?php endforeach; ?>
                                    </select>                  
                                </div>
                            </div>
                            <div class="col-md-4 col-sm-4">
                                <button style="padding: 1px 10px 1px 10px;" type="button" id="orgIdSubmit" class="btn btn-primary btn-condensed" onclick="redirect();">Submit</button>
                            </div>    
                        </div>
                        <?php if($org_id == 0){ ?>
                        <!-- <div slass="notediv"><span class="note">Please select organization to create new users.</span></div> -->
                         <?php } } else{  ?>
                        <center>
                            <h3>USER MANAGEMENT</h3>
                        </center>
                        <?php }  ?>
                    </div>
                </div>


                <div class="container-fluid rgpage">
                    <div class="container">
                        <?php
                        $notification = $this->session->flashdata('notification');
                        if ($notification) {
                            ?>
                            <div class="alert alert-success">
                            <?php echo $notification; ?>
                            </div>
                            <?php }
                        ?>
                        <?php echo form_error('notification'); ?>

                        <?php
                        $notification = $this->session->flashdata('updatenotification');
                        if ($notification) {
                            ?>
                            <div class="alert alert-success">
                            <?php echo $notification; ?>
                            </div>
                            <?php }
                        ?>
                        <?php echo form_error('updatenotification'); ?>

                        <?php
                        $notification = $this->session->flashdata('deletenotification');
                        if ($notification) {
                            ?>
                            <div class="alert alert-success">
                            <?php echo $notification; ?>
                            </div>
                            <?php } ?>
                            <?php echo form_error('deletenotification'); ?>


<div class="mt-4 mb-4">
										<center> 						
					<!--		 <a style="padding: 1px 10px 1px 10px;" type="button" id="orgIdSubmit" class="btn btn-primary btn-condensed"  href="test.xlsx" download >Download Templete</a> -->
                      <a style="padding: 1px 10px 1px 10px;" class="btn btn-primary btn-condensed" href="<?php echo base_url() ?>assets\files\testcsv.csv" download="testcsv.csv">Download</a>
                                		<a style="padding: 1px 10px 1px 10px;" type="button" id="orgIdSubmit" class="btn btn-primary btn-condensed"  href="<?php echo base_url() ?>importcsv.php">Upload .csv File</a>							
										</center>
							</div>





                        <?php if($_SESSION['role'] === 'super_adminNOTNEEDE') { ?>
                        <form action="<?php echo base_url() ?>add_new_users/users/<?php echo $this->uri->segment(3) ?>" method="post" id="usersform">
                                <?php print_r(form_error()); ?>
                            <div>
                                <input type="text" name="name" placeholder="First Name" value="<?= set_value('name') ?>" required>
                                <?php echo form_error('name'); ?>
                            </div>

                            <div>
                                <input type="text" name="last_name" placeholder="Last Name" value="<?= set_value('last_name') ?>" required>
                                <?php echo form_error('last_name'); ?>
                            </div>

                            <div>
                                <input type="text" name="linkedin" placeholder="Linked In" value="<?= set_value('linkedin') ?>">
                            </div>
                            <div>
                                <input type="text" name="twitter" placeholder="Twitter" value="<?= set_value('twitter') ?>">
                            </div>
                            <input type="hidden" name="organization_id"  value="<?php echo $org_id ?>">


                            <div class="eph">
                                <select class="required form-control" name="age" required>
                                    <option value="">Select Age</option>
                                    <option value="1" <?php echo set_value('age') == '1' ? 'selected' : '' ?>>21-36</option>
                                    <option value="2" <?php echo set_value('age') == '2' ? 'selected' : '' ?>>37-50</option>
                                    <option value="3" <?php echo set_value('age') == '3' ? 'selected' : '' ?>>50+</option>
                                </select>
                                <?php echo form_error('age'); ?>
                            </div>
                            <div class="methods">Gender:
                                <input type="radio" name="gender" value="male" <?php echo set_value('gender') == '1' ? 'checked' : 'checked' ?>>Male&nbsp;&nbsp;
                                <input type="radio" name="gender" value="female" <?php echo set_value('gender') == '1' ? 'checked' : '' ?>>Female<br>
                                <?php echo form_error('gender'); ?>
                            </div>



                            <div>

                                <input type="email" name="email" placeholder="Email id" value="<?= set_value('email') ?>" required>
                                    <?php
                                    $error_msg = $this->session->flashdata('error_msg');
                                    if ($error_msg) {
                                        ?>
                                    <div class="alert alert-danger">
                                    <?php echo $error_msg; ?>
                                    </div>
                                    <?php } ?>
                                <?php echo form_error('email'); ?>
                            </div>
                            <div>

                                <input type="text" name="password" placeholder="Password" value="<?= set_value('password') ?>" required>
                                <?php echo form_error('password'); ?>
                            </div>
                            <div>
                                <input type="text" name="phone" placeholder="Contact No" value="<?= set_value('phone') ?>" required>
                                <?php echo form_error('phone'); ?>
                            </div>


                            <div>
                                <h5 class="aeu">Access for Aggregator Knowledge Center</h5>
                                <select name="kaccess" id="status2">                 
                                    <option value="no" <?php if ($row->kaccess == 'no' || set_value('kaccess') == 'no') { echo "selected"; } ?> >No</option> 
                                    <option value="yes" <?php if ($row->kaccess == 'yes' || set_value('kaccess') == 'yes') { echo "selected"; } ?> >Yes</option>                 
                                </select>
                            </div>

                            <div class="alab" id="mdl-kaccess" style="display:<?php echo $row->kaccess == 'yes' ? '' : 'none' ?>">
                                <div class="col-lg-12">
                                    <div class="col-lg-9">
                                        <select class="col-lg-3 select2me kca_a_list" name="kca[]" multiple >
                                            <option value=""></option>
                                            <?php
                                            $kca_a_list = json_decode(json_encode($kca_a_list), true);
                                            $kca_kc_id = array_column($kca_a_list, 'kca_kc_id');
                                            foreach ($kc_a_list as $row1) { ?>
                                                <option value="<?= $row1->prg_id ?>" <?php if (in_array($row1->prg_id, $kca_kc_id)) { echo 'selected';}?> ><?= $row1->prg_name ?></option>
                                            <?php } ?>
                                        </select>
                                        <?php echo form_error('kca[]'); ?>
                                    </div>
                                </div>
                            </div>

                            <div>
                                <h5 class="aeu">Access for Client Knowledge Center</h5>
                                <select name="kc_c_access" id="kc_c_access">                 
                                    <option value="no" <?php if ($row->kc_c_access == 'no' || set_value('kc_c_access') == 'no') { echo "selected"; } ?> >No</option> 
                                    <option value="yes" <?php if ($row->kc_c_access == 'yes' || set_value('kc_c_access') == 'yes') {  echo "selected"; } ?> >Yes</option>                 
                                </select>
                            </div>
                           
                            <div class="alab" id="mdl-kc_c_access" style="display:<?php echo $row->kc_c_access == 'yes' ? '' : 'none' ?>">
                                <div class="col-lg-12">
                                    <div class="col-lg-9">
                                        <select class="col-lg-3 select2me kca_c_list" name="kca_c[]" multiple >
                                            <option value=""></option>
                                            <?php $kca_c_list = json_decode(json_encode($kca_c_list), true);
                                                  $kca_kc_id = array_column($kca_c_list, 'kca_kc_id');
                                                  foreach ($kc_c_list as $row2) {  ?>
                                                  <option value="<?= $row2->prg_id ?>" <?php  if (in_array($row2->prg_id, $kca_kc_id)) {  echo 'selected'; }  ?> ><?= $row2->prg_name ?></option>
                                                  <?php }?>
                                        </select>
                                        <?php echo form_error('kca_c[]'); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="alab">
                                <h5>Access for Aggregator MLP</h5>
                                <select name="access2" id="status1" required>
                                    <option selected="" value="">Select Access</option>
                                    <option value="yes" <?php echo set_value('access2') == 'yes' ? 'selected' : '' ?>>Yes</option>
                                    <option value="no" <?php echo set_value('access2') == 'no' ? 'selected' : '' ?>>No</option>
                                </select>
                                        <?php echo form_error('access2'); ?>
                            </div>

                            <div class="alab" id="module" style="display:<?php echo set_value('access2') == 'yes' ? '' : 'none' ?>">
                                <div class="col-lg-12">
                                    <div class="col-lg-9">
                                        <select class="col-lg-3 select2me idp_program" name="idp[]" multiple>
                                            <option value=""></option> <?php $sel_data = array(); foreach ($idp as $row) {  ?>
                                                <option value="<?= $row->id ?>" <?php
                                                    if (in_array($row->id, set_value('idp'))) { echo 'selected'; $sel_data[$row->id] = $row->title;  } ?>><?= $row->title ?></option>
                                                    <?php } ?>
                                        </select>
                                        <?php echo form_error('idp[]'); ?>
                                    </div>
                                        <?php  foreach (set_value('idp') as $row) {  ?>
                                        <div class="col-lg-12 div_<?= $row ?>"><?= $sel_data[$row] ?><div class="col-lg-9">
                                                <select class="col-lg-3 select2me idp_program1" name="selected_<?= $row ?>[]" multiple required>
                                                    <option value=""></option>
                                                    <?php foreach (json_decode($programs) as $row1) { ?>
                                                        <option value="<?= $row1->id ?>" <?php echo in_array($row1->id, set_value('selected_' . $row)) ? 'selected' : '' ?>><?= $row1->text ?></option>
                                                    <?php } ?>
                                                </select>
                                                <?php echo form_error('selected_' . $row . '[]'); ?>
                                            </div>
                                        </div>
                                        <?php } ?>
                                </div>
                            </div>

                            <div class="alab">
                                <h5>Access for Client MLP</h5>
                                <select name="idp_c_access" id="idp_c_access" required>
                                    <option selected="" value="">Select Access</option>
                                    <option value="yes" <?php echo set_value('idp_c_access') == 'yes' ? 'selected' : '' ?>>Yes</option>
                                    <option value="no" <?php echo set_value('idp_c_access') == 'no' ? 'selected' : '' ?>>No</option>
                                </select>
                                <?php echo form_error('idp_c_access'); ?>
                            </div>

                            <div class="alab" id="mdl-idp_c_access" style="display:<?php echo set_value('idp_c_access') == 'yes' ? '' : 'none' ?>">
                                <div class="col-lg-12">
                                    <div class="col-lg-9">
                                        <select class="col-lg-3 select2me idp_program_c" name="idp_c[]" multiple>
                                            <option value=""></option>
                                                <?php
                                                $sel_data_c = array();
                                                foreach ($idp_c as $rowc1) {
                                                    ?>
                                                <option value="<?= $rowc1->id ?>" <?php
                                                if (in_array($rowc1->id, set_value('idp_c'))) {  echo 'selected'; $sel_data_c[$rowc1->id] = $rowc1->title;} ?>><?= $rowc1->title ?></option>
                                                <?php } ?>
                                        </select>
                                        <?php echo form_error('idp_c[]'); ?>
                                    </div>

                                        <?php   foreach (set_value('idp_c') as $rowc2) {     ?>
                                        <div class="col-lg-12 div_c_<?= $rowc2 ?>"><?= $sel_data_c[$rowc2] ?><div class="col-lg-9">
                                                <select class="col-lg-3 select2me idp_program_c1" name="selected_c_<?= $row ?>[]" multiple required>
                                                    <option value=""></option>
                                                    <?php foreach (json_decode($programs_c) as $row12) { ?>
                                                        <option value="<?= $row12->id ?>" <?php echo in_array($row12->id, set_value('selected_c_' . $rowc2)) ? 'selected' : '' ?>><?= $row12->text ?></option>
                                                    <?php } ?>
                                                </select>
                                                <?php echo form_error('selected_c_' . $rowc2 . '[]'); ?>
                                            </div>
                                        </div>
                                        <?php } ?>
                                </div>
                            </div>


                            <div class="alab">
                                <h5>User Status</h5>
                                <select name="status" id="status1" required>
                                    <option selected="" value="">Select Status</option>
                                    <option value="active" <?php echo set_value('status') == 'active' ? 'selected' : '' ?>>active</option>
                                    <option value="inactive" <?php echo set_value('status') == 'inactive' ? 'selected' : '' ?>>inactive</option>
                                </select>

                            <?php echo form_error('status'); ?>
                            </div>
                            <input type="submit" name="submit" class="btn btn-primary" value="submit">

                        </form>
                        <?php } ?>
                        <div>
                            <p>List of all Login access users</p>
                            <table class="table table-bordered dataTable customTbl customColTbl" id="dataTable" width="100%" cellspacing="0" role="grid" aria-describedby="dataTable_info" style="width: 100%;">
                                <thead>
                                    <tr>
                                        <th>S.no</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <!-- <th>Password</th> -->
                                        <th>Contact</th>
										<?php if($_SESSION['role'] === 'super_admin'|| $_SESSION['role'] === 'group_admin') { ?>
                                        <th>Organization</th>
										 
                                        <th>Online Knowledge Access</th>
                                        <th>Client Knowledge Access</th>
                                        <th>Online IDP Access</th>
                                        <th>Status</th>
                                       <?php if($_SESSION['role'] === 'super_admin') { ?>
                                        <th>Action</th>
										<?php }?>
                                        <?php }?>
                                    </tr>
                                </thead>
                                <?php $i = 0;    foreach ($list as $row) : $i++;     ?>
                                    <tr>
                                        <td style="text-align: center"><?php echo $i; ?></td> <!-- php 5.6 version -->
                                        <td><?php echo $row->name . ' ' . $row->last_name ?></td>
                                        <td><?php echo $row->email ?></td>
                                        <!-- <td><php echo $row->password ?></td> -->
                                        <td><?php echo $row->contact ?></td>
										<?php if($_SESSION['role'] === 'super_admin' || $_SESSION['role'] === 'group_admin') { ?>
                                        <td><?php echo $row->kaccess ?></td>
										
                                        <td><?php echo $row->caccess ?></td>       
                                        <td>
                                        <?php echo $row->kaccess ?>
                                        <?php if ($row->kaccess == 'yes') { ?>
                                                <p><a href="<?php echo base_url() ?>addmodulecontent/<?php echo $row->id ?>/<?php echo $this->uri->segment(3)?>/#aidp" target="_blank">Add Module Content</a></p>
                                        <?php }  ?>
                                        </td>
                                        <td>
                                        <?php echo $row->caccess ?>
                                        <?php if ($row->caccess == 'yes') { ?>
                                                <p><a href="<?php echo base_url() ?>addmodulecontent/<?php echo $row->id ?>/<?php echo $this->uri->segment(3)?>/#cidp" target="_blank">Add Module Content</a></p>
                                        <?php }  ?>
                                        </td>
                                        <td><?php echo $row->status ?></td>
                                        <?php if($_SESSION['role'] === 'super_admin') { ?>
                                        <td>
                                            <span>
                                                <a href="<?php echo base_url() ?>edituser/users/<?php echo $row->id ?>/<?php echo $this->uri->segment(3) ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span><span> 
                                                <a href="#" onclick="deleteprogram('<?php echo base_url() ?>add_new_users/delete/<?php echo $row->id ?>/<?php echo $this->uri->segment(3) ?>')" ><i class="fa fa-trash" aria-hidden="true"></i></a>
                                            </span>
                                        </td>
                                        <?php } ?>
                                    </tr>
								 <?php } ?>
                                        <?php endforeach; ?>
                            </table>
                        </div>
                    </div>
    <?php include_once('footer.php'); ?>
                </div>
                <!-- Bootstrap core JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/jquery/jquery.min.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

                <!-- Core plugin JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
                <!-- Page level plugin JavaScript-->
                <script src="<?php echo base_url() ?>assets/vendor/chart.js/Chart.min.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/datatables/jquery.dataTables.js"></script>
                <script src="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
                <!-- Custom scripts for all pages-->
                <script src="<?php echo base_url() ?>assets/js/sb-admin.min.js"></script>
                <!-- Custom scripts for this page-->
                <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
                <script src="<?php echo base_url() ?>assets/select2/select2.full.min.js" type="text/javascript"></script>
                <!--   <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script> -->
                <script type="text/javascript">
                            $( document ).ready(function() {
                               var orgid =  $('select[name="org_id"]').val();
                               if (orgid == 0) {
                                    $('#usersform').css('display', 'none');
                                    
                                } else {
                                    $('#usersform').css('display', '');
                                }
                            });
                            $(".kca_a_list").select2({
                                placeholder: "Select Knowlege Center",
                                width: '400px'
                            });

                            $('select[name="kaccess"]').on('change', function (e) {
                                if (this.value == 'yes') {
                                    $('#mdl-kaccess').css('display', '');
                                } else {
                                    $('#mdl-kaccess').css('display', 'none');
                                }
                            });
                            
                            $(".kca_c_list").select2({
                                placeholder: "Select Knowlege Center",
                                width: '400px'
                            });

                            $('select[name="kc_c_access"]').on('change', function (e) {
                                if (this.value == 'yes') {
                                    $('#mdl-kc_c_access').css('display', '');
                                } else {
                                    $('#mdl-kc_c_access').css('display', 'none');
                                }
                            });

                            $(".kc_list,.kc_list1").select2({
                                placeholder: "Select Categories",
                                width: '400px'
                            });
                            $(".idp_program,.idp_program1,.idp_program_c,.idp_program_c1").select2({
                                placeholder: "Select Categories",
                                width: '400px'
                            });

                            $(document).ready(function () {
                                $('#checkBtn').click(function () {
                                    checked = $("input[type=checkbox]:checked").length;
                                    if (!checked) {
                                        alert("Select atleast one access pages condition.");
                                        return false;
                                    }

                                });
                                $('select[name="access2"]').on('change', function (e) {
                                    if (this.value == 'yes') {
                                        $('#module').css('display', '');
                                    } else {
                                        $('#module').css('display', 'none');
                                    }
                                });
                                $('select[name="idp_c_access"]').on('change', function (e) {
                                    if (this.value == 'yes') {
                                        $('#mdl-idp_c_access').css('display', '');
                                    } else {
                                        $('#mdl-idp_c_access').css('display', 'none');
                                    }
                                });
                            });

                            var programs = <?php echo isset($programs) ? $programs : 'null' ?>;

                            $('.idp_program').on('select2:select', function (e) {
                                var cat_name = e.params.data.text;
                                var cat_id = e.params.data.id;

                                $("#module").append('<div class="col-lg-12 div_' + cat_id + '">' + cat_name + '<div class="col-lg-9"><select class="col-lg-3 select2me" name="selected_' + cat_id + '[]" multiple></select></div></div>');

                                $.ajax({
                                    url: "<?php echo base_url() ?>add_new_users/get_already_selected_value/" + cat_id,
                                    success: function (result) {
                                        data = JSON.parse(result);
                                        var aa = [];
                                        $.each(data, function (index, value) {
                                            aa.push(value.id);
                                        });
                                        $('select[name="selected_' + cat_id + '[]"]').select2({
                                            placeholder: "Select Programs",
                                            width: 'auto',
                                            data: programs
                                        }).val(aa).trigger("change");
                                    }
                                });
                            });

                            $('.idp_program').on('select2:unselect', function (e) {
                                var b = e.params.data.id;
                                $('.div_' + b).remove();
                            });

                            ////
                            var programs_c = <?php echo isset($programs) ? $programs : 'null' ?>;

                            $('.idp_program_c').on('select2:select', function (e) {
                                var cat_name = e.params.data.text;
                                var cat_id = e.params.data.id;

                                $("#mdl-idp_c_access").append('<div class="col-lg-12 div_c_' + cat_id + '">' + cat_name + '<div class="col-lg-9"><select class="col-lg-3 select2me" name="selected_c_' + cat_id + '[]" multiple></select></div></div>');

                                $.ajax({
                                    url: "<?php echo base_url() ?>add_new_users/get_already_selected_value/" + cat_id,
                                    success: function (result) {
                                        data = JSON.parse(result);
                                        var aa = [];
                                        $.each(data, function (index, value) {
                                            aa.push(value.id);
                                        });
                                        $('select[name="selected_c_' + cat_id + '[]"]').select2({
                                            placeholder: "Select Programs",
                                            width: 'auto',
                                            data: programs_c
                                        }).val(aa).trigger("change");
                                    }
                                });
                            });

                            $('.idp_program_c').on('select2:unselect', function (e) {
                                var b = e.params.data.id;
                                $('.div_c_' + b).remove();
                            });

                            function redirect() {
                                var orgid = $('#org_id').val();
                                if ('<?php echo $this->uri->segment(2) ?>' === 'users') {
                                    window.location.href = ' <?php echo base_url() ?>add_new_users/users/' + orgid;
                                }
                            };
                            function deleteprogram(url) {
                                a = confirm("Are you sure to delete?");
                                console.log(a);
                                if (a) {
                                    window.location.href = url;
                                }
                            }
                </script>


            </div>

        </body>

    </html>
     <?php } ?> 

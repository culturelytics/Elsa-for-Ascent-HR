<!-- <?php
        if (!isset($_SESSION["email"])) {
            header("Location: login1");
        } else {
        ?> -->

<?php
            defined('BASEPATH') or exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title><?php echo $this->config->item('page_title') ?></title>
    <!-- Bootstrap core CSS-->
    <link href="<?php echo base_url() ?>assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="<?php echo base_url() ?>assets/vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="<?php echo base_url() ?>assets/css/sb-admin.css" rel="stylesheet">
</head>

<body class="fixed-nav sticky-footer bg-dark" id="page-top">
    <!-- Navigation-->
    <?php include "sidebar.php"; ?>
    <div class="content-wrapper admpage2 ccntr">
        <div class="container-headbox">
            <!-- Breadcrumbs-->
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo base_url() ?>dashboard/">Home</a>
                </li>
                <li class="breadcrumb-item active">Competencies Center</li>
            </ol>
            <!-- Icon Cards-->

            <div class="clearfix">
                <center>
                    <h3>COMPETENCIES CENTER</h3>
                </center>
            </div>
        </div>

        <div class="container-fluid rgpage">
            <!-- Icon Cards-->
            <div>
                <!--<center><h3>Competency Center</h3></center>-->
                <p align="right">
                    <!--<a href="<?php echo base_url() ?>competency_center/export" class="btn btn-primary btn-condensed">Add New</a>&nbsp;&nbsp;-->
                    <a data-toggle="modal" data-target="#addCompetencyModal" class="btn btn-primary btn-condensed" style="color: #fff;">Add New</a>&nbsp;&nbsp;
                    <!--<a href="<?php // echo base_url() ?>competencies/export" class="btn btn-primary btn-condensed">Export</a>-->
                </p>
            </div>
            <!--<hr>-->
            <div class="container cmptcycntr" style="padding-right: 0px !important;padding-left: 0px !important;margin-top: -50px;">
                <!--<p>List of all Module</p>-->
                <div class="table-responsive">
                    <table class="table table-bordered dataTable" id="dataTable" cellspacing="0" role="grid" aria-describedby="dataTable_info">
                        <thead>
                            <tr>
                                <th style="width: 8%; min-width: 40px; text-align:left;">S.no</th>
                                <th style="width: 77%; min-width: 250px; text-align:left;">Name</th>
                                <th style="width: 15%; min-width: 115px; text-align:center;">Action</th>
                            </tr>
                        </thead>
                        <?php $i = 0;
                        foreach ($list as $row) : $i++;
                        ?>
                            <tr>
                                <td style="text-align: center;"><?php echo $i; ?></td> <!-- php 5.6 version -->
                                <td><?php echo $row->prg_name ?></td>
                                <td>
                                    <span><a href="#" class="programeditccenter" title="Edit" data-pid="<?= $row->prg_id ?>"><i class="fa fa-pencil" aria-hidden="true"></i></a></span>
                                    <span><a href="#" class="delete" title="Delete" onclick="deleteprogram('<?php echo base_url() ?>competencies/delete/<?php echo $row->prg_id ?>')"><i class="fa fa-trash" aria-hidden="true"></i></a></span>
                                    <span><a href="<?php echo base_url() ?>competencies/attributes/<?= $row->prg_id ?>" title="Manage Attributes"><i class="fa fa-sliders" aria-hidden="true"></i></a></span>
                                    <span><a href="<?php echo base_url() ?>competencies/modules/<?= $row->prg_id ?>" title="Manage Modules"><i class="fa fa-list-ul" aria-hidden="true"></i></a></span>

                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </table>
                </div>
            </div>
            <?php include_once('footer.php'); ?>
        </div>
    </div>
    <div class="modal fade" id="addCompetencyModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Add Competency</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">

                    <form action="<?php echo base_url() ?>competencies" method="post" id="usersform">
                        <div>
                            <input type="text" name="prg_name" placeholder="Competency Name" required>
                            <?php echo form_open('prg_name'); ?>
                        </div>
                        <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">

                    </form>
                </div>
            </div>
        </div>
    </div>

    <div class=" modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal" aria-hidden="true">
        <div class="modal-dialog" style="width:600px;max-width: 600px;" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Competency</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form action="<?php echo base_url() ?>competencies/update" method="post" id="usersform">
                        <div class="modal-body"> <input type="text" name="prg_name1" placeholder="Competency Name" id="prg_name1" value="" required>
                            <input type="hidden" name="prg_id1" placeholder="Program Name" id="prg_id1" value="" required>
                        </div>

                        <input type="submit" name="submit" class="btn btn-primary" value="submit" id="checkBtn">
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src=" <?php echo base_url() ?>assets/vendor/jquery/jquery.min.js"> </script>
    <script src="<?php echo base_url() ?>assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url() ?>assets/vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url() ?>assets/vendor/chart.js/Chart.min.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/datatables/jquery.dataTables.js"></script>
    <script src="<?php echo base_url() ?>assets/vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url() ?>assets/assets/js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="<?php echo base_url() ?>assets/js/sb-admin-datatables.min.js"></script>
    <script src="<?php echo base_url() ?>assets/js/sb-admin-charts.min.js"></script>

    <script type="text/javascript">
                $(document).on('click', '.programeditccenter',function (e) {
                var pid = $(this).data('pid');
                $.post('<?php echo base_url() ?>competencies/edit', 'pid=' + pid, function(rs) {
                    if (rs) {
                        rs = JSON.parse(rs);
                        console.log(rs);
                        $('#prg_id1').val(rs[0].prg_id);
                        $('#prg_name1').val(rs[0].prg_name);
                        $('#myModal').modal('show');
                    } else {
                        alert("No record found")
                    }
                });
            });

        function deleteprogram(url) {
            a = confirm("Are you sure to delete?");
            if (a) {
                window.location.href = url;
            }
        }
    </script>
</body>

</html>
<!-- <?php } ?> -->
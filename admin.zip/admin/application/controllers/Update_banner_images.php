<?php

class Update_banner_images extends CI_Controller {

    public function __construct()
    {
            parent::__construct();
            // $this->load->helper(array('form', 'url'));
            // $this->load->helper(array('form', 'url'));
            $this->load->library('upload');
            $this->load->library('session');
            $this->load->model('update_banner_images_model');
    }

    public function index()
    {

        if($this->session->userdata('email')){
          if($_SESSION['role'] === 'super_admin') { 
            $data['list']=$this->update_banner_images_model->get_image();
            $this->load->view('update_banner_images', $data);
          }else{
            redirect('dashboard/index', 'refresh');
          }
        }
         else{

        redirect(base_url('login'));
      }      
    }


    public function addimage(){

    if($this->input->post()){

  
        
         
        
        //$new_image_name = time() . str_replace(str_split(' ()\\/,:*?"<>|'), '', 
        
        $config['file_name'] = $_FILES['bannerimg']['name'];
        $config['upload_path'] = 'uploads/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '10000';
        $config['max_width']  = '10240';
        $config['max_height']  = '7680';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if (!$this->upload->do_upload('bannerimg'))
        {
          $error = array('error' => $this->upload->display_errors());
          $this->session->set_flashdata('notification', 'file not uploaded success');
          redirect('update_banner_images','refresh');
        }
        else {
        $value = array('uploadimage' => $config['file_name'], 'imagelink' => $this->input->post('imagelink'));

            $val = $this->update_banner_images_model->addimage($value);         
            if($val == TRUE) {
              $this->session->set_flashdata('addednotification', 'New Banner Added successfully');
              redirect('update_banner_images','refresh'); 
            }
            else {
            $this->session->set_flashdata('notnotification', 'Cannot Add banner image');
            }
          

        }


        
    }
    }


  public function update_image()
   {
    $id= $this->input->post('id');
    if($this->input->post()){

     if($_FILES['image']['name'] != NULL){
        
        $config['file_name'] = $_FILES['image']['name'];
        $config['upload_path'] = 'uploads/';
        $config['allowed_types'] = 'gif|jpg|png|jpeg';
        $config['max_size'] = '10000';
        $config['max_width']  = '10240';
        $config['max_height']  = '7680';

        $this->load->library('upload', $config);
        $this->upload->initialize($config);
   
        if (!$this->upload->do_upload('image'))
        {
          $error = array('error' => $this->upload->display_errors());
          $this->session->set_flashdata('notification', 'file not uploaded success');
          redirect('update_banner_images','refresh');
        }
        else {
        $value = array('uploadimage' => $config['file_name'], 'imagelink' => $this->input->post('name'));

            $val = $this->update_banner_images_model->update_image($value, $id);         
            if($val == TRUE) {
              $this->session->set_flashdata('notification', 'Added successfully');
              redirect('update_banner_images','refresh'); 
            }
            else {
            $this->session->set_flashdata('notification', 'Cant Add banner image');
            }
          

        }

       }

       else{
        
        $value = array('imagelink' => $this->input->post('name'));
        $val = $this->update_banner_images_model->update_image($value, $id); 
          if($val == TRUE) {
            $this->session->set_flashdata('updatenotification', 'Updated successfully');
            redirect('update_banner_images' ); 
          }
          else {
            $this->session->set_flashdata('notnotification', ' Cannot updated');
            echo "ddddd";
          
            }
       }
       
    }
   } 

  public function delete()
  {
      
     $id2 = $this->uri->segment(3);

   
      $this->update_banner_images_model->deletee($id2);
      $this->session->set_flashdata('deletenotification', 'Banner deleted successfully');
      redirect('update_banner_images');
  }

    }
    ?>
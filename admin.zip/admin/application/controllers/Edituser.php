<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Edituser extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('edituser_model');
        $this->load->model('user_details_model');
    }

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function users($id, $org_id) {
       
        $loggedInUser = $this->user_details_model->get_admin_by_email($this->session->userdata('email'));
        if ($this->session->userdata('email')) {
         if($_SESSION['role'] === 'super_admin') { 
          
            $data['organization_id'] = $org_id;
            $data['organizations'] = $this->user_details_model->get_organizations($loggedInUser->id);
            $data['row'] = $this->edituser_model->get_data($id);
            $data['idp'] = $this->user_details_model->get_all_idp();
            $data['idp_c'] = $this->user_details_model->get_all_idp_c($org_id);
            $data['programs'] = json_encode($this->user_details_model->get_all_programs());
            $data['ui_idp_id'] = $this->user_details_model->get_edit_idp_id($id);
            $data['ui_idp_id_c'] = $this->user_details_model->get_edit_idp_id_c($id);
            $data['kc_a_list'] = $this->user_details_model->get_all_kc_a_list();
            $data['kc_c_list'] = $this->user_details_model->get_all_kc_c_list($data['row']->organization_id);
            $data['kca_a_list'] = $this->user_details_model->get_all_kca_a($id);
            $data['kca_c_list'] = $this->user_details_model->get_all_kca_c($id);
            if ($this->input->post()) {

                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]|max_length[40]');

                $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[1]|max_length[40]');
                $this->form_validation->set_rules('phone', 'Phone', 'trim|required|min_length[1]|max_length[10]');
                $this->form_validation->set_rules('kaccess', 'Access', 'trim|required|min_length[1]|max_length[10]');
                $this->form_validation->set_rules('kc_c_access', 'Access', 'trim|required|min_length[1]|max_length[10]');
                $this->form_validation->set_rules('caccess', 'IDP Aggregator Access', 'trim|required|min_length[1]|max_length[10]');
                $this->form_validation->set_rules('idp_c_access', 'IDP Client Access', 'trim|required|min_length[1]|max_length[10]');
                $this->form_validation->set_rules('status', 'Status', 'trim|required|min_length[1]|max_length[10]');

                $this->form_validation->set_rules('status', 'last_name', 'trim|required');
                $this->form_validation->set_rules('status', 'age', 'trim|required');
                $this->form_validation->set_rules('status', 'gender', 'trim|required');

                $this->form_validation->set_rules('organization_id', 'organization_id', 'trim|required');


                if ($this->input->post('caccess') == 'yes') {
                    $this->form_validation->set_rules('idp[]', 'Programs Names', 'required');
                    foreach ($this->input->post('idp') as $row) {
                        $this->form_validation->set_rules('selected_' . $row . '[]', 'Modules Names', 'required');
                    }
                }

                if ($this->input->post('idp_c_access') == 'yes') {
                    $this->form_validation->set_rules('idp_c[]', 'Programs Names', 'required');
                    foreach ($this->input->post('idp_c') as $row) {
                        $this->form_validation->set_rules('selected_c_' . $row . '[]', 'Modules Names', 'required');
                    }
                }

                if ($this->form_validation->run() == TRUE) {
                    $id = $this->input->post('id');
                    $data1 = $this->input->post();
                    $this->user_details_model->update_data($data1, $id);
                    $this->session->set_flashdata('notification', 'User Updated successfully');
                    redirect('add_new_users/users/' . $this->uri->segment(4), 'refresh');
                } else {
                    $this->load->view('edit_user', $data);
                    return;
                }
            } else {
                $this->load->view('edit_user', $data);
            }
          }else{
              redirect('add_new_users/users/' . $this->uri->segment(4), 'refresh');
          }
        } else {
            redirect('login');
        }
    
    }
    
    public function update_user() {
        $id = $this->input->post('id');
        $data = array(
            'email' => $this->input->post('email'),
            'name' => $this->input->post('name'),
            'password' => $this->input->post('password'),
            'contact' => $this->input->post('phone'),
            'kaccess' => $this->input->post('kaccess'),
            'caccess' => $this->input->post('caccess'),
            'status' => $this->input->post('status'),
        );


        $this->user_details_model->update_data($data, $id);
        redirect('add_new_users/users/' . $this->uri->segment(3));
    }

    public function edituser() {
        $id = $this->input->post('id');

        $this->load->view('edit_user');

        $data = array(
            'email' => $this->input->post('email'),
            'name' => $this->input->post('name'),
            'password' => $this->input->post('password'),
            'contact' => $this->input->post('phone'),
            'kaccess' => $this->input->post('kaccess'),
            'caccess' => $this->input->post('caccess'),
            'status' => $this->input->post('status'),
        );

        $this->user_details_model->update_data($data, $id);
        redirect('add_new_users/users/' . $this->uri->segment(3));
    }

}

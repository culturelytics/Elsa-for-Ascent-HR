<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Addmodulecontent extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
         $this->load->helper(array('form', 'url'));
         $this->load->library('upload');
         $this->load->library('session');
         $this->load->model('Addmodulecontent_model');
         if(!$this->session->userdata('email')){ 
         	redirect(base_url('login'));
        }
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index($id,$org_id)
	{
		$user_id = $this->uri->segment(2);
		$usermoduledata['data'] = $this->Addmodulecontent_model->getusermodule($user_id);

		foreach($usermoduledata['data'] as $key=>$umd) {
			$prg_ids = unserialize($umd['ui_module_ids']);

			$usermoduledata['data'][$key]['modules'] = $this->Addmodulecontent_model->getusermodulenames($prg_ids);

		}


		$this->load->view('addmodulecontent', $usermoduledata);
		
	}
	public function getidpname(){
		$usermoduledata['data2'] = $this->Addmodulecontent_model->idpname($data1);
		$this->load->view('addmodulecontent', $usermoduledata);
	}
}
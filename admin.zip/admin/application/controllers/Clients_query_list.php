<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Clients_query_list extends CI_Controller {
public function __construct()
    {
        parent::__construct();
        $this->load->model('clients_query_model');
    }
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	    if($this->session->userdata('email')){
			$org_id=0; $users = array();
			if($_SESSION["role"] !== 'super_admin') {
				$org_id = $_SESSION["org_id"];
			}

			if( $_SESSION['role'] === 'group_admin') {
				// first fetch all group ids which are under current group admin
				$groupids =$this->clients_query_model->get_grps($_SESSION['user_id']);
			
				// fetch all users of all group ids from above
				
				if(count($groupids) > 0){ 
					$groupMembers =$this->clients_query_model->get_grpmembers($groupids);
					if(count($groupMembers) > 0){
						$users=array_column($groupMembers, 'user_id');
					}
				}	
				
			}
			// if($_SESSION['role'] === 'super_admin') { 
				$data['list']=$this->clients_query_model->get_query($org_id, $users);


				$this->load->view('query_list', $data);
			// }else{
			// 	redirect('dashboard/index', 'refresh');
			// }
	}
	else{
		redirect('login');
	}
	}
}

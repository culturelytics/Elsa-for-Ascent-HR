<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
		 //$this->load->helper(array('form', 'url'));     
		 //$this->load->helper('url');
         //$this->load->library('session');
         //$this->load->model('programs_model');
    }

	public function index()
	{
		if(!$this->session->userdata('email')) {
			redirect('login');
		}

		$user_id = $this->input->get('user_id');
		if(!isset($user_id) || $user_id == null) {
			// $user_id = 'ALL';
			$user_id = $_SESSION['user_id'];
		}

		$organization_id = $this->input->get('organization_id');
		if(!isset($organization_id) || $organization_id == null) {
			$organization_id = 0;
		}

		$role = $this->session->userdata('role'); $role_org = $this->session->userdata('org_id');
		if($role === 'org_admin' || $role === 'group_admin') {
			$organization_id = $role_org;
		}

		$organizations = [];
		$organizations = $this->db->query("SELECT id, org_name FROM tbl_organization;")->result_array();

		// --- User Data Start ----------------------------------------------------------------------------------------/
		$udata = array("mucount" => 0, "fucount" => 0, "aaucount" => 0, "abucount" => 0, "userids" => array(), "usernames" => array());		
		$sqlusers = "SELECT id, name, last_name, gender, age, organization_id FROM `tbl_user` AS u WHERE u.status='active'";
		if ($organization_id != null) {
			$sqlusers = $sqlusers . " AND u.organization_id = " . $organization_id . " ";
		}

		if($role === 'group_admin') {
			$sqlusers = $sqlusers . " AND u.id IN (SELECT user_id FROM `tbl_group_user` WHERE STATUS = 'active' AND group_id IN (SELECT group_id FROM `tbl_group_user` WHERE STATUS = 'active' AND user_id = ".$user_id." AND is_admin = 1)) ";
		}

		$users = $this->db->query($sqlusers)->result_array();
		foreach($users as $u) {
			array_push($udata['userids'], $u['id']);
			$udata['usernames'][$u['id']] = $u['name']." ".$u['last_name'];
			if(strtolower($u['gender']) == 'male') { $udata['mucount']++; } else { $udata['fucount']++; }
			if(strtolower($u['age']) <= 1) { $udata['abucount']++; } else { $udata['aaucount']++; }
		}
		// --- User Data End ----------------------------------------------------------------------------------------/

		// --- Content Data Start ----------------------------------------------------------------------------------------/
		$cntdata = array('Article' => 0, 'Video' => 0, 'Assessment' => 0, 'SelfAssessment' => 0, 'Booksuggestion' => 0, 'Module' => 0);
		$cntdatat = $this->db->query("SELECT kl_cat, COUNT(*) AS total FROM tbl_kc_list WHERE STATUS = 'Active' GROUP BY kl_cat;")->result_array();
		foreach($cntdatat as $k => $row) {
			if($row['kl_cat'] === 'Elsa Assessment' || $row['kl_cat'] === 'Assessment') {
				$cntdata['Assessment'] += $row['total'];
			}
			else {
				$cntdata[$row['kl_cat']] = $row['total'];
			}
		}
		
		$cntdatat = $this->db->query("SELECT COUNT(*) AS total FROM tbl_knowledge_center WHERE prg_status = 'Active';")->result_array();
		foreach($cntdatat as $k => $row) {
			$cntdata['Module'] = $row['total'];
		}

		$t_img_total = array();
		$rs_img_total = $this->db->query("SELECT COUNT(DISTINCT img_id) AS total FROM tbl_image_content;")->result_array();
		foreach($rs_img_total as $k => $row) {
			$t_img_total = $row['total'];
		}

		$oloverview = array(
            0 => array("label" => "ARTICLES", "icon" => "articles", "number" => $cntdata['Article']),
            1 => array("label" => "VIDEOS", "icon" => "videos", "number" => $cntdata['Video']),
            2 => array("label" => "ASSESSMENTS", "icon" => "assessments", "number" => $cntdata['Assessment']),
            3 => array("label" => "SELF ASSESSMENTS", "icon" => "assessments", "number" => $cntdata['SelfAssessment']),
            4 => array("label" => "BOOK SUGGESTIONS", "icon" => "books", "number" => $t_img_total) // $cntdata['Booksuggestion'])
          );
		// --- Content Data End ----------------------------------------------------------------------------------------/
		
		// --- Time Spent Data Start ----------------------------------------------------------------------------------------/
		$tsdata = array(
			'lts' => 0, 'ats' => 0, 'users' => array(), 'user_names' => array(), 'ucount' => 0, 'mucount' => 0, 'fucount' => 0, 'aaucount' => 0, 'abucount' => 0, 'mucount' => 0, 'fucount' => 0,
			'musers' => array(), 'fusers' => array(), 'aausers' => array(), 'abusers' => array(), 'mpercent' => 0, 'fpercent' => 0, 'aapercent' => 0, 'abpercent' => 0,
			'lts_ind' => 0, 'ats_ind' => 0, 'users_ind' => array(), 'ucount_ind' => 0,
			'modules' => array(), 'mmodules' => array(), 'fmodules' => array(), 'aamodules' => array(), 'abmodules' => array(),
			'acontent' => array(), 'vcontent' => array(), 'bcontent' => array(),
			'account' => array(), 'vccount' => array(), 'bccount' => array()
		); 
		
		// $tquery = " SELECT tbl_user_login_history.*, tbl_user.organization_id from tbl_user_login_history 
		// LEFT JOIN tbl_user ON tbl_user.id = tbl_user_login_history.ulh_u_id
		// WHERE ulh_id IN (SELECT DISTINCT(eh_ul_id) FROM tbl_event_history) ";

		$tquery = " SELECT tbl_event_history.*, tbl_user_login_history.*, 
		tbl_user.id, tbl_user.name, tbl_user.last_name, tbl_user.age, tbl_user.gender, tbl_user.organization_id, 
		tbl_knowledge_center.prg_name, tbl_image_content.img_title, tbl_kc_list.kl_cat, tbl_kc_list.kl_list 
		FROM tbl_event_history 
		LEFT JOIN tbl_user_login_history ON tbl_user_login_history.ulh_id = tbl_event_history.eh_ul_id
		LEFT JOIN tbl_user ON tbl_user.id = tbl_user_login_history.ulh_u_id 
		LEFT JOIN tbl_kc_list ON tbl_event_history.eh_kc_list_id = tbl_kc_list.kl_id and tbl_event_history.eh_cori = 'content' 
		LEFT JOIN tbl_image_content ON tbl_event_history.eh_kc_list_id = tbl_image_content.img_id and tbl_event_history.eh_cori = 'image' 
		LEFT JOIN tbl_kc_content ON tbl_kc_list.kl_kc_id = tbl_kc_content.kc_id 
		LEFT JOIN tbl_knowledge_center ON tbl_kc_content.kc_prg_id = tbl_knowledge_center.prg_id or tbl_image_content.img_kc_id = tbl_knowledge_center.prg_id 
		WHERE tbl_event_history.eh_ul_id > 0
		
		";
		if($organization_id !== 0) {
			$orgs = array();
			$ors = $this->db->query("SELECT id FROM tbl_organization where industry_id = (select industry_id from tbl_organization where id = " . $organization_id . " ) ")->result();
			if($ors) { $orgs = array_column($ors, 'id'); }	
			if(count($orgs) == 0) { array_push($orgs, $organization_id); }		

			$tquery .= " AND tbl_user.organization_id in ( " . implode(",", $orgs) . ")";
		}

		$tquery .= " ORDER BY tbl_event_history.eh_ul_id ";

		$tdata = $this->db->query($tquery)->result(); $previous_ulh_id = 0;
		foreach($tdata as $row) {
			
			if($previous_ulh_id !== $row->ulh_id) {
				$start_date = new DateTime($row->eh_created_at);
				$ts = $start_date->diff(new DateTime($row->ulh_end_time)); 
				$org_add = true;

				$minutes = $ts->days * 24 * 60; $minutes += $ts->h * 60; $minutes += $ts->i; if(is_nan($minutes)) { $minutes = 0; }
				$tsdata['lts_ind'] += $minutes;

				if(isset($tsdata['modules'][$row->prg_name]) == false) { $tsdata['modules'][$row->prg_name] = 0; }
				$tsdata['modules'][$row->prg_name] += $minutes;

				if(strtolower($row->eh_cori) == 'content') {
					if(strtolower($row->kl_cat) == 'article') {
						if(isset($tsdata['acontent'][$row->kl_list]) == false) { $tsdata['acontent'][$row->kl_list] = 0; }
						$tsdata['acontent'][$row->kl_list] += $minutes;
						if(isset($tsdata['account'][$row->kl_list]) == false) { $tsdata['account'][$row->kl_list] = 0; }
						$tsdata['account'][$row->kl_list]++;
					}
					else if(strtolower($row->kl_cat) == 'video') {
						if(isset($tsdata['vcontent'][$row->kl_list]) == false) { $tsdata['vcontent'][$row->kl_list] = 0; }
						$tsdata['vcontent'][$row->kl_list] += $minutes;
						if(isset($tsdata['vccount'][$row->kl_list]) == false) { $tsdata['vccount'][$row->kl_list] = 0; }
						$tsdata['vccount'][$row->kl_list]++;
					}
				}
				else if(strtolower($row->eh_cori) == 'image') {
					if(isset($tsdata['bcontent'][$row->img_title]) == false) { $tsdata['bcontent'][$row->img_title] = 0; }
					$tsdata['bcontent'][$row->img_title] += $minutes;
					if(isset($tsdata['bccount'][$row->kl_list]) == false) { $tsdata['bccount'][$row->kl_list] = 0; }
					$tsdata['bccount'][$row->kl_list]++;
				}

				if(isset($tsdata['users_ind'][$row->ulh_u_id]) === false) {
					$tsdata['users_ind'][$row->ulh_u_id] = 0; 
					$tsdata['ucount_ind']++; 
				}
				$tsdata['users_ind'][$row->ulh_u_id] += $minutes;
				
				if($organization_id !== 0) {
					if($row->organization_id !== $organization_id) {
						$org_add = false;
					}
				}

				if($role === 'group_admin') {
					if(in_array($row->ulh_u_id, $udata['userids']) == false) {
						$org_add = false;
					}
				}

				if($org_add) {
					$tsdata['lts'] += $minutes;
					if(isset($tsdata['users'][$row->ulh_u_id]) === false) {
						$tsdata['users'][$row->ulh_u_id] = 0; 
						$tsdata['ucount']++; 
						if($row->age <= 1) { 
							if(isset($tsdata['abusers'][$row->ulh_u_id]) === false) { $tsdata['abusers'][$row->ulh_u_id] = 0; }
							$tsdata['abusers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['abmodules'][$row->prg_name]) == false) { $tsdata['abmodules'][$row->prg_name] = 0; }
							$tsdata['abmodules'][$row->prg_name] += $minutes;
							$tsdata['abucount']++;
						} else { 
							if(isset($tsdata['aausers'][$row->ulh_u_id]) === false) { $tsdata['aausers'][$row->ulh_u_id] = 0; }
							$tsdata['aausers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['aamodules'][$row->prg_name]) == false) { $tsdata['aamodules'][$row->prg_name] = 0; }
							$tsdata['aamodules'][$row->prg_name] += $minutes;
							$tsdata['aaucount']++; 
						}
						if(strtolower($row->gender) == 'male') {
							if(isset($tsdata['musers'][$row->ulh_u_id]) === false) { $tsdata['musers'][$row->ulh_u_id] = 0; }
							$tsdata['musers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['mmodules'][$row->prg_name]) == false) { $tsdata['mmodules'][$row->prg_name] = 0; }
							$tsdata['mmodules'][$row->prg_name] += $minutes;
							$tsdata['mucount']++; 
						} else { 
							if(isset($tsdata['fusers'][$row->ulh_u_id]) === false) { $tsdata['fusers'][$row->ulh_u_id] = 0; }
							$tsdata['fusers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['fmodules'][$row->prg_name]) == false) { $tsdata['fmodules'][$row->prg_name] = 0; }
							$tsdata['fmodules'][$row->prg_name] += $minutes;
							$tsdata['fucount']++; 
						}
					}
					$tsdata['users'][$row->ulh_u_id] += $minutes;
				}

				$previous_ulh_id = $row->ulh_id;

			}

		}

		$tsdata['ats_ind'] = ($tsdata['lts_ind'] > 0 && $tsdata['ucount_ind'] > 0) ? $tsdata['lts_ind'] / $tsdata['ucount_ind'] : 0;
		$tsdata['ats'] = ($tsdata['lts'] > 0 && $tsdata['ucount'] > 0) ? $tsdata['lts'] / $tsdata['ucount'] : 0;

		$tsdata['mpercent'] = ($tsdata['mucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['mucount'] * 100) / $tsdata['ucount']) : 0;
		$tsdata['fpercent'] = ($tsdata['fucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['fucount'] * 100) / $tsdata['ucount']) : 0;

		$tsdata['aapercent'] = ($tsdata['aaucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['aaucount'] * 100) / $tsdata['ucount']) : 0;
		$tsdata['abpercent'] = ($tsdata['abucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['abucount'] * 100) / $tsdata['ucount']) : 0;

		arsort($tsdata['modules']);
		arsort($tsdata['aamodules']);
		arsort($tsdata['abmodules']);
		arsort($tsdata['mmodules']);
		arsort($tsdata['fmodules']);

		arsort($tsdata['users']);
		arsort($tsdata['aausers']);
		arsort($tsdata['abusers']);
		arsort($tsdata['musers']);
		arsort($tsdata['fusers']);
		
		arsort($tsdata['acontent']);
		arsort($tsdata['vcontent']);
		arsort($tsdata['bcontent']);
		
		arsort($tsdata['account']);
		arsort($tsdata['vccount']);
		arsort($tsdata['bccount']);
		
		$tsdata['umax'] = max(array_filter($tsdata['users']));
		$tsdata['umin'] = min(array_filter($tsdata['users']));
		$tsdata['uavg'] = ($tsdata['ucount'] > 0) ? round(array_sum($tsdata['users']) / $tsdata['ucount']) : 0;

		$tsdata['mumax'] = max(array_filter($tsdata['musers'])); 
		$tsdata['mumin'] = min(array_filter($tsdata['musers'])); 
		$tsdata['muavg'] = ($tsdata['mucount'] > 0) ? round(array_sum($tsdata['musers']) / $tsdata['mucount'], 2) : 0;

		$tsdata['fumax'] = max(array_filter($tsdata['fusers']));
		$tsdata['fumin'] = min(array_filter($tsdata['fusers']));
		$tsdata['fuavg'] = ($tsdata['fucount'] > 0) ? round(array_sum($tsdata['fusers']) / $tsdata['fucount'], 2) : 0;

		$tsdata['mumaxp'] = $tsdata['mumax'] * 100 / ($tsdata['mumax'] + $tsdata['fumax']); 
		$tsdata['muminp'] = $tsdata['mumin'] * 100 / ($tsdata['mumin'] + $tsdata['fumin']);
		$tsdata['muavgp'] = $tsdata['muavg'] * 100 / ($tsdata['muavg'] + $tsdata['fuavg']); 

		$tsdata['fumaxp'] = $tsdata['fumax'] * 100 / ($tsdata['mumax'] + $tsdata['fumax']); 
		$tsdata['fuminp'] = $tsdata['fumin'] * 100 / ($tsdata['mumin'] + $tsdata['fumin']);
		$tsdata['fuavgp'] = $tsdata['fuavg'] * 100 / ($tsdata['muavg'] + $tsdata['fuavg']); 

		
		$tsdata['aaumax'] = max(array_filter($tsdata['aausers'])); 
		$tsdata['aaumin'] = min(array_filter($tsdata['aausers'])); 
		$tsdata['aauavg'] = ($tsdata['aaucount'] > 0) ? round(array_sum($tsdata['aausers']) / $tsdata['aaucount'], 2) : 0;

		$tsdata['abumax'] = max(array_filter($tsdata['abusers']));
		$tsdata['abumin'] = min(array_filter($tsdata['abusers']));
		$tsdata['abuavg'] = ($tsdata['abucount'] > 0) ? round(array_sum($tsdata['abusers']) / $tsdata['abucount'], 2) : 0;

		$tsdata['aaumaxp'] = $tsdata['aaumax'] * 100 / ($tsdata['aaumax'] + $tsdata['abumax']); 
		$tsdata['aauminp'] = $tsdata['aaumin'] * 100 / ($tsdata['aaumin'] + $tsdata['abumin']);
		$tsdata['aauavgp'] = $tsdata['aauavg'] * 100 / ($tsdata['aauavg'] + $tsdata['abuavg']); 

		$tsdata['abumaxp'] = $tsdata['abumax'] * 100 / ($tsdata['aaumax'] + $tsdata['abumax']); 
		$tsdata['abuminp'] = $tsdata['abumin'] * 100 / ($tsdata['aaumin'] + $tsdata['abumin']);
		$tsdata['abuavgp'] = $tsdata['abuavg'] * 100 / ($tsdata['aauavg'] + $tsdata['abuavg']); 

		$totalcontent = array_sum($tsdata['account']) + array_sum($tsdata['vccount']) + array_sum($tsdata['bccount']);

		$tsdata['acpercent'] = ( array_sum($tsdata['account']) > 0 && $totalcontent > 0 ) ? array_sum($tsdata['account']) * 100 / $totalcontent : 0;
		$tsdata['vcpercent'] = ( array_sum($tsdata['vccount']) > 0 && $totalcontent > 0 ) ? array_sum($tsdata['vccount']) * 100 / $totalcontent : 0;
		$tsdata['bcpercent'] = ( array_sum($tsdata['bccount']) > 0 && $totalcontent > 0 ) ? array_sum($tsdata['bccount']) * 100 / $totalcontent : 0;

		
		// var_dump(array_slice($tsdata['musers'] , 0, 3, true)); die;

		// --- Time Spent Data End ----------------------------------------------------------------------------------------/

		$data = array(
			'user_id' => $user_id,
			'organization_id' => $organization_id,
			'organizations' => $organizations,
			'cntdata' => $cntdata,
			'udata' => $udata,
			'tsdata' => $tsdata,
			't_img_total' => $t_img_total,
			'oloverview' => $oloverview
		);
		
		$this->load->view('dashboard_company', $data);
	}

	
	public function report($organization_id = 0)
	{
		if(!$this->session->userdata('email')) {
			redirect('login');
		}

		$user_id = $this->input->get('user_id');
		if(!isset($user_id) || $user_id == null) {
			$user_id = 'ALL';
		}

		$organization_id = $this->input->get('organization_id');
		if(!isset($organization_id) || $organization_id == null) {
			$organization_id = 0;
		}

		$role = $this->session->userdata('role'); $role_org = $this->session->userdata('org_id');
		if($role === 'org_admin' || $role === 'group_admin') {
			$organization_id = $role_org;
		}

		$organizations = [];
		$organizations = $this->db->query("SELECT id, org_name FROM tbl_organization;")->result_array();

		// --- User Data Start ----------------------------------------------------------------------------------------/
		$udata = array("mucount" => 0, "fucount" => 0, "aaucount" => 0, "abucount" => 0, "userids" => array(), "usernames" => array());		
		$sqlusers = "SELECT id, name, last_name, gender, age, organization_id FROM `tbl_user` AS u WHERE u.status='active'";
		if ($organization_id != null) {
			$sqlusers = $sqlusers . " AND u.organization_id = " . $organization_id . " ";
		}

		if($role === 'group_admin') {
			$sqlusers = $sqlusers . " AND u.id IN (SELECT user_id FROM `tbl_group_user` WHERE STATUS = 'active' AND group_id IN (SELECT group_id FROM `tbl_group_user` WHERE STATUS = 'active' AND user_id = ".$user_id." AND is_admin = 1)) ";
		}

		$users = $this->db->query($sqlusers)->result_array();
		foreach($users as $u) {
			array_push($udata['userids'], $u['id']);
			$udata['usernames'][$u['id']] = $u['name']." ".$u['last_name'];
			if(strtolower($u['gender']) == 'male') { $udata['mucount']++; } else { $udata['fucount']++; }
			if(strtolower($u['age']) <= 1) { $udata['abucount']++; } else { $udata['aaucount']++; }
		}
		// --- User Data End ----------------------------------------------------------------------------------------/

		// --- Content Data Start ----------------------------------------------------------------------------------------/
		$cntdata = array('Article' => 0, 'Video' => 0, 'Assessment' => 0, 'SelfAssessment' => 0, 'Booksuggestion' => 0, 'Module' => 0);
		$cntdatat = $this->db->query("SELECT kl_cat, COUNT(*) AS total FROM tbl_kc_list WHERE STATUS = 'Active' GROUP BY kl_cat;")->result_array();
		foreach($cntdatat as $k => $row) {
			if($row['kl_cat'] === 'Elsa Assessment' || $row['kl_cat'] === 'Assessment') {
				$cntdata['Assessment'] += $row['total'];
			}
			else {
				$cntdata[$row['kl_cat']] = $row['total'];
			}
		}
		
		$cntdatat = $this->db->query("SELECT COUNT(*) AS total FROM tbl_knowledge_center WHERE prg_status = 'Active';")->result_array();
		foreach($cntdatat as $k => $row) {
			$cntdata['Module'] = $row['total'];
		}

		$t_img_total = array();
		$rs_img_total = $this->db->query("SELECT COUNT(DISTINCT img_id) AS total FROM tbl_image_content;")->result_array();
		foreach($rs_img_total as $k => $row) {
			$t_img_total = $row['total'];
		}

		$oloverview = array(
            0 => array("label" => "ARTICLES", "icon" => "articles", "number" => $cntdata['Article']),
            1 => array("label" => "VIDEOS", "icon" => "videos", "number" => $cntdata['Video']),
            2 => array("label" => "ASSESSMENTS", "icon" => "assessments", "number" => $cntdata['Assessment']),
            3 => array("label" => "SELF ASSESSMENTS", "icon" => "assessments", "number" => $cntdata['SelfAssessment']),
            4 => array("label" => "BOOK SUGGESTIONS", "icon" => "books", "number" => $t_img_total) // $cntdata['Booksuggestion'])
          );
		// --- Content Data End ----------------------------------------------------------------------------------------/
		
		// --- Time Spent Data Start ----------------------------------------------------------------------------------------/
		$tsdata = array(
			'lts' => 0, 'ats' => 0, 'users' => array(), 'user_names' => array(), 'ucount' => 0, 'mucount' => 0, 'fucount' => 0, 'aaucount' => 0, 'abucount' => 0, 'mucount' => 0, 'fucount' => 0,
			'musers' => array(), 'fusers' => array(), 'aausers' => array(), 'abusers' => array(), 'mpercent' => 0, 'fpercent' => 0, 'aapercent' => 0, 'abpercent' => 0,
			'lts_ind' => 0, 'ats_ind' => 0, 'users_ind' => array(), 'ucount_ind' => 0,
			'modules' => array(), 'mmodules' => array(), 'fmodules' => array(), 'aamodules' => array(), 'abmodules' => array(),
			'acontent' => array(), 'vcontent' => array(), 'bcontent' => array(),
			'account' => array(), 'vccount' => array(), 'bccount' => array()
		); 
		
		// $tquery = " SELECT tbl_user_login_history.*, tbl_user.organization_id from tbl_user_login_history 
		// LEFT JOIN tbl_user ON tbl_user.id = tbl_user_login_history.ulh_u_id
		// WHERE ulh_id IN (SELECT DISTINCT(eh_ul_id) FROM tbl_event_history) ";

		$tquery = " SELECT tbl_event_history.*, tbl_user_login_history.*, 
		tbl_user.id, tbl_user.name, tbl_user.last_name, tbl_user.age, tbl_user.gender, tbl_user.organization_id, 
		tbl_knowledge_center.prg_name, tbl_image_content.img_title, tbl_kc_list.kl_cat, tbl_kc_list.kl_list 
		FROM tbl_event_history 
		LEFT JOIN tbl_user_login_history ON tbl_user_login_history.ulh_id = tbl_event_history.eh_ul_id
		LEFT JOIN tbl_user ON tbl_user.id = tbl_user_login_history.ulh_u_id 
		LEFT JOIN tbl_kc_list ON tbl_event_history.eh_kc_list_id = tbl_kc_list.kl_id and tbl_event_history.eh_cori = 'content' 
		LEFT JOIN tbl_image_content ON tbl_event_history.eh_kc_list_id = tbl_image_content.img_id and tbl_event_history.eh_cori = 'image' 
		LEFT JOIN tbl_kc_content ON tbl_kc_list.kl_kc_id = tbl_kc_content.kc_id 
		LEFT JOIN tbl_knowledge_center ON tbl_kc_content.kc_prg_id = tbl_knowledge_center.prg_id or tbl_image_content.img_kc_id = tbl_knowledge_center.prg_id 
		WHERE tbl_event_history.eh_ul_id > 0
		
		";
		if($organization_id !== 0) {
			$orgs = array();
			$ors = $this->db->query("SELECT id FROM tbl_organization where industry_id = (select industry_id from tbl_organization where id = " . $organization_id . " ) ")->result();
			if($ors) { $orgs = array_column($ors, 'id'); }	
			if(count($orgs) == 0) { array_push($orgs, $organization_id); }		

			$tquery .= " AND tbl_user.organization_id in ( " . implode(",", $orgs) . ")";
		}

		$tquery .= " ORDER BY tbl_event_history.eh_ul_id ";

		$tdata = $this->db->query($tquery)->result(); $previous_ulh_id = 0;
		foreach($tdata as $row) {
			
			if($previous_ulh_id !== $row->ulh_id) {
				$start_date = new DateTime($row->eh_created_at);
				$ts = $start_date->diff(new DateTime($row->ulh_end_time)); 
				$org_add = true;

				$minutes = $ts->days * 24 * 60; $minutes += $ts->h * 60; $minutes += $ts->i; if(is_nan($minutes)) { $minutes = 0; }
				$tsdata['lts_ind'] += $minutes;

				if(isset($tsdata['modules'][$row->prg_name]) == false) { $tsdata['modules'][$row->prg_name] = 0; }
				$tsdata['modules'][$row->prg_name] += $minutes;

				if(strtolower($row->eh_cori) == 'content') {
					if(strtolower($row->kl_cat) == 'article') {
						if(isset($tsdata['acontent'][$row->kl_list]) == false) { $tsdata['acontent'][$row->kl_list] = 0; }
						$tsdata['acontent'][$row->kl_list] += $minutes;
						if(isset($tsdata['account'][$row->kl_list]) == false) { $tsdata['account'][$row->kl_list] = 0; }
						$tsdata['account'][$row->kl_list]++;
					}
					else if(strtolower($row->kl_cat) == 'video') {
						if(isset($tsdata['vcontent'][$row->kl_list]) == false) { $tsdata['vcontent'][$row->kl_list] = 0; }
						$tsdata['vcontent'][$row->kl_list] += $minutes;
						if(isset($tsdata['vccount'][$row->kl_list]) == false) { $tsdata['vccount'][$row->kl_list] = 0; }
						$tsdata['vccount'][$row->kl_list]++;
					}
				}
				else if(strtolower($row->eh_cori) == 'image') {
					if(isset($tsdata['bcontent'][$row->img_title]) == false) { $tsdata['bcontent'][$row->img_title] = 0; }
					$tsdata['bcontent'][$row->img_title] += $minutes;
					if(isset($tsdata['bccount'][$row->kl_list]) == false) { $tsdata['bccount'][$row->kl_list] = 0; }
					$tsdata['bccount'][$row->kl_list]++;
				}

				if(isset($tsdata['users_ind'][$row->ulh_u_id]) === false) {
					$tsdata['users_ind'][$row->ulh_u_id] = 0; 
					$tsdata['ucount_ind']++; 
				}
				$tsdata['users_ind'][$row->ulh_u_id] += $minutes;
				
				// if($organization_id !== 0) {
				// 	if($row->organization_id !== $organization_id) {
				// 		$org_add = false;
				// 	}
				// }

				// if($role === 'group_admin') {
				// 	if(in_array($row->ulh_u_id, $udata['userids']) == false) {
				// 		$org_add = false;
				// 	}
				// }

				if($org_add) {
					$tsdata['lts'] += $minutes;
					if(isset($tsdata['users'][$row->ulh_u_id]) === false) {
						$tsdata['users'][$row->ulh_u_id] = 0; 
						$tsdata['ucount']++; 
						if($row->age <= 1) { 
							if(isset($tsdata['abusers'][$row->ulh_u_id]) === false) { $tsdata['abusers'][$row->ulh_u_id] = 0; }
							$tsdata['abusers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['abmodules'][$row->prg_name]) == false) { $tsdata['abmodules'][$row->prg_name] = 0; }
							$tsdata['abmodules'][$row->prg_name] += $minutes;
							$tsdata['abucount']++;
						} else { 
							if(isset($tsdata['aausers'][$row->ulh_u_id]) === false) { $tsdata['aausers'][$row->ulh_u_id] = 0; }
							$tsdata['aausers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['aamodules'][$row->prg_name]) == false) { $tsdata['aamodules'][$row->prg_name] = 0; }
							$tsdata['aamodules'][$row->prg_name] += $minutes;
							$tsdata['aaucount']++; 
						}
						if(strtolower($row->gender) == 'male') {
							if(isset($tsdata['musers'][$row->ulh_u_id]) === false) { $tsdata['musers'][$row->ulh_u_id] = 0; }
							$tsdata['musers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['mmodules'][$row->prg_name]) == false) { $tsdata['mmodules'][$row->prg_name] = 0; }
							$tsdata['mmodules'][$row->prg_name] += $minutes;
							$tsdata['mucount']++; 
						} else { 
							if(isset($tsdata['fusers'][$row->ulh_u_id]) === false) { $tsdata['fusers'][$row->ulh_u_id] = 0; }
							$tsdata['fusers'][$row->ulh_u_id] += $minutes;
							if(isset($tsdata['fmodules'][$row->prg_name]) == false) { $tsdata['fmodules'][$row->prg_name] = 0; }
							$tsdata['fmodules'][$row->prg_name] += $minutes;
							$tsdata['fucount']++; 
						}
					}
					$tsdata['users'][$row->ulh_u_id] += $minutes;
				}

				$previous_ulh_id = $row->ulh_id;

			}

		}

		$tsdata['ats_ind'] = ($tsdata['lts_ind'] > 0 && $tsdata['ucount_ind'] > 0) ? $tsdata['lts_ind'] / $tsdata['ucount_ind'] : 0;
		$tsdata['ats'] = ($tsdata['lts'] > 0 && $tsdata['ucount'] > 0) ? $tsdata['lts'] / $tsdata['ucount'] : 0;

		$tsdata['mpercent'] = ($tsdata['mucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['mucount'] * 100) / $tsdata['ucount']) : 0;
		$tsdata['fpercent'] = ($tsdata['fucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['fucount'] * 100) / $tsdata['ucount']) : 0;

		$tsdata['aapercent'] = ($tsdata['aaucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['aaucount'] * 100) / $tsdata['ucount']) : 0;
		$tsdata['abpercent'] = ($tsdata['abucount'] > 0 && $tsdata['ucount'] > 0) ? round( ($tsdata['abucount'] * 100) / $tsdata['ucount']) : 0;

		arsort($tsdata['modules']);
		arsort($tsdata['aamodules']);
		arsort($tsdata['abmodules']);
		arsort($tsdata['mmodules']);
		arsort($tsdata['fmodules']);

		arsort($tsdata['users']);
		arsort($tsdata['aausers']);
		arsort($tsdata['abusers']);
		arsort($tsdata['musers']);
		arsort($tsdata['fusers']);
		
		arsort($tsdata['acontent']);
		arsort($tsdata['vcontent']);
		arsort($tsdata['bcontent']);
		
		arsort($tsdata['account']);
		arsort($tsdata['vccount']);
		arsort($tsdata['bccount']);
		
		$tsdata['umax'] = max(array_filter($tsdata['users']));
		$tsdata['umin'] = min(array_filter($tsdata['users']));
		$tsdata['uavg'] = ($tsdata['ucount'] > 0) ? round(array_sum($tsdata['users']) / $tsdata['ucount']) : 0;

		$tsdata['mumax'] = max(array_filter($tsdata['musers'])); 
		$tsdata['mumin'] = min(array_filter($tsdata['musers'])); 
		$tsdata['muavg'] = ($tsdata['mucount'] > 0) ? round(array_sum($tsdata['musers']) / $tsdata['mucount'], 2) : 0;

		$tsdata['fumax'] = max(array_filter($tsdata['fusers']));
		$tsdata['fumin'] = min(array_filter($tsdata['fusers']));
		$tsdata['fuavg'] = ($tsdata['fucount'] > 0) ? round(array_sum($tsdata['fusers']) / $tsdata['fucount'], 2) : 0;

		$tsdata['mumaxp'] = $tsdata['mumax'] * 100 / ($tsdata['mumax'] + $tsdata['fumax']); 
		$tsdata['muminp'] = $tsdata['mumin'] * 100 / ($tsdata['mumin'] + $tsdata['fumin']);
		$tsdata['muavgp'] = $tsdata['muavg'] * 100 / ($tsdata['muavg'] + $tsdata['fuavg']); 

		$tsdata['fumaxp'] = $tsdata['fumax'] * 100 / ($tsdata['mumax'] + $tsdata['fumax']); 
		$tsdata['fuminp'] = $tsdata['fumin'] * 100 / ($tsdata['mumin'] + $tsdata['fumin']);
		$tsdata['fuavgp'] = $tsdata['fuavg'] * 100 / ($tsdata['muavg'] + $tsdata['fuavg']); 

		
		$tsdata['aaumax'] = max(array_filter($tsdata['aausers'])); 
		$tsdata['aaumin'] = min(array_filter($tsdata['aausers'])); 
		$tsdata['aauavg'] = ($tsdata['aaucount'] > 0) ? round(array_sum($tsdata['aausers']) / $tsdata['aaucount'], 2) : 0;

		$tsdata['abumax'] = max(array_filter($tsdata['abusers']));
		$tsdata['abumin'] = min(array_filter($tsdata['abusers']));
		$tsdata['abuavg'] = ($tsdata['abucount'] > 0) ? round(array_sum($tsdata['abusers']) / $tsdata['abucount'], 2) : 0;

		$tsdata['aaumaxp'] = $tsdata['aaumax'] * 100 / ($tsdata['aaumax'] + $tsdata['abumax']); 
		$tsdata['aauminp'] = $tsdata['aaumin'] * 100 / ($tsdata['aaumin'] + $tsdata['abumin']);
		$tsdata['aauavgp'] = $tsdata['aauavg'] * 100 / ($tsdata['aauavg'] + $tsdata['abuavg']); 

		$tsdata['abumaxp'] = $tsdata['abumax'] * 100 / ($tsdata['aaumax'] + $tsdata['abumax']); 
		$tsdata['abuminp'] = $tsdata['abumin'] * 100 / ($tsdata['aaumin'] + $tsdata['abumin']);
		$tsdata['abuavgp'] = $tsdata['abuavg'] * 100 / ($tsdata['aauavg'] + $tsdata['abuavg']); 

		$totalcontent = array_sum($tsdata['account']) + array_sum($tsdata['vccount']) + array_sum($tsdata['bccount']);

		$tsdata['acpercent'] = ( array_sum($tsdata['account']) > 0 && $totalcontent > 0 ) ? array_sum($tsdata['account']) * 100 / $totalcontent : 0;
		$tsdata['vcpercent'] = ( array_sum($tsdata['vccount']) > 0 && $totalcontent > 0 ) ? array_sum($tsdata['vccount']) * 100 / $totalcontent : 0;
		$tsdata['bcpercent'] = ( array_sum($tsdata['bccount']) > 0 && $totalcontent > 0 ) ? array_sum($tsdata['bccount']) * 100 / $totalcontent : 0;

		
		// var_dump(array_slice($tsdata['musers'] , 0, 3, true)); die;

		// --- Time Spent Data End ----------------------------------------------------------------------------------------/

		$data = array(
			'user_id' => $user_id,
			'organization_id' => $organization_id,
			'organizations' => $organizations,
			'cntdata' => $cntdata,
			'udata' => $udata,
			'tsdata' => $tsdata,
			't_img_total' => $t_img_total,
			'oloverview' => $oloverview
		);
		
		$this->load->view('dashboard_report', $data);
	}
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_query_list extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
        $this->load->model('editclients_query_model');
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		  if($this->session->userdata('email')){
		 $id = $this->uri->segment(2);
		  
		$data['row']=$this->editclients_query_model->get_data($id);
		$this->load->view('edit_clients_query', $data);
	}else{
		redirect('login');
	}
	}
	
	
	public function update_query()
	{
		 $id = $this->input->post('id');

		 $data = array(
		 		'name' => $this->input->post('name'),
		 	    'module' => $this->input->post('module'),
			  	'sdate' => $this->input->post('sdate'),
			  	'cdate' => $this->input->post('cdate'),
			  	'department' => $this->input->post('department'),
			  	'sign' => $this->input->post('sign'),
			 	'dstop' => $this->input->post('dstop'),
			 	'consequence' => $this->input->post('consequence'),
			 	'dstart' => $this->input->post('dstart'),
			 	'benefits' => $this->input->post('benefits'),
			 	'aplan' => $this->input->post('aplan'),
			 	'progress' => $this->input->post('progress'),
			 	'week1' => $this->input->post('week1'),
			 	'week2' => $this->input->post('week2'),
			 	'week3' => $this->input->post('week3'),
			 	'week4' => $this->input->post('week4'),
		 	);
		 
	 
		  $this->editclients_query_model->update_data($data, $id);

           $this->session->set_flashdata('updatenotification', 'Clients Query details updated successfully');
		  redirect( base_url('clients_query_list'));
	}
	
	
	public function delete(){
		$id = $this->uri->segment(3);
		
		$this->db->where('id', $id);
		$this->db->delete('tbl_query');

	     $this->session->set_flashdata('deletenotification', 'Clients Query details deleted successfully');
		redirect( base_url('clients_query_list'));
	}
}

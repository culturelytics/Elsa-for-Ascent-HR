<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class programs extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
         $this->load->helper(array('form', 'url'));     
         $this->load->library('session');
         $this->load->model('programs_model');
    }

	public function aggregator()
	{
		$data['list']=$this->programs_model->get_data($this->uri->segment(3));
                $data['orgdetails']=$this->programs_model->get_orgDetails($this->uri->segment(3));
		if($this->session->userdata('email')){ 
		if($this->input->post()){
	 		$this->form_validation->set_rules('prg_name', 'Program Name', 'trim|required');
			if ($this->form_validation->run() == TRUE) {
				$data = array(
				'prg_name' => $this->input->post('prg_name'),
                                'org_id' => $this->input->post('org_id')
				);
			$this->programs_model->addprogram($data);
			$this->session->set_flashdata('notification', 'Added successfully');
			redirect('programs/aggregator/'.$this->input->post('org_id'),'refresh'); 
			} else {
			 $this->load->view('programs', $data);
			}
		}else{
			$this->load->view('programs', $data);	
		}
	    }
	    else{
	    	redirect(base_url('login'));
	    }
	}
        
        public function client()
	{
		$data['list']=$this->programs_model->get_data($this->uri->segment(3));
                $data['orgdetails']=$this->programs_model->get_orgDetails($this->uri->segment(3));
                
		if($this->session->userdata('email')){ 
		if($this->input->post()){
                     $this->form_validation->set_rules('prg_name', 'Program Name', 'trim|required');
			if ($this->form_validation->run() == TRUE) {
				$data = array(
				'prg_name' => $this->input->post('prg_name'),
                                'org_id' => $this->input->post('org_id')
                                        
				);
			$this->programs_model->addprogram($data);
			$this->session->set_flashdata('notification', 'Added successfully');
			redirect('programs/client/'.$this->input->post('org_id'),'refresh'); 
			} else {
			 $this->load->view('programs', $data);
			}
		}else{
			$this->load->view('programs', $data);	
		}
	    }
	    else{
	    	redirect(base_url('login'));
	    }
	}
	
	public function edit(){
		if($this->input->post()){
			$data=$this->programs_model->editprogram($this->input->post());
		  if(!empty($data)){
		  	echo json_encode($data);
		  }else{
		  	echo "";
		  }
		}else{
			echo "";
		}
	}

	public function update(){
		if($this->input->post()){
		  if($this->programs_model->updateprogram($this->input->post())){
		  $this->session->set_flashdata('notification', 'updated successfully');
//                  var_dump($this->uri->segment(2),$this->uri->segment(3),$this->uri->segment(4));die;
                  if($this->uri->segment(3) == 'client' ){
			redirect('programs/client/'.$this->uri->segment(4),'refresh'); 
                  }else{
                      redirect('programs/aggregator/'.$this->uri->segment(4),'refresh'); 
                  }
		  }else{
		  $this->session->set_flashdata('notification', 'Not updated');
			if($this->uri->segment(3) == 'client' ){
			redirect('programs/client/'.$this->uri->segment(4),'refresh'); 
                  }else{
                      redirect('programs/aggregator/'.$this->uri->segment(4),'refresh'); 
                  }
		  }
		}else{
			echo "";
		}
	}

	public function delete(){
		if($this->uri->segment(3)){
		  if($this->programs_model->deleteprogram($this->uri->segment(3))){
		  $this->session->set_flashdata('notification', 'updated successfully');
		if($this->uri->segment(4) == 'client' ){
			redirect('programs/client/'.$this->uri->segment(5),'refresh'); 
                  }else{
                      redirect('programs/aggregator/'.$this->uri->segment(5),'refresh'); 
                  }
		  }else{
		  $this->session->set_flashdata('notification', 'Not updated');
		if($this->uri->segment(4) == 'client' ){
			redirect('programs/client/'.$this->uri->segment(5),'refresh'); 
                  }else{
                      redirect('programs/aggregator/'.$this->uri->segment(5),'refresh'); 
                  }
		  }
		}else{
			echo "";
		}
	}
}

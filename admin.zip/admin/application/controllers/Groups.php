<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Groups extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
        $this->load->model(array('group_model', 'user_details_model'));
        if (!$this->session->userdata('email')) {
            redirect('login');
        }
    }

    public function index($org_id=0)
    {
        if($_SESSION["role"] !== 'super_admin') {
            $org_id = $_SESSION["org_id"];
        }
        $data['org_id'] = $org_id;
        $data['roles'] = $roles;
        if($_SESSION["role"] == 'group_admin') {
            $groups = $this->group_model->get_groups($org_id);
            $usergroups = unserialize($_SESSION["group_ids"]);
            $data['list'] = [];
            foreach ($groups as $key => $value) {
                if(in_array($value->id, $usergroups)) {
                    $data['list'][] = $value;
                }
            }
        } else {
            $data['list'] = $this->group_model->get_groups($org_id);
        }
        
        $data['organizations'] = $this->group_model->get_organizations();

        $this->load->view('groups_list', $data);
    }

    public function addedit($org_id, $id = 0)
    {
        $loggedInUser = $this->user_details_model->get_admin_by_email($this->session->userdata('email'));
        if($id > 0) {
            $groupdetails = $this->group_model->get_details($id);
            $data['name'] = $groupdetails->group_name;
            $data['description'] = $groupdetails->description;
            $data['status'] = $groupdetails->status;
            $data['id'] = $groupdetails->id;
			$data['batch'] = $groupdetails->batch_no;
			$data['startdate'] = $groupdetails->training_startdate;
			$data['enddate'] = $groupdetails->training_enddate;
			$data['starttime'] = $groupdetails->training_starttime;
			$data['endtime'] = $groupdetails->training_endtime;
			$data['location'] = $groupdetails->training_location;
			
			$data['module'] = $groupdetails->module_type;
			
        }
		
        if ($this->session->userdata('email')) {
            $data['organization_id'] = $this->input->get_post('organization_id');
            if ($org_id != 'undefined' && $org_id != '') {
                $data['org_id'] = $org_id;
            } else {
                $data['org_id'] = 1;
            }
            
            $data['organizations'] = $this->group_model->get_organizations($loggedInUser->id);
            
            $data['users_list'] = $this->group_model->get_all_users_list($org_id);
            $data['usersa_list'] = $this->group_model->get_users_list($id);
            
            $data['adminsa_list'] = $this->group_model->get_admins_list($id);
            
            $data['kc_a_list'] = $this->group_model->get_all_kc_a_list();
            $data['kc_c_list'] = $this->group_model->get_all_kc_c_list($org_id);
            $data['kca_a_list'] = $this->group_model->get_all_kca_a($id);
            $data['kca_c_list'] = $this->group_model->get_all_kca_c($id);

            $data['idp_a_list'] = $this->group_model->get_all_idp_a_list();
            $data['idp_c_list'] = $this->group_model->get_all_idp_c_list($org_id);
            $data['idpa_a_list'] = $this->group_model->get_all_idpa_a($id);
            $data['idpa_c_list'] = $this->group_model->get_all_idpa_c($id);

            $data['programs']= json_encode($this->group_model->get_all_programs());
            
            if ($this->input->post()) {
                $this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[1]|max_length[40]');
                $this->form_validation->set_rules('description', 'Description', 'trim');
                $this->form_validation->set_rules('status', 'Status', 'trim|required|min_length[1]|max_length[10]');
                $this->form_validation->set_rules('organization_id', 'organization_id', 'trim|required');

                if ($this->form_validation->run() == true) {
                    $data1 = $this->input->post();
                    $data1['user_id'] = $loggedInUser->id;
                    $data1['org_id'] = $org_id;
                    $data1['id'] = $id;
                    $this->group_model->adddetail($data1);
                    $this->session->set_flashdata('notification', 'Group saved successfully');

                    redirect('groups/index/' . $this->uri->segment(3), 'refresh');
                } else {
                    echo validation_errors();
                    $this->load->view('groups_addedit', $data);
                    return;
                }
            }
            $this->load->view('groups_addedit', $data);
        } else {
            redirect(base_url('login'));
        }
    }

    public function get_already_selected_value($id){
        echo json_encode($this->group_model->get_all_idp_programs($id));
    }

    public function export()
    {
        if ($this->input->post()) {
            $data = $this->input->post('user');
            $this->group_model->export_event($data);
        } else {
            $data['user'] = $this->group_model->get_user();
            $this->load->view('export_kc', $data);
        }
    }

    public function edit()
    {
        if ($this->input->post()) {
            $data = $this->group_model->editprogram($this->input->post());
            if (!empty($data)) {
                echo json_encode($data);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function update()
    {
        if ($this->input->post()) {
            if ($this->group_model->updateprogram($this->input->post())) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('groups', 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('groups', 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function delete()
    {
        if ($this->uri->segment(3)) {
            if ($this->group_model->deleteprogram($this->uri->segment(3))) {
                $this->session->set_flashdata('notification', 'Group deleted successfully');
                redirect('groups/index', 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not deleted');
                redirect('groups/index', 'refresh');
            }
        } else {
            echo "";
        }
    }

    /* Attributes -start */

    public function attributes($id)
    {
        if ($id != null) {
            $data['kc'] = $this->group_model->get_details($id);
            $data['list'] = $this->group_model->get_attributes($id);

            return $this->load->view('competency_attributes', $data);
        } else {
            redirect('groups', 'refresh');
        }
    }

    public function addattribute($id)
    {
        if ($id != null) {
            $data['kc'] = $this->group_model->get_details($id);
            $data['list'] = $this->group_model->get_attributes($id);

            if (!empty($data['kc'])) {
                if ($this->input->post()) {
                    $this->form_validation->set_rules('attr_name', 'Title', 'trim|required');
                    //$this->form_validation->set_rules('attr_desc', 'Title', 'trim|required');
                    if ($this->form_validation->run() == true) {
                        $data1 = $this->input->post();
                        unset($data1['submit']);
                        if ($data = $this->group_model->add_attribute($data1, $id)) {
                            $this->session->set_flashdata('notification', 'Added successfully');
                            redirect('groups/attributes/' . $id, 'refresh');
                        } else {
                            $this->session->set_flashdata('notification', 'Not Added.Try again later');
                            redirect('groups/attributes/' . $id, 'refresh');
                        }
                    } else {
                        $this->load->view('competency_attributes', $data);
                    }
                } else {
                    $this->load->view('competency_attributes', $data);
                }
            } else {
                redirect('groups/attributes/' . $id, 'refresh');
            }
        } else {
            redirect('groups', 'refresh');
        }
    }

    public function editattribute()
    {

        if ($this->input->post()) {
            $data = $this->group_model->get_attribute($this->input->post('id'));
            if (!empty($data)) {
                echo json_encode($data);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function updateattribute()
    {
        if ($this->input->post()) {
            $data = $this->group_model->get_attribute($this->input->post('id'));
            if (!empty($data)) {
                $data1 = $this->input->post();
                unset($data1['submit']);
                if ($this->group_model->update_attribute($data1)) {
                    $this->session->set_flashdata('notification', 'updated successfully');
                    redirect('groups/attributes/' . $data1['competency_id'], 'refresh');
                }
            }
            $this->session->set_flashdata('notification', 'Not updated');
            redirect('groups', 'refresh');
        } else {
            echo "";
        }
    }

    public function deleteattribute($id)
    {
        if ($id) {
            $data = $this->group_model->get_attribute($id);
            if (!empty($data)) {
                if ($this->group_model->delete_attribute($id)) {
                    $this->session->set_flashdata('notification', 'deleted successfully');
                    redirect('groups/attributes/' . $data->competency_id, 'refresh');
                }
            }
            $this->session->set_flashdata('notification', 'Not deleted');
            redirect('groups/attributes/' . $data->competency_id, 'refresh');
        } else {
            echo "";
        }
    }

    /* Attributes -end */

    /* Modules -start */

    public function modules($id)
    {
        $data['mdllist'] = $this->group_model->get_moduleslist();
        $data['levels'] = [0 => 'Basic', 1 => 'Intermediate', 2 => 'Expert'];

        if ($id != null) {
            $data['kc'] = $this->group_model->get_details($id);
            $data['list'] = $this->group_model->get_modules($id);

            /*foreach($data['list'] as $k => $v) {
            foreach ($data['mdllist'] as $key => $value) {
            if($value->prg_id == $v->cmdl_kc_id) {
            unset($data['mdllist'][$key]);
            }
            }
            }*/

            return $this->load->view('competency_modules', $data);
        } else {
            redirect('groups', 'refresh');
        }
    }

    public function addmodule($id)
    {
        if ($id != null) {
            $data['kc'] = $this->group_model->get_details($id);
            $data['list'] = $this->group_model->get_modules($id);
            if (!empty($data['kc'])) {
                if ($this->input->post()) {
                    $this->form_validation->set_rules('cmdl_level', 'Level', 'trim|required');
                    $this->form_validation->set_rules('cmdl_kc_id', 'Module', 'trim|required');
                    if ($this->form_validation->run() == true) {
                        $data1 = $this->input->post();
                        unset($data1['submit']);
                        if ($data = $this->group_model->add_module($data1, $id)) {
                            $this->session->set_flashdata('notification', 'Added successfully');
                            redirect('groups/modules/' . $id, 'refresh');
                        } else {
                            $this->session->set_flashdata('notification', 'Not Added.Try again later');
                            redirect('groups/modules/' . $id, 'refresh');
                        }
                    } else {
                        $this->load->view('competency_modules', $data);
                    }
                } else {
                    $this->load->view('competency_modules', $data);
                }
            } else {
                redirect('groups/modules/' . $id, 'refresh');
            }
        } else {
            redirect('groups', 'refresh');
        }
    }

    public function editmodule()
    {
        if ($this->input->post()) {
            $data = $this->group_model->get_module($this->input->post('id'));
            if (!empty($data)) {
                echo json_encode($data);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function updatemodule()
    {
        if ($this->input->post()) {
            $data = $this->group_model->get_module($this->input->post('id'));
            if (!empty($data)) {
                $data1 = $this->input->post();
                unset($data1['submit']);
                if ($this->group_model->update_module($data1)) {
                    $this->session->set_flashdata('notification', 'updated successfully');
                    redirect('groups/modules/' . $data1['cmdl_c_id'], 'refresh');
                }
            }
            $this->session->set_flashdata('notification', 'Not updated');
            redirect('groups', 'refresh');
        } else {
            echo "";
        }
    }

    public function deletemodule($id)
    {
        if ($id) {
            $data = $this->group_model->get_module($id);
//                        var_dump($data);die;
            if (!empty($data)) {
                if ($this->group_model->delete_module($id)) {
                    $this->session->set_flashdata('notification', 'deleted successfully');
                    redirect('groups/modules/' . $data->cmdl_c_id, 'refresh');
                }
            }
            $this->session->set_flashdata('notification', 'Not deleted');
            redirect('groups/modules/' . $data->cmdl_c_id, 'refresh');
        } else {
            echo "";
        }
    }

    /* Modules -end */

    /* AttrModules -start */

    public function attrmodules($id)
    {
        $data['mdllist'] = $this->group_model->get_moduleslist();
        $data['levels'] = [0 => 'Basic', 1 => 'Intermediate', 2 => 'Expert'];

        if ($id != null) {
            $data['kc'] = $this->group_model->get_attribute($id);
            $data['list'] = $this->group_model->get_attrmodules($id);

            return $this->load->view('competency_attrmodules', $data);
        } else {
            redirect('groups', 'refresh');
        }
    }

    public function addattrmodule($id)
    {
        if ($id != null) {
            $data['kc'] = $this->group_model->get_attribute($id);
            $data['list'] = $this->group_model->get_attrmodules($id);
            if (!empty($data['kc'])) {
                if ($this->input->post()) {
                    $this->form_validation->set_rules('camdl_ca_id', 'Level', 'trim|required');
                    $this->form_validation->set_rules('camdl_kc_id', 'Module', 'trim|required');
                    if ($this->form_validation->run() == true) {
                        $data1 = $this->input->post();
                        unset($data1['submit']);
                        if ($data = $this->group_model->add_attrmodule($data1, $id)) {
                            $this->session->set_flashdata('notification', 'Added successfully');
                            redirect('groups/attrmodules/' . $id, 'refresh');
                        } else {
                            $this->session->set_flashdata('notification', 'Not Added.Try again later');
                            redirect('groups/attrmodules/' . $id, 'refresh');
                        }
                    } else {
                        $this->load->view('competency_attrmodules', $data);
                    }
                } else {
                    $this->load->view('competency_attrmodules', $data);
                }
            } else {
                redirect('groups/attrmodules/' . $id, 'refresh');
            }
        } else {
            redirect('groups', 'refresh');
        }
    }

    public function editattrmodule()
    {
        if ($this->input->post()) {
            $data = $this->group_model->get_attrmodule($this->input->post('id'));
            if (!empty($data)) {
                echo json_encode($data);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function updateattrmodule()
    {
        if ($this->input->post()) {
            $data = $this->group_model->get_attrmodule($this->input->post('id'));
            if (!empty($data)) {
                $data1 = $this->input->post();
                unset($data1['submit']);
                if ($this->group_model->update_attrmodule($data1)) {
                    $this->session->set_flashdata('notification', 'updated successfully');
                    redirect('groups/attrmodules/' . $data1['camdl_ca_id'], 'refresh');
                }
            }
            $this->session->set_flashdata('notification', 'Not updated');
            redirect('groups', 'refresh');
        } else {
            echo "";
        }
    }

    public function deleteattrmodule($id)
    {
        if ($id) {
            $data = $this->group_model->get_attrmodule($id);
            if (!empty($data)) {
                if ($this->group_model->delete_attrmodule($id)) {
                    $this->session->set_flashdata('notification', 'deleted successfully');
                    redirect('groups/attrmodules/' . $data->camdl_ca_id, 'refresh');
                }
            }
            $this->session->set_flashdata('notification', 'Not deleted');
            redirect('groups/attrmodules/' . $data->camdl_ca_id, 'refresh');
        } else {
            echo "";
        }
    }

    /* Modules -end */
}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Editbanner extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
        $this->load->model('editbanner_model');
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		 if($this->session->userdata('email')){
		 $id = $this->uri->segment(2);
		  
		$data['row']=$this->editbanner_model->get_data($id);
		$this->load->view('editbanner', $data);
	}
	else{
		redirect('login');
	}
	}
	
	
	public function update_user()
	{
		 $id = $this->input->post('id');
		 $data = array(
		 	'uploadimage' => $this->input->post('bannerimg'),
			  	'imagelink' => $this->input->post('imagelink'),
			  	
		 	);
		  
	 
		  $this->editbanner_model->update_data($data , $id);
		  redirect('update_banner_images');
	}
	
	public function edituser()
	{
		$id = $this->input->post('id');
	 		
		 $this->load->view('editbanner');
		  
		$data = array(
		 	'uploadimage' => $this->input->post('bannerimg'),
			  	'imagelink' => $this->input->post('imagelink'),
			  	
		 	);

		  $this->editbanner_model->update_data($data , $id);
		  redirect('update_banner_images');
		 
	}
}

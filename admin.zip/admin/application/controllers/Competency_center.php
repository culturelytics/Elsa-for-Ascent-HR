<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class competency_center extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
         $this->load->helper(array('form', 'url'));     
         $this->load->library('session');
         $this->load->model('competency_center_model');
         if(!$this->session->userdata('email')){ 
         	redirect('competency_center');
         }
    }

	public function index()
	{
		//echo "Sdfsdf";
		$data['list']=$this->competency_center_model->get_data();

		if($this->session->userdata('email')){ 
		if($this->input->post()){
	 		$this->form_validation->set_rules('prg_name', 'Program Name', 'trim|required');
			if ($this->form_validation->run() == TRUE) {
				$data = array(
				'prg_name' => $this->input->post('prg_name')
				);
			$this->competency_center_model->addprogram($data);
			$this->session->set_flashdata('notification', 'Added successfully');
			redirect('competency_center','refresh'); 
			} else {
			 $this->load->view('competency_center', $data);
			}
		}else{
			$this->load->view('competency_center', $data);	
		}
	    }
	    else{
	    	redirect(base_url('login'));
	    }
	}

	public function export()
	{
		if($this->input->post()){
		 $data=$this->input->post('user');
		 $this->competency_center_model->export_event($data);	
		}else{
			$data['user']=$this->competency_center_model->get_user();
			$this->load->view('export_kc', $data);
		}
	}
	
public function edit(){
		if($this->input->post()){
			$data=$this->competency_center_model->editprogram($this->input->post());
		  if(!empty($data)){
		  	echo json_encode($data);
		  }else{
		  	echo "";
		  }
		}else{
			echo "";
		}
	}

	public function update(){
		if($this->input->post()){
		  if($this->competency_center_model->updateprogram($this->input->post())){
		  $this->session->set_flashdata('notification', 'updated successfully');
			redirect('competency_center','refresh'); 
		  }else{
		  $this->session->set_flashdata('notification', 'Not updated');
			redirect('competency_center','refresh'); 
		  }
		}else{
			echo "";
		}
	}

	public function delete(){
		if($this->uri->segment(3)){
		  if($this->competency_center_model->deleteprogram($this->uri->segment(3))){
		  $this->session->set_flashdata('notification', 'updated successfully');
			redirect('competency_center','refresh'); 
		  }else{
		  $this->session->set_flashdata('notification', 'Not updated');
			redirect('competency_center','refresh'); 
		  }
		}else{
			echo "";
		}
	}


	public function add_attribute(){
		if($this->uri->segment(3)){
			$kc=$this->competency_center_model->editprogram(array('pid'=>$this->uri->segment(3)));
			$k_list=$this->competency_center_model->get_list($this->uri->segment(3));
		  if(!empty($kc)){
		  	if($this->input->post()){

			  	$data['kc']=$kc;
			  	$this->form_validation->set_rules('kc_title_old', 'Title', 'trim|required');
			  	/*$this->form_validation->set_rules('kc_content_old', 'Content', 'trim|required');*/
				if ($this->form_validation->run() == TRUE) {
					$data1=$this->input->post();
		  			if($this->competency_center_model->add_attribute($data1,$this->uri->segment(3))){
			  			$this->session->set_flashdata('notification', 'Added successfully');
						redirect('competency_center','refresh'); 
		  			}else{
			  			$this->session->set_flashdata('notification', 'Not Added.Try again later');
						redirect('competency_center','refresh'); 
		  			}
		  		}else{
		  			$this->load->view('add_cc_content', $data);
		  		}
		  	}else{
                            $data['kc']=$kc;
                            $data['list']=$k_list;
                            $this->load->view('add_cc_content', $data);
		  	}
		  }else{
		  	redirect('competency_center','refresh'); 
		  }
		}else{
			redirect('competency_center','refresh'); 
		}
	}



	public function list_all_image()
	{
		if($this->uri->segment(3)){
		$kc=$this->competency_center_model->editprogram(array('pid'=>$this->uri->segment(3)));
		$kcimage=$this->competency_center_model->get_image($this->uri->segment(3));
		if(!empty($kc)){
		if($this->input->post()){
			$error="";
	 			$this->form_validation->set_rules('img_title', 'Title of image', 'trim|required');
	 			$this->form_validation->set_rules('img_link', 'Link of image', 'trim|required');
	 			$error="";
	 			$new_name = time().$_FILES["img_name"]['name'];
                $config['upload_path']          = './uploads/content_images';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 51200;
                $config['max_width']            = 1024;
                $config['max_height']           = 1024;
                 $config['min_width']           = 50;
                $config['min_height']           = 50;
                $config['file_name']           = $new_name;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if ( ! $this->upload->do_upload('img_name'))
                {
                        $data['error'] = array('error' => $this->upload->display_errors());
                        $error="error";
                }else
                {
                $uploadData = $this->upload->data();
                $picture = $uploadData['file_name'];
                }
			if ($this->form_validation->run() == TRUE && $error=='') {
				$data = array(
				'img_title' => $this->input->post('img_title'),
				'img_link' => $this->input->post('img_link'),
				'img_name' => $picture,
				'img_kc_id' => $this->uri->segment(3),
				);
			$this->competency_center_model->add_image_content($data);
			$this->session->set_flashdata('notification', 'Added successfully');
			redirect('competency_center/list_all_image/'.$this->uri->segment(3),'refresh'); 
			} else {
				if(isset($picture)){
					$file='./uploads/content_images/'.$picture;
					unlink($file);
				}
			 $data['kc']=$kc;
			 $data['kcimage']=$kcimage;

			 $this->load->view('add_image_content', $data);
			}
		}else{
			 $data['kc']=$kc;
			 $data['kcimage']=$kcimage;
			 $this->load->view('add_image_content', $data);	
		}
	  }else{
	  	
	  		redirect('competency_center','refresh'); 
	  }
	}else{
		
		redirect('competency_center','refresh'); 
	}
	   
	}
	
	public function edit_image(){

		if($this->input->post()){
			$data=$this->competency_center_model->edit_image($this->input->post());
		  if(!empty($data)){
		  	echo json_encode($data);
		  }else{
		  	echo "";
		  }
		}else{
			echo "";
		}
	}

	public function update_image($id){
		if($this->input->post()){
		 	$picture='';
		  	if($_FILES["prg_image"]['name']!=''){
		  		$new_name = time().$_FILES["img_name"]['name'];
                $config['upload_path']          = './uploads/content_images';
                $config['allowed_types']        = 'gif|jpg|png|jpeg';
                $config['max_size']             = 51200;
                $config['max_width']            = 1024;
                $config['max_height']           = 1024;
                 $config['min_width']           = 50;
                $config['min_height']           = 50;
                $config['file_name']           = $new_name;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if ( ! $this->upload->do_upload('prg_image'))
                {
                        $data['error'] = array('error' => $this->upload->display_errors());
                        $error="error";                    
                }else
                {
                $uploadData = $this->upload->data();
                $picture = $uploadData['file_name'];
                }
		  	}
		  		
		  	if($picture!=''){
		  		$data=array(
		  			'img_name'=>$picture,
		  			'img_title'=>$this->input->post('prg_name1'),
		  			'img_link'=>$this->input->post('img_link1'),
		  			);
		  	}else{
		  		$data=array(
		  			'img_title'=>$this->input->post('prg_name1'),
		  			'img_link'=>$this->input->post('img_link1'),
		  			);
		  	}

		  if($this->competency_center_model->update_image($data,$this->input->post('prg_id1'))){
		  	$this->session->set_flashdata('notification', 'updated successfully');
			redirect('competency_center/list_all_image/'.$id,'refresh'); 
		
		  }else{
		  $this->session->set_flashdata('notification', 'Not updated');
			redirect('competency_center/list_all_image/'.$id,'refresh'); 
		  }
		}else{
			echo "";
		}
	}

		public function delete_image(){
		if($this->uri->segment(3)){
		  if($this->competency_center_model->delete_image($this->uri->segment(3))){
		  $this->session->set_flashdata('notification', 'updated successfully');
			redirect('competency_center/list_all_image/'.$this->uri->segment(4),'refresh'); 
		  }else{
		  $this->session->set_flashdata('notification', 'Not updated');
			redirect('competency_center/list_all_image/'.$this->uri->segment(4),'refresh'); 
		  }
		}else{
			redirect('competency_center');
		}
	}






}

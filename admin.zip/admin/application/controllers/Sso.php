<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Sso extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
         $this->load->helper(array('form', 'url'));
         $this->load->library('upload');
         $this->load->library('session');
         $this->load->model('user_details_model');
		 $this->load->model('login1_model');
         /*if(!$this->session->userdata('email')){ 
         	redirect(base_url('login'));
		 }*/
		 
    }

	public function index()
	{
		$msg = ""; $_SERVER['QUERY_STRING']; parse_str(($_SERVER['QUERY_STRING']), $getData); $userkey = $getData['key'];
		
		$loggedInUser = $this->user_details_model->get_admin_by_email($this->session->userdata('email'));
		
		if($this->session->userdata('email') && $this->session->userdata('email') == $this->input->get_post('email_id')){
			redirect('dashboard');
		}else {
			
			$path = str_replace('\admin','',FCPATH);
			$path = str_replace('/admin','',$path);

			require_once($path . "lib/aesencrypt.php");
			
			$plaintext = getDecrypt($_GET['key']);
			parse_str(($plaintext), $request);

			// print_r($request);
			// die;

			$data['email']=$request['email_id'];
			$data['name']=$request['first_name'];
			$data['last_name']=$request['last_name'];
			$data['contact']=$request['contact_number'];
			$data['gender']=$request['gender'];
			$data['linkedin']=$request['linkedin'];
			$data['twitter']=$request['twitter'];
			$data['organization_code']=$request['organization_id'];
			$data['organization_name']=$request['organization_name'];
			$data['industry_code']=$request['industry_id'];
			$data['industry_name']=$request['industry_name'];
			$redirect_url = $request['redirectto'];
			$data['password'] = rand(10001, 99999);

			$data['industry_id'] = '';
			$data['organization_id'] = '';

			// print_r($data); die;

			$confirm_password1 = '';
			$val_name = "";
			$val_email = "";
			$val_password = "";
			$val_contact = "";
			$val_last_name = "";
			$val_age = "";
			$val_gender = "";
			$val_confirm_password = "";
			$val_confirm_password1 = "";
			$val_organization = "";
			if ($data['name'] == '') {
				$val_name = "First name is required";
			}
			if ($data['email'] == '') {
				$val_email = "Email is required";
			}
			if ((!filter_var($data['email'], FILTER_VALIDATE_EMAIL))) {
				$val_email = "Invalid Email";
			}
			/*if ($data['password'] == '') {
				$val_password = "Password is required";
			}
			if (!(strlen($data['password']) >= 4 && strlen($data['password']) <= 10)) {
				$val_password = "Password len is min 4 max 10";
			}*/
			/*if($confirm_password==''){
			$val_confirm_password="Confirm Password is required";
			}
			if($confirm_password!=$password){
			$val_confirm_password1="Password Mismatch";
			}*/
			if ($data['contact'] == '') {
				$val_contact = "Mobile Number is required";
			}
			if (!preg_match('/^[0-9]{10}+$/', $data['contact'])) {
				$val_contact = "Invalid Mobile Number";
			}
			if ($data['last_name'] == '') {
				$val_last_name = "Last name is required";
			}
			/*if($age==''){
				$val_age="Age is required";
			}*/
			$birth_date = null;
			if($data['date_of_birth'] !== null) {
				$dob = DateTime::createFromFormat('d/m/Y', $data['date_of_birth']);
				$birth_date = $dob->format('Y-m-d');
			}
			if ($data['gender'] == '') {
				$val_gender = "Gender is required";
			}
			if ($data['industry_code'] == '' || $data['industry_name'] == '') {
				$val_organization = "Industry is required";
			}
			if ($data['organization_code'] == '' || $data['organization_name'] == '') {
				$val_organization = "Organization is required";
			}
			/*if($organization==''){
			$val_organization="Organization is required";
			}*/
		
			//$val_twitter = $data['twitter'];
			//$val_linkedin = $data['linkedin'];
			
			if ($data['industry_code'] !== '' && $data['industry_name'] !== '') {
				$row = $this->db->query("select  * from tbl_industry where ind_code = '".$data['industry_code']."'")->row_array();

				if ($row !== null) {
					$data['industry_id'] = $row['id'];
					if($row['ind_name'] != $data['industry_name']) {
						$setqr = "update tbl_industry set ind_name = '".$data['industry_name']."' where id = ". $row['id'];
						$res = $this->db->query($setqr);
						if($res !== null){
						}
					}
				} else {
					$setqr = "insert into tbl_industry (ind_name, ind_code) values ('".$data['industry_name']."', '". $data['industry_code'] . "')";
					$res = $this->db->query($setqr);
					if($res !== null){
						$data['industry_id'] = $this->db->insert_id();
					}
				}
			} else {
				$val_industry = "Industry is required";
			}
			
			if ($data['organization_code'] !== '' && $data['organization_name'] !== '') {
				$row = $this->db->query("select  * from tbl_organization where org_code = '".$data['organization_code']."'")->row_array();

				if ($row !== null) {
					$data['organization_id'] = $row['id'];
					if($row['org_name'] !== $data['organization_name'] || $row['industry_id'] != $data['industry_id']) {
						$setqr = "update tbl_organization set org_name = '".$data['organization_name']."', industry_id = '".$data['industry_id']."' where id = ". $row['id'];
						$res = $this->db->query($setqr);
						if($res !== null){
						}
					}
				} else {
					$setqr = "insert into tbl_organization (org_name, org_code, industry_id) values ('".$data['organization_name']."', '". $data['organization_code'] . "', ". $data['industry_id'] . ")";
					$res = $this->db->query($setqr);
					if($res !== null){
						$data['organization_id'] = $this->db->insert_id();
					}
				}
			}
			else {
				$val_organization = "Organization is required";
			}
			
			if ($data['email'] != '') {
				$rowcount = $this->db->query("select * from tbl_admin where email='" . $data['email'] . "'")->row();
				if ($rowcount !== null) {
					$val_email = "E-mail id is already registered";
				}
			}

			$queryorg = "SELECT * FROM `tbl_admin` ";
			//$queryorg .= " INNER JOIN `tbl_organization` ON `tbl_organization`.`id` = `tbl_admin`.`organization_id` ";
			$queryorg .= " WHERE `tbl_admin`.`email` = '".$data['email']."' AND `tbl_admin`.`status` = 'active'; ";
			$row = $this->db->query($queryorg)->row_array();
			
			if ($row !== null) {
				$setqr = '';
				// TODO - check organization change
				// birth date, age ?
				if ($row['organization_id'] != $data['organization_id']) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_admin`.`organization_id` = ' . $data['organization_id'];
				}
				if ($row['username'] != $data['name']) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_admin`.`username` = \'' . $data['name'] . '\'';
				}
				if ($row['last_name'] != $data['last_name']) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_admin`.`last_name` =  \'' . $data['last_name'] . '\'';
				}
				if (strtolower($row['gender']) != strtolower($data['gender'])) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_admin`.`gender` =  \'' . strtolower($data['gender']) . '\'';
				}
				if($birth_date !== null) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_admin`.`birth_date` =  \'' . $birth_date . '\'';
				}
				
				if ($setqr != '') {
					$setqr = "UPDATE `tbl_admin` SET " . $setqr . " WHERE `tbl_admin`.`email` = '".$data['email']."'; ";
					
					// update fields and login automatically
					$res = $this->db->query($setqr);
					if($res !== null){
					}
				}
				// TODO - password encrypted
				return $this->login($data['email'], $row['password'], $redirect_url);
			} else {
				//var_dump($val_name,$val_email,$val_password,$val_contact,$val_last_name,$val_age,$val_gender,$val_confirm_password1,$val_confirm_password);
				//die;
				if ($val_name == "" && $val_email == "" && $val_contact == "" && $val_last_name == "" && $val_gender == "" && $val_industry == "" && $val_organization == "") {
					// register and login automatically
					$setqr2 = "INSERT INTO `tbl_admin`( `username`, `email`, `password`, `role`, `contact`,  `last_name`, `gender`, `linkedin`, `twitter`,`status`,`organization_id`) VALUES ('".$data['name']."'
					, '".$data['email']."', '".$data['password']."', 'super_admin', '".$data['contact']."', '".$data['last_name']."', '".$data['gender']."', '".$data['linkedin']."', '".$data['twitter']."','active',".$data['organization_id'].")";
					
					$res2 = $this->db->query($setqr2);
					//var_dump($setqr2, mysqli_affected_rows($dbconnect));

					if($res2 !== null){
						$this->login($data['email'],$data['password'], $redirect_url);
						//loginwithemail($data['email'],$data['password']);
					} else {
						$msg = '<div class="alert alert-warning text-center">Invalid request!</div>';
					}
				} else {
					$msg = '<div class="alert alert-warning text-center">Invalid request!</div>';
				}
			}
		}
		
		$this->load->view('sso_index', $msg);
	}

	public function login($email, $password, $redirect_url){
		// Load the model
		// Validate the user can login
		if($this->session->userdata('email')){
		  redirect('');
		}
		 //$email = $this->security->xss_clean($this->input->post('email'));
		 //$password = $this->security->xss_clean($this->input->post('password'));

		$logininfo = array('email' => $email, 'password' => $password);


		$result = $this->login1_model->validate($logininfo);
		
		// Now we verify the result
		if(!$result){
			// If user did not validate, then show them login page again
			$msg = '<font color=red>Invalid username and/or password.</font><br />';
			$this->index($msg);
		}
		else{
			$this->session->set_userdata('redirect_url', $redirect_url);
			// If user did validate, 
			// Send them to members area
			redirect(base_url());
		}        
	}
}

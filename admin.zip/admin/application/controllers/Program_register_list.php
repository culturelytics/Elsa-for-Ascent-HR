<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Program_register_list extends CI_Controller {
public function __construct()
    {
        parent::__construct();
        $this->load->model('user_details_model');
    }
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	     if($this->session->userdata('email')){
			if($_SESSION['role'] === 'super_admin') { 
				$data['list']=$this->user_details_model->get_program();
				$this->load->view('program_register_list', $data);
			}else{
				
				redirect('dashboard/index', 'refresh');
			}
	}
	else{
		redirect('login');
	}
	}
}

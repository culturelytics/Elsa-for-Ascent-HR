<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mis_tracker extends CI_Controller {
public function __construct()
    {
        parent::__construct();
        $this->load->model('mist_copy_model');
    }
	
	public function index()
	{
	    if($this->session->userdata('email')){
			$org_id=0; $users = array();
			if($_SESSION["role"] !== 'super_admin') {
				$org_id = $_SESSION["org_id"];
			}

			if( $_SESSION['role'] === 'group_admin') {
				// first fetch all group ids which are under current group admin
				$groupids =$this->mist_copy_model->get_grps($_SESSION['user_id']);
			
				// fetch all users of all group ids from above
				
				if(count($groupids) > 0){ 
					$groupMembers =$this->mist_copy_model->get_grpmembers($groupids);
					if(count($groupMembers) > 0){
						$users=array_column($groupMembers, 'user_id');
					}
				}	
				
			}
			// if($_SESSION['role'] === 'super_admin') { 
				$data['list']=$this->mist_copy_model->get_query($org_id, $users);


				$this->load->view('mist_view', $data);
			// }else{
			// 	redirect('dashboard/index', 'refresh');
			// }
	}
	else{
		redirect('login');
	}
	}
}

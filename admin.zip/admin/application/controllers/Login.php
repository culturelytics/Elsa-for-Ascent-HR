<?php

  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
  /* Author: Jorge Torres
  * Description: Login controller class
  */
  {
    class Login extends CI_Controller{

      function __construct(){
          parent::__construct();
          $this->load->model('login1_model');

      }


      public function index($msg = NULL){
          // Load our view to be displayed
          // to the user
		      if($this->config->item('ssoenabled')) {
            //TODO -  
          }

         if($this->session->userdata('email')){
            redirect('');
          }
          $data['msg'] = $msg;
          $this->load->view('login', $data);
          
      }
      
      public function logout()
      {
         // $this->session->unset_userdata('$data');
        $this->session->sess_destroy();
        redirect(base_url('login'));
      }

      public function process(){
          // Load the model
          // Validate the user can login
         if($this->session->userdata('email')){
            redirect('');
          }
           $email = $this->security->xss_clean($this->input->post('email'));
           $password = $this->security->xss_clean($this->input->post('password'));

           $logininfo = array('email' => $email, 'password' => $password);
           // print_r($logininfo);
           // exit();

          $result = $this->login1_model->validate($logininfo);
         
          // Now we verify the result
          if(! $result){
              // If user did not validate, then show them login page again
              $msg = '<font color=red>Invalid username and/or password.</font><br />';
              $this->index($msg);
          }
          else{
              // If user did validate, 
              // Send them to members area
              redirect(base_url());
          }        
      }
    }
  }
?>
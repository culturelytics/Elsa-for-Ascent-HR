<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Org_admins extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
        $this->load->model(array('org_model', 'user_details_model'));
        if (!$this->session->userdata('email')) {
            redirect('login');
        }
    }

    public function index()
    {
        $data['organizations'] = $this->org_model->get_organizations();
        $data['users_list'] = $this->org_model->get_users();
        $data['industry'] = $this->org_model->get_industry();
       

        $this->load->view('org_admins', $data);
    }

    public function addedit()
    {
        $org_id = $this->input->get_post('org_id');
        $loggedInUser = $this->user_details_model->get_admin_by_email($this->session->userdata('email'));
        $data['organizations'] = $this->org_model->get_organizations();
        $data['users_list'] = $this->org_model->get_users();
        $data['industry'] = $this->org_model->get_industry();
       
        if($id > 0) {
            $groupdetails = $this->group_model->get_details($id);
            $data['name'] = $groupdetails->name;
            $data['description'] = $groupdetails->description;
            $data['status'] = $groupdetails->status;
            $data['id'] = $groupdetails->id;
        }
		
        if ($this->session->userdata('email')) {
            if ($this->input->post()) {
                //$this->form_validation->set_rules('admins[]', 'admins', 'trim|required');
                $this->form_validation->set_rules('org_id', 'org_id', 'trim|required');

                if ($this->form_validation->run() == true) {
                    $data1 = $this->input->post();
                    $data1['user_id'] = $loggedInUser->id;
                    $data1['org_id'] = $org_id;
                    $data1['id'] = $id;
                    $this->org_model->adddetail($data1);
                    $this->session->set_flashdata('notification', 'Group saved successfully');

                    redirect('org_admins/index', 'refresh');
                } else {
                    echo validation_errors();
                    $this->load->view('org_admins/index', $data);
                    return;
                }
            }
            $this->load->view('org_admins/index', $data);
        } else {
            redirect(base_url('login'));
        }
    }

     public function update_org() {
         $this->org_model->update_org($this->input->post());
         $this->session->set_flashdata('notification', 'Organization Updated successfully!');
         redirect('org_admins/index', 'refresh');
     }
     public function add_org_inds() {
         $orgdata = $this->input->post();
         $this->org_model->add_org_inds($orgdata);
         $this->session->set_flashdata('notification', 'Organization Added successfully');
         redirect('org_admins/index', 'refresh');
     }
}

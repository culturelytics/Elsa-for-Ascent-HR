<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add_new_users extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
         $this->load->helper(array('form', 'url'));
         $this->load->library('upload');
         $this->load->library('session');
         $this->load->model('user_details_model');
         if(!$this->session->userdata('email')){ 
         	redirect(base_url('login'));
         }
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function users($id)
	{
		$loggedInUser = $this->user_details_model->get_admin_by_email($this->session->userdata('email'));
		if($this->session->userdata('email')){ 
		$data['organization_id']=$this->input->get_post('organization_id');
                if($id != 'undefined' && $id != ''){
                    $data['org_id'] = $id;
                }else{
                    $data['org_id'] = 1;
                }
                $role = $this->session->userdata('role'); $role_org = $this->session->userdata('org_id');
		if($role === 'org_admin' || $role === 'group_admin') {
			$data['org_id'] = $role_org;
		}
		$data['organizations']=$this->user_details_model->get_organizations($loggedInUser->id);
		$data['list']=$this->user_details_model->get_data($data['org_id']);
		$data['idp']=$this->user_details_model->get_all_idp();
		$data['idp_c']=$this->user_details_model->get_all_idp_c($id);
		$data['programs']= json_encode($this->user_details_model->get_all_programs());
		
		$data['kc_a_list']=$this->user_details_model->get_all_kc_a_list();
		$data['kc_c_list']=$this->user_details_model->get_all_kc_c_list($id);
		$data['kca_a_list']=$this->user_details_model->get_all_kca_a($id);
		$data['kca_c_list']=$this->user_details_model->get_all_kca_c($id);

		if($this->input->post()){
		$this->form_validation->set_rules('email', 'Email ID', 'trim|required|min_length[5]|max_length[40]|is_unique[tbl_user.email]');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[5]|max_length[40]');

		$this->form_validation->set_rules('name', 'Name', 'trim|required|min_length[1]|max_length[40]');
		$this->form_validation->set_rules('phone', 'Phone', 'trim|required|min_length[1]|max_length[10]');
		$this->form_validation->set_rules('kaccess', 'Access', 'trim|required|min_length[1]|max_length[10]');
		$this->form_validation->set_rules('kc_c_access', 'Access', 'trim|required|min_length[1]|max_length[10]');
		$this->form_validation->set_rules('access2', 'Access', 'trim|required|min_length[1]|max_length[10]');
		$this->form_validation->set_rules('idp_c_access', 'Access Client IDP', 'trim|required|min_length[1]|max_length[10]');
		$this->form_validation->set_rules('status', 'Status', 'trim|required|min_length[1]|max_length[10]');

		
		$this->form_validation->set_rules('status', 'last_name', 'trim|required');
		$this->form_validation->set_rules('status', 'age', 'trim|required');
		$this->form_validation->set_rules('status', 'gender', 'trim|required');
		$this->form_validation->set_rules('organization_id', 'organization_id', 'trim|required');
		
		
		if($this->input->post('access2')=='yes'){

		 	$this->form_validation->set_rules('idp[]', 'Programs Names', 'required');
		 	foreach ($this->input->post('idp') as $row) {
		 	$this->form_validation->set_rules('selected_'.$row.'[]', 'Modules Names', 'required');
		 	}
		 }

		 if($this->input->post('idp_c_access')=='yes'){
 
			  $this->form_validation->set_rules('idp_c[]', 'Programs Names', 'required');
			  foreach ($this->input->post('idp_c') as $row) {
			  $this->form_validation->set_rules('selected_c_'.$row.'[]', 'Modules Names', 'required');
			  }
		  }
		 if ($this->form_validation->run() == TRUE) {
                    $data1 = $this->input->post();
                    $this->user_details_model->adddetail($data1);
                    $this->session->set_flashdata('notification', 'New User Added successfully');
                    
                    redirect('add_new_users/users/' . $this->uri->segment(3), 'refresh');
		 } else {
                    echo validation_errors(); 
                    $this->load->view('add_new_user', $data);
                    return;
		 }
		}
		$this->load->view('add_new_user', $data);
	    }
	    else{
	    	redirect(base_url('login'));
	    }
	}
		
		public function get_already_selected_value($id){
			echo json_encode($this->user_details_model->get_all_idp_programs($id));
		}

	
	public function update_user()
	{
		 $id = $this->input->post('id');
		 $noSpacespwd = str_replace(' ', '', $this->input->post('password'));
		 
		 $data = array(
		 	'email' => $this->input->post('email'),
			  	'name' => $this->input->post('name'),
			  	'password' => $noSpacespwd,
			 	'contact' => $this->input->post('phone'),
			 	'status' => $this->input->post('status'),
			 	'kaccess' => $this->input->post('kaccess'),
			 	'caccess' => $this->input->post('caccess'),
		 	);
		  $this->user_details_model->update_data($data , $id);
		  $this->session->set_flashdata('updatenotification', 'User updated successfully');
		   redirect('add_new_users/users/' . $this->uri->segment(3), 'refresh');
	}
	public function delete()
	{
		  
		 $id2 = $this->uri->segment(3);
		  $this->user_details_model->deletee($id2);
		  $this->session->set_flashdata('deletenotification', 'User deleted successfully');
                  redirect('add_new_users/users/' . $this->uri->segment(4), 'refresh');
	}
	public function edituser()
	{
		 $this->load->view('edit_user');
		  $id = $this->input->post('id');
                 
		 $data = array(
		 	'email' => $this->input->post('email'),
			  	'name' => $this->input->post('name'),
			  	'password' => $this->input->post('password'),
			 	'contact' => $this->input->post('phone'),
			 	'status' => $this->input->post('status'),
			 	'caccess' => $this->input->post('access2'),
			 	'kaccess' => $this->input->post('access1'),
		 	);

		  $this->user_details_model->update_data($data , $id);
		   redirect('add_new_users/users/' . $this->uri->segment(4), 'refresh');
		 
	}
}

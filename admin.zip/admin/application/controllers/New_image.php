<?php
class New_image extends CI_Controller {
public function __construct()
    {
            parent::__construct();
    
            $this->load->library('upload');
            $this->load->model('update_banner_images_model');
    }

    public function index()
    {
          // $data['list']=$this->update_banner_images_model->get_image();
                    $this->load->view('new_upload');
                  
    }

if($this->input->post()){
            
       $this->form_validation->set_error_delimiters('<div class="error" style="color:#e73d4a">', '</div>');s
        $this->form_validation->set_rules('imagelink', ' Link', 'required');
        
       $_FILES["image"]["name"]=time().$_FILES["image"]["name"];
       $config['upload_path']          = 'uploads/';
       $config['allowed_types']        = 'gif|jpeg|jpg|png';
       $config['max_size']             = 5120;
       // $config['max_width']            = 1400;
       // $config['max_height']           = 500;
       $this->load->library('upload', $config);
       if ( ! $this->upload->do_upload('image'))
       {
           $data['error'] =$this->upload->display_errors();
           if ($this->form_validation->run() == FALSE){
           $this->load->view('state-add');
           return;
           }else{
           $this->load->view('state-add');
           return;
           }
       }
       if ($this->form_validation->run() == FALSE)
       {
       $this->load->view('state-add');
       }
       else
       {
           $string=$this->db->escape_str($this->input->post('location_slug'));
       $data=array(
                   // 'text'=>$this->input->post('location_name'),
                   'name'=>$this->input->post('name'),
                   'cost'=>$this->input->post('cost'),
                   'ocost'=>$this->input->post('ocost'),
                   'description'=>$this->input->post('desc'),
                   'availability'=>$this->input->post('available'),
                   'flashproduct'=>$this->input->post('flash'),
                   // 'priority'=>$this->input->post('priority'),
                   
                   // 'blog_name_russian'=>$this->db->escape_str($this->input->post('location_name_russian')),
                   // 'blog_desc_russian'=>$this->input->post('location_desc_russian'),
                   'image'=>$this->db->escape_str($_FILES['image']['name']),
                    //'blog_slug'=>$string,
                   // 'category'=>$this->db->escape_str($this->input->post('category')),
                   // 'blog_seodesc'=>$this->db->escape_str($this->input->post('location_seodesc')),
                   // 'position'=>$this->input->post('location_position'),
               );

               $this->New_upload_model->save_location($data);
               redirect(base_url());
       }
       }

else{
$this->load->view('state');
    }

  }
    ?>
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_program_register extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
        $this->load->model('editprogram_register_model');
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		  if($this->session->userdata('email')){
		 $id = $this->uri->segment(2);
		  
		$data['row']=$this->editprogram_register_model->get_data($id);
		$this->load->view('edit_program_register', $data);
	}else{
		redirect('login');
	}
	}
	
	
	public function update_program()
	{
		 $id = $this->input->post('id');

		 $data = array(
		 	'orderid' => $this->input->post('orderid'),
		 	    'email' => $this->input->post('email'),
			  	'name' => $this->input->post('name'),
			  	'phoneno' => $this->input->post('phone'),
			 	'dob' => $this->input->post('dob'),
			 	'offaddress' => $this->input->post('offaddress'),
			 	'position' => $this->input->post('position'),
			 	'workexperience' => $this->input->post('workexperience'),
			 	'domain' => $this->input->post('domain'),
			 	'amount' => $this->input->post('amount'),
			 	'paymentmethod' => $this->input->post('paymethod'),
			 	'paymentstatus' => $this->input->post('paymentstatus'),
		 	);
		 
	 
		  $this->editprogram_register_model->update_data($data, $id);

           $this->session->set_flashdata('updatenotification', 'Program details updated successfully');
		  redirect( base_url('program_register_list'));
	}
	
	
	public function delete(){
		$id = $this->uri->segment(3);
		
		$this->db->where('programid', $id);
		$this->db->delete('tbl_program');

	     $this->session->set_flashdata('deletenotification', 'Program details deleted successfully');
		redirect( base_url('program_register_list'));
	}
}

<?php  
defined('BASEPATH') OR exit('No direct script access allowed');  
  
class FeedbackContent extends CI_Controller {  
public function __construct()
    {
        parent::__construct();
        $this->load->model('Feedback_model');
    }
    public function index()  
    {  
		 if($this->session->userdata('email')){
            if($_SESSION['role'] === 'super_admin') { 
                $data['list']=$this->Feedback_model->get_query();
                $this->load->view('feedback_content', $data);  
            }else{
				redirect('dashboard/index', 'refresh');
			}
    }
		else{
		redirect('login');
	}
		}
}  
?>  
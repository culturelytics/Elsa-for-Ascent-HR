<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class idp_content  extends CI_Controller {
public function __construct()
    {
        parent::__construct();
        $this->load->model('idp_content_model');
        $this->load->model('programs_model');
    }
	
	public function aggregator()
	{
	     if($this->session->userdata('email')){
		$data['list']=$this->idp_content_model->get_program($this->uri->segment(3));
                $data['orgdetails']=$this->idp_content_model->get_orgDetails($this->uri->segment(3));
                $url = 'idp_content/'.$this->uri->segment(2).'/'.$this->uri->segment(3);
                $data['urlsegment']=$url;
	
		$this->load->view('idp_content', $data);
	}
	else{
		redirect('login');
	}
	}
        public function client()
	{
	     if($this->session->userdata('email')){
		$data['list']=$this->idp_content_model->get_program($this->uri->segment(3));
                $data['orgdetails']=$this->idp_content_model->get_orgDetails($this->uri->segment(3));
                $url = 'idp_content/'.$this->uri->segment(2).'/'.$this->uri->segment(3);
                $data['urlsegment']=$url;
                
		$this->load->view('idp_content', $data);
	}
	else{
		redirect('login');
	}
	}
	public function add($param1,$org_id)
	{
                        ini_set('display_errors',1);
		if($this->session->userdata('email')){
			$data['programs']=$this->programs_model->get_data($org_id);
                       
                        $data['orgdetails']=$this->idp_content_model->get_orgDetails($this->uri->segment(4));
                        $url = 'idp_content/'.$this->uri->segment(3).'/'.$this->uri->segment(4);
                        $data['client']=$url;
                
			if($this->input->post()){
				$this->form_validation->set_rules('title', 'Title', 'trim|required');
				$this->form_validation->set_rules('subtitle', 'Subtitle ', 'trim|required');
				$this->form_validation->set_rules('description', 'Description', 'trim|required');
				$error="";
//				if(!$this->input->post('programs[]')){
//					$error="Please Enter programs";
//				}else if($this->input->post('programs[]')==NULL || $this->input->post('programs[]')=='' ){
//					$error="Please Enter programs";
//				}

				if ($this->form_validation->run() === FALSE ||$error!=''){			
					$data['error']=$error;
                                       
					$this->load->view('addidp_content', $data);	
				}else{
					$data=array(
					'title'=>$this->input->post('title'),
					'subtitle'=>$this->input->post('subtitle'),
					'description'=>$this->input->post('description'),
                                            'org_id'=>$this->input->post('org_id'),
					);
                                       
					$data1=$this->input->post('programs');
                                        
					$this->idp_content_model->add($data,$data1);
                                        redirect($this->input->post('pathSegment2')); 
				}
			}else{
				$this->load->view('addidp_content', $data);	
			}
		}
		else{
			redirect('login');
		}
	}	


	public function delete()
	{
		$id=$this->uri->segment(3);
		if($id!=NULL){
		$this->idp_content_model->delete($id);
		$this->session->set_flashdata('notification', 'Deleted Successfully');
			redirect('idp_content/'.$this->uri->segment(5).'/'.$this->uri->segment(6)); 

		}else{
			$this->session->set_flashdata('notification', 'Not Deleted Try again later');
			redirect('idp_content/'.$this->uri->segment(5).'/'.$this->uri->segment(6)); 
		}
	}
}

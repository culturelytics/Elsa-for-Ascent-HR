<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class upcoming_events extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
        $this->load->model('upcoming_events_model');
        if (!$this->session->userdata('email')) {
            redirect('upcoming_events/events/'.$this->uri->segment(3));
        }
    }

    public function events() {
        
        if($this->uri->segment(3) !== 'undefined' ||$this->uri->segment(3) !== null){
            $data['organization_id'] = $this->uri->segment(3);
        }else{
            $data['organization_id'] = 1;
        }
        $role = $this->session->userdata('role'); $role_org = $this->session->userdata('org_id');
		if($role === 'org_admin' || $role === 'group_admin') {
			$data['organization_id'] = $role_org;
		}
        $data['list'] = $this->upcoming_events_model->get_data($data['organization_id']);
        $data['organizations'] = $this->upcoming_events_model->get_org_data();
        if ($this->session->userdata('email')) {
            if ($this->input->post()) {
                $this->form_validation->set_rules('evnt_name', 'Event Title', 'trim|required');
                $this->form_validation->set_rules('evnt_desc', 'description', 'trim|required');
                $this->form_validation->set_rules('evnt_status', 'status', 'trim|required');
                if ($this->form_validation->run() == TRUE) {
                    $data = array(
                        'title' => $this->input->post('evnt_name'),
                        'description' => $this->input->post('evnt_desc'),
                        'status' => $this->input->post('evnt_status'),
                        'org_id' => $this->input->post('org_id')
                    );
                    $this->upcoming_events_model->addprogram($data);
                    $this->session->set_flashdata('notification', 'Added successfully');
                    redirect('upcoming_events/events/'.$this->uri->segment(3), 'refresh');
                } else {
                    $this->load->view('upcoming_events', $data);
                }
            } else {
                $this->load->view('upcoming_events', $data);
            }
        } else {
            redirect(base_url('login'));
        }
    }

    public function edit() {
        if ($this->input->post()) {
            $data = $this->upcoming_events_model->editprogram($this->input->post());
            if (!empty($data)) {
                echo json_encode($data);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function update() {
        if ($this->input->post()) {
            $org_id = $this->input->post('org_id');
            if($org_id == '' ||$org_id == null || $org_id == 'undefined' ){
                $org_id = 1;
            }
            if ($this->upcoming_events_model->updateprogram($this->input->post())) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('upcoming_events/events/'.$org_id, 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('upcoming_events/events/'.$org_id, 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function delete() {
        if ($this->uri->segment(3)) {
            if ($this->upcoming_events_model->deleteprogram($this->uri->segment(3))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('upcoming_events/events/'.$this->uri->segment(4), 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('upcoming_events/events/'.$this->uri->segment(4), 'refresh');
            }
        } else {
            echo "";
        }
    }
}

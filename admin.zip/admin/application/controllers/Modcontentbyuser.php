<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Modcontentbyuser extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
         $this->load->helper(array('form', 'url'));
         //$this->load->library('upload');
         $this->load->library('session');
         $this->load->model('Addmodulecontentuser_model');
         if(!$this->session->userdata('email')){ 
         	redirect(base_url('login'));
        }
    }
	public function index()
	{
		$user_id = $this->uri->segment(2);
		$org_id = $this->uri->segment(3);
		$idp_id = $this->uri->segment(4);
		$prog_id = $this->uri->segment(5);
		
		$arraydata = array('userid' => $user_id, 'idpid' => $idp_id, 'idpmoduleid' => $prog_id);
		$response['data'] = $this->Addmodulecontentuser_model->getmodulecontent($arraydata);
		$tempData = $this->Addmodulecontentuser_model->getmodulename($prog_id);
		
		$response['data']->prg_name = $tempData->prg_name;
		
		$this->load->view('addmodulecontentbyuser', $response);
	}
	public function addinfo(){
		
		$data = array ('userid'=> $this->input->post('userid'), 'idpid' => $this->input->post('idpid'),'idpmoduleid'=> $this->input->post('idpmoduleid'),'description'=> $this->input->post('description'));
		
		
		if(!empty($_FILES['docs']['name'])){
			$newfilename = 
			$config['upload_path']          = './uploads/usermoduledocs/';
			$config['allowed_types']        = '*';
			$config['max_size']             = 100000;
			$config['encrypt_name'] = TRUE;
			//$config['docs']           = $_FILES['docs']['name'];;
			
			$this->load->library('upload', $config);
			

			if (!$this->upload->do_upload('docs')) {
				$error = array('error' => $this->upload->display_errors());
				print_r($error);
			}
			else {
				$uploadfiledata = array('upload_data' => $this->upload->data());
				$uploadedfilename = $uploadfiledata['upload_data']['file_name'];
				$data = array_merge($data, array('docs'=>$uploadedfilename));
				$response = $this->Addmodulecontentuser_model->add($data);
				if($response == 1) {
					
					$this->session->set_flashdata('successmsg', 'Updated successfully');
					redirect('modcontentbyuser/'.$this->input->post('userid').'/'.$this->input->post('orgid').'/'.$this->input->post('idpid').'/'.$this->input->post('idpmoduleid').'', 'refresh');
				}else {
					$this->session->set_flashdata('failuremessage', 'Cannot update now with images, Please try again later');
					redirect('modcontentbyuser/'.$this->input->post('userid').'/'.$this->input->post('orgid').'/'.$this->input->post('idpid').'/'.$this->input->post('idpmoduleid').'', 'refresh');
				}
				
			}
		}else {
			$response = $this->Addmodulecontentuser_model->add($data);
			if($response == 1) {
				$this->session->set_flashdata('successmsg', 'Updated successfully');
				redirect('modcontentbyuser/'.$this->input->post('userid').'/'.$this->input->post('orgid').'/'.$this->input->post('idpid').'/'.$this->input->post('idpmoduleid').'', 'refresh');
				
			}else {
				$this->session->set_flashdata('failuremessage', 'Looks like there is not modification on module content');
				redirect('modcontentbyuser/'.$this->input->post('userid').'/'.$this->input->post('orgid').'/'.$this->input->post('idpid').'/'.$this->input->post('idpmoduleid').'', 'refresh');
			}
		}
		
		// $respose = $this->Addmodulecontentuser_model->add($data);
		// print_r($respose);
	}
	public function deletedoc(){
		$data = array(
		'userid'=> $this->input->post('userid'),
		'idpid'=> $this->input->post('idpid'),
		'idpmoduleid'=> $this->input->post('idpmoduleid'),
		'docs' => $this->input->post('docs')
		);
		
		if(!empty($data['docs'])){
			$docspath = 'uploads/usermoduledocs/'.$data['docs'];
			
			if(@unlink($docspath)){
				//echo "file deleted";
				$response = $this->Addmodulecontentuser_model->deletedoc($data);
				if($response == TRUE){
						$result_html = "Successfully deleted the files";
					    echo json_encode($result_html);
				}else {
					$result_html = "cannot delete file";
					echo json_encode($result_html);
				}
			}else {
				$result_html =  "files are not present in folder";
				echo json_encode($result_html);
			}
		}else {
			$result_html =  "something went wrong";
			echo json_encode($result_html);
		}
		//echo json_encode($data)
		
	}
}
<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Competencies extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper(array('form', 'url'));
		$this->load->library('session');
		$this->load->model('competency_center_model');
		if (!$this->session->userdata('email')) {
			redirect('competencies');
		}
	}

	public function index()
	{
		//echo "Sdfsdf";
		$data['list'] = $this->competency_center_model->get_data();

		if ($this->session->userdata('email')) {
                    if($_SESSION['role'] === 'super_admin') {
			if ($this->input->post()) {
				$this->form_validation->set_rules('prg_name', 'Program Name', 'trim|required');
				if ($this->form_validation->run() == TRUE) {
					$data = array(
						'prg_name' => $this->input->post('prg_name')
					);
					$this->competency_center_model->addprogram($data);
					$this->session->set_flashdata('notification', 'Added successfully');
					redirect('competencies', 'refresh');
				} else {
					$this->load->view('competencies', $data);
				}
			} else {
				$this->load->view('competencies', $data);
			}
                    }else{
                        redirect('dashboard/index', 'refresh');
                    }
		} else {
			redirect(base_url('login'));
		}
	}

	public function export()
	{
		if ($this->input->post()) {
			$data = $this->input->post('user');
			$this->competency_center_model->export_event($data);
		} else {
			$data['user'] = $this->competency_center_model->get_user();
			$this->load->view('export_kc', $data);
		}
	}

	public function edit()
	{
		if ($this->input->post()) {
			$data = $this->competency_center_model->editprogram($this->input->post());
			if (!empty($data)) {
				echo json_encode($data);
			} else {
				echo "";
			}
		} else {
			echo "";
		}
	}

	public function update()
	{
		if ($this->input->post()) {
			if ($this->competency_center_model->updateprogram($this->input->post())) {
				$this->session->set_flashdata('notification', 'updated successfully');
				redirect('competencies', 'refresh');
			} else {
				$this->session->set_flashdata('notification', 'Not updated');
				redirect('competencies', 'refresh');
			}
		} else {
			echo "";
		}
	}

	public function delete()
	{
		if ($this->uri->segment(3)) {
			if ($this->competency_center_model->deleteprogram($this->uri->segment(3))) {
				$this->session->set_flashdata('notification', 'updated successfully');
				redirect('competencies', 'refresh');
			} else {
				$this->session->set_flashdata('notification', 'Not updated');
				redirect('competencies', 'refresh');
			}
		} else {
			echo "";
		}
	}

	/* Attributes -start */

	public function attributes($id)
	{
		if ($id != null) {
			$data['kc'] = $this->competency_center_model->get_details($id);
			$data['list'] = $this->competency_center_model->get_attributes($id);

			return $this->load->view('competency_attributes', $data);
		} else {
			redirect('competencies', 'refresh');
		}
	}
	
	public function addattribute($id)
	{
		if ($id != null) {
			$data['kc'] = $this->competency_center_model->get_details($id);
			$data['list'] = $this->competency_center_model->get_attributes($id);

			if (!empty($data['kc'])) {
				if ($this->input->post()) {
					$this->form_validation->set_rules('attr_name', 'Title', 'trim|required');
					//$this->form_validation->set_rules('attr_desc', 'Title', 'trim|required');
					if ($this->form_validation->run() == TRUE) {
						$data1 = $this->input->post();
						unset($data1['submit']);
						if ($data = $this->competency_center_model->add_attribute($data1, $id)) {
							$this->session->set_flashdata('notification', 'Added successfully');
							redirect('competencies/attributes/' . $id, 'refresh');
						} else {
							$this->session->set_flashdata('notification', 'Not Added.Try again later');
							redirect('competencies/attributes/' . $id, 'refresh');
						}
					} else {
						$this->load->view('competency_attributes', $data);
					}
				} else {
					$this->load->view('competency_attributes', $data);
				}
			} else {
				redirect('competencies/attributes/' . $id, 'refresh');
			}
		} else {
			redirect('competencies', 'refresh');
		}
	}

	public function editattribute()
	{
		
		if ($this->input->post()) {
			$data = $this->competency_center_model->get_attribute($this->input->post('id'));
			if (!empty($data)) {
				echo json_encode($data);
			} else {
				echo "";
			}
		} else {
			echo "";
		}
	}

	public function updateattribute()
	{
		if ($this->input->post()) {
			$data = $this->competency_center_model->get_attribute($this->input->post('id'));
			if(!empty($data)){
				$data1 = $this->input->post();
				unset($data1['submit']);
				if ($this->competency_center_model->update_attribute($data1)) {
					$this->session->set_flashdata('notification', 'updated successfully');
					redirect('competencies/attributes/' . $data1['competency_id'], 'refresh');
				}
			}
			$this->session->set_flashdata('notification', 'Not updated');
			redirect('competencies', 'refresh');
		} else {
			echo "";
		}
	}

	public function deleteattribute($id)
	{
		if ($id) {
			$data = $this->competency_center_model->get_attribute($id);
			if(!empty($data)){
				if ($this->competency_center_model->delete_attribute($id)) {
					$this->session->set_flashdata('notification', 'deleted successfully');
					redirect('competencies/attributes/' . $data->competency_id, 'refresh');
				}
			}
			$this->session->set_flashdata('notification', 'Not deleted');
			redirect('competencies/attributes/' . $data->competency_id, 'refresh');
		} else {
			echo "";
		}
	}

	/* Attributes -end */

	

	/* Modules -start */

	public function modules($id)
	{
		$data['mdllist'] = $this->competency_center_model->get_moduleslist();
		$data['levels'] = [0 => 'Basic', 1 => 'Intermediate', 2 => 'Expert'];
		
		if ($id != null) {
			$data['kc'] = $this->competency_center_model->get_details($id);
			$data['list'] = $this->competency_center_model->get_modules($id);

			/*foreach($data['list'] as $k => $v) {
				foreach ($data['mdllist'] as $key => $value) {
					if($value->prg_id == $v->cmdl_kc_id) {
						unset($data['mdllist'][$key]);
					}
				}
			}*/

			return $this->load->view('competency_modules', $data);
		} else {
			redirect('competencies', 'refresh');
		}
	}
	
	public function addmodule($id)
	{
		if ($id != null) {
			$data['kc'] = $this->competency_center_model->get_details($id);
			$data['list'] = $this->competency_center_model->get_modules($id);
			if (!empty($data['kc'])) {
				if ($this->input->post()) {
					$this->form_validation->set_rules('cmdl_level', 'Level', 'trim|required');
					$this->form_validation->set_rules('cmdl_kc_id', 'Module', 'trim|required');
					if ($this->form_validation->run() == TRUE) {
						$data1 = $this->input->post();
						unset($data1['submit']);
						if ($data = $this->competency_center_model->add_module($data1, $id)) {
							$this->session->set_flashdata('notification', 'Added successfully');
							redirect('competencies/modules/' . $id, 'refresh');
						} else {
							$this->session->set_flashdata('notification', 'Not Added.Try again later');
							redirect('competencies/modules/' . $id, 'refresh');
						}
					} else {
						$this->load->view('competency_modules', $data);
					}
				} else {
					$this->load->view('competency_modules', $data);
				}
			} else {
				redirect('competencies/modules/' . $id, 'refresh');
			}
		} else {
			redirect('competencies', 'refresh');
		}
	}

	public function editmodule()
	{
		if ($this->input->post()) {
			$data = $this->competency_center_model->get_module($this->input->post('id'));
			if (!empty($data)) {
				echo json_encode($data);
			} else {
				echo "";
			}
		} else {
			echo "";
		}
	}

	public function updatemodule()
	{
		if ($this->input->post()) {
			$data = $this->competency_center_model->get_module($this->input->post('id'));
			if(!empty($data)){
				$data1 = $this->input->post();
				unset($data1['submit']);
				if ($this->competency_center_model->update_module($data1)) {
					$this->session->set_flashdata('notification', 'updated successfully');
					redirect('competencies/modules/' . $data1['cmdl_c_id'], 'refresh');
				}
			}
			$this->session->set_flashdata('notification', 'Not updated');
			redirect('competencies', 'refresh');
		} else {
			echo "";
		}
	}

	public function deletemodule($id)
	{
		if ($id) {
			$data = $this->competency_center_model->get_module($id);
//                        var_dump($data);die;
			if(!empty($data)){
				if ($this->competency_center_model->delete_module($id)) {
					$this->session->set_flashdata('notification', 'deleted successfully');
					redirect('competencies/modules/' . $data->cmdl_c_id, 'refresh');
				}
			}
			$this->session->set_flashdata('notification', 'Not deleted');
			redirect('competencies/modules/' . $data->cmdl_c_id, 'refresh');
		} else {
			echo "";
		}
	}

	/* Modules -end */

	

	/* AttrModules -start */

	public function attrmodules($id)
	{
		$data['mdllist'] = $this->competency_center_model->get_moduleslist();
		$data['levels'] = [0 => 'Basic', 1 => 'Intermediate', 2 => 'Expert'];
		
		if ($id != null) {
			$data['kc'] = $this->competency_center_model->get_attribute($id);
			$data['list'] = $this->competency_center_model->get_attrmodules($id);

			return $this->load->view('competency_attrmodules', $data);
		} else {
			redirect('competencies', 'refresh');
		}
	}
	
	public function addattrmodule($id)
	{
		if ($id != null) {
			$data['kc'] = $this->competency_center_model->get_attribute($id);
			$data['list'] = $this->competency_center_model->get_attrmodules($id);
			if (!empty($data['kc'])) {
				if ($this->input->post()) {
					$this->form_validation->set_rules('camdl_ca_id', 'Level', 'trim|required');
					$this->form_validation->set_rules('camdl_kc_id', 'Module', 'trim|required');
					if ($this->form_validation->run() == TRUE) {
						$data1 = $this->input->post();
						unset($data1['submit']);
						if ($data = $this->competency_center_model->add_attrmodule($data1, $id)) {
							$this->session->set_flashdata('notification', 'Added successfully');
							redirect('competencies/attrmodules/' . $id, 'refresh');
						} else {
							$this->session->set_flashdata('notification', 'Not Added.Try again later');
							redirect('competencies/attrmodules/' . $id, 'refresh');
						}
					} else {
						$this->load->view('competency_attrmodules', $data);
					}
				} else {
					$this->load->view('competency_attrmodules', $data);
				}
			} else {
				redirect('competencies/attrmodules/' . $id, 'refresh');
			}
		} else {
			redirect('competencies', 'refresh');
		}
	}

	public function editattrmodule()
	{
		if ($this->input->post()) {
			$data = $this->competency_center_model->get_attrmodule($this->input->post('id'));
			if (!empty($data)) {
				echo json_encode($data);
			} else {
				echo "";
			}
		} else {
			echo "";
		}
	}

	public function updateattrmodule()
	{
		if ($this->input->post()) {
			$data = $this->competency_center_model->get_attrmodule($this->input->post('id'));
			if(!empty($data)){
				$data1 = $this->input->post();
				unset($data1['submit']);
				if ($this->competency_center_model->update_attrmodule($data1)) {
					$this->session->set_flashdata('notification', 'updated successfully');
					redirect('competencies/attrmodules/' . $data1['camdl_ca_id'], 'refresh');
				}
			}
			$this->session->set_flashdata('notification', 'Not updated');
			redirect('competencies', 'refresh');
		} else {
			echo "";
		}
	}

	public function deleteattrmodule($id)
	{
		if ($id) {
			$data = $this->competency_center_model->get_attrmodule($id);
			if(!empty($data)){
				if ($this->competency_center_model->delete_attrmodule($id)) {
					$this->session->set_flashdata('notification', 'deleted successfully');
					redirect('competencies/attrmodules/' . $data->camdl_ca_id, 'refresh');
				}
			}
			$this->session->set_flashdata('notification', 'Not deleted');
			redirect('competencies/attrmodules/' . $data->camdl_ca_id, 'refresh');
		} else {
			echo "";
		}
	}

	/* Modules -end */
}

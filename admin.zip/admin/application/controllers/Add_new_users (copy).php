<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Add_new_users extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
         $this->load->helper(array('form', 'url'));
            $this->load->library('upload');
            $this->load->library('session');
        $this->load->model('user_details_model');
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{

		if($this->session->userdata('email')){ 
		$data['list']=$this->user_details_model->get_data();
		$this->load->view('add_new_user', $data);
	    }

	    else{

	    	redirect(base_url('login1'));
	    }

	}
	
	public function adduser()
	{
		 
		 $data = array(
		 	'email' => $this->input->post('email'),
			  	'name' => $this->input->post('name'),
			  	'password' => $this->input->post('password'),
			 	'contact' => $this->input->post('phone'),
			 	'status' => $this->input->post('status'),
			 	'access_type' => json_encode($this->input->post('access')),
		 	);
	 
		  $this->user_details_model->adddetail($data);
		  redirect(base_url('add_new_users'));
	}
	public function update_user()
	{
		 $id = $this->input->post('id');
		 $data = array(
		 	'email' => $this->input->post('email'),
			  	'name' => $this->input->post('name'),
			  	'password' => $this->input->post('password'),
			 	'contact' => $this->input->post('phone'),
			 	'status' => $this->input->post('status'),
			 	'access_type' => $this->input->post('access'),

		 	);
		  
	 
		  $this->user_details_model->update_data($data , $id);
		  redirect(base_url('add_new_users'));
	}
	public function delete()
	{
		  
		 $id2 = $this->uri->segment(3);

	 
		  $this->user_details_model->deletee($id2);
		  redirect(base_url('add_new_users'));
	}
	public function edituser()
	{
		 $this->load->view('edit_user');
		  $id = $this->input->post('id');
		 $data = array(
		 	'email' => $this->input->post('email'),
			  	'name' => $this->input->post('name'),
			  	'password' => $this->input->post('password'),
			 	'contact' => $this->input->post('phone'),
			 	'status' => $this->input->post('status'),
			 	'access_type' => $this->input->post('access'),
		 	);

		  $this->user_details_model->update_data($data , $id);
		  redirect(base_url('add_new_users'));
		 
	}
}

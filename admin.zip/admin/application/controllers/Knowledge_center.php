<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class knowledge_center extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('form', 'url'));
        $this->load->library('session');
        $this->load->model('knowledge_center_model');
        if (!$this->session->userdata('email')) {
            redirect('knowledge_center');
        }
    }

    public function aggregator() {
        $data['baseURL'] = base_url() . 'knowledge_center/aggregator';
        $data['organization_id'] = 0;

        $data['idpModuleURL'] = base_url() . 'programs/aggregator/' . $data['organization_id'];
        $data['idpContentURL'] = base_url() . 'idp_content/aggregator/' . $data['organization_id'];

        $data['list'] = $this->knowledge_center_model->get_data($data['organization_id']);
        if ($this->session->userdata('email')) {
          if($_SESSION['role'] === 'super_admin') { 
            if ($this->input->post()) {
                $this->form_validation->set_rules('prg_name', 'Program Name', 'trim|required');
                if ($this->form_validation->run() == TRUE) {
                    $data = array(
                        'prg_name' => $this->input->post('prg_name'),
                        'prg_desc' => $this->input->post('prg_desc'),
                        'org_id' => $this->input->post('org_id'),
                        'prg_trtp_id' => '1'
                    );
                    if ($data['prg_desc'] !== 'undefined' || $data['prg_desc'] !== null) {
                        $object['prg_desc'] = $data['prg_desc'];
                    }

                    $this->knowledge_center_model->addprogram($data);
                    $this->session->set_flashdata('notification', 'Added successfully');
                    redirect('knowledge_center/aggregator', 'refresh');
                } else {
                    $this->load->view('knowledge_center', $data);
                }
            } else {
                $this->load->view('knowledge_center', $data);
            }
        }else{
              redirect('dashboard/index', 'refresh');
          }
        } else {
            redirect(base_url('login'));
        }
    }

    public function client($orgid) {
       
        if ($this->session->userdata('email')) {
            $role = $this->session->userdata('role'); $role_org = $this->session->userdata('org_id');
		if($role === 'org_admin' || $role === 'group_admin') {
			$orgid = $role_org;
		}
            if ($this->input->post()) {
                $pdata = $this->input->post();
                $this->form_validation->set_rules('prg_name', 'Program Name', 'trim|required');
                if ($this->form_validation->run() == TRUE) {
                    $data = array(
                        'prg_name' => $this->input->post('prg_name'),
                        'prg_desc' => $this->input->post('prg_desc'),
                        'org_id' => $this->input->post('org_id'),
                        'prg_trtp_id' => '1'
                    );
                    if ($data['prg_desc'] !== 'undefined' || $data['prg_desc'] !== null) {
                        $object['prg_desc'] = $data['prg_desc'];
                    }
                    $this->knowledge_center_model->addprogram($data);
                    $this->session->set_flashdata('notification', 'Added successfully');

                    if ($this->input->post('org_id') !== null || $this->input->post('org_id') !== '') {
                        $data['organization_id'] = $this->input->post('org_id');
                    } else {
                        $data['organization_id'] = 1;
                      
                    }
                } else {
                    $data['organization_id'] = $this->input->post('organization_id');
                }
                $data['baseURL'] = base_url() . 'knowledge_center/client/' . $orgid;
                $data['organizations'] = $this->knowledge_center_model->get_org_data();
                $data['list'] = $this->knowledge_center_model->get_data($orgid);
                //var_dump( $data['list']);
                $data['idpModuleURL'] = base_url() . 'programs/client/' . $data['organization_id'];
                $data['idpContentURL'] = base_url() . 'idp_content/client/' . $data['organization_id'];
                $this->load->view('knowledge_center', $data);
            } else {
                $data['organization_id'] = $this->uri->segment(3);
                if($role === 'org_admin' || $role === 'group_admin') {
			$data['organization_id'] = $role_org;
		}
                $data['organizations'] = $this->knowledge_center_model->get_org_data();
                $data['list'] = $this->knowledge_center_model->get_data($data['organization_id']);
                $data['idpModuleURL'] = base_url() . 'programs/client/' . $data['organization_id'];
                $data['idpContentURL'] = base_url() . 'idp_content/client/' . $data['organization_id'];
                $this->load->view('knowledge_center', $data);
            }
        } else {
            redirect(base_url('login'));
        }
    }

    public function export() {
        if ($this->input->post()) {
            $data = $this->input->post('user');
            $this->knowledge_center_model->export_event($data);
        } else {
            $data['user'] = $this->knowledge_center_model->get_user();
            $this->load->view('export_kc', $data);
        }
    }

    public function edit() {
        if ($this->input->post()) {
            $data = $this->knowledge_center_model->editprogram($this->input->post());
            if (!empty($data)) {
                echo json_encode($data);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function update() {
        if ($this->input->post()) {
            $pdata = $this->input->post();
           
            if ($this->knowledge_center_model->updateprogram($this->input->post())) {
                $this->session->set_flashdata('notification', 'updated successfully');

                redirect('knowledge_center/'.$pdata['seg2'].'/'.$pdata['seg3'], 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                 redirect('knowledge_center/'.$pdata['seg2'].'/'.$pdata['seg3'], 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function delete() {
        if ($this->uri->segment(3)) {
            if ($this->knowledge_center_model->deleteprogram($this->uri->segment(3))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                if ($this->uri->segment(4) == 0) {
                    redirect('knowledge_center/aggregator/' . $this->uri->segment(4), 'refresh');
                } else {
                    redirect('knowledge_center/client/' . $this->uri->segment(4), 'refresh');
                }
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                if ($this->uri->segment(4) == 0) {
                   redirect('knowledge_center/aggregator/' . $this->uri->segment(4), 'refresh');
                } else {
                    redirect('knowledge_center/client/' . $this->uri->segment(4), 'refresh');
                }
            }
        } else {
            echo "";
        }
    }

    public function deleteSubContent() {
        if ($this->uri->segment(3)) {
           
            if ($this->knowledge_center_model->deleteSubContent($this->uri->segment(3), $this->uri->segment(4))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function edit_content() {
        if ($this->input->post()) {

            $cdata = $this->knowledge_center_model->editcontent($this->input->post());
            if (!empty($cdata)) {
                echo json_encode($cdata);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function add_content() {
        if ($this->uri->segment(3)) {
            $kc = $this->knowledge_center_model->editprogram(array('pid' => $this->uri->segment(3)));
            
            $expire_assessment = $this->knowledge_center_model->expire_assessment();
            $k_list = $this->knowledge_center_model->get_list($this->uri->segment(3));
            $kcimage = $this->knowledge_center_model->get_image($this->uri->segment(3));
            $assessment_list = $this->knowledge_center_model->get_assessment_list($this->uri->segment(3));

            if (!empty($kc)) {
                if ($this->input->post()) {
                    $data['kc'] = $kc;
                    $this->form_validation->set_rules('kc_title_old', 'Title', 'trim|required');
                    /* $this->form_validation->set_rules('kc_content_old', 'Content', 'trim|required'); */

                    if ($this->form_validation->run() == TRUE) {
                        $data1 = $this->input->post();
                        if ($this->knowledge_center_model->add_content($data1, $this->uri->segment(3))) {
                            $this->session->set_flashdata('notification', 'Added successfully');
                            redirect('knowledge_center', 'refresh');
                        } else {
                            $this->session->set_flashdata('notification', 'Not Added.Try again later');
                            if ($this->uri->segment(4) == 'client') {
                                redirect('knowledge_center/client', 'refresh');
                            } else {
                                redirect('knowledge_center', 'refresh');
                            }
                        }
                    } else {
                        $this->load->view('add_kc_content', $data);
                    }

//                                load image content
                    $error = "";
                    $this->form_validation->set_rules('img_title', 'Title of image', 'trim|required');
                    $this->form_validation->set_rules('img_link', 'Link of image', 'trim|required');
                    $error = "";
                    $new_name = time() . $_FILES["img_name"]['name'];
                    $config['upload_path'] = './uploads/content_images';
                    $config['allowed_types'] = 'gif|jpg|png|jpeg';
                    $config['max_size'] = 51200;
                    $config['max_width'] = 1024;
                    $config['max_height'] = 1024;
                    $config['min_width'] = 50;
                    $config['min_height'] = 50;
                    $config['file_name'] = $new_name;
                    $this->load->library('upload', $config);
                    $this->upload->initialize($config);
                    if (!$this->upload->do_upload('img_name')) {
                        $data['error'] = array('error' => $this->upload->display_errors());
                        $error = "error";
                    } else {
                        $uploadData = $this->upload->data();
                        $picture = $uploadData['file_name'];
                    }
                    if ($this->form_validation->run() == TRUE && $error == '') {
                        $data = array(
                            'img_title' => $this->input->post('img_title'),
                            'img_link' => $this->input->post('img_link'),
                            'img_name' => $picture,
                            'img_kc_id' => $this->uri->segment(3),
                        );
                        $this->knowledge_center_model->add_image_content($data);
                        $this->session->set_flashdata('notification', 'Added successfully');
                        redirect('knowledge_center/add_content/' . $this->uri->segment(3), 'refresh');
                    } else {
                        if (isset($picture)) {
                            $file = './uploads/content_images/' . $picture;
                            unlink($file);
                        }
                        $data['kc'] = $kc;
                        $data['kcimage'] = $kcimage;

                        $this->load->view('add_image_content', $data);
                    }
                } else {
                    $data['kc'] = $kc;
                    $data['list'] = $k_list;
                    $data['kcimage'] = $kcimage;
                    $data['assessment_list'] = $assessment_list;
                    $this->load->view('add_kc_content', $data);
                }
            } else {
                if ($this->uri->segment(4) == 'client') {
                    redirect('knowledge_center/client', 'refresh');
                } else {
                    redirect('knowledge_center', 'refresh');
                }
            }
        } else {
            if ($this->uri->segment(4) == 'client') {
                redirect('knowledge_center/client', 'refresh');
            } else {
                redirect('knowledge_center', 'refresh');
            }
        }
    }

    public function add_topic() {
        $datatopic = $this->input->post();
        if ($this->knowledge_center_model->add_topic($datatopic, $this->uri->segment(3))) {
            $this->session->set_flashdata('notification', 'Added successfully');
            redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$datatopic['topicUrl'], 'refresh');
        } else {
            $this->session->set_flashdata('notification', 'Not Added.Try again later');
            redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$datatopic['topicUrl'], 'refresh');
        }
    }

    public function add_kc_content() {
        $datacontent = $this->input->post();
        
        /* Add file -start */
        if(count($_FILES) > 0) {
            $error = "";
            $new_name = time() . $_FILES["img_name"]['name'];
            $config['upload_path'] = './uploads/content_images';
            $config['allowed_types'] = 'gif|jpg|png|jpeg|pdf|doc|docx|xls|xlsx|ppt|pptx|mp4|mp3';
            $config['max_size'] = 5120000;
            //$config['max_width'] = 1024;
            //$config['max_height'] = 1024;
            //$config['min_width'] = 50;
            //$config['min_height'] = 50;
            $config['file_name'] = $new_name;
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if (!$this->upload->do_upload('img_name')) {
                $data['error'] = array('error' => $this->upload->display_errors());
                $error = "error";
            } else {
                $uploadData = $this->upload->data();
                $datacontent['file_url'] = '/uploads/content_images/' .$uploadData['file_name'];
            }
            //var_dump($_FILES,$this->upload->do_upload('img_name'),$picture,$datacontent);die;
        }
        /* Add file -end */
        if ($this->knowledge_center_model->add_kc_content($datacontent, $this->uri->segment(3))) {
            $this->session->set_flashdata('notification', 'Added successfully');
            redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$datacontent['topicUrl'], 'refresh');
        } else {
            $this->session->set_flashdata('notification', 'Not Added.Try again later');
            redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$datacontent['topicUrl'], 'refresh');
        }
    }

    public function add_kc_image_content() {
        if ($this->input->post()) {
            $new_name = time() . $_FILES["img_name"]['name'];
            $config['upload_path'] = './uploads/content_images';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size'] = 51200;
            $config['max_width'] = 1024;
            $config['max_height'] = 1024;
            $config['min_width'] = 50;
            $config['min_height'] = 50;
            $config['file_name'] = $new_name;
            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if (!$this->upload->do_upload('img_name')) {
                $data['error'] = array('error' => $this->upload->display_errors());
                $error = "error";
            } else {
                $uploadData = $this->upload->data();

                $picture = $uploadData['file_name'];
            }
            if ($picture == null) {
                $picture = $this->input->post('old_img_name');
            }
            $data = array(
                'img_title' => $this->input->post('img_title'),
                'img_link' => $this->input->post('img_link'),
                'img_name' => $picture,
                'img_kc_id' => $this->uri->segment(3),
            );
            if ($this->input->post('img_id') !== '') {
                $data['img_id'] = $this->input->post('img_id');
            }
            $this->knowledge_center_model->add_image_content($data);
            $this->session->set_flashdata('notification', 'Added successfully');
            redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->input->post('topicUrl'), 'refresh');
        } else {
            $data['kc'] = $kc;
            $data['kcimage'] = $kcimage;

            $this->load->view('add_image_content', $data);
        }
    }

    public function list_all_image() {
        if ($this->uri->segment(3)) {
//            $kc = $this->knowledge_center_model->editprogram(array('pid' => $this->uri->segment(3)));
//            $kcimage = $this->knowledge_center_model->get_image($this->uri->segment(3));

            if ($this->input->post()) {
                $error = "";
                $this->form_validation->set_rules('img_title', 'Title of image', 'trim|required');
                $this->form_validation->set_rules('img_link', 'Link of image', 'trim|required');
                $error = "";
                $new_name = time() . $_FILES["img_name"]['name'];
                $config['upload_path'] = './uploads/content_images';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = 51200;
                $config['max_width'] = 1024;
                $config['max_height'] = 1024;
                $config['min_width'] = 50;
                $config['min_height'] = 50;
                $config['file_name'] = $new_name;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('img_name')) {
                    $data['error'] = array('error' => $this->upload->display_errors());
                    $error = "error";
                } else {
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }
                if ($this->form_validation->run() == TRUE && $error == '') {
                    $data = array(
                        'img_title' => $this->input->post('img_title'),
                        'img_link' => $this->input->post('img_link'),
                        'img_name' => $picture,
                        'img_kc_id' => $this->uri->segment(3),
                    );
                    $this->knowledge_center_model->add_image_content($data);
                    $this->session->set_flashdata('notification', 'Added successfully');
                    redirect('knowledge_center/add_content/' . $this->uri->segment(3), 'refresh');
                } else {
                    if (isset($picture)) {
                        $file = './uploads/content_images/' . $picture;
                        unlink($file);
                    }
                    $data['kc'] = $kc;
                    $data['kcimage'] = $kcimage;

                    $this->load->view('add_image_content', $data);
                }
            }
        } else {

            redirect('knowledge_center', 'refresh');
        }
    }

    public function edit_image() {
        if ($this->input->post()) {
            $data = $this->knowledge_center_model->edit_image($this->input->post());
            if (!empty($data)) {
                echo json_encode($data);
            } else {
                echo "";
            }
        } else {
            echo "";
        }
    }

    public function update_image($id) {
        if ($this->input->post()) {
            $picture = '';
            if ($_FILES["prg_image"]['name'] != '') {
                $new_name = time() . $_FILES["img_name"]['name'];
                $config['upload_path'] = './uploads/content_images';
                $config['allowed_types'] = 'gif|jpg|png|jpeg';
                $config['max_size'] = 51200;
                $config['max_width'] = 1024;
                $config['max_height'] = 1024;
                $config['min_width'] = 50;
                $config['min_height'] = 50;
                $config['file_name'] = $new_name;
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                if (!$this->upload->do_upload('prg_image')) {
                    $data['error'] = array('error' => $this->upload->display_errors());
                    $error = "error";
                } else {
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }
            }

            if ($picture != '') {
                $data = array(
                    'img_name' => $picture,
                    'img_title' => $this->input->post('prg_name1'),
                    'img_link' => $this->input->post('img_link1'),
                );
            } else {
                $data = array(
                    'img_title' => $this->input->post('prg_name1'),
                    'img_link' => $this->input->post('img_link1'),
                );
            }

            if ($this->knowledge_center_model->update_image($data, $this->input->post('prg_id1'))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('knowledge_center/add_content/' . $id, 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('knowledge_center/add_content/' . $id, 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function delete_image() {
        if ($this->uri->segment(3)) {
            
            if ($this->knowledge_center_model->delete_image($this->uri->segment(3))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('knowledge_center/add_content/' . $this->uri->segment(4).'/'. $this->uri->segment(5), 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('knowledge_center/add_content/' . $this->uri->segment(4).'/'. $this->uri->segment(5), 'refresh');
            }
        } else {
            redirect('knowledge_center');
        }
    }    

    public function add_assessment() {
        $datacontent = $this->input->post();

        $datacontent['edit_action'] = true;
        if ($datacontent['subcontentid'] == '') {
            $datacontent['kc_content']['64'][] = $datacontent['assessment_title'];
            $datacontent['kc_content']['64'][] = 'Elsa Assessment';
            $datacontent['kc_content']['64'][] = '';
            $datacontent['kc_content']['64'][] = '';
            $datacontent['subcontentid'] = $this->knowledge_center_model->add_kc_content($datacontent, $this->uri->segment(3), 'id');
            $datacontent['edit_action'] = false;
        }
        if ($this->knowledge_center_model->add_assessment($datacontent, $this->uri->segment(3))) {
            $this->session->set_flashdata('notification', 'Added successfully');
            redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$datacontent['topicUrl'], 'refresh');
        } else {
            $this->session->set_flashdata('notification', 'Not Added.Try again later');
            redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$datacontent['topicUrl'], 'refresh');
        }
    }

    public function deleteAssessment() {
        if ($this->uri->segment(3)) {           
            if ($this->knowledge_center_model->deleteAssessment($this->uri->segment(3), $this->uri->segment(4))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function publishAssessment() {
        if ($this->uri->segment(3)) {           
            if ($this->knowledge_center_model->publishAssessment($this->uri->segment(3), $this->uri->segment(4))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function cloneAssessment() {
        if ($this->uri->segment(3)) {
            if ($this->knowledge_center_model->cloneAssessment($this->uri->segment(3), $this->uri->segment(4))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            }
        } else {
            echo "";
        }
    }

    public function deleteContent() {
        if ($this->uri->segment(3)) {   
            if ($this->knowledge_center_model->deleteContent($this->uri->segment(3), $this->uri->segment(4))) {
                $this->session->set_flashdata('notification', 'updated successfully');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            } else {
                $this->session->set_flashdata('notification', 'Not updated');
                redirect('knowledge_center/add_content/' . $this->uri->segment(3).'/'.$this->uri->segment(5), 'refresh');
            }
        } else {
            echo "";
        }
    }

}

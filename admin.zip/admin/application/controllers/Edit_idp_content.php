<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Edit_idp_content extends CI_Controller {
	public function __construct()
    {
        parent::__construct();
        $this->load->model('edit_idp_content_model');
        $this->load->model('programs_model');
        if(!$this->session->userdata('email')){
        	redirect('login');
        }
    }

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function client()
	{
           
	if($this->session->userdata('email')){
		$id = $this->uri->segment(4);
                $org_id = $this->uri->segment(3);
		$data['programs']=$this->programs_model->get_data($org_id); 
		$data['row']=$this->edit_idp_content_model->get_data($id);
                $data['urlsegment'] = 'idp_content/'.$this->uri->segment(2).'/'.$this->uri->segment(3);
		
		if(!empty($data['row'])){		
			$data['row1']=$this->edit_idp_content_model->get_extra_data($id);
		}
		$this->load->view('edit_idp_content', $data);
	}else{
		redirect('login');
	}
	}
        public function aggregator()
	{
	if($this->session->userdata('email')){
		$id = $this->uri->segment(4);
                $org_id = $this->uri->segment(3);
		$data['programs']=$this->programs_model->get_data($org_id); 
		$data['row']=$this->edit_idp_content_model->get_data($id);
		$data['urlsegment'] = 'idp_content/'.$this->uri->segment(2).'/'.$this->uri->segment(3);
		if(!empty($data['row'])){		
			$data['row1']=$this->edit_idp_content_model->get_extra_data($id);
		}
		$this->load->view('edit_idp_content', $data);
	}else{
		redirect('login');
	}
	}
	
	
	public function update_data()
	{ 
		 $id = $this->input->post('id');
                 $orgid= $this->input->post('orgid');
                 
		 if($id!=NULL){
                     
		$data['programs']=$this->programs_model->get_data($orgid); 
                
		$data['row']=$this->edit_idp_content_model->get_data($id);
                 
		if(!empty($data['row'])){ 	
			$data['row1']=$this->edit_idp_content_model->get_extra_data($id);
		} 
				$this->form_validation->set_rules('title', 'Title', 'trim|required');
				$this->form_validation->set_rules('subtitle', 'Subtitle ', 'trim|required');
				$this->form_validation->set_rules('description', 'Description', 'trim|required');
				$error="";
//				if(!$this->input->post('programs[]')){
//					$error="Please Enter programs";
//				}  elseif($this->input->post('programs[]')==''){
//					$error="Please Enter programs";
//				}

				if ($this->form_validation->run() === FALSE || $error!=''){			
					$data['error']=$error;
					$this->load->view('edit_idp_content', $data);
                                         
				}else{
		 	$data = array(
		 		'title' => $this->input->post('title'),
		 	    'subtitle' => $this->input->post('subtitle'),
			  	'description' => $this->input->post('description'),
		 	);
		  	$this->edit_idp_content_model->update_data($data, $id,$this->input->post('programs[]'));
          	$this->session->set_flashdata('updatenotification', 'IDP Page content updated successfully');
              
          	redirect($this->input->post('urlsegment'));
          }
      }else{  
		  redirect($_SERVER['HTTP_REFERER']);
      }
	}
	
	
	public function delete(){
		$id = $this->uri->segment(3);
		
		$this->db->where('id', $id);
		$this->db->delete('tbl_idp');

	     $this->session->set_flashdata('deletenotification', 'IDP Page content deleted successfully');
		redirect( base_url('idp_content'));
	}
}

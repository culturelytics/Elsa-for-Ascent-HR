<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">DEVELOPING VALUES</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	Developing Values- "Culture" is a big word which covers a lot of ground. A very brief definition is that culture refers to a set of behaviors, habits, roles, and norms that apply to a particular group. Through BYTES, e2e aims to setup a framework that can catalyse these very emotions in a scientific manner.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	DEVELOPING VALUES
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">One State Street and one AIS</p>
		<ul class="cs-ui">
			<li><a href="https://www.sandler.com/blog/6-benefits-of-teamwork-in-the-workplace" target="_blank">Stronger together- 6 Benefits of Teamwork in the Workplace</a></li>
			<li><a href="https://www.insidehighered.com/blogs/globalhighered/global-citizenship-–-what-are-we-talking-about-and-why-does-it-matter" target="_blank">Global Force- local citizen-- Global Citizenship – What Are We Talking About and Why Does It Matter?</a></li>
			<li><a href="https://www.aegisdentalnetwork.com/idt/2016/08/finding-better-ways-a-model-for-the-future" target="_blank">Always finding better ways- Finding Better Ways: a model for the future</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Customer Centricity</p>
		<ul class="cs-ui">
			<li><a href="https://www.i-scoop.eu/customer-centricity/" target="_blank"></a>Customer-centricity explained – what it means to be customer-centric</li>
			<li><a href="https://www.superoffice.com/blog/how-to-create-a-customer-centric-strategy/" target="_blank">How to Create a Customer Centric Strategy For Your Business</a></li>
			<li><a href="https://www.ama.org/publications/eNewsletters/MarketingInsightsNewsletter/Pages/7-pillars-of-customer-centricity.aspx" target="_blank">The 7 Pillars of Customer Centricity</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Risk Excellence</p>
		<ul class="cs-ui">
			<li><a href="https://www.cgerisk.com/2014/03/how-can-you-use-risk-management-to-achieve-operational-excellence/" target="_blank">How can you use risk management to achieve Operational Excellence?</a></li>
			<li><a href="http://www.industryweek.com/lean-six-sigma/pursue-common-ground-effective-operational-risk-management-and-operational-excellence" target="_blank">Pursue the Common Ground in Effective Operational Risk Management and Operational Excellence</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Appreciation and Value</p>
		<ul class="cs-ui">
			<li><a href="http://www.businessmomentum.org/research/article_appreciation.html" target="_blank">Appreciation in the workplace</a></li>
			<li><a href="https://www.entrepreneur.com/article/244657" target="_blank">Appreciation at Work: Two Major Misconceptions Leaders Hold</a></li>
			<li><a href="http://switchandshift.com/10-key-strategies-to-value-employees-that-increase-profitability" target="_blank">10 Key Strategies to Value Employees That Increase Profitability </a></li>
		</ul>
		</div>
									
		<div class="info-n">
		<p class="abt-sub-titles ab">Feedback-Rich Environment</p>
		<ul class="cs-ui">
			<li><a href="https://www.gsb.stanford.edu/insights/carole-robin-how-create-feedback-rich-environment" target="_blank">Carole Robin: How to Create a Feedback-Rich Environment</a></li>
			<li><a href="https://explorance.com/2013/02/how-to-create-an-effective-feedback-culture-2/" target="_blank">How to Create an Effective Feedback Culture</a></li>
			<li><a href="https://www.chamberplan.ca/business-tips/273-the-essential-elements-for-a-feedback-rich-work-culture" target="_blank">The essential elements for a feedback-rich work culture
​</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Assuming positive intent</p>
		<ul class="cs-ui">
			<li><a href="http://www.zenworkplace.com/2016/03/13/start-by-assuming-positive-intent/" target="_blank">Assume positive intent at work</a></li>
			<li><a href="https://believe.christianmingle.com/the-power-of-assuming-positive-intent/" target="_blank">How To Assume Positive Intent And Avoid Jumping To Conclusions</a></li>
			<li><a href="https://people-equation.com/5-ways-leaders-build-culture-of-trust/" target="_blank">5 Ways Leaders Build a Culture of Trust</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">High performance, Achievement oriented</p>
		<ul class="cs-ui">
			<li><a href="https://www.torbenrick.eu/blog/performance-management/10-key-elements-in-creating-a-high-performance-culture/" target="_blank">Top 10+ key elements in creating a high performance culture</a></li>
			<li><a href="https://www.psychologytoday.com/blog/youre-hired/201110/how-do-high-achievers-really-think" target="_blank">How Do High Achievers Really Think?</a></li>
			<li><a href="http://www.mauricekerrigan.com/blog/what-is-achievement-orientation-and-why-is-it-important/" target="_blank">What is achievement orientation and why is it important?</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Accountability</p>
		<ul class="cs-ui">
			<li><a href="https://soapboxhq.com/create-culture-accountability-workplace/" target="_blank">Make Accountability a Core Part of Your Culture</a></li>
			<li><a href="https://talentculture.com/why-accountability-in-the-workplace-matters/" target="_blank">Why Accountability in the Workplace Matters</a></li>
			<li><a href="https://www.linkedin.com/pulse/responsibility-accountability-should-work-together-really-abu-ghosh-5993785093456408576" target="_blank">Responsibility & Accountability should work together REALLY!!!</a></li>
		</ul>
		</div>						


	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	DEVELOPING MODULES
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Accountability and Ownership</p>
		<ul class="cs-ui">
			<li><a href="#">Difference Between Ownership and Accountability</a></li>
			<li><a href="#">The centrality of ownership and self-accountability</a></li>
			<li><a href="#">Build a Culture of Ownership at Your Company</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Business Communication</p>
		<ul class="cs-ui">
			<li><a href="https://catalog.flatworldknowledge.com/bookhub/reader/15?e=mclean-ch01_s02" target="_blank">Business Communication for Success</a></li>
			<li><a href="http://learningindia.in/forms-of-business-communication-in-india/" target="_blank">The Golden Rule for Choosing the Best Forms of Business Communication in India</a></li>
			<li><a href="https://www.infosciencetoday.org/communication-technology/forms-of-business-communication.html" target="_blank">Forms of Business Communication</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Learning Effective Time Management Techniques</p>
		<ul class="cs-ui">
			<li><a href="http://www.lifehack.org/articles/productivity/10-proven-time-management-skills-you-should-learn-today.html" target="_blank">10 Proven Time Management Skills You Should Learn Today</a></li>
			<li><a href="http://growthcheatsheet.com/time-management-tips-and-strategies/" target="_blank">Time Management Tips & Strategies (Epic How-to Methods)</a></li>
			<li><a href="https://www.nhs.uk/Conditions/stress-anxiety-depression/Pages/Time-management-tips.aspx" target="_blank">Easy time-management tips</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Problem-solving and decision-making</p>
		<ul class="cs-ui">
			<li><a href="https://www.businessballs.com/problem-solving-and-decision-making/decision-making-and-problem-solving-108/" target="_blank">Simple processes for problem-solving and decision-making</a></li>
			<li><a href="https://www.mediate.com/articles/thicks.cfm" target="_blank">Seven Steps for Effective Problem Solving in the Workplace</a></li>
			<li><a href="https://knowhownonprofit.org/login_form?came_from=https://knowhownonprofit.org/people/your-development/professional/problemsolving" target="_blank">Decision making and problem solving</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Interpersonal skills</p>
		<ul class="cs-ui">
			<li><a href="#">11 Interpersonal Skills an Effective Leader Must Possess</a></li>
			<li><a href="https://selfimprovement.org/interpersonal-skills" target="_blank">What are Interpersonal Skills & How to Improve Them</a></li>
			<li><a href="https://www.roberthalf.co.uk/blog/interview-tips/working-room-how-showcase-your-interpersonal-skills-during-job-interview" target="_blank">Working the room: How to showcase your interpersonal skills during a job interview</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">VIDEOS</p>
		<ul class="cs-ui">
			<li><a href="https://www.youtube.com/watch?v=Scals__YL8U" target="_blank">Accountability vs Responsibility</a></li>
			<li><a href="https://www.youtube.com/watch?v=BD0S0eCulHc" target="_blank">How Leaders hold Employees accountable</a></li>
		</ul>
		</div>


	</div>
	</div>
   </div>
	</div>	




</div>	

</div>

<?php
}
?>
            
<?php include('footer.php'); ?>
<?php
session_start();
if(isset($_SESSION["sess_email_kaccess"]) || isset($_SESSION["sess_email_caccess"] )) {
	header("Location: home.php");
}
else
{
?>
<?php
$errormsg="";
?>
<?php
include_once('connectdb.php');

if($ssoenabled){
	echo '<div class="alert alert-warning text-center">Access denied!</div>';
} else if(isset($_POST["submit"])){
	 if(!empty($_POST['email']) && !empty($_POST['password'])){
		 $email = $_POST['email'];
		 $password = $_POST['password'];
		 $email = stripslashes($email);
		 $password = stripslashes($password);  	
		 $query = mysqli_query($dbconnect, "SELECT * FROM tbl_user WHERE BINARY email='".$email."' AND status= 'active' AND password='".$password."'");
		 $numrows = mysqli_num_rows($query);
		 if($numrows !=0) {
			 while($row = mysqli_fetch_assoc($query))
			 {
				$dbemail=$row['email'];
				$dbpassword=$row['password'];
				$kaccess=$row['kaccess'];
				$caccess=$row['caccess'];
				$id=$row['id'];
				$name=$row['name'];
			 }

			$query=mysqli_query($dbconnect,"INSERT INTO `tbl_user_login_history`( `ulh_u_id`,`ulh_start_time`) VALUES ('".$id."','".date('Y-m-d H:i:s')."')");
		 	$last_id = mysqli_insert_id($dbconnect);
		 	
		 		
				if($email == $dbemail && $password == $dbpassword) {
					if($kaccess == "yes") {
						 if($caccess == "yes"){
							 session_start();
							 $_SESSION['sess_email_kaccess']=$email;
							 $_SESSION['sess_email_caccess']=$email;
							 $_SESSION['user_id']=$id;
							 $_SESSION['user_name']=$name;
							 $_SESSION['ul_id']=$last_id;
							 print_r($_SESSION);
							 header("Location: home.php");
						 }else {
							 
							 session_start();
							 $_SESSION['sess_email_kaccess']=$dbemail;
							 $_SESSION['user_id']=$id;
							 $_SESSION['user_name']=$name;
							 $_SESSION['ul_id']=$last_id;
							 header("Location: home.php");
							 
						 }
					 }elseif($kaccess == "no") {
						if($caccess == "yes"){
							 session_start();
							 $_SESSION['sess_email_caccess']=$email;
							 $_SESSION['user_id']=$id;
							 $_SESSION['user_name']=$name;
							 $_SESSION['ul_id']=$last_id;
							 header("Location: home.php");
						 }else {
							header("Location: login.php");
						 }
					 }else {
						 header("Location: login.php");
					 }
					
				 }
			 }
		 else
		 {
		 $errormsg = "Invalid credentials or You are Inactive!";
		 }
	 }
	 else {
			$errormsg = "Required All fields!";
	 }
}
?>
<?php include('header.php'); ?>
<?php if(!$ssoenabled): ?>
<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">LOG IN</h2>
<hr class="line-75">
</div>



<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mob-no-padng" style="margin-bottom: 4%;margin-top: 5%">

<div class="col-lg-4"></div>
<div class="col-lg-4">
     <form action="" id="register-form1" method="POST">
<?php echo $errormsg;?>
 

      <div class="form-sub-w3  left-form-w3-agile" style="padding: 20px">

               <input type="text" class="ar" name="email" placeholder="Email" required="">
               <input type="password" class="ar" name="password" placeholder="Password" required="">
      </div>
      <div class="submit-bg"><input type="submit" value="Log In" name="submit"></div>
      </form>

      
</div>
<div class="col-lg-4"></div>

</div><!--col-12-->

     <div class="login-contact-person text-center">
     <!--<p>For User Name and Password kindly contact ,<br> <span class="ab">Deepak Rahul</span> - <a href="mailto:deepak@e2epeoplepractices.com">deepak@e2epeoplepractices.com</a> , <a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a> <br> Tel : +91 9916520301</p>-->
	 <p><a href="forgot_password.php">Forgot Password</a></p>
     </div>

</div>
<?php endif; ?>

<?php include('footer.php'); ?>
<?php
}
?>	
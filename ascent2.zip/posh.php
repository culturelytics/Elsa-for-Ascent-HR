<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">POSH</p>
    <hr class="line-75">
    <ul class="cs-ui">
    
	   <li class="line-height-30"><a href="https://www.poshatwork.com/sexual-harassment-act-rules/" target="_blank" class="margin-10">Sexual Harassment Act: Rules</a></li>

           <li class="line-height-30"><a href="https://www.peoplematters.in/article/diversity/few-steps-to-remove-the-unconscious-gender-bias-at-workplace-17336" target="_blank" class="margin-10">Few steps to remove the unconscious gender bias at work</a></li>

            <li class="line-height-30"><a href="https://www.nolo.com/legal-encyclopedia/preventing-sexual-harassment-workplace-29851.html" target="_blank" class="margin-10">Preventing sexual harassment at the workplace</a></li>

            <li class="line-height-30"><a href="https://www.nytimes.com/2017/12/11/upshot/sexual-harassment-workplace-prevention-effective.html" target="_blank" class="margin-10">Prevention of sexual harassment</a></li>

            <li class="line-height-30"><a href="https://blog.ipleaders.in/sexual-harassment-at-workplace/" target="_blank" class="margin-10">Sexual harassment at the workplace</a></li>

            <li class="line-height-30"><a href="https://www.youtube.com/watch?v=d0pbHOliQu0" target="_blank" class="margin-10">Understanding sexual harassment</a></li>

            <li class="line-height-30"><a href="https://www.youtube.com/watch?v=DWq_mDJq9IA" target="_blank" class="margin-10">3 ways to avoid sexual harassment</a></li>
            
            <li class="line-height-30"><a href="https://www.youtube.com/watch?v=YmRKlZEXVQM&amp;t=18s" target="_blank" class="margin-10">How I survived workplace bullying: Tedx Talks</a></li>
    </ul>
    </div>



	</div>	
</div>	
</div>

<?php
}
?>
<?php include('footer.php'); ?>
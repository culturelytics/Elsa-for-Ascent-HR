<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Contact:e2e</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="Address:D, Manor House, 19/3/1,Palace Orchards, 8th Main, 18th Cross, Sadashivnagar,Bangalore - 560080. Contact No:+91 80 23615999. Email:info@e2epeoplepractices.com">

        <meta name="keywords" content="Mergers and Acquisitions,Leadership,Learning and Development,Culture Audit,Value Added Business Solution,HR Consulting,Team Bonding,LeAP,Business Alignment,Culture Transition,People Analytics">
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>

<?php
$mail= "";
        if(isset($_POST['submit'])){  
          
        $c_name = $_POST['fname'];
        $c_lname = $_POST['lname'];
        $jobtitle = $_POST['jobtitle'];
        $company = $_POST['company'];
        $c_email = $_POST['email'];
        $c_tel = $_POST['phone'];
        $service = $_POST['service'];
        $location = $_POST['location'];
        $c_msg = $_POST['comments'];
        $to ="info@e2epeoplepractices.com";
        $subject = "Enquiry";
        $txt ="
        Hi, Here u got one new Enquiry.<br><br>
        <b>FIRST_NAME:</b> $c_name<br>
        <b>LAST_NAME:</b> $c_lname<br>
        <b>Job Title:</b> $jobtitle<br>
        <b>Company:</b> $company<br>        
        <b>NUMBER:</b> $c_tel <br>
        <b>MAIL ID:</b> $c_email<br>
        <b>Service:</b> $service<br>
        <b>Location:</b> $location<br>
        <b>Message:</b> $c_msg"; 
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: info@e2epeoplepractices.com" . "\r\n" ."CC: ".$c_email;
       
        if(mail($to,$subject,$txt,$headers)){
        $mail=  ' <span style="color:Green;font-size:16px;font-weight:bold;margin-top:10px"> Mail has been sent</span>';
        }
        else{
        $mail=  '<span style="color:red;font-size:16px;font-weight:bold;margin-top:10px">Something went wrong..</span>';
        }
        }
      ?>





<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 full-col-12">


<h2 class="ar career-title text-center">CONTACT US</h2>
<hr class="line-75">
<!--both sides-->


<div class="col-lg-2 hidden-sm hidden-xs"></div>


<!--left sides-->
		<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 left-form-w3-agile"
		style="padding: 0px">
		<?php echo $mail ?>
			<h2 class="ab">Get In Touch :</h2>
			<form action="" method="post" id="contact-form">
			<div class="upper">
				<div class="form-sub-w3">
					<input type="text" class="ar" name="fname" id="fname" placeholder="First Name" required="">
				</div>

				<div class="form-sub-w3">
					<input type="text" class="ar" name="lname" id="lname" placeholder="Last Name" required="">
				</div>

				<div class="form-sub-w3">
					<input type="text" class="ar" name="jobtitle" id="jobtitle" placeholder="Job Title" required="">
				</div>

				<div class="form-sub-w3">
					<input type="text" class="ar" name="company" id="company" placeholder="Company" required="">
				</div>

				<div class="form-sub-w3">
					<input type="email" class="ar" name="email" id="email" placeholder="Youremail@email.com" required="">
				</div>

				<div class="form-sub-w3">
					<input type="text" class="ar" name="phone" id="phone" placeholder="Phone" required="">
				</div>
                 


				<div class="form-sub-w3">
					<select name="service" id="service">
                        <option value="" disabled="disabled">-- Select Option --</option>
					    <option value="Investor Dashboard">Investor Dashboard</option>
					    <option value="Leadership Potential Capability Audit">Leadership Potential Capability Audit</option>
					    <option value="Inventions & Innovation Propeller">Inventions & Innovation Propeller</option>
					    <option value="Transformational Leadership Programs">Transformational Leadership Programs</option>
					    <option value="Talent Mobility Management">Talent Mobility Management</option>
					    <option value="Start-up Kit">Start-up Kit</option>
					    <option value="BOT Models">BOT Models</option>
					    <option value="Surveys Benchmarks">Surveys Benchmarks</option>
					    <option value="Accelerator Kit">Accelerator Kit</option>
					    <option value="Board Advisory">Board Advisory</option>
					    <option value="Mergers and Acquisitions">Mergers and Acquisitions</option>
					    <option value="HR Consultancy">HR Consultancy</option>
					    <option value="LnOD">LnOD</option>
                    </select> 
				</div>

				<div class="form-sub-w3" style="margin-top: 15px;">
					<select name="location" id="location">
                        
					    <option value="Bangalore">Bangalore</option>
					    <option value="London">London</option>
					    <option value="Melbourne">Melbourne</option>
					    <option value="Dubai">Dubai</option>
                    </select> 
				</div>

				<div class="form-sub-w3">
					<textarea name="comments" id="Comments" placeholder="Your Message" required=""></textarea>
				</div>

			</div>
					<div class="submit-w3l">
					<input type="submit" value="" name="submit">
					</div>
			</form>
			
		</div>


<!--right side-->
		<div class="col-lg-4 col-md-12 col-sm-12 col-xs-12 right-map-w3-agile res-margin-top-30 " style="padding: 0px">
		<h2 class="ab">Locate us :</h2>
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.426538145603!2d77.58074151408411!3d13.008487590831685!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae1635a442d0f9%3A0x81d00337d78def28!2sE2E+People+Practices!5e0!3m2!1sen!2sin!4v1511416764143"></iframe>
			<ul class="add">
				<li class="adrs-li1 ab">Corporate Office :</li>
				<li>e2e People Practices Pvt Ltd</li>
				<li>D, Manor House, 19/3/1,</li>
				<li> Palace Orchards, 8th Main, 18th Cross, Sadashivnagar,</li>
				<li>Bangalore - 560080</li>
				<li style="margin-top: 10px;">Tel: +91 80 23615999</li>
				<li>Write to :<a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a></li>
			</ul>				
		</div>

<div class="col-lg-2 hidden-sm hidden-xs"></div>
<!-- <div class="line-full" style="margin-bottom: 0px"></div> -->
</div>	






<?php include('footer.php'); ?>
<script type="text/javascript">
    $(document).ready(function () {
  
  $("#contact-form").validate({
    rules: {
      fname: "required",
      lname: "required",
        email: {
        required: true,
        email: true
      },
      jobtitle: "required",
      company: "required",
      phone:  {
        required: true,
        minlength: 7,
        number: true,
        maxlength: 15
      },
      comments: "required",

       
     

       
    },
    messages: {
      fname: "Please enter your first name",
      lname: "Please enter your last name",
      comments: "Please enter your message",
      jobtitle: "Please enter your Job Title",
      company: "Please enter your Company Name",
      service: "Please select your service",
      location: "Please select your location",
      phone: {
        required: "Please enter your Mobile number",
        minlength: "Your Mobile number must be atleast 7 number above",
        number: "Please enter only numbers",
        maxlength: "Your Mobile number must be below 12 number"
      },
       
      email: {
        required: "Please enter your email",
        email: "Your email is not validate"
      },
      // confirm_password: {
      //   required: "Please provide a password",
      //   minlength: "Your password must be at least 5 characters long",
      //   equalTo: "Please enter the same password as above"
      // },
      // email: "Please enter a valid email address",
      
    },
    // submitHandler: function (form) { // for demo
    //   alert('valid form');
    //   //return false;
    // }
  });

});
</script>

<script type="text/javascript">
$('select').each(function(){
    var $this = $(this), numberOfOptions = $(this).children('option').length;
  
    $this.addClass('select-hidden'); 
    $this.wrap('<div class="select"></div>');
    $this.after('<div class="select-styled"></div>');

    var $styledSelect = $this.next('div.select-styled');
    $styledSelect.text($this.children('option').eq(0).text());
  
    var $list = $('<ul />', {
        'class': 'select-options'
    }).insertAfter($styledSelect);
  
    for (var i = 0; i < numberOfOptions; i++) {
        $('<li />', {
            text: $this.children('option').eq(i).text(),
            // rel: $this.children('option').eq(i).val()
        }).appendTo($list);
    }
  
    var $listItems = $list.children('li');
  
    $styledSelect.click(function(e) {
        e.stopPropagation();
        $('div.select-styled.active').not(this).each(function(){
            $(this).removeClass('active').next('ul.select-options').hide();
        });
        $(this).toggleClass('active').next('ul.select-options').toggle();
    });
  
    $listItems.click(function(e) {
        e.stopPropagation();
        $styledSelect.text($(this).text()).removeClass('active');
        // $this.val($(this).attr('rel'));
        $list.hide();
        //console.log($this.val());
    });
  
    $(document).click(function() {
        $styledSelect.removeClass('active');
        $list.hide();
    });

});
</script>
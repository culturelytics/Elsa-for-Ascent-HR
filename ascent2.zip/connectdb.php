<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $databasename = "elsa_ims_db";
    $dbconnect = new mysqli($servername, $username, $password, $databasename);

    if($dbconnect === false){
        die("ERROR: Could not connect. " . $mysqli->connect_error);
    }

	ini_set('display_errors', 1);

    $pri_logo = 'images/e2e-logo.png';
    $sec_logo = 'images/e2e-logo.png';
	// for e2e it is index.php and for others it is home.php
    $pri_logo_url = 'index.php';
    $coprights = 'Copyright &copy; ' . Date('Y') . ' e2e People Practices';

    $ssoenabled = false;
    $clienturls = array(
        array('id' => 1, 'name' => 'AcsentHR', 'url' => 'ascenthr.com'),
        array('id' => 2, 'name' => 'Client 2', 'url' => 'client2.com')
    );
?>
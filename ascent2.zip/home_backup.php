<?php include('header.php'); ?>
<?php

include_once("connectdb.php");
if(!isset($_SESSION["sess_email_kaccess"]) && !isset($_SESSION["sess_email_caccess"])){
header("Location: login.php");
}
else
{
?>
<div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<input class="search" id="autocomplete" placeholder="    Ask ELSA.." style="background-color:GreenYellow;margin: 30px;width: 300px; float:right" />
	</div>
</div>
<div class="row">
	  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	  	<!-- Centered Tabs -->
		<ul class="nav nav-tabs nav-justified col-transparent" role="tablist" id="tabsmain">
			<li role="presentation" class="active"><a aria-controls="pg-dashboard" role="tab" data-toggle="tab" href="#pg-dashboard">Dashboard</a></li>
			<li role="presentation"><a aria-controls="pg-elsa" role="tab" data-toggle="tab" href="#pg-elsa">ELSA</a></li>
			<li role="presentation"><a aria-controls="pg-client" role="tab" data-toggle="tab" href="#pg-client">Client</a></li>
		</ul>
		<div class="tab-content">
			<div role="tabpanel" class="tab-pane fade in active" id="pg-dashboard">
				<?php require_once("dashboard.php"); ?>
			</div>
			<div role="tabpanel" class="tab-pane fade" id="pg-elsa">
				<?php require_once("e2e-library.php"); ?>
			</div>
			<div role="tabpanel" class="tab-pane fade" id="pg-client">
				<?php require_once("clients.php"); ?>
			</div>
		</div>
	  </div>
	</div>

<?php
}
?>
<?php include('footer.php'); ?>
<script>
jQuery(document).ready(function(){
     jQuery("#tabsmain").tabs();
  });
</script>
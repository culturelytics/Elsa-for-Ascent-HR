<?php include('header.php'); ?>
<?php
if(isset($_SESSION["sess_email_kaccess"]) || isset($_SESSION["sess_email_caccess"] )) {
header("Location: index.php");
}
else
{
if(isset($_POST['submit']) && $_POST['submit']=='register'){
include_once('connectdb.php');
$name=mysqli_real_escape_string($dbconnect,$_POST['first_name']);
$email=mysqli_real_escape_string($dbconnect,$_POST['email']);
$password=mysqli_real_escape_string($dbconnect,$_POST['password']);
$contact=mysqli_real_escape_string($dbconnect,$_POST['mobile']);
$last_name=mysqli_real_escape_string($dbconnect,$_POST['last_name']);
$age=mysqli_real_escape_string($dbconnect,$_POST['age']);
$gender=isset($_POST['gender'])?mysqli_real_escape_string($dbconnect,$_POST['gender']):'';
$linkedin=mysqli_real_escape_string($dbconnect,$_POST['linkedin']);
$twitter=mysqli_real_escape_string($dbconnect,$_POST['twitter']);
$confirm_password=mysqli_real_escape_string($dbconnect,$_POST['confirm_password']);
$organization=mysqli_real_escape_string($dbconnect,$_POST['organization']);

$confirm_password1='';
$val_name="";$val_email="";
$val_password=""; $val_contact=""; $val_last_name=""; $val_age=""; $val_gender="";$val_confirm_password="";$val_confirm_password1="";
$val_organization="";
if($name==''){
  $val_name="First name is required";
}
if($email=='' || (!filter_var($email, FILTER_VALIDATE_EMAIL))){
  $val_email="Email is required";
}
if($password==''){
  $val_password="Password is required";
}
if(!(strlen($password)>=4 && strlen($password)<=10)){
  $val_password="Password len is min 4 max 10";
}
if($confirm_password==''){
  $val_confirm_password="Confirm Password is required";
}
if($confirm_password!=$password){
$val_confirm_password1="Password Mismatch";
}
//if($contact=='' || !preg_match('/^[0-9]{10}+$/', $contact)){
 //$val_contact="Mobile Number is required";
//} TO REMOVE MOBILE NUMBER FOR REQUIRED

if($last_name==''){
  $val_last_name="Last name is required";
}
if($age==''){
  $val_age="Age is required";
}
if($gender==''){
  $val_gender="Gender is required";
}
if($organization==''){
  $val_organization="Organization is required";
}

 $val_twitter=$twitter; 
 $val_linkedin=$linkedin; 

if($email!=''){
  $q=mysqli_query($dbconnect,"select * from tbl_user where email='".$email."'");
  $rowcount=mysqli_num_rows($q);
  if($rowcount>0){
    $val_email="E-mail id is already registered";
  }

} 
//&& $val_contact==""  <REMOVED FOR RMOVING IT FROM REQUIRED
if($val_name=="" && $val_email=="" && $val_password==""  && $val_last_name=="" && $val_age=="" && $val_gender=="" && $val_confirm_password1==""  && $val_confirm_password=="") {
  mysqli_query($dbconnect,"INSERT INTO `tbl_user`( `name`, `email`, `password`, `contact`,  `last_name`, `age`, `gender`, `linkedin`, `twitter`,`status`,`organization`) VALUES ('".$name."'
    , '".$email."', '".$password."', '".$contact."',  '".$last_name."', '".$age."', '".$gender."', '".$linkedin."', '".$twitter."','inactive','".$organization."')");
 if(mysqli_affected_rows($dbconnect)>0){
    $_SESSION['register']=1;
$to = $email;
$subject = "New User Registered";

$message = "
<html>
<body>
<p>New User Registered</p>
<table>
<tr>
<th>Firstname</th>
<th>Lastname</th>
<th>Email</th>
<th>Mobile</th>
<th>Password</th>
</tr>
<tr>
<th>".$name."</th>
<th>".$last_name."</th>
<th>".$email."</th>
<th>".$contact."</th>
<th>".$password."</th>
</tr>
</table>
</body>
</html>
";

$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
$headers .= 'From: <info@e2epeoplepractices.com>' . "\r\n";
mail('info@e2epeoplepractices.com', $subject,$message ,$headers);

 }else{
    $_SESSION['register']=2;
 }
}else{

    $_SESSION['register']=3;
}
}
?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">Register</h2>
<hr class="line-75">
</div>


<div class="registercon">
<p class="bkt" style="text-align: center;">Register with us by filling the below form</p>
<?php 
if( isset($_SESSION['register']) && $_SESSION['register']==1){
 ?>
  <center><p class="bkt" style="background: #13a474;padding: 5px;margin-top: 15px;">Thank You for registering with us! You will receive a confirmation e-mail that enables your account.</p></center>
<?php 
unset($_SESSION['register']);
$_POST=array();
if(isset($val_linkedin)){$val_linkedin='';}
if(isset($val_twitter)){$val_twitter='';}
}else if( isset($_SESSION['register']) && $_SESSION['register']==2){
  unset($_SESSION['register']);
 ?>
  <p class="bkt" style="text-align: center;">Data Not Saved.Try again later</p>
<?php }else if( isset($_SESSION['register']) && $_SESSION['register']==3){
  unset($_SESSION['register']);
  ?>
<center><p class="bkt" style="background: #a41319;padding: 5px;margin-top: 15px;">Enter all mandatory fields</p></center>
<?php } ?>

<form method="post" name="customerData" enctype="multipart/form-data" action="" id="programregister-form" style="width: 100%;">

 <div class="logincontainer loginfields">
 <div class="col-md-6">
	 <div class="">
    <input type="text" name="first_name" class="required"  placeholder="First Name" value="<?php echo isset($_POST['first_name'])?$_POST['first_name']:''?>">
    <?php echo isset($val_name)?$val_name:''?>
  </div>
    <div class="">
    <input type="text" name="last_name" class="required" placeholder="Last Name" value="<?php echo isset($_POST['last_name'])?$_POST['last_name']:''?>">
    <?php echo isset($val_last_name)?$val_last_name:''?>
  </div>

     <div class="">
    <input type="text" name="organization" class="required" placeholder="Organization/business/profession/others" value="<?php echo isset($_POST['organization'])?$_POST['organization']:''?>">
    <?php echo isset($val_organization)?$val_organization:''?>
  </div>

  <div class="">
    <input type="email"  value="<?php echo isset($_POST['email'])?$_POST['email']:'';?>" name="email" class="required" placeholder="Email" >
    <?php echo isset($val_email)?$val_email:''?>
  </div>
  <div class="">
    <input type="text" name="mobile" class="" placeholder="Mobile No" value="<?php echo isset($_POST['mobile'])?$_POST['mobile']:''?>"> 
    <?php echo isset($val_contact)?$val_contact:''?>
  </div>
 </div>
 
 <div class="col-md-6">
 <div class="">
    <input type="password" name="password" class="required" placeholder="Password"> 
    <?php echo isset($val_password)?$val_password:''?>
  </div>
  <div class="">
    <input type="password" name="confirm_password" class="required" placeholder="Confirm password"> 
    <?php echo isset($val_confirm_password)?$val_confirm_password:''?>
    <?php echo isset($val_confirm_password1)?$val_confirm_password1:''?>
  </div>

   <div class="">
    <input type="text" name="linkedin" class="" placeholder="Linkedin" value="<?php echo isset($val_linkedin)?$val_linkedin:''?>" > 
   
  </div>
  <div class="">
    <input type="text" name="twitter" class="" placeholder="Twitter" value="<?php echo isset($val_twitter)?$val_twitter:''?>"> 

  </div>

  <div class="">
    <select class="required" name="age" style="width: 100%;background: transparent;border: solid 1px #fff;border-radius: 3px;height: 35px;color:#fff">
      <option value="">Age</option>
      <option value="1" <?php echo isset($_POST['age']) && $_POST['age']=='1' ?'selected':''?> >21-36</option>
      <option value="2" <?php echo isset($_POST['age']) && $_POST['age']=='2' ?'selected':''?>>37-50</option>
      <option value="3" <?php echo isset($_POST['age']) && $_POST['age']=='3' ?'selected':''?>>50+</option>
    </select>
    <?php echo isset($val_age)?$val_age:''?>
  </div>

  <div class="methods" style="margin-top: 10px;"><b>Gender : </b>
	<label>
    <input type="radio" name="gender" value="male" <?php echo isset($_POST['gender']) && $_POST['gender']=='1' ?'checked':'checked'?>>Male&nbsp;&nbsp;
	</label>
	<label>
    <input type="radio" name="gender" value="female" <?php echo isset($_POST['gender']) && $_POST['gender']=='1' ?'checked':''?>>Female<br>
    <?php echo isset($val_gender)?$val_gender:''?>
	</label>
  </div>
 </div>
 
  
  <button type="reg_submit" name="submit" value="register">Register</button>
   </div> 
</form>
</div>

</div>
 
 
<?php include('footer.php');
}
 ?>
<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">TEAM BONDING</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	Team Bonding - Ability to identify and motivate individual employees to form a team that stays together, works together, and achieves together.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	TEAM BONDING
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">Team bonding</p>
		<ul class="cs-ui">
			<li><a href="https://www.thebalance.com/what-is-team-building-1918270" target="_blank">What Is Team Building?</a></li>
			<li><a href="https://www.teambonding.com/team-building-for-work/" target="_blank">Team Bonding v.s. Team Building For Work</a></li>
			<li><a href="https://redshoespr.com/5-reasons-why-team-building-is-important/" target="_blank">Why team building is important</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Types of Team Building</p>
		<ul class="cs-ui">
			<li><a href="#">Four different types of team building</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Team goals</p>
		<ul class="cs-ui">
			<li><a href="#">Top 11 Advantages and Disadvantages of Working in a Team</a></li>
			<li><a href="https://www.roberthalf.ca/en/blog/management-tips/setting-team-goals-how-to-ensure-no-ideas-are-left-out" target="_blank">Setting Team Goals</a></li>
			<li><a href="http://smallbusiness.chron.com/examples-goals-objectives-workplace-18579.html" target="_blank">Examples of Goals & Objectives in the Workplace</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Team Building Activities</p>
		<ul class="cs-ui">
			<li><a href="https://wheniwork.com/blog/team-building-games/" target="_blank">An Epic List of Great Team Building Games</a></li>
			<li><a href="https://www.youtube.com/watch?v=xFxavUOfn9k" target="_blank">Team building video</a></li>
			<li><a href="https://www.youtube.com/watch?v=7mhhU4Wbqi8" target="_blank">60 Seconds to Do Good - Fun Team Building & Networking Game Solutions</a></li>
		</ul>
		</div>
									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng lg-border-left">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">



	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/future-shock.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text color-white">Future Shock by Alvin Toffler</p>
	<ul class="cs-ui">
	<li><a href="https://en.wikipedia.org/wiki/Alvin_Toffler" target="_blank">About Alvin Toffler</a></li>
	<li><a href="https://en.wikipedia.org/wiki/Future_Shock" target="_blank">Future Shock- book</a></li>
	<li><a href="https://www.youtube.com/watch?v=fkUwXenBokU" target="_blank">Future Shock Documentary (1972) - 'Future Shock' is a documentary film based on the book writtenin 1970 by sociologist and futurist Alvin Toffler. Released in 1972, with a cigar-chomping Orson Welles as on-screen narrator, this piece of futurism is darkly dystopian and oozing techno-paranoia.</a></li>
	<li><a>4 Things Futurist Alvin Toffler Predicted About Work Back in 1970</a></li>
	</ul>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/pulling-togather.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.google.co.in/aclk?sa=L&ai=DChcSEwiup-LfpIrTAhUNbn4KHa_RDycYABABGgJwYw&sig=AOD64_1t_UwOrVraTSW7TuLy4iTD7AiATQ&ctype=5&q=&ved=0ahUKEwiP2d_fpIrTAhUMymMKHTS3ArAQ9A4Ieg&adurl=" target="_blank">Pulling Together:10 Rules for High-Performance Teamwork by John J. Murphy
​</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/a-team-of-leaders.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://amzn.to/1Rzg7An" target="_blank">A Team of Leaders: Empowering Every Member to Take Ownership, Demonstrate Initiative, and Deliver Results by Paul Gustavson and Stewart Liff</a></p>
	</div>
	</div>



	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


 <?php
 }
 ?>           
<?php include('footer.php'); ?>
<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>
<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">SALES COMMUNICATION</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	A salesperson’s success is linked to his or her ability to communicate clearly, concisely, and openly, while maintaining positive client relationships. This involves strong presentation skills, the ability to engage in business conversations with customers at all levels, negotiating from a win-win stance, and communicating customer needs within their own company. Furthermore, it’s critical for salespeople to adapt their message to the needs and preferences of the customer.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	SALES COMMUNICATION
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Introduction to Sales Communication</p>
		<ul class="cs-ui">
			<li><a href="https://www.thebalance.com/communication-skills-sales-people-2917513" target="_blank">Communication Skills for Salespeople</a></li>
			<li><a href="https://thesaleshunter.com/resources/articles/communication-skills/communication-tips/" target="_blank">10 Communication Tips to Boost Your Sales</a></li>
			<li><a href="https://blog.hubspot.com/sales/communication-skills-sales" target="_blank">13 Communication Skills That Are Crucial to Sales Success</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Sales Communication Styles</p>
		<ul class="cs-ui">
			<li><a href="https://www.slideshare.net/earlstevens58/4-sales-training-communication-styles" target="_blank">Sales training communication styles (Slide Share)</a></li>
			<li><a href="http://troyspro.com.au/sales/5-top-principles-of-communication-style-in-sales-sales-communication/" target="_blank">5 Top Principles of Communication Style in Sales</a></li>
			<li><a href="https://benefitsbridge.unitedconcordia.com/different-communication-styles-work-manage/" target="_blank">Different Communication Styles at Work and How to Manage Them</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Sales Communication Techniques</p>
		<ul class="cs-ui">
			<li><a href="http://www.sellbetter.ca/news/three-proven-communication-techniques-for-sales-success/" target="_blank">​Three Proven Communication Techniques for Sales Success</a></li>
			<li><a href="https://www.forconstructionpros.com/business/article/10288514/communication-techniques-that-win-sales" target="_blank">Communication Techniques That Win Sales</a></li>
			<li><a href="https://www.salesreadinessgroup.com/blog/techniques-for-building-sales-relationships" target="_blank">Three Simple Techniques for Building Sales Relationships</a></li>
			<li><a href="https://blog.hubspot.com/sales/communication-skills-sales" target="_blank">13 Communication Skills That Are Crucial to Sales Success</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">VIDEOS</p>
		<ul class="cs-ui">
			<li><a href="https://www.youtube.com/watch?v=xp1RVqT_-FI&feature=youtu.be" target="_blank">3 Steps to Effective Communication in Sales</a></li>
			<li><a href="https://www.youtube.com/watch?v=EYSP6g1Ce2c&feature=youtu.be" target="_blank">Role Play - Selling Skills; Communication - OTEN TAFE</a></li>
			<li><a href="https://www.youtube.com/watch?v=Ml4CMlXAU7k&feature=youtu.be" target="_blank">Is Your Sales Communication Style FLEXIBLE?</a></li>
		</ul>
		</div>


	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/sales-bible.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://smallbiztrends.com/2015/12/sales-bible-book-review.html" target="_blank">The Sales Bible: The Ultimate Sales Resource by Jeffrey Gitomer</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/brain.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.nairaland.com/4002399/book-summary-psychology-selling-brian" target="_blank">The Psychology Of Selling By Brian Tracy</a></p>
	</div>
	</div>





	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
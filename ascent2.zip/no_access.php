<?php
session_start();
  if(isset($_SESSION["sess_email_kaccess"])){
?>
<?php include('header.php'); ?>

<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">No Access</h2>
<hr class="line-75">
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
   <p>No access to view a client page.</p> 
</div>
</div>
<?php include('footer.php'); ?>
<?php 
  }else{
    header("Location: login.php");  
  }
?>

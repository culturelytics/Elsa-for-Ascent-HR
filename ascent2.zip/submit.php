<?php
    if (!isset($_SESSION)) {
        session_start();
    }

	include_once('connectdb.php');
	
//print_r($_REQUEST); // Establishing Connection 
if($_REQUEST['method']=='save'){

$name=$_POST['name'];
$module=$_POST['module'];
$sdate=$_POST['sdate'];
$cdate=$_POST['cdate'];
$dstop=$_POST['dstop'];
$department=$_POST['department'];
$sign=$_POST['sign'];
$consequence=$_POST['consequence'];
$dstart=$_POST['dstart'];
$idp_id_from_uip=$_POST['idp_id_from_uip'];
$benefits=$_POST['benefits'];
$aplan=$_POST['aplan'];
$mypas=$_POST['mypas'];
$progress=$_POST['progress'];
if($_POST['week1']== 'null'){
	$week1= '';
}else{
	$week1= $_POST['week1'];
}
if($_POST['week2']== 'null'){
	$week2='';
}else{
	$week2= $_POST['week2'];
}
if($_POST['week3']== 'null'){
	$week3='';
}else{
	$week3= $_POST['week3'];
}
if($_POST['week4']== 'null'){
	$week4= '';
}else{
	$week4= $_POST['week4'];
}

$user_id=$_SESSION['user_id'];
$query = mysqli_query($dbconnect,"insert into tbl_query(name, module, sdate, cdate, department, sign, dstop, consequence, dstart, benefits, aplan, mypas, progress, week1, week2, week3, week4,user_id,idp_id_from_uip) values ('".$name."', '".$module."', '".$sdate."','".$cdate."','".$department."','".$sign."','".$dstop."', '".$consequence."', '".$dstart."','".$benefits."', '".$aplan."', '".$mypas."','".$progress."','".$week1."','".$week2."','".$week3."','".$week4."','".$user_id."','".$idp_id_from_uip."')");

echo "Your form has been successfully submitted.";


}

if($_REQUEST['method']=='view_last_data'){

$user_id=$_SESSION['user_id'];
$mod=$_POST['module'];
$idp_id_from_uip=$_POST['idp_id_from_uip'];

$sql = "select * from tbl_query where user_id='".$user_id."' and module='".$mod."' and idp_id_from_uip = '".$idp_id_from_uip."' order by id desc limit 1";
$result3=mysqli_query($dbconnect, $sql);
$res3 = mysqli_fetch_array($result3);

$name=$res3[1];
$sdate=$res3[3];
$cdate=$res3[4];
$department=$res3[5];
$sign=$res3[6];
$dstop=$res3[7];
$consequence=$res3[8];
$dstart=$res3[9];
$benefits=$res3[10];
$aplan=$res3[11];
$mypas=$res3[12];
$progress=$res3[13];
$week1=$res3[14];
$week2=$res3[15];
$week3=$res3[16];
$week4=$res3[17];
echo $name."|*|".$sdate."|*|".$cdate."|*|".$department."|*|".$sign."|*|".$dstop."|*|".$consequence."|*|".$dstart."|*|".$benefits."|*|".$aplan."|*|".$mypas."|*|".$progress."|*|".$week1."|*|".$week2."|*|".$week3."|*|".$week4;
}

if($_REQUEST['method']=='getmodulecontent'){
	$user_id=$_SESSION['user_id'];
	$idp_id_from_uip = $_POST['idp_id_from_uip'];
	$mod = $_POST['module'];
	
	$sql4 = "SELECT id, userid, idpid, idpmoduleid, LEFT(description , 150), docs FROM tbl_user_modulecontent WHERE userid='".$user_id."' and idpid='".$idp_id_from_uip."' and idpmoduleid = '".$mod."'";
	
	$result4 = mysqli_query($dbconnect, $sql4);
	$res4 = mysqli_fetch_row($result4);
	if($res4 == NULL){
		$result_html = 'NULL';
		echo json_encode($result_html);
	}else {
		echo json_encode($res4);
		//print_r($res4[4]);
	}
	
}
mysqli_close($dbconnect); // Connection Closed
?>
<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">CORPORATE SOCIAL RESPONSIBILITY</h2>
<hr class="line-75">
</div>

<p class="ab">THE CAUSE WE DEEPLY CARE ABOUT AND THE NGOs WE SUPPORT :</p>

<div class="col-lg-12">
<div class="col-lg-6" style="padding: 20px 0px">
	<div class="col-lg-3">
		<img src="images/ithy.jpg">
	</div>
	<div class="col-lg-9">
		<p class="ab abt-sub-titles" style="color:greenyellow;">Ithy-ADee</p>
		<p>Ithy-ADee’s vision is to Accelerate Adoption of Handlooms in households across the world, through weaver programs, training and developing weavers’ in self sustained programs.</p>
		<p style="margin-top: 10px">For more information, visit : <a href="https://www.ithyadee.com/" target="_blank">www.ithyadee.com</a></p>
	</div>
</div>

<div class="col-lg-6" style="padding: 20px 0px">
	<div class="col-lg-3">
		<img src="images/i-create.jpg">
	</div>
	<div class="col-lg-9">
		<p class="ab abt-sub-titles" style="color:greenyellow;">i-create</p>
		<p>Developing Entrepreneurs in India What Started as a compassionate act which has now turned in to a movement for entrepreneurship development for the underprivileged and disadvantaged.</p>
		<p style="margin-top: 10px">For more information, visit : <a href="http://www.icreateincorporated.org/" target="_blank">www.icreateincorporated.org</a></p>
	</div>
</div>
</div>



<div class="col-lg-12">
<div class="col-lg-6" style="padding: 20px 0px">
	<div class="col-lg-3">
		<img src="images/shanti.jpg">
	</div>
	<div class="col-lg-9">
		<p class="ab abt-sub-titles" style="color:greenyellow;">Shantibhavan</p>
		<p>Shantibhavan redefines what is possible, they bring children from generational poverty to life of dignity and achievement. They follow an unprecedented education model that reaches beyond individual students to tackle poverty and create positive changes in their families and communities.</p>
		<p style="margin-top: 10px">For more information, visit : <a href="http://www.shantibhavanchildren.org/" target="_blank">www.shantibhavanchildren.org</a></p>
	</div>
</div>


<div class="col-lg-6" style="padding: 20px 0px">
	<div class="col-lg-3">
		<img src="images/sama.jpg">
	</div>
	<div class="col-lg-9">
		<p class="ab abt-sub-titles" style="color:greenyellow;">Samatvam</p>
		<p>Founded in 1993, Samatvam (= equanimity) has three core areas: health care, education and research. Through the combination of our care and treatment provision, development programs and research and training activities, Samatvam has become a prominent national and international entity, serving all socioeconomic segments of our society.  The fundamental foundation is the integration of science and spirituality in the context of health care.</p>
		<p style="margin-top: 10px">For more information, visit : <a href="http://www.samatvam.in/" target="_blank">www.samatvam.in</a></p>
	</div>
</div>
</div>

</div>

<?php include('footer.php'); ?>
<?php
    if (!isset($_SESSION)) {
        session_start();
    }

    include_once('connectdb.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Elsa</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="author" href="https://plus.google.com/yourpersonalprofile">
    <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
    <link href="css/css.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
    <link rel="stylesheet" href="css/m/font-awesome.min.css">
    <link rel="stylesheet" href="css/m/animate.min.css">
    <link rel="stylesheet" href="css/m/default.min.css">
    <link rel="stylesheet" href="css/m/demo.css">
    <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
    <link rel="stylesheet" href="css/loading-bar.min.css">
    <link rel="shortcut icon" href="images/fav_e2e2.ico" />
    <script src="js/m/modernizr.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script charset="UTF-8" src="//cdn.sendpulse.com/js/push/db8cde1c62db5073de7f1354dfe65ed7_0.js" async></script>
</head>
<body class="<?php if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { echo 'noscroll'; } ?>">
    <div class="comn-bg">
        <div class="container  <?php if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { echo 'lheader'; } ?>">
            <?php if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { ?>
            <div class="col-lg-12 col-sm-12 col-xs-12 header-pdng">
                <div class="logo logo-left">
                    <!--a href="?php echo $pri_logo_url; ?-->"><a href="index.php">
                        <img src="<?php echo $pri_logo ?>" class="header-logo" alt="Logo">
                    </a>
                </div>
                <div class="logo logo-right">
                    <img src="<?php echo $sec_logo ?>" class="header-logo" alt="image">
                </div>
                <div class="header-strip">
                    <div class="nav-li li-login" style="margin-top: 10px;padding-left: 0px">
                        <a href="home.php" class="login-btn" title="Home"><i class="fa fa-home"></i></a>
                        <a href="logout.php" class="login-btn" title="Logout"><i class="fa fa-power-off"></i></a>
                    </div>
                </div>
                <div class="header-strip title">
                    Welcome,&nbsp;<font><?php echo $_SESSION['user_name']; ?></font>
                </div>
            </div>
            <?php } else { ?>
            <div class="col-lg-12 col-sm-12 col-xs-12 header-pdng all-border-btm">
                <div class="col-lg-3 col-sm-12 col-xs-12 center-below-992">
                  <a href="index.php">  <img src="<?php echo $pri_logo ?>" class="header-logo" alt="Logo" ></a>
                </div>
                <div class="col-lg-9  col-sm-12 col-xs-12 li-details header-strip " style="margin-top: 15px;">
                    <div class="col-lg-3 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
                        <span style="color:red;" class="ar">Quick Contact : </span>+91 80 23615999
                    </div>
                    <div class="col-lg-3 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
                        <span class="ar"></span><a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a>
                    </div>
                    <div class="col-lg-2" style="margin-top: 9px;"><a href="program-register.php" class="login-btn" style="padding: 9px 9px;font-size: 12px;">e2e pay</a></div>
                    <div class="col-lg-3  col-sm-6 col-xs-6 nav-li li-login" style="margin-top: 10px;padding-left: 0px">
                        <!-- <a href="login.php" class="login-btn">Log In</a> -->
                        <?php if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { ?>
                            <a href="logout.php" class="login-btn">Logout</a>
                        <?php } else { ?>
                            <a href="login.php" class="login-btn">Log In</a>
                        <?php } ?>
                        <?php
                        if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { ?>
                        <?php } else { ?>
                            <a href="register.php" class="login-btn">Register</a>
                        <?php } ?>

                    </div>
                    <div class="col-lg-1  col-sm-6 col-xs-6 toggle-menu right0-abv768">
                        <div class="nav-li-last w3-button w3-xlarge" style="float: right;" onclick="w3_open()">
							
                            <div class="icon"></div>
                            <div class="icon"></div>
                            <div class="icon"></div>
                        </div>
                    </div>
					 

                </div>
            </div>
            <?php } ?>
        </div>

        <div class="container <?php if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { echo 'lcontent'; } ?>">
	
<?php include('header.php'); ?>
<html>
	<meta name="viewport" content="width-device-width, initial-scale=1.0">
	<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/base/jquery-ui.css" rel="stylesheet" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js"></script>
	
	<style>
        .content{
          margin-left: 50px;
          font-size: 16px;
			margin-bottom: 20px;
         }
		input[type=text], select {
          width: 40%;
			padding: 10px;
          margin: 8px 0;
          display: inline-block;
          border: 1px solid #ccc;
          border-radius:3px;
          box-sizing: border-box;
			background-color:#092840;
			color: white;
           }
		input[type=email], select {
          width: 40%;
			padding: 10px;
          margin: 8px 0;
          display: inline-block;
         border: 1px solid #ccc;
          border-radius:3px;
          box-sizing: border-box;
			/*border: none;
    border-bottom: 1px solid #fff;*/
			background-color:#092840;
			color: white;
           }
       input[type=submit] {
         width: 40%;
         background-color: #4CAF50;
         color: white;
         padding: 14px 20px;
         margin-top: 30px;
         margin-left: 300px;
         border: none;
         border-radius: 4px;
         cursor: pointer;
          }
	.product-list,.clarity-list,.case-list,.knowledge-list,.presentation-list,.examples-list,.queries-list,.impact-list{
	width: 15px;
	height: 15px;
      }
		.indicates{
			margin-left: 300px;
			font-size: 18px;
		margin-top: 30px;
		}
		@media only screen and (max-width:420px){
			input[type=submit]{
			 margin-left: 50px;
			}
		 .product-list{
			 display:inline;
			margin-left:-10px;
			}
			input[type=checkbox]{
			display:inline;
			margin-left:-60px;
			}
		.new{
			margin-left:-200px;}
		}
	</style>
	
<body>
	<center><h3 class="title">FEEDBACK FORM</h3></center>
	
         <p class="content"> Dear  Participant,<br>
          We thank you for attending the Workshop, We Would like you to share your views.</p>
	<div class="container">
         <form action="display.php" method="post" name="feed">
Name:* <input type="text" name="firstname" required autocomplete="off" style="margin-left: 40px;margin-right:10px;">
  Email:* <input type="email" id="textemail" name="email" required autocomplete="off" style="margin-left: 20px;"><br>
    Desgination:* <input type="text" name="desg" required autocomplete="off" style="margin-left: 5px;">
      Contact:* <input type="text" name="contact" required autocomplete="off" pattern="[0-9]{10}" style="margin-left: 15px;"><br>
             Date Of Birth:* <input type="text" name="dob" id="tbDate" autocomplete="off" required placeholder="DD/MM/YYYY" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])/(0[1-9]|1[012])/[0-9]{4}">
             Company:* <input type="text" name="company" required autocomplete="off" style="margin-left:3px;"><br>
      Date:* <input type="text" name="date" required id="tbDate1" autocomplete="off" style="margin-left: 50px;" placeholder="DD/MM/YYYY" pattern="(0[1-9]|1[0-9]|2[0-9]|3[01])/(0[1-9]|1[012])/[0-9]{4}">
           Program:* <input type="text" name="program" autocomplete="off" required style="margin-left: 10px;"><br>
			 
             1.Feedback on Content(Please Select anyone of them) <br>			 
			 <span class="new" style="margin-left: 220px"><span class="new">a.Coverage of Subject:*</span>
		   <input type="checkbox" name="coverage" value="1" class="product-list" style="margin-left: 60px;margin-top:10px;"> Poor
           <input type="checkbox" name="coverage" value="2" class="product-list" style="margin-left: 20px;margin-top:10px;"> Average
    <input type="checkbox" name="coverage" value="3" class="product-list" style="margin-left: 20px;margin-top:10px;"> Good
         <input type="checkbox" name="coverage" value="4" class="product-list" style="margin-left: 20px;margin-top:10px;"> Very Good
 <input type="checkbox" name="coverage" value="5" class="product-list" style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
			 <span style="margin-left: 220px"><span class="new">b.Clarity of Objective:*</span>
		<input type="checkbox" name="clarity" value="1"  class="clarity-list" style="margin-left: 69px;margin-top:10px;"> Poor
          <input type="checkbox" name="clarity" value="2" class="clarity-list" style="margin-left: 20px;margin-top:10px;"> Average
      <input type="checkbox" name="clarity" value="3" class="clarity-list" style="margin-left: 20px;margin-top:10px;"> Good
    <input type="checkbox" name="clarity" value="4" class="clarity-list" style="margin-left: 20px;margin-top:10px;"> Very Good
<input type="checkbox" name="clarity" value="5"  class="clarity-list"style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
			 <span style="margin-left: 220px" ><span class="new">c.Case Study/Exercises:*</span>
<input type="checkbox" name="casestudy" value="1" class="case-list" style="margin-left: 50px;margin-top:10px;"> Poor
         <input type="checkbox" name="casestudy" value="2" class="case-list" style="margin-left: 20px;margin-top:10px;"> Average
          <input type="checkbox" name="casestudy" value="3"  class="case-list"style="margin-left: 20px;"margin-top:10px;> Good
        <input type="checkbox" name="casestudy" value="4"  class="case-list" style="margin-left: 20px;margin-top:10px;"> Very Good
   <input type="checkbox" name="casestudy" value="5" class="case-list" style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
2.Feedback on Faculty <br> 
			 <span style="margin-left: 220px"><span class="new">a. Knowledge of the Subject:*</span>
	<input type="checkbox" name="knowledge" value="1" class="knowledge-list" style="margin-left:25px;margin-top:10px;"> Poor
    <input type="checkbox" name="knowledge" value="2" class="knowledge-list" style="margin-left: 20px;margin-top:10px;"> Average
   <input type="checkbox" name="knowledge" value="3" class="knowledge-list" style="margin-left: 20px;margin-top:10px;"> Good
   <input type="checkbox" name="knowledge" value="4" class="knowledge-list" style="margin-left: 20px;margin-top:10px;"> Very Good
<input type="checkbox" name="knowledge" value="5"  class="knowledge-list" style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
			 <span style="margin-left: 220px"><span class="new">b. Presentation Skills:*</span>
 <input type="checkbox" name="presentation" value="1"  class="presentation-list"style="margin-left: 68px;margin-top:10px;"> Poor
 <input type="checkbox" name="presentation" value="2"  class="presentation-list" style="margin-left: 20px;margin-top:10px;"> Average
  <input type="checkbox" name="presentation" value="3" class="presentation-list" style="margin-left: 20px;margin-top:10px;"> Good
		 <input type="checkbox" name="presentation" value="4"  class="presentation-list" style="margin-left: 20px;margin-top:10px;"> Very Good
		 <input type="checkbox" name="presentation" value="5" class="presentation-list" style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
			 <span style="margin-left: 220px"><span class="new">c. Examples Used:*</span>
	<input type="checkbox" name="examples" value="1"  class="examples-list" style="margin-left: 85px;margin-top:10px;"> Poor
         <input type="checkbox" name="examples" value="2" class="examples-list" style="margin-left: 20px;margin-top:10px;"> Average
      <input type="checkbox" name="examples" value="3" class="examples-list" style="margin-left: 20px;margin-top:10px;"> Good
     <input type="checkbox" name="examples" value="4" class="examples-list" style="margin-left: 22px;margin-top:10px;"> Very Good
<input type="checkbox" name="examples" value="5"  class="examples-list" style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
			 <span style="margin-left: 220px"><span class="new">d. Answering Queries:*</span>
	<input type="checkbox" name="queries" value="1" class="queries-list" style="margin-left: 63px;margin-top:10px;"> Poor
    <input type="checkbox" name="queries" value="2"  class="queries-list" style="margin-left: 20px;margin-top:10px;"> Average
   <input type="checkbox" name="queries" value="3" class="queries-list" style="margin-left: 20px;margin-top:10px;"> Good
    <input type="checkbox" name="queries" value="4" class="queries-list" style="margin-left: 22px;margin-top:10px;"> Very Good
 <input type="checkbox" name="queries" value="5" class="queries-list" style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
			 <span style="margin-left: 220px"><span class="new">e. Overall Impact:*</span>
	<input type="checkbox" name="impact" value="1" class="impact-list" style="margin-left: 91px;margin-top:10px;"> Poor
    <input type="checkbox" name="impact" value="2"  class="impact-list"style="margin-left: 20px;margin-top:10px;"> Average
    <input type="checkbox" name="impact" value="3"  class="impact-list"style="margin-left: 20px;margin-top:10px;"> Good
   <input type="checkbox" name="impact" value="4" class="impact-list" style="margin-left: 22px;margin-top:10px;"> Very Good
<input type="checkbox" name="impact" value="5" class="impact-list" style="margin-left: 20px;margin-top:10px;"> Excellent<br></span>
			 
3.Comments/Suggestions:(Limited to 100 words)<br><input type="text" name="comments" autocomplete="off" style="margin-left: 30px;border: none;border-bottom: 1px solid #fff;"class="comments"><br>
4.Participants Speak:<br><input type="text" name="testimonial" autocomplete="off" style="margin-left: 30px;border: none;border-bottom: 1px solid #fff;"><br>
5.What are the three things I would like to take away from this training program and Implement:<br><input type="text" name="trainingthings" autocomplete="off" style="margin-left:30px;border: none;
    border-bottom: 1px solid #fff;"><br>
			 <div class="submit"><input type="submit"></div>
</form>
	<p style="indicates"> * Indicates that all mention details are manadatory</p>
	</div>
	
</body>
	<script type="text/javascript">
    $('.product-list').on('change', function() {
        $('.product-list').not(this).prop('checked', false);  
    });
	$('.clarity-list').on('change', function() {
        $('.clarity-list').not(this).prop('checked', false);  
    });
		$('.case-list').on('change', function() {
        $('.case-list').not(this).prop('checked', false);  
    });
		$('.knowledge-list').on('change', function() {
        $('.knowledge-list').not(this).prop('checked', false);  
    });
		$('.presentation-list').on('change', function() {
        $('.presentation-list').not(this).prop('checked', false);  
    });
		$('.examples-list').on('change', function() {
        $('.examples-list').not(this).prop('checked', false);  
    });
		$('.queries-list').on('change', function() {
        $('.queries-list').not(this).prop('checked', false);  
    });
		$('.impact-list').on('change', function() {
        $('.impact-list').not(this).prop('checked', false);  
    });
		$(document).ready(function () {
        $('input[id$=tbDate]').datepicker({
        dateFormat: 'dd/mm/yy'});
    });
		$(document).ready(function () {
        $('input[id$=tbDate1]').datepicker({
        dateFormat: 'dd/mm/yy'});
    });
		</script>
</html>
<?php include('footer.php'); ?>
<?php include('header.php'); ?>
<?php 
	if (!isset($_SESSION["sess_email_kaccess"]) && !isset($_SESSION["sess_email_caccess"])) {
		header("Location: login.php");
	}

	$user_id = $_SESSION["user_id"];

	// Expire all trophies achieved by User after valid till date
	$expireTrophies = mysqli_query($dbconnect, "UPDATE tbl_module_trophies SET STATUS = '1' WHERE valid_till < UNIX_TIMESTAMP(NOW()) AND STATUS = '0';");

	$cntdata = array('Article' => 0, 'Video' => 0, 'Assessment' => 0, 'Booksuggestion' => 0, 'Module' => 0);
	if ($result = mysqli_query($dbconnect, "SELECT kl_cat, COUNT(*) AS total FROM tbl_kc_list WHERE STATUS = 'Active' GROUP BY kl_cat;")) {
		while ($row = mysqli_fetch_assoc($result)) {
			if($row['kl_cat'] === 'Elsa Assessment' || $row['kl_cat'] === 'Assessment') {
				$cntdata['Assessment'] += $row['total'];
			}
			else {
				$cntdata[$row['kl_cat']] = $row['total'];
			}
		}
		// Free result set
		mysqli_free_result($result);

	}
	if ($result = mysqli_query($dbconnect, "SELECT COUNT(*) AS total FROM tbl_image_content")) {
		while ($row = mysqli_fetch_assoc($result)) {
			$cntdata["Booksuggestion"] = $row['total'];
		}
		// Free result set
		mysqli_free_result($result);
	}
	if ($result = mysqli_query($dbconnect, "SELECT COUNT(*) AS total FROM tbl_knowledge_center WHERE prg_status = 'Active';")) {
		while ($row = mysqli_fetch_assoc($result)) {
			$cntdata["Module"] = $row['total'];
		}
		// Free result set
		mysqli_free_result($result);
	}

	$organization_id = null;
	$org_name = "";

	$queryorg = "SELECT * FROM `tbl_user` ";
	$queryorg .= " INNER JOIN `tbl_organization` ON `tbl_organization`.`id` = `tbl_user`.`organization_id` ";
	$queryorg .= " WHERE `tbl_user`.`id` = $user_id; ";
	if ($result = mysqli_query($dbconnect, $queryorg)) {
		while ($row = mysqli_fetch_assoc($result)) {
			$org_name = $row['org_name'];
			$organization_id = $row['organization_id'];
		}
		// Free result set
		mysqli_free_result($result);
	}

	$events = array();
	if ($result = mysqli_query($dbconnect, "SELECT * FROM tbl_events;")) {
		while ($row = mysqli_fetch_assoc($result)) {
			$events[$row['id']] = $row;
		}
		// Free result set
		mysqli_free_result($result);
	}

	$comp_kc = array(); $batt_kc = array();

	$crs = mysqli_query($dbconnect, "select cm.*, c.prg_name as comp_name, kc.* from tbl_competency_modules cm left join tbl_competencies c on c.prg_id = cm.cmdl_c_id left join tbl_knowledge_center kc on cm.cmdl_kc_id = kc.prg_id where c.prg_status = 'Active' and kc.prg_status = 'Active'");
	
	if($crs) {
		while($crow = mysqli_fetch_assoc($crs)) {
			if(!array_key_exists($crow['comp_name'], $comp_kc)) {
				$comp_kc[$crow['comp_name']] = array();
				$comp_kc[$crow['comp_name']]['Basic'] = array();
				$comp_kc[$crow['comp_name']]['Intermediate'] = array();
				$comp_kc[$crow['comp_name']]['Expert'] = array(); 
			}
			if($crow['cmdl_level'] == 0 || $crow['cmdl_level'] == '0') {
				$level = 'Basic';
			}
			if($crow['cmdl_level'] == 1 || $crow['cmdl_level'] == '1') {
				$level = 'Intermediate';
			}
			if($crow['cmdl_level'] == 2 || $crow['cmdl_level'] == '2') {
				$level = 'Expert';
			}
			array_push($comp_kc[$crow['comp_name']][$level], $crow);

		}
		mysqli_free_result($crs);
	}
	
	$crs = mysqli_query($dbconnect, "select cm.*, ca.attr_name, c.prg_name as comp_name, kc.* from tbl_competency_attrmodules cm left join tbl_competency_attributes ca on ca.id = cm.camdl_ca_id left join tbl_competencies c on ca.competency_id = c.prg_id left join tbl_knowledge_center kc on cm.camdl_kc_id = kc.prg_id where c.prg_status = 'Active' and ca.attr_status = 'Active' and kc.prg_status = 'Active'");
	
	if($crs) {
		while($crow = mysqli_fetch_assoc($crs)) {
			if(!array_key_exists($crow['comp_name'], $batt_kc)) {
				$batt_kc[$crow['comp_name']] = array();
			}
			
			if(!array_key_exists($crow['attr_name'], $batt_kc[$crow['comp_name']])) {
				$batt_kc[$crow['comp_name']][$crow['attr_name']] = array();
			}

			array_push($batt_kc[$crow['comp_name']][$crow['attr_name']], $crow);

		}
		mysqli_free_result($crs);
	}

	$user_assignments = array(); $kc_total_credits = array(); $kc_total_contents = array();

	$uars = mysqli_query($dbconnect, "select kas.*, kc.* from tbl_kc_assignments kas JOIN tbl_knowledge_center kc ON kc.prg_id = kas.kca_kc_id  where kca_user_id = ". $user_id ." and kc.prg_status = 'Active'");
	if($uars) {
		while($uarow = mysqli_fetch_assoc($uars)) {
			$uas = new stdClass();
			$uas->user_id = $user_id;
			$uas->course_id = $uarow['prg_id'];
			$uas->course_name = $uarow['prg_name'];
			$uas->assign_type = ($uarow['kca_isself'] == 1 || $uarow['kca_isself'] == '1') ? 'self' : 'admin';
			$uas->console = ($uarow['org_id'] > 0) ? 'client' : 'aggregator';
			$uas->total_credits = 0;
			$uas->user_credits = 0;
			$uas->progress = 0;
			$uas->trophy_slabs = array();
			$uas->trophy_template = '';
			$uas->trophy_image = '';
			$uas->trophy = '';
			$uas->total_content = array();
			$uas->visited_content = array();

			if(!array_key_exists($uas->course_id, $kc_total_credits)) {
				$crs = mysqli_query($dbconnect, "select * from tbl_kc_list kcl where kcl.kl_prg_id = ".$uas->course_id." and status = 'Active' and kl_cat in('Article', 'Video', 'Assessment') ");
				
				if($crs) {
					while($crow = mysqli_fetch_assoc($crs)) {
						array_push($uas->total_content, $crow['kl_id']);
						
						$uas->total_credits += $crow['kl_credits'];
					}
				}
				$kc_total_credits[$uas->course_id] = $uas->total_credits;
				$kc_total_contents[$uas->course_id] = $uas->total_content;
			}
			else {
				$uas->total_credits = $kc_total_credits[$uas->course_id];
				$uas->total_content = $kc_total_contents[$uas->course_id];
			}
			
			if($uarow['prg_trtp_id'] > 0) {
				$trs = mysqli_query($dbconnect, "select sl.*, t.trpt_name from tbl_trophy_template_slab sl JOIN tbl_trophy_template t on t.trpt_id = sl.trps_trpt_id where sl.trps_trpt_id = ".$uarow['prg_trtp_id']." order by sl.trps_perc");
				if($trs) {
					while($trow = mysqli_fetch_assoc($trs)) {
						$uas->trophy_template = $trow['trpt_name'];
						$uas->trophy_image = $uas->trophy_template;
						array_push($uas->trophy_slabs, $trow);
					}
				}
			}
			$user_assignments[$uas->course_id] = $uas;
			unset($uas);
		}
		mysqli_free_result($uars);
	}	
	
        $idpAggregatordata = array();  $idpClientdata = array();
//var_dump("SELECT  tbl_user_idp_programs.ui_id AS aid,ui_idp_id,org_id,NAME,title,subtitle FROM tbl_user_idp_programs LEFT JOIN tbl_user ON tbl_user.id=tbl_user_idp_programs.ui_user_id LEFT JOIN tbl_idp ON tbl_idp.id=tbl_user_idp_programs.ui_idp_id WHERE ui_user_id= $user_id AND  idp_status='Active' AND org_id IN (0,$organization_id);");die;
	if ($result = mysqli_query($dbconnect, "SELECT  tbl_user_idp_programs.ui_id AS aid,ui_idp_id,org_id,NAME,title,subtitle FROM tbl_user_idp_programs LEFT JOIN tbl_user ON tbl_user.id=tbl_user_idp_programs.ui_user_id LEFT JOIN tbl_idp ON tbl_idp.id=tbl_user_idp_programs.ui_idp_id WHERE ui_user_id= $user_id AND  idp_status='Active' AND org_id IN (0,$organization_id);")) {
		while ($row = mysqli_fetch_assoc($result)) {
                    if($row['org_id'] == 0){
			$idpAggregatordata[$row['aid']] = $row;
                    }else{
                        $idpClientdata[$row['aid']] = $row;
                    }
		}
		// Free result set
		mysqli_free_result($result);
	}
	
	$t_ts_m = $t_ts_h = $t_mdl_learnt = $t_mdl_total = $p_modules_learnt = $t_ppl = 0;
	$a_mdl_learnt = [];
	$a_mdl_ts = [];
	$t_ts_male_m = $t_ts_male_h = $t_ts_female_m = $t_ts_male_h = 0;
	$a_ts_male = $a_ts_female = [];
	$a_mdl_cat = $a_mdl_cat_video = $a_mdl_cat_article = $a_mdl_cat_book = [];

	if ($result = mysqli_query($dbconnect, "SELECT COUNT(DISTINCT kc_title) AS total FROM tbl_kc_content;")) {
		while ($row = mysqli_fetch_assoc($result)) {
			$t_mdl_total = $row['total'];
		}
		// Free result set
		mysqli_free_result($result);
	}

	$tquery = " SELECT tbl_event_history.*, tbl_user_login_history.*, 
		tbl_user.id, tbl_user.name, tbl_user.last_name, tbl_user.age, tbl_user.gender, tbl_user.organization_id, 
		tbl_knowledge_center.prg_name, tbl_image_content.img_title, tbl_kc_list.kl_cat, tbl_kc_list.kl_list,
		tbl_knowledge_center.org_id   
		FROM tbl_event_history 
		LEFT JOIN tbl_user_login_history ON tbl_user_login_history.ulh_id = tbl_event_history.eh_ul_id
		LEFT JOIN tbl_user ON tbl_user.id = tbl_user_login_history.ulh_u_id 
		LEFT JOIN tbl_kc_list ON tbl_event_history.eh_kc_list_id = tbl_kc_list.kl_id and tbl_event_history.eh_cori = 'content' 
		LEFT JOIN tbl_image_content ON tbl_event_history.eh_kc_list_id = tbl_image_content.img_id and tbl_event_history.eh_cori = 'image' 
		LEFT JOIN tbl_kc_content ON tbl_kc_list.kl_kc_id = tbl_kc_content.kc_id 
		LEFT JOIN tbl_knowledge_center ON tbl_kc_content.kc_prg_id = tbl_knowledge_center.prg_id or tbl_image_content.img_kc_id = tbl_knowledge_center.prg_id 
		WHERE tbl_event_history.eh_ul_id > 0 AND tbl_user.organization_id = " . $organization_id .
		 " ORDER BY tbl_event_history.eh_ul_id ";

	
	$newline = "\n";
	$newtab = "\t";
	$columnHeader = "" . $newtab . $newtab . $newtab . "Analytical Report" . $newtab . "" . "\t \n \n";
	$columnHeader = $columnHeader . "Sl.NO" . $newtab . "Date" . $newtab . "User ID" . $newtab . "First Name " . "$newtab" . "Last Name" . "$newtab" . "Email ID" . "$newtab" . "Phone No" . "$newtab" . "Organization" . "$newtab" . "Sex" . "$newtab" . "Age" . "$newtab" . "Linked IN" . "$newtab" . "Twitter" . "$newtab" . "Date" . "$newtab" . "Login Time" . "$newtab" . "Logout Time" . "$newtab" . "Page Name" . "$newtab" . "Links" . "$newtab" . "Page Link Open Time" . "$newtab" . "Module" . "$newtab" . "\t \n";
	$setData = '';

	$tsdata = array(
		'lts' => 0, 'ats' => 0, 'users' => array(), 'user_names' => array(), 'ucount' => 0, 'mucount' => 0, 'fucount' => 0, 'aaucount' => 0, 'abucount' => 0, 'mucount' => 0, 'fucount' => 0,
		'musers' => array(), 'fusers' => array(), 'aausers' => array(), 'abusers' => array(), 'mpercent' => 0, 'fpercent' => 0, 'aapercent' => 0, 'abpercent' => 0,
		'lts_ind' => 0, 'ats_ind' => 0, 'users_ind' => array(), 'ucount_ind' => 0,
		'modules' => array(), 'mmodules' => array(), 'fmodules' => array(), 'aamodules' => array(), 'abmodules' => array(),
		'acontent' => array(), 'vcontent' => array(), 'bcontent' => array(),
		'account' => array(), 'vccount' => array(), 'bccount' => array()
	); 

	if ($result = mysqli_query($dbconnect, $tquery)) {
		while ($row = mysqli_fetch_object($result)) {
			$start_date = new DateTime($row->eh_created_at);
			$ts = $start_date->diff(new DateTime($row->ulh_end_time)); 
			$org_add = true;

			$minutes = $ts->days * 24 * 60; $minutes += $ts->h * 60; $minutes += $ts->i; if(is_nan($minutes)) { $minutes = 0; }
			$tsdata['lts_ind'] += $minutes;

			if($row->org_id == 0) {
				if(isset($tsdata['modules'][$row->prg_name]) == false) { $tsdata['modules'][$row->prg_name] = 0; }
				$tsdata['modules'][$row->prg_name] += $minutes;
			}

			if(isset($tsdata['users'][$row->ulh_u_id]) === false) {
				$tsdata['users'][$row->ulh_u_id] = 0; 
				$tsdata['ucount']++; 
				$tsdata['user_names'][$row->ulh_u_id] = $row->name . " " . $row->last_name;
			}
			$tsdata['users'][$row->ulh_u_id] += $minutes;
			
			if($row->org_id == 0) {
				if(isset($tsdata['musers'][$row->ulh_u_id]) === false) { $tsdata['musers'][$row->ulh_u_id] = 0; }
				$tsdata['musers'][$row->ulh_u_id] += $minutes;
				$tsdata['mucount']++; 
			}
			else if($row->org_id > 0) {
				if(isset($tsdata['fusers'][$row->ulh_u_id]) === false) { $tsdata['fusers'][$row->ulh_u_id] = 0; }
				$tsdata['fusers'][$row->ulh_u_id] += $minutes;
				$tsdata['fucount']++; 
			}

			if($row->ulh_u_id == $user_id) {
				$tsdata['lts'] += $minutes;
				if($row->org_id == 0) {
					if(isset($tsdata['mmodules'][$row->prg_name]) == false) { $tsdata['mmodules'][$row->prg_name] = 0; }
					$tsdata['mmodules'][$row->prg_name] += $minutes;
				}
				else if($row->org_id > 0) {
					if(isset($tsdata['fmodules'][$row->prg_name]) == false) { $tsdata['fmodules'][$row->prg_name] = 0; }
					$tsdata['fmodules'][$row->prg_name] += $minutes;
				}
			}
		}

		// var_dump($tsdata); die;
		function comparator($object1, $object2) { 
			return $object1->progress < $object2->progress; 
		} 

		usort($user_assignments, 'comparator'); 
		
		arsort($tsdata['users']);
		arsort($tsdata['musers']);
		arsort($tsdata['fusers']);
		arsort($tsdata['mmodules']);
		arsort($tsdata['fmodules']);

		// Free result set
		mysqli_free_result($result);
	}

	function numf($number, $decimals = 0) {
		if ($number < 1000) {
			// Anything less than a million
			$format = number_format($number, $decimals);
		} else if ($number < 1000000) {
			// Anything less than a million
			$format = number_format($number / 1000, $decimals) . 'K';
		} else if ($number < 1000000000) {
			// Anything less than a billion
			$format = number_format($number / 1000000, $decimals) . 'M';
		} else {
			// At least a billion
			$format = number_format($number / 1000000000, $decimals) . 'B';
		}
		echo $format;
	}

?>
<!-- <div class="row">
	<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
		<input class="search" id="autocomplete" placeholder="    Ask ELSA.." style="background-color:GreenYellow;margin: 30px;width: 300px; float:right" />
	</div>
</div> -->
<div class="row udb">
	<!-- Centered Tabs -->
	<ul class="nav nav-tabs lnav" role="tablist" id="tabsmain">
		<li role="presentation" class="active"><a aria-controls="pg-akc" role="tab" data-toggle="tab" href="#pg-akc">Existing Content</a></li>
		<li role="presentation"><a aria-controls="pg-ckc" role="tab" data-toggle="tab" href="#pg-ckc">New Content</a></li>
	</ul>
	<div class="tab-content">
		<div role="tabpanel" class="tab-pane fade" id="pg-ckc">
			<div class="container tpcnt">
				<div class="row half-box">
					<div class="col col-lg-8 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 mycourses"></div></div>
								<div class="ub-title"><h4>My Courses</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php foreach($user_assignments as $course_id => $assignment) { ?>
									<?php if($assignment->console == 'client' && $assignment->assign_type == 'admin') { ?>
									<?php
										$trophy_type_sql = "SELECT trophy_type FROM tbl_module_trophies WHERE `userid` = '".$user_id."' AND `moduleid` = '".$assignment->course_id."' AND `status` = '0' ORDER BY mtid DESC LIMIT 1";
										$trophy_type_exec = mysqli_query($dbconnect, $trophy_type_sql);
										$trophy_type_no_rows = mysqli_num_rows($trophy_type_exec);
										if ($trophy_type_no_rows != 0) {
											$trophy_type_row = mysqli_fetch_array($trophy_type_exec);
											$trophy_type = $trophy_type_row['trophy_type'];
											$trophy_image = $assignment->trophy_template.'-'.$trophy_type;
										} else {
											$trophy_type = 'No';
											$trophy_image = $assignment->trophy_template.'-'.$trophy_type;
											// $trophy_image = $assignment->trophy_template;
										}
									?>
									<?php
									$sqlcredits = " SELECT `tbl_kc_list`.`".$assignment->course_id."` AS 'tkl_id', `tbl_kc_list`.`kl_credits` AS 'tkl_credits' FROM `tbl_event_history` ";
							$sqlcredits .= " LEFT JOIN `tbl_kc_list` ON `tbl_event_history`.`eh_kc_list_id` = `tbl_kc_list`.`kl_id`  ";
							$sqlcredits .= " LEFT JOIN `tbl_user` ON `tbl_event_history`.`eh_u_id` = `tbl_user`.`id` ";
							$sqlcredits .= " WHERE `eh_cori` = 'content' ";
							$sqlcredits .= " AND `tbl_event_history`.`eh_u_id` = " . $user_id;
							$sqlcredits .= " AND `tbl_kc_list`.`kl_prg_id` = " .$assignment->course_id. " AND `tbl_kc_list`.`status` = 'Active' ";
							$sqlcredits .= " GROUP BY tkl_id";
							$sqlcredits .= " ORDER BY `organization` ASC;";

							$cntdata = [];
							$totdata = 0;
							$currentcredits = 0; $completed_items = 0;
							if ($result = mysqli_query($dbconnect, $sqlcredits)) {
								while ($row4 = mysqli_fetch_assoc($result)) {
									$cntdata[$row4['tkl_id']] = $row4['tkl_credits'];
									$totdata += (int) $row4['tkl_credits'];
									$currentcredits += (int) $row4['tkl_credits'];
									$completed_items++;
								}
								// Free result set
								mysqli_free_result($result);
								$obtainedscore=1;
							}

							$total_credits = 0; $total_items = 0;
							$trs = mysqli_query($dbconnect, "select kl_credits as tscore from tbl_kc_list where kl_prg_id = " .$assignment->course_id." and status = 'Active'");
							if($trs) {
								while($trow =  mysqli_fetch_assoc($trs)) {
									$total_credits += $trow['tscore'];
									$total_items++;
								}
								mysqli_free_result($trs);
							}
							$qrcrd = "SELECT `tbl_kc_assignments`.`kca_credits` as `kca_credits` FROM `tbl_kc_assignments` WHERE `tbl_kc_assignments`.`kca_user_id` = " . $_SESSION['user_id'] . " AND `tbl_kc_assignments`.`kca_kc_id` = " . $row['prg_id'] . " AND `tbl_kc_assignments`.`kca_status` = 'Active';";
							if ($rescrd = mysqli_query($dbconnect, $qrcrd)) {
							while ($rwrescrd = mysqli_fetch_object($rescrd)) {
							 		$currentcredits += $rwrescrd->kca_credits;
							 	}
							 	mysqli_free_result($rescrd);
							 }
							$complete_perc = 0;
							if($total_items > 0 && $completed_items > 0) {
								$complete_perc = number_format(  ( ($completed_items * 100) / $total_items ) , 0);
							}
							?>
									
									<div class="prg-item" >
										<div class="prg-title"><a class="trlvl" href="dynamic_kc.php?kc_id=<?php echo $assignment->course_id ?>" title="<?php echo $assignment->course_name ?>"><i class="fa fa-book"></i><?php echo $assignment->course_name ?></a></div>
										<div class="prg-progress"><div class="progress"><div class="progress-bar green" style="width:<?php echo $assignment->progress ?>%"></div></div></div>
										<div class="prg-trophy"><div class="ub-icon"><div class="olo-icon oloi-20 <?php echo $trophy_image ?>" style="background-image: url(images/<?php echo $trophy_image ?>.png)"></div></div></div>
										
										 <!-- <div class="prg-trophy"><div class="ub-icon"><div class="olo-icon oloi-20 <php echo $assignment->trophy_image ?>" style="background-image: url(images/php echo $assignment->trophy_image ?>.png)"></div></div></div> -->
									</div> 
									<?php } ?>
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 myidp"></div></div>
								<div class="ub-title"><h4>My Learning Progress (MLP)</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
								<?php if(count($idpClientdata)>0) { ?>
									<div class="col-md-12">
										<?php  foreach ($idpClientdata as &$idpckcdata) { ?>  
											<div class="prg-item">
												<div class="prg-title">
													<a class="trlvl" href="clients.php?id=<?= $idpckcdata['aid'] ?>" title="<?php echo $idpckcdata['title']; ?>"><i class="fa fa-address-book-o "></i><?php echo $idpckcdata['title']; ?></a>
												</div>
											</div> 
										<?php } ?>
									</div>
									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No data available</p>
										</div>
									<?php } ?>  
																
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="row half-box">
					<div class="col col-lg-8 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 uevents"></div></div>
								<div class="ub-title"><h4>Upcoming Events</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
								<?php // var_dump($events);?>
								<?php if(count($events)>0) { ?>
									<div class="col-md-12">
                                        <?php

   $sql = "select * from tbl_events order by created desc";
	 $sqla = "select * from tbl_events order by created desc limit 1";
$query = mysqli_query($dbconnect, $sql);
	$queryy = mysqli_query($dbconnect, $sqla);
	$frow = mysqli_fetch_array($queryy);
	$fr = $frow['id'];
$numrows = mysqli_num_rows($query);
	if ($numrows != 0) {
	
	                   while($row = mysqli_fetch_array($query)) {
										  
										
                          ?>                      
                                        <div class="prg-item">
                                            <div class="prg-title full">
												
												<?php if ($row['id']===$fr){ ?>
                                                <a class="trlvl evdata" data-evid="<?php echo $row['id']; ?> " data-toggle="modal" data-target="#<?php echo $row['id']; ?>" title="<?php echo $row['title']; ?>" style=" border-radius:2px;  color:white;"><i class="fa fa-address-book-o "></i><span  style="padding:10px; background-color:#104C89; border-radius:2px; margin-right:10px;color:white;content-align:center; border-radius:2px;">&nbsp;Most Recent</span><?php echo $row['title']; ?></a>

                                                <input type="hidden" id="eventdesc" class="ev_<?php echo $row['id']; ?>" value="<?php echo $row['description']; ?>" />
                                                <input type="hidden" id="eventtitle" class="evt_<?php echo $row['id']; ?>" value="<?php echo $row['title']; ?>" />
<?php } ?> 
												 <a class="trlvl evdata" data-evid="<?php echo $row['id']; ?> " data-toggle="modal" data-target="#<?php echo $row['id']; ?>" title="<?php echo $row['title']; ?>"><i class="fa fa-address-book-o "></i><?php echo $row['title']; ?></a>

                                                <input type="hidden" id="eventdesc" class="ev_<?php echo $row['id']; ?>" value="<?php echo $row['description']; ?>" />
                                                <input type="hidden" id="eventtitle" class="evt_<?php echo $row['id']; ?>" value="<?php echo $row['title']; ?>" />
												
                                            </div>
                                        </div>


   
<div class="modal fade" id="<?php echo $row['id']; ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

    <div class="modal-dialog" role="document" style="width: 800px;max-width: 800px;">
        <div class="modal-content" style="margin-left: 25%;margin-top: 25%;height: 400px;">
            <div class="modal-header">
               
                <h5 style="color:black"><?php echo $row['title']; ?></h5>


                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="desc"><span></span>
                    <div style="color:black"><?php echo $row['description']; ?></div>
                </div>
            </div>

        </div>
    </div>

</div>
										
<?php } ?>
										<?php } ?>

                                       
                                    </div>


									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No events available</p>
										</div>
									<?php } ?>  
								</div>
							</div>
						</div>
					</div>
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 toplearners"></div></div>
								<div class="ub-title"><h4>Top Learners</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php if(count($tsdata['fusers']) > 0) { ?>
									<div class="col-md-12">
										<?php  foreach (array_slice($tsdata['fusers'] , 0, 3, true) as $km => $user) { ?>  
											<div class="prg-item">
												<div class="prg-title">
												<div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><i class="fa fa-user"></i><?php echo $tsdata['user_names'][$km]; ?></div>
                                      	
												</div>
											</div> 
										<?php } ?>
									</div>
									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No data available</p>
										</div>
									<?php } ?>  			
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div role="tabpanel" class="tab-pane fade in active" id="pg-akc">
			<div class="container tpcnt">
				<div class="row half-box">
					
					<!-- ---------------Mmy Courses(Client Console)---------------- -->
					
					
					<div style="height: 100% !important;">
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12" style="height: 100% !important;">
						<div class="ubox big">

							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 mycourses"></div></div>
								<div class="ub-title"><h4>My Courses</h4></div>
							</div>

							
						

							<div class="ub-content">
								<div class="prg-list">
									<?php foreach($user_assignments as $course_id => $assignment) { ?>
									<?php if($assignment->console == 'aggregator' && $assignment->assign_type == 'admin') { ?>
									<?php
										$trophy_type_sql = "SELECT trophy_type FROM tbl_module_trophies WHERE `userid` = '".$user_id."' AND `moduleid` = '".$assignment->course_id."' AND `status` = '0' ORDER BY mtid DESC LIMIT 1";
										$trophy_type_exec = mysqli_query($dbconnect, $trophy_type_sql);
										$trophy_type_no_rows = mysqli_num_rows($trophy_type_exec);
										if ($trophy_type_no_rows != 0) {
											$trophy_type_row = mysqli_fetch_array($trophy_type_exec);
											$trophy_type = $trophy_type_row['trophy_type'];
											$trophy_image = $assignment->trophy_template.'-'.$trophy_type;
										} else {
											$trophy_type = 'No';
											$trophy_image = $assignment->trophy_template;
										}
									?>
									<div class="prg-item">
										<div class="prg-title"><a class="trlvl" href="dynamic_kc.php?kc_id=<?php echo $assignment->course_id ?>" title="<?php echo $assignment->course_name ?>"><i class="fa fa-book"></i><?php echo $assignment->course_name ?></a></div>
										<div class="prg-progress"><div class="progress"><div class="progress-bar green" style="width:<?php echo $assignment->progress ?>%"></div></div></div>
										<div class="prg-trophy"><div class="ub-icon"><div class="olo-icon oloi-20 <?php echo $trophy_image ?>" style="background-image: url(images/<?php echo $trophy_image ?>.png)"></div></div></div>
									</div>
									<?php } ?>
									<?php } ?>
								</div>
							</div>
							<!--
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 catalog"></div></div>
								<div class="ub-title"><h4>Catalog By Competencies</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php $comp_index = 0; foreach($comp_kc as $comp_name => $comp_level) { $comp_index++; ?>
										<div class="prg-item comp_cc_<?php echo $comp_index ?>">
											<div class="prg-title full">
												<a class="trlvl l1" title="<?php echo $comp_name ?>" onclick="toggleTree('comp_cc_<?php echo $comp_index ?>', 'comp_cc_lvl_<?php echo $comp_index ?>', 'comp_cc_cr_<?php echo $comp_index ?>')"><i class="fa fa-folder-o"></i><i class="fa fa-folder-open-o"></i><?php echo $comp_name ?></a>
											</div>
										</div>
										<?php $comp_level_index = 0; if(count($comp_level) > 0) { foreach($comp_level as $level_name => $modules) { $comp_level_index++; ?>
											<div class="prg-item comp_cc_lvl_<?php echo $comp_index ?> comp_cc_lvl_<?php echo $comp_index ?>_<?php echo $comp_level_index ?>" style="display: none">
												<div class="prg-title full">
													<a class="trlvl l2" title="<?php echo $level_name ?>" onclick="toggleTree('comp_cc_lvl_<?php echo $comp_index ?>_<?php echo $comp_level_index ?>', 'comp_cc_cr_<?php echo $comp_index ?>_<?php echo $comp_level_index ?>')"><i class="fa fa-folder-o"></i><i class="fa fa-folder-open-o"></i><?php echo $level_name ?></a>
												</div>
											</div>
											<?php if(count($modules) > 0) { foreach($modules as $module) { ?>
												<div class="prg-item comp_cc_cr_<?php echo $comp_index ?> comp_cc_cr_<?php echo $comp_index ?>_<?php echo $comp_level_index ?>" style="display: none">
													<div class="prg-title full"><a class="trlvl l3" href="dynamic_kc.php?kc_id=<?php echo $module['prg_id'] ?>" title="<?php echo $module['prg_name'] ?>"><i class="fa fa-book"></i><?php echo $module['prg_name'] ?></a></div>
												</div>
											<?php } } ?>
										<?php } } ?>
									<?php } ?>
								</div>
							</div>


						</div>
					</div>
					
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
<!--
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 myreadings"></div></div>
								<div class="ub-title"><h4>My Readings</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php foreach($user_assignments as $course_id => $assignment) { ?>
									<?php if($assignment->console == 'aggregator' && $assignment->assign_type == 'self') { ?>
									<?php
										$trophy_type_sql = "SELECT trophy_type FROM tbl_module_trophies WHERE `userid` = '".$user_id."' AND `moduleid` = '".$assignment->course_id."' AND `status` = '0' ORDER BY mtid DESC LIMIT 1";
										$trophy_type_exec = mysqli_query($dbconnect, $trophy_type_sql);
										$trophy_type_no_rows = mysqli_num_rows($trophy_type_exec);
										if ($trophy_type_no_rows != 0) {
											$trophy_type_row = mysqli_fetch_array($trophy_type_exec);
											$trophy_type = $trophy_type_row['trophy_type'];
											$trophy_image = $assignment->trophy_template.'-'.$trophy_type;
										} else {
											$trophy_type = 'No';
											$trophy_image = $assignment->trophy_template;
										}
									?>
									<div class="prg-item" >
										<div class="prg-title"><a class="trlvl" href="dynamic_kc.php?kc_id=<?php echo $assignment->course_id ?>" title="<?php echo $assignment->course_name ?>"><i class="fa fa-book"></i><?php echo $assignment->course_name ?></a></div>
										<div class="prg-progress"><div class="progress"><div class="progress-bar green" style="width:<?php echo $assignment->progress ?>%"></div></div></div>
										<div class="prg-trophy"><div class="ub-icon"><div class="olo-icon oloi-20 <?php echo $trophy_image ?>" style="background-image: url(images/<?php echo $trophy_image ?>.png)"></div></div></div>
									</div>
									<?php } ?>
									<?php } ?>
								</div>
							</div>
											
-->					
					

						</div>
					</div>
					</div>
					
					<!-- ----------------END My Courses(Client Console)---------------- -->
					
					
					
					<!-- ----------------My ID---------------- -->
					
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 myidp"></div></div>
								<div class="ub-title"><h4>My Learning Progress (MLP)</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php if(count($idpAggregatordata)>0) { ?>
									<div class="col-md-12">
										<?php  foreach ($idpAggregatordata as &$idpdata) { ?>  
											<div class="prg-item">
												<div class="prg-title">
													<a class="trlvl" href="clients.php?id=<?= $idpdata['aid'] ?>" title="<?php echo $idpdata['title']; ?>"><i class="fa fa-address-book-o "></i><?php echo $idpdata['title']; ?></a>
												</div>
											</div> 
										<?php } ?>
									</div>
									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No Record Found  </p>
										</div>
									<?php } ?>  
									</div>
								</div>
                        </div>
                    </div>
					<!-- ----------------END My ID---------------- -->
                
					
					
					
					
										
					
					<!-- -------------------- Top Learner -------------------- -->
					
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 toplearners"></div></div>
								<div class="ub-title"><h4>Top Learners</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php if(count($tsdata['musers']) > 0) { ?>
									<div class="col-md-12">
										<?php  foreach (array_slice($tsdata['musers'] , 0, 3, true) as $km => $user) { ?>  
											<div class="prg-item">
												<div class="prg-title">
												<div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><i class="fa fa-user"></i><?php echo $tsdata['user_names'][$km]; ?></div>
										
												</div>
											</div> 
										<?php } ?>
									</div>
									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No data available</p>
										</div>
									<?php } ?>  			
								</div>
							</div>
						</div>
					</div>
					<!-- --------------------  END Top Learner -------------------- -->
					

					
						<!-- ------------------------------Catalog By Behaviour Attributes (This Section is hidden from the user.)------------------------------ -->
					
				<div hidden  class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
					<div class="ubox">
							
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 catalog"></div></div>
								<div class="ub-title"><h4>Catalog By Behaviour Attributes</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php $batt_index = 0; foreach($batt_kc as $batt_name => $batt_level) { $batt_index++; ?>
										<div class="prg-item batt_cc_<?php echo $batt_index ?>">
											<div class="prg-title full">
												<a class="trlvl l1" title="<?php echo $batt_name ?>" onclick="toggleTree('batt_cc_<?php echo $batt_index ?>', 'batt_cc_lvl_<?php echo $batt_index ?>', 'batt_cc_cr_<?php echo $batt_index ?>')"><i class="fa fa-folder-o"></i><i class="fa fa-folder-open-o"></i><?php echo $batt_name ?></a>
											</div>
										</div>
										<?php $batt_level_index = 0; if(count($batt_level) > 0) { foreach($batt_level as $level_name => $modules) { $batt_level_index++; ?>
											<div class="prg-item batt_cc_lvl_<?php echo $batt_index ?> batt_cc_lvl_<?php echo $batt_index ?>_<?php echo $batt_level_index ?>" style="display: none">
												<div class="prg-title full">
													<a class="trlvl l2" title="<?php echo $level_name ?>" onclick="toggleTree('batt_cc_lvl_<?php echo $batt_index ?>_<?php echo $batt_level_index ?>', 'batt_cc_cr_<?php echo $batt_index ?>_<?php echo $batt_level_index ?>')"><i class="fa fa-folder-o"></i><i class="fa fa-folder-open-o"></i><?php echo $level_name ?></a>
												</div>
											</div>
											<?php if(count($modules) > 0) { foreach($modules as $module) { ?>
												<div class="prg-item batt_cc_cr_<?php echo $batt_index ?> batt_cc_cr_<?php echo $batt_index ?>_<?php echo $batt_level_index ?>" style="display: none">
													<div class="prg-title full"><a class="trlvl l3" href="dynamic_kc.php?kc_id=<?php echo $module['prg_id'] ?>" title="<?php echo $module['prg_name'] ?>"><i class="fa fa-book"></i><?php echo $module['prg_name'] ?></a></div>
												</div>
											<?php } } ?>
										<?php } } ?>
									<?php } ?>
								</div>
							</div>
				</div>
			 </div>
							<!-- ------------------------------ END Catalog By Behaviour Attributes------------------------------ -->
					
					
					
										<!-- -------------------------My Top Modules Learnt------------------------- -->
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 toplearners"></div></div>
								<div class="ub-title"><h4>My Top Modules Learnt</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php if(count($tsdata['mmodules']) > 0) { ?>
									<div class="col-md-12">
										<?php  foreach (array_slice($tsdata['mmodules'] , 0, 3, true) as $km => $user) { ?>  
											<div class="prg-item">
												<div class="prg-title">
													<div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><i class="fa fa-book"></i><?php echo $km; ?></div>
										
												</div>
											</div> 
										<?php } ?>
									</div>
									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No data available</p>
										</div>
									<?php } ?>  			
								</div>
							</div>
						</div>
					</div>
					<!-- ------------------------- END My Top Modules Learnt------------------------- -->
					
					
					
					
					<!-- ------------------Top Modules Learnt By Group------------------ -->
					
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
						
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 toplearners"></div></div>
								<div class="ub-title"><h4>Top Modules Learnt By Group</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php if(count($tsdata['modules']) > 0) { ?>
									<div class="col-md-12">
										<?php  foreach (array_slice($tsdata['modules'] , 0, 3, true) as $km => $user) { ?>  
											<div class="prg-item">
												<div class="prg-title">
													<div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><i class="fa fa-book"></i><?php echo $km; ?></div>
										
												</div>
											</div> 
										<?php } ?>
									</div>
									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No data available</p>
										</div>
									<?php } ?>  			
								</div>
							</div>
						

						</div>
					</div>
					
					<!-- ------------------ END Top Modules Learnt By Group------------------ -->
					
					
					
				</div>                    <!-- ----------Div class=Half box----------------- -->
				</div>                    <!-- ----------Div class=container----------------- -->
			
			
			
								<!-- ----------------------------------Div  Online Learning---------------------------------- -->

				<div class="row half-box">
					<div class="col col-lg-8 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox big">
							<div class="ub-head">
								<div class="ub-icon">
									<div class="olo-icon oloi-30 mycourses"></div>
								</div>
								<div class="ub-title">
									<h4>Total Learning Assets</h4>
								</div>
							</div>
							<div class="ub-content ucdb" style="padding-top: 20px">
								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 align-center">
									<div class="info-box infbv infb-1 bg-pink hover-expand-effect1">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-value="<?= $cntdata['Article'] ?>">686</div>
										<div class="info-icon">
											<div class="olo-icon oloi-46 articles"></div>
										</div>
										<div class="content">
											<div class="info-text">Articles</div>
										</div>
									</div>
								</div>

								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 align-center">
									<div class="info-box infbv infb-1 bg-pink hover-expand-effect1">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-value="<?= $cntdata['Video'] ?>">421</div>
										<div class="info-icon">
											<div class="olo-icon oloi-46 videos"></div>
										</div>
										<div class="content">
											<div class="info-text">Videos</div>
										</div>
									</div>
								</div>

								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 align-center">
									<div class="info-box infbv infb-1 bg-pink hover-expand-effect1">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-value="<?= $cntdata['Assessment'] ?>">82</div>
										<div class="info-icon">
											<div class="olo-icon oloi-46 assessments"></div>
										</div>
										<div class="content">
											<div class="info-text">Assessments</div>
										</div>
									</div>
								</div>

								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 align-center">
									<div class="info-box infbv infb-1 bg-pink hover-expand-effect1">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?= $cntdata['Booksuggestion'] ?>">539</div>
										<div class="info-icon">
											<div class="olo-icon oloi-46 books"></div>
										</div>
										<div class="content">
											<div class="info-text">Books</div>
										</div>
									</div>
								</div>

								<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12 align-center">
									<div class="info-box infbv infb-1 bg-pink hover-expand-effect1">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-value="<?= $cntdata["Module"] ?>">7</div>
										<div class="info-icon">
											<div class="olo-icon oloi-46 modules"></div>
										</div>
										<div class="content">
											<div class="info-text">Modules</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox big">
							<div class="ub-head">
								<div class="ub-icon">
									<div class="olo-icon oloi-30 myreadings"></div>
								</div>
								<div class="ub-title">
									<h4>My Learning Report</h4>
								</div>
							</div>
							<div class="ub-content">
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
									<div class="info-box dgbox">
										<div class="icon">
											<div class="olo-icon oloi-62 lts"></div>
										</div>
										<div class="content full-width">
											<div class="text col-dark-grey">LEARNING TIME SPENT</div>
											<div class="pbar">
												<div class="progress col-transparent">
                                    				<div class="progress-bar bg-yellow" role="progressbar" style="width: <?php echo ($tsdata['lts_ind'] == 0 && $tsdata['lts'] == 0 ? 0 : 100) ?>%"></div>
												</div>
                                  				<span><?php echo ($tsdata['lts_ind'] < 60 ?  round($tsdata['lts_ind'], 0) . ' Minutes' : numf($tsdata['lts_ind'] / 60, 2) . ' Hours'); ?></span>

											</div>
											<div class="pbar">
												<div class="progress col-transparent">
													<div class="progress-bar bg-purple" role="progressbar" style="width: <?php echo round(($tsdata['lts_ind'] == $tsdata['lts'] ? ( $tsdata['lts_ind'] == 0 ? 0 : 100 ) : ($tsdata['lts']*100) / $tsdata['lts_ind']), 2) ?>%"></div>
												</div>
												<span><?php echo ($tsdata['lts'] < 60 ? round($tsdata['lts'], 0) . ' Minutes' : numf($tsdata['lts'] / 60, 2) . ' Hours'); ?></span>
											</div>
										</div>
									</div>
								</div>
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mb-1">
									<div class="info-box dgbox">
										<div class="icon">
											<div class="olo-icon oloi-62 ats"></div>
										</div>
										<div class="content full-width">
											<div class="text col-dark-grey">TOTAL MODULES LEARNT</div>
											<div class="pbar">
												<div class="progress col-transparent">
                                    				<div class="progress-bar bg-yellow" role="progressbar" style="width: <?php echo (count($tsdata['modules']) == 0 && count($tsdata['mmodules']) == 0 ? 0 : 100) ?>%"></div>
												</div>
                                  				<span><?php echo count($tsdata['modules']); ?></span>

											</div>
											<div class="pbar">
												<div class="progress col-transparent">
													<div class="progress-bar bg-purple" role="progressbar" style="width: <?php echo round((count($tsdata['modules']) == count($tsdata['mmodules']) ? ( count($tsdata['modules']) == 0 ? 0 : 100 ) : (count($tsdata['mmodules'])*100) / count($tsdata['modules'])), 2) ?>%"></div>
												</div>
												<span><?php echo count($tsdata['mmodules']); ?></span>
											</div>
										</div>
									</div>
								</div>
								
								<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
									<span class="icn bg-yellow dgicn">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small class="dgleg">Peer Learning</small>&nbsp;&nbsp;&nbsp;
									<span class="icn bg-purple dgicn">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small class="dgleg">My Learning</small>
								</div>
							</div>
						</div>
					</div>
				</div>

				
				<div class="row half-box">


<!--
					<div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 toplearners"></div></div>
								<div class="ub-title"><h4>Top Modules Learnt By Group</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php if(count($tsdata['modules']) > 0) { ?>
									<div class="col-md-12">
										<?php  foreach (array_slice($tsdata['modules'] , 0, 3, true) as $km => $user) { ?>  
											<div class="prg-item">
												<div class="prg-title">
													<div class="text" title="<?php echo round($user / 60, 2) . ' Hours'; ?>"><i class="fa fa-book"></i><?php echo $km; ?></div>
										
												</div>
											</div> 
										<?php } ?>
									</div>
									<?php } else { ?>
										<div class="col-md-12 nodatadiv">
											<p>No data available</p>
										</div>
									<?php } ?>  			
								</div>
							</div>
						</div>
					</div>
-->
					<!--div class="col col-lg-4 col-md-12 col-sm-12 col-xs-12">
						<div class="ubox">
							<div class="ub-head">
								<div class="ub-icon"><div class="olo-icon oloi-30 myreadings"></div></div>
								<div class="ub-title"><h4>Suggested Modules</h4></div>
							</div>
							<div class="ub-content">
								<div class="prg-list">
									<?php
										$suggested_modules = array(18 => "Behavioural Interviewing Skills", "");

									?>
									<?php foreach ($suggested_modules as $module) :  ?>
										<div class="prg-item">
											<div class="prg-title full" title="<?php echo $module ?>"><i class="fa fa-book"></i><?php echo $module ?></div>											
										</div>
									<?php endforeach; ?>
								</div>
							</div>
						</div>
					</div-->
                </div>
			</div>
		</div>
	</div>
</div>
 
        
<!--
								
										<div class="col-md-12 nodatadiv">
											<p>No events available</p>
										</div>
									 
-->

<?php include('footer-index.php'); ?>

<script src="//cdnjs.cloudflare.com/ajax/libs/waypoints/4.0.1/jquery.waypoints.min.js"></script>
<script src="js/jquery.counterup.min.js"></script>
<script type="text/javascript">
$('.count-to').counterUp({delay: 10, time: 1000});
</script>
<script>
	jQuery(document).ready(function() {
		jQuery("#tabsmain").tabs();

	});
          $(document).ready(function () {
               $('.evdata').click(function (e) {
                    var evid = $(this).data('evid');
                   $('.ev_'+evid+' .modal-body .desc span').html();
                   var evdesc =  $('.ev_'+evid).val();
                    var evtitle =  $('.evt_'+evid).val();
                   $('#exampleModal .modal-body .desc span').html(evdesc);
                    $('#exampleModalLabel').html(evtitle);
                   
               });
          });


	function toggleTree(clickedItem, firstLevel, secondLevel) {
		if($('.'+clickedItem).hasClass('expanded')) {
			$('.'+clickedItem).removeClass('expanded');
			$('.'+firstLevel).removeClass('expanded').hide();
			$('.'+secondLevel).hide();
		}
		else {
			$('.'+clickedItem).addClass('expanded');
			$('.'+firstLevel).removeClass('expanded').show();
			$('.'+secondLevel).hide();
		}
	}
</script>
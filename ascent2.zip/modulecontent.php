<?php include('header.php'); ?>
<?php
if(!isset($_SESSION["user_id"])){
	echo "<div class=\"col-sm-12\"><p style=\"text-align:center;margin-top:20px;font-size:20px\">Dont have access this page, Please login again and check</p></div>";
}else {
	

$id = $_GET['id'];
$user_id = $_SESSION['user_id'];


$sql4 = "SELECT * FROM tbl_user_modulecontent WHERE userid='".$user_id."' and id='".$id."'";
$result4= mysqli_query($dbconnect, $sql4);
$res4 = mysqli_fetch_row($result4);

if($res4 == NULL){
		echo "<div class=\"col-sm-12\"><p style=\"text-align:center;margin-top:20px;font-size:20px\">You Dont have access this page</p></div>";
	}else { ?>
		<div class="col-lg-12  mob-no-padng" style="margin-top:30px">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">
				<div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
					<div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
						<div id="moduleshortdes_box" class="col-lg-12 inside-box mob-no-padng" style="">
							<p style="color: #0088C7;font-size: 16px;margin-bottom: 15px;">Module Descriptions</p>
							<div style="padding-bottom: 10px;margin-bottom: 10px;border-bottom: solid 1px #3c3b3b;">
								<?php if(!empty($res4[4])){
									echo $res4[4];
								}; ?>
							</div>
							<?php 
							if(!empty($res4[5])){ ?>
									<div id="mod_links" class="col-sm-12" style="text-align:right">
										<a id="mod_docs_links" target="_blank" href="admin/uploads/usermoduledocs/<?php echo $res4[5]; ?>" style="">
										<i class="fa fa-download" style="font-size: 20px;padding: 10px;color: #0088c7;"></i>Documents</a> 
									</div>
							<?php } ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	<?php }

// print_r ($res4);
?>

<?php
	}
?>
<?php include('footer-index.php'); ?>
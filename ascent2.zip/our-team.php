<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
        dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'UA-112031379-1');

</script>


<div class="col-lg-12  mob-no-padng">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">



        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

            <h2 class="ar career-title text-center">OUR TEAM</h2>
            <hr class="line-75">
        </div>

        <div class="col-lg-12  mob-no-padng" style="margin-bottom: 10px">
            <div class="box-5">Awards ​Galore</div>
            <div class="box-5">Thought Leaders</div>
            <div class="box-5">Harvard, ISB, IIM, KPMG, PwC, NHS, Monsanta, Infosys</div>
            <div class="box-5">International Recognition</div>
            <div class="box-5">VC, Coach, Technology, AI, Professors, Change Experts and Mentors.​</div>
        </div>


        <div class="row" style="margin-right: 15px;margin-left: 15px">
            <ul class="tablist " role="tablist">
                <li class="tab" role="tab"><a href="#panel1" style="color: #666;">BOARD OF ADVISORS</a></li>
                <li class="tab" role="tab"><a href="#panel2" style="color: #666;">CORE TEAM</a></li>
                <li class="tab" role="tab"><a href="#panel3" style="color: #666;">EXPERTS</a></li>
                <li class="tab-menu">
                    <div class="line"></div>
                    <div class="line"></div>
                    <div class="line"></div>
                </li>
            </ul>

            <!--panel-1-->

            <div class="tabpanel" id="panel1" role="tabpanel">
                <div class="row">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/srinivas.jpg" alt="image">
                        <p class="team-name">Mr. HN Srinivas</p>
                        <p class="team-expertise">Culture</p>
                        <button class="team-km" onclick="showModal('m1')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/sudha.gif" alt="image">
                        <p class="team-name">Ms. Sudha Raju</p>
                        <p class="team-expertise">Strategy</p>
                        <button class="team-km" onclick="showModal('m3')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/rajiv-new.jpg" alt="image">
                        <p class="team-name">Mr. Rajiv Kuchhal</p>
                        <p class="team-expertise">Business</p>
                        <button class="team-km" onclick="showModal('m2')">Know More</button>
                    </div>
                </div>

                <!-- 
<div class="row" style="margin-top: 30px">
<div class="col-lg-4 text-center">
  <img class="team-pic" src="images/team/amitabh-c.jpg" alt="image">
      <p class="team-name">Mr. Amitabh Chaturvedi</p>
      <p class="team-expertise">Business</p>
      <button class="team-km" onclick="showModal('m24')">Know More</button>
</div>  
<div class="col-lg-4 text-center">
  <img class="team-pic" src="images/team/swami.jpg" alt="image">
      <p class="team-name">Mr. Swaminathan</p>
      <p class="team-expertise">Business</p>
      <button class="team-km" onclick="showModal('m25')">Know More</button>
</div>
<div class="col-lg-4 text-center">
  <img class="team-pic" src="images/team/shyam-p.jpg" alt="image">
      <p class="team-name">Mr. Shyam Powar</p>
      <p class="team-expertise">Business</p>
      <button class="team-km" onclick="showModal('m26')">Know More</button>
</div>
</div>

<div class="row" style="margin-top: 30px">
<div class="col-lg-4 text-center">
  <img class="team-pic" src="images/team/srinivas-k.jpg" alt="image">
      <p class="team-name">Mr. Srinivas Katta</p>
      <p class="team-expertise">MnA</p>
      <button class="team-km" onclick="showModal('m27')">Know More</button>
</div>
<div class="col-lg-4 text-center">
  <img class="team-pic" src="images/team/anjana.jpg" alt="image">
      <p class="team-name">Anjana Vivek</p>
      <p class="team-expertise">MnA</p>
      <button class="team-km" onclick="showModal('m28')">Know More</button>
</div>
<div class="col-lg-4 text-center">
  <img class="team-pic" src="images/team/jordan.jpg" alt="image">
      <p class="team-name">Eleanor Tabi Haller-Jorden</p>
      <p class="team-expertise">Analytics</p>
      <button class="team-km" onclick="showModal('m29')">Know More</button>
</div>
</div> -->

            </div>

            <!--panel-2-->

            <div class="tabpanel" id="panel2" role="tabpanel">
                <div class="row">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/yesh.jpg" alt="image">
                        <p class="team-name">Ms. Yeshasvini Ramaswamy</p>
                        <p class="team-expertise">Managing Director , M & A</p>
                        <button class="team-km" onclick="showModal('m4')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/smita.jpg" alt="image">
                        <p class="team-name"> Ms. Smita Tharoor</p>
                        <p class="team-expertise">Psychology</p>
                        <button class="team-km" onclick="showModal('m5')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/varun.jpg" alt="image">
                        <p class="team-name">Mr. Varun Gupta</p>
                        <p class="team-expertise">Management Consulting , M & A</p>
                        <button class="team-km" onclick="showModal('m7')">Know More</button>
                    </div>
                </div>

                <div class="row" style="margin-top: 30px">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/devika.png" alt="image">
                        <p class="team-name">Ms. Devika Ramarathnam</p>
                        <p class="team-expertise">Human Resourse and L&D</p>
                        <button class="team-km" onclick="showModal('m8')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/deepak.png" alt="image">
                        <p class="team-name">Mr. Deepak Rahul</p>
                        <p class="team-expertise">New Product Development, Sales</p>
                        <button class="team-km" onclick="showModal('m9')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/dr-arun.jpg" alt="image">
                        <p class="team-name">Dr. Arun Krishnan</p>
                        <p class="team-expertise">Consultant</p>
                        <button class="team-km" onclick="showModal('m50')">Know More</button>
                    </div>
                </div>

                <div class="row" style="margin-top: 30px">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/rajiv-r.jpg" alt="image">
                        <p class="team-name">Rajiv Raghunand</p>
                        <p class="team-expertise">Consultant</p>
                        <button class="team-km" onclick="showModal('m51')">Know More</button>
                    </div>
                </div>
            </div>

            <!--panel-3-->

            <div class="tabpanel" id="panel3" role="tabpanel">
                <p style="text-align: center;color: black;margin-bottom: 15px;">A Strong community of more than 140 subject matter experts.</p>

                <div class="row">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/ganesh-prabhu.jpg" alt="image">
                        <p class="team-name">Prof Ganesh N Prabhu</p>
                        <p class="team-expertise">Research and Teaching</p>
                        <button class="team-km" onclick="showModal('m52')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/nandlal.jpg" alt="image">
                        <p class="team-name">Nandlal Narayana</p>
                        <p class="team-expertise">Development Expert</p>
                        <button class="team-km" onclick="showModal('m53')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/anoop.jpg" alt="image">
                        <p class="team-name">Mr. Anoop Sequeira</p>
                        <p class="team-expertise">Franchise Management</p>
                        <button class="team-km" onclick="showModal('m14')">Know More</button>
                    </div>
                </div>

                <div class="row" style="margin-top: 30px">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/rajesh-ceo.jpg" alt="image">
                        <p class="team-name">Rajesh Khamat</p>
                        <p class="team-expertise">Consulting</p>
                        <button class="team-km" onclick="showModal('m54')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/narendra.jpg" alt="image">
                        <p class="team-name">Prof. Narendra M. Agrawal</p>
                        <p class="team-expertise">Strategy HR</p>
                        <button class="team-km" onclick="showModal('m11')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/RAGA.jpg" alt="image">
                        <p class="team-name">Ms. Raga D’silva</p>
                        <p class="team-expertise">Brand Management</p>
                        <button class="team-km" onclick="showModal('m13')">Know More</button>
                    </div>
                </div>

                <div class="row" style="margin-top: 30px">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/shesadri.jpg" alt="image">
                        <p class="team-name">Mr. Shesadri Mukundhan</p>
                        <p class="team-expertise">Strategy</p>
                        <button class="team-km" onclick="showModal('m10')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/chandrika.jpg" alt="image">
                        <p class="team-name">Ms. Chandrika</p>
                        <p class="team-expertise">Training , Counselling</p>
                        <button class="team-km" onclick="showModal('m12')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/kusum.jpg" alt="image">
                        <p class="team-name">Ms. Kusum Prasad</p>
                        <p class="team-expertise">Media & Communications</p>
                        <button class="team-km" onclick="showModal('m15')">Know More</button>
                    </div>
                </div>


                <div class="row" style="margin-top: 30px">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/kranthi.jpg" alt="image">
                        <p class="team-name">Mr. Kranthi</p>
                        <p class="team-expertise">Management Consultant</p>
                        <button class="team-km" onclick="showModal('m16')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/hemachandran.jpg" alt="image">
                        <p class="team-name">Mr. Hemachandran </p>
                        <p class="team-expertise">Strategic Finance</p>
                        <button class="team-km" onclick="showModal('m17')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/vasudevan.jpg" alt="image">
                        <p class="team-name">Mr. Vasudevan Srivasan</p>
                        <p class="team-expertise">Strategic HR</p>
                        <button class="team-km" onclick="showModal('m18')">Know More</button>
                    </div>
                </div>

                <div class="row" style="margin-top: 30px">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/kunalshah.jpg" alt="image">
                        <p class="team-name">Mr.Kunal Shah</p>
                        <p class="team-expertise">New Product Development and Management Consulting</p>
                        <button class="team-km" onclick="showModal('m19')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/anand.jpg" alt="image">
                        <p class="team-name">Mr. Anand Reddy</p>
                        <p class="team-expertise">Education Consulting, Training</p>
                        <button class="team-km" onclick="showModal('m20')">Know More</button>
                    </div>
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/rubia.jpg" alt="image">
                        <p class="team-name">Ms. Rubia Braun</p>
                        <p class="team-expertise">Media & Communications</p>
                        <button class="team-km" onclick="showModal('m21')">Know More</button>
                    </div>
                </div>

                <div class="row" style="margin-top: 30px">
                    <div class="col-lg-4 text-center">
                        <img class="team-pic" src="images/team/deepak-k.jpg" alt="image">
                        <p class="team-name">Deepak Kaushik</p>
                        <p class="team-expertise">CA</p>
                        <button class="team-km" onclick="showModal('m23')">Know More</button>
                    </div>
                </div>

            </div>

        </div>

    </div>



    <div id="m1" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m1')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/srinivas.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. HN Srinivas – e2e Strategic Advisor </p>
                        <ul style="list-style: inside;">
                            <li>Senior Vice President & Head – Human Resources for Taj Group of Hotels.</li>
                            <li>Has over 33 years of experience in the field of Human Resources, in both manufacturing service public and private sector companies.
                                Served the Tata Group for over 23 years</li>
                            <li>Served the Tata Group for over 23 years</li>
                            <li>Introduced several innovative world-class HR practices and helped the company in adopting value based and caring approaches for managing people.</li>
                            <li>Recipient of a National Award for Best HR Practices for The Taj Group HR team in 1992 by NHRD.</li>
                            <li>AMITY HR Excellence Award ; Best Employer in Hospitality Awards– 2009</li>
                            <li>Handled the rehabilitation and relief for all the terror victims of Mumbai under the aegis of the Taj Welfare Trust</li>
                            <li>Was actively engaged in handling the HR issues post terror attack of 26/11, which effort has been recognized across the country as a Landmark Practice.</li>
                            <li>Under his stewardship, IHCL has been conferred the international "Best Employer" Award by M/s. Hewitt Associates.</li>
                            <li>Great Places to Work – Award in 2010</li>
                            <li>Has led the company to receive the Global Best Workplace Award by Gallup Worldwide for four consecutive years in 2010, 2011, 2012 & 2013.</li>
                            <li>MaFoi Randstadt Awards : Best Employer in Hospitality Industry - 2011</li>
                            <li>Global HR Excellence Awards – 2010/2011 for HR Leadership instituted by World HRD Congress.</li>
                            <li>CII National HR Excellence Awards : Significant Achievement in HR Excellence - 2011</li>
                            <li>HR Leadership Award for Benchmarking Talent & HR Processes – by Institute of Public Enterprise in February 2011.</li>
                            <li>Federation of Gujarat Industries (FGI) Vadodra – FGI HR Award to Mr. Shrinivas & the Taj Hotels for contributing exceptionally in the field of HR practices on 24th February 2012</li>
                            <li>Global Vision Award for Outstanding Leadership by U.S. based Travel & Leisure Magazine – 2012 (for our efforts towards responsible tourism and commitment to sustain livelihoods in places where we operate)</li>
                            <li>Led the Company's Taj Hotel's Journey of Business Excellence resulting in winning the JRDQV Award (fashioned on the lines of the Malcolm Baldridge National Quality Award – U.S.) - 2012 by Tata Group Chairman – in 2012</li>
                            <li>Travel + Leisure Global Vision (CSR) Award in Leadership Category – 2012</li>
                            <li>Best HR Professional in the Country Award by NHED – 2012</li>
                            <li>Affirmative Action Award by Tata Group – 2013</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="m2" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m2')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/rajiv-new.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Rajiv Kuchhal – e2e Strategic Advisor</p>
                        <p>Rajiv is an active angel investor and mentor to multiple startups in the social enterprise and technology space. He is an Advisor, Board Member of many such companies. He is also a general partner at the Exfinity fund.</p>
                        <p>Rajiv has spent more than 2 decades in IT/BPO industry, mainly with Infosys group. He led Infosys’ foray into telecom and product engineering services space in early ’90s. He became one of the youngest Business Head and Management Council members at Infosys. He led Infosys’ foray into BPO as a founding team member of Progeon (now Infosys BPO). He was Chief Operating Officer of OnMobile and was part of senior management team instrumental in helping OnMobile scale as an organisation and consolidate its market leadership.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m3" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m3')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/sudha.gif" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Ms. Sudha Raju</p>
                        <p>Ms. Sudha Raju is an independent strategic advisor. Before that she was with Manipal Universal (MU) as Principal Officer, Corporate Affairs & Strategies from November, 2006. At MU Sudha contributed to & was responsible for areas connected to Strategy Development, Networking & Government Relations, Marketing, Leadership Development, and Business Development (including a special focus on creating Placement relationships with corporate organisations).</p>
                        <p>Prior to joining MU, Sudha was working with NIIT for close to 23 years and her assignment at the time of leaving was that of Senior Vice President, responsible for strategic relationships for NIIT. She has worked in various areas other than IT such as Head Strategic HR (worked with CMD to set processes for managing the top 100 people), Personal Quality Movement and in the capacity of Head – Southern region of NIS and has good experience in Sales & Marketing. She started her career at Indian Institute of Management - Bangalore in 1978. While at IIM-B, apart from teaching, she worked on various projects too. She worked for EDCAT providing management consultancy and imparting computer training, courses on soft skills & competencies. She has a rich & varied professional experience of more than 31 years.</p>
                        <p>Sudha was a Director in the local Board of State Bank of India; she was also the convenor of CII’s Women Business leaders’ forum and IT & BPO panel. She is an invited member of the BMA managing committee and is the immediate past Regional Vice President of CSI. She is the past chairperson of the MAIT, Southern region. She has been involved in various committees of Karnataka Government and has participated in the Tamil Nadu, Goa, and Kerala state IT Councils. She can be contacted through :</p>
                        <p><a href="mailto:sudharaju@e2epeoplepractices.com">sudharaju@e2epeoplepractices.com.</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m4" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m4')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/yesh.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Ms. Yeshasvini Ramaswamy – Managing Director</p>
                        <p>Ms. Yeshasvini Ramaswamy is the Managing Director of <a href="http://www.e2epeoplepractices.com"><span style="color: #008ADA;">e2e People Practices Pvt. Ltd</span></a> a Leadership Audit firm that helps entrepreneur CEOs scale their businesses. She has been noted to bring in a fresh outlook to business aligned HR practices.</p>
                        <p>A former management consultant at <a href="http://www.infosys.com"><span style="color: #008ADA;">Infosys BPO</span></a>, she has built her expertise in creating people engagement models to help organizations track their ROI on HR related investments and business performance. With her career spanning close to one and half decades with rich experience in startup environments, she has facilitated learning through mentoring and group sessions to more than 3000 people in areas pertaining to leadership principles and self-management. She has managed international migrations "Build Operate Transfer" models from countries such as USA, Australia, England and Dubai in KPO, Training and BPO industry segments. At a national level her BOT model has been to successfully launch India’s first MBA in entrepreneurship with committed funding with <a href="http://www.jgi.ac.in/"><span style="color: #008ADA;">JGI</span></a> where she also serves the Board at JGI Ventures. She has also been instrumental in building robust recruitment processes which hired over 3500 employees over the years.</p>
                        <p>Prior to starting her entrepreneurial venture, she headed the People Practices function for the Velankani conglomerate comprising of companies diverse fields ranging from <a href="http://www.viteos.com"><span style="color: #008ADA;">Hedge Fund Services</span></a>, SEZ, Tech Parks to Food services.</p>
                        <p>With her interactive and thought provoking style of communication, Ms. Yeshasvini has become popular as a visiting faculty at leading business schools including the <a href="http://www.iimb.ernet.in"><span style="color: #008ADA;">IIM-B</span></a>. She was recently invited to the 99th Indian Science Congress as a Key Note Speaker on Women Empowerment. In recognition to her work in encouraging entrepreneurs, she has been nominated as a co- Program Director for the All India IIM entrepreneur accelerator program.</p>
                        <p>In 2012, the State Department, Govt. of The United States of America, nominated Ms. Ramaswamy to represent India in the prestigious Fortune Most Powerful Women Program. She was among the elite 25 leaders chosen from all over the world and was hosted by Secy of State Hillary Clinton. She has also visited the Silicon Valley, Berkeley and Stanford to understand how creative education can support entrepreneurship and hopes to set up a lab promoting innovation and creativity for India. A certified psychometric analyst and People CMM practitioner from Carnegie Mellon University, she has been widely quoted in the press on women entrepreneurship and HR issues, with Economic Times naming her a pioneer woman entrepreneur in the HR space.</p>
                        <p>She was one of the core members of the <a href="http://www.cii.in"><span style="color: #008ADA;">CII (Confederation of Indian Industry)</span></a> Women Business Leaders Forum (WBLF) and the Management Committee Member of the <a href="http://www.csi-india.org/"><span style="color: #008ADA;">CSI</span></a> in Bangalore. She has also contributed to the
                            <a href="http://www.nasscom.org"><span style="color: #008ADA;">NASSCOM’s Diversity & Inclusivity Initiative</span></a> by heading their Cultural D&I group. She has been recognized as an emerging future world leader by GIFT an initiative supported by the Bill Clinton Global Leadership, USA.</p>
                        <p>She devotes her free time on the Board of the <a href="http://samatvamdiabetes.com"><span style="color: #008ADA;">Samatvam</span></a> Trust, which is presided by Justice MN Venkatachaliah, our former Chief Justice of the Supreme Court of India. It is an Endocrinology Diabetes not for profit Center (SEDC) that specializes in treating and managing diabetes for the under-privileged children.</p>
                        <p>You can know more about her through a Google Search “yeshasvini ramaswamy”</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m5" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m5')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/smita.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Smita Tharoor</p>
                        <p>The bigot in your brain. Are you conscious of your unconscious bias?? At Tharoor Associates we understand the importance of stories - both personal and corporate - and their role in defining an organisation's identity and practices. Harnessing the power of your story, we help you become more self aware and in tune with the unique capacities and potential of your organisation. This in turn empowers you to make positive and dynamic changes, communicate your goals and mission and tap into the deepest potential of your employees.</p>
                        <p>Smita has over 20 years experience within corporate, regional and international frameworks and in large voluntary, statutory, health and private sector organisations. She has considerable experience in embedding a Coaching culture into organisations and in providing turn-around solutions for training & development companies in their fledgling state. She has expertise in the pioneering and development of training and education provision; with particular experience in the business management and service improvement areas. Smita is an exceptional self-starter and team player who has a self-reliant "can do" approach. She works flexibly to achieve corporate targets and has a strong passion for challenge. She is adapt at business and corporate relationship building. Her experience working in the UK and India gives her a unique advantage in understanding the expectations and needs of different cultures.</p>
                        <p>Her specialties include Leadership development, strategy development, coaching and people development, alignment of an organisation's people and its external strategy, executive coaching, team coaching, team development, career coaching, cultural alignment.</p>
                        <p>Specialties:Use NLP tools</p>
                        <p>Change/OD consultant </p>
                        <p>Advisory board, School of Leadership Excellence,India </p>
                        <p>Design & Delivery of bespoke training initiatives;Thinking Differently, Diversity, Change Management, Coaching, leadership/management, Positive Action </p>
                        <p>Programmes & compliance led initiatives in India and the UK</p>
                        <p>Executive Coaching & embedding a Coaching Culture</p>
                        <p>Implementer of multiple change/transformational projects such as leadership competencies, business restructuring and system/process reviews.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="m7" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m7')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/varun.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Varun Gupta</p>
                        <p>Varun has completed his Master in Business Administration from Harvard Business School, Elected Chair of External Relations for the South Asian Business Association; Director of Business Plan Initiative for the Entrepreneurship Club; Career Coach to five 1st year students; Financial Accounting Tutor to four 1st year students.</p>
                        <p>Founder and CEO in stealth stage, has played a key role in outlining business strategy for Trans Maldivian Airways Pvt. Ltd and contributed extensively to their organizational development. He is also the founder and manager of Zuna Capital Partners and has contributed towards finding investors from the US, UK and India with $240,000 in search capital – investors included founding partners of US PE funds, CXOs, and Entrepreneurs.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m8" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m8')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/devika.png" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Ms. Devika Ramarathnam – Associate Director</p>
                        <p>Devika heads the HR division of e2e People Practices and is also a passionate handloom Entrepreneur at Ithy-ADee. Devika’s career of more than 25 years, spans across blue-chip companies like Infosys, Deutsche Software, VeriFone, Hewlett Packard, Accenture, Manipal Education. Devika has held responsibility for Business Strategy, Design, Delivery and Operations of L&D. Devika has provided Thought Leadership around Strategic Consulting with Businesses on Learning Solutions, Coaching, Retention Strategies, Talent Management and has contributed in the areas of Diversity, Employee Engagement and Culture Building Initiatives, MADO (Mergers, Acquisitions, Divestitures and Outsourcing), Country HR Leadership Council.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m9" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m9')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/deepak.png" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Deepak Rahul</p>
                        <p>Deepak is a young leader gaining a fast reputation of being one of the top creative minds of the emerging management consulting practice in India. Having worked in high growth environments at First Source and Max New York Life Insurance, in the area of Sales and training, he has been awarded employee of the month and best performer awards.</p>
                        <p>After working for MetLife insurance, his experience with The Jain Group of Institutions as a project manager further enhanced his reputation as an out of box thinker and helped him build his expertise in new product development (lab to land). Among other things, two of his flagship initiatives were working with the core team to launch India's first Global MBA program in Entrepreneurship with committed angel funding spanning 5 Geos (Germany, Sri-Lanka, Philippines, China and Hong Kong) and conceptualizing & administering the En-Act club which is student body driving entrepreneur activities.</p>
                        <p>Having facilitated full house sessions to more than 1800 students, he strongly believes in the promise that the young generation holds for the country and actively devotes time as a student mentor. In the corporate arena he has co facilitated LeAP (Leadership Accelerator Programs) programs in B'lore, Mumbai and Chandigargh. A foodie at heart, he draws his inspiration from nature, loves to travel and adores his bikes. A few of his character sketches have also won him recognition in local publications.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m10" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m10')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/shesadri.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Shesadri Mukundhan</p>
                        <p>Elect & Comm Engineering degree. IIT alumnus.</p>
                        <p>31 years of Corporate & Entrepreneurial work-life experience globally</p>
                        <p>22 years with Technology Companies : JVs of Canon & Siemens, Hewlett Packard (HP) and Agilent Technologies Inc</p>
                        <p>9 years @ HP in Leadership roles in India & Singapore (Asia Pacific Region role). Spans Manufacturing, Procurement, Supply Chain & Quality.</p>
                        <p>7 years @ Agilent Tech in Singapore & USA. Wholesome Business & Support function experience. Upon Exit as Director of a Significant & Global foot-print business, Re-located to India to Establish businesses to serve Glo-Cal Customers</p>
                        <p>Multiple Foreign Service assignments in Asia & USA</p>
                        <p>Lead several Strategic & Operational Excellence Initiatives spanning Global Mfg & Distribution Supply chain, Mind-to-Market Products/ Solutions dev. Business growth, Disruptive Business Transformation, Global Sourcing & RFQs, M & A Integration, ERP Implementation</p>
                        <p>Since July 2006, passionately wearing Investor, Director & CEO hat.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="m11" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m11')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/narendra.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Prof. Narendra M. Agrawal </p>
                        <p>Narendra M. Agrawal is an Adjunct Professor in OBHRM area at IIM Bangalore (He superannuated as a full professor in July 2014). Prior to joining IIMB, Professor Agrawal worked for 24 years with Hindustan Aeronautics Limited.</p>
                        <p>Professor Agrawal’s areas of research interests are essentially organisation focused and multi-disciplinary in nature. His current research interests are human challenges of knowledge organizations, innovative learning processes in high performing Indian organizations, leadership and change management, developing leadership pipeline, managing knowledge workers, creating learning and innovative organizations, and designing effective training systems. Professor Agrawal is consultant to a large number of public and private sector enterprises, and to central and state governments in India and abroad. He has conducted more than 500 management development programmes in India and abroad.</p>
                        <p>He has been a British Council Scholar. He is visiting faculty at St. Gallan University, Switzerland, Gothenburg University, Sweden; AESE, Lisbon, IESE, Madrid , PUC, Chile and PIM, Colombo, Sri Lanka.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m12" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m12')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/chandrika.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Ms. Chandrika</p>
                        <p>Co-Founder & Director at Aplus Corporate Protection Services (ACPS) Pvt Ltd. "ACPS - A Total Security Solutions Company" located in Bangalore.</p>
                        <p>I have over 2 decades of experience in the areas of People Management, Customer Management and Psychological Counselling. Started my career with Software Technology Parks of India in 1992 (STPI - set up in 1991 by the Government of India under the Dept of Electronics and IT), followed by stints as HR Manager at Revere Group India (an offshore business centre of NTT Data company), SemIndia Systems (an ODM for telecom products). I was heading the Membership Services at India Electronics Semiconductor Association IESA (then ISA) and prior to ACPS was the Business Head - Certificate Programs at Latitude Edutech. During my tenure with STPI and IESA I was part of Government and Business Delegations to the US and UK. </p>
                        <p>At ACPS, we conceptualised an initiative called MPOWER which offers counselling services to individuals (including ACPS Security Personnel), NGOs, Schools, Colleges & Corporate.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m13" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m13')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/RAGA.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Ms. Raga D’silva</p>
                        <p>Raga D’silva has over 20 years of background in advertising, marketing, brand development and strategic fundraising.</p>
                        <p>Raga has worked with the top agencies in India, including Lowe Lintas, JWT, McCann, and was the VP and Branch Head for Lintas Direct until 2001, before she immigrated to New Zealand.</p>
                        <p>In New Zealand, she spearheaded large initiatives in her numerous senior management roles in advertising and marketing. Raga set up Global Village Unlimited, a consulting agency in 2007 to support New Zealand businesses with their market entry into India. As an India market entry expert, Raga served on various boards, including the prestigious India New Zealand Business Council, as their Deputy Chair for 3 years.</p>
                        <p>This business has now evolved and has registered companies in India, the UK and New Zealand, and was re-branded as RHM Global, with the registered name as Red Hot Mirchi Consulting. The geographic reach is now extensive with its multi-country operations, including China and Hong Kong.</p>
                        <p>RHM Global focuses on creating personal brands and developing business-tobusiness strategies for corporate companies with focus in India. It made it’s entry into the knowledge space in 2007 with large scale premium open programs with top management gurus such as Late Stephen Covey, Edward de Bono, Deepak Chopra, Tom Peters, with seminars in New Zealand, Australia, China, Hong Kong, Singapore, Malaysia and India.</p>
                        <p>Raga has been the South Asian Ambassador for one of the UKs largest NGO’s, Diabetes UK since 2013, with her own story of overcoming diabetes. She is also the founder of Use it 2 Lose it, which has a large membership, and has made many appearances on mainstream television – BBC, Sky News UK, ITV, Channel 5 UK, and is regularly featured in the top magazines in the UK.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="m14" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m14')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/anoop.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Anoop Sequeira</p>
                        <p>Anoop Sequeira, is a charismatic motivational speaker and a corporate trainer specializing in leadership, life skills and outbound training. He strongly believes that “attitude is the foundation of success”.
                            Anoop has led teams to success with the belief that individuals and teams deliver their best when they are happy and work from their heart. Excellent people management and leadership skills have been Anoop’s key factors of success and it is these attributes that he blends into his training programs. Energetic and articulate, Former CEO of Pizza Corner, Starbucks, and an entrepreneur with Currylicious, he draws from his past experiences to deliver a world class program. </p>
                        <p style="margin-top: 10px">Areas of Training Expertise :</p>
                        <ul style="list-style: inside;">
                            <li>Train the Trainer</li>
                            <li>Leadership for First Time Managers</li>
                            <li>Interview Skills</li>
                            <li>Supervisory Skills</li>
                            <li>Setting SMART goals</li>
                            <li>Art of delegation</li>
                            <li>Presentation Skills</li>
                            <li>Time Management</li>
                            <li>Passion at Work</li>
                            <li>Managing Conflict</li>
                        </ul>

                        <p style="margin-top: 10px">Workshops conducted at JGI IDEA :</p>
                        <ul style="list-style: inside;">
                            <li>Franchising and Retail Management (Feb 2013 and Aug 2014)</li>
                            <li>Time Management (Oct 2014)</li>
                        </ul>

                        <p>During the training program’s Anoop blends in anecdotes and real life examples to drive home the objectives to the participants. Workshops conducted by Anoop involve high energy, high level of motivation and encourages active participation and involvement by trainees to ensure lasting impact.</p>

                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m15" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m15')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/kusum.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Ms. Kusum Prasad</p>
                        <p>Being a creative, adaptable and a meticulous worker by nature she have built a ground for herself in the industry. She has been teaching and delivered training for about 20 years in the areas of Corporate and Organisational Institutes.</p>
                        <p>Along with the above mentioned , she has an MA in English, DCM, DIATM, B Ed and Certificate of Proficiency in Corporate Growth and Organizational Behaviour from Columbia Business School.</p>
                        <p>She has trained at all levels in an organization, from Campus to Corporate to Directors. She travels Pan India to conduct her training.</p>
                        <p>Some of the reputed clients she have worked with are ANAND GROUP OF INDUSTRIES ,BIRLA SOFT, BRISTLECONE , CADES, CIBER, COMFED, DBS, DELOITTE, DHL, EUREKA FORBES, GATI, GRANT THORNTON, HDFC,HICAL , ICAI, ICICI, INFOTECH, JINDAL’s , L&T(Constructions, Finance ,Ship building) , MATE , Ministry of Public Health and Social Welfare, ORACLE, ,QUALITY GROUPS (TANZANIA ), ,SIEMENS, SIGNODE ,SUZLON, TYCO, UNFPA, YODDLE etc to name a few</p>
                        <p style="margin-top: 10px">Professional Qualification</p>
                        <ul style="list-style: inside;">
                            <li>Graduate - B.A. B Ed</li>
                            <li>Post Graduate – MA</li>
                            <li>Diploma in Computer Management</li>
                            <li>Diploma in Airline and Travel Management</li>
                            <li>Certification from Columbia Business School in Corporate Growth and Organizational Behavior</li>
                            <li>Certification from UNFPA – Master trainer in Adolescence Empowerment Programme </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m16" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m16')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/kranthi.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Kranthi Varma</p>
                        <p>Indian Kranthi is a third generation filmmaker, distributor and exhibitor.</p>
                        <p>He completed his Masters in Marketing at Victoria University of Wellington and his MBA from Melbourne Business School. He manages a chain of cinema theatres around South India and was also responsible for bringing the first moonlight cinema concept to India. Mr Varma is an honorary member of the Karnataka Film Chamber of Commerce.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="m17" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m17')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/hemachandran.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Hemachandran </p>
                        <p>Hemachandran Sheshadri is an accomplished leader and visionary with over 3 decades distinctive experience in managing the finance functions involving Strategic Management, Accounts / MIS, Fund Management / Budgeting, Auditing / Compliance, Financial Planning as well as Cost Accounting.</p>
                        <p>Worked in all parts of the world as an international manager. A keen planner with recognised proficiency in country and regional management, program administration, project management, instituting systems and controls for pro-active financial management, developing cost savings methods to impact bottom line, conducting investigations and developing problem solving measures.</p>
                        <p>A multicultural and multilingual international manager with proven track record of delivering results coupled with exceptional communication and relationship management abilities.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m18" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m18')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/vasudevan.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Vasudevan Srinivasan</p>
                        <ul style="list-style: inside;">
                            <li>Advisor, mentor, and coach for senior executives.</li>
                            <li>Facilitator & Coach for grooming effective senior leaders.</li>
                            <li>Advisor for senior leadership selection through assessment systems.</li>
                            <li>Help second line leaders rise to the top quickly and capably.</li>
                            <li>Build organization wide systems that foster a positive leadership culture.</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <div id="m19" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m19')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/kunalshah.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr.Kunal Shah</p>
                        <p>Kunal Shah is the founder & Senior Counsellor at Stencil Consulting, Bangalore. He has over 15 years of marketing strategy consulting, brand management and sales experience, working for leading companies in the U.S. Apart from counselling Kunal has been a active speaker at various forums and has extensively spoken on education, entrepreneurship and on self help.</p>
                        <p>He has been invited for some of the prestigious universities & organizations from across India to address their teams. He has also conducted various workshops at these places to get the members completely involved in his teachings. He is a excellent speaker and a fantastic motivator.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m20" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m20')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/anand.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Anand Reddy</p>
                        <p>Anand is a qualified professional with over 31 years of experience in the Service Industry (Hotels, Retail, Education & Consulting). He is passionate about the process of learning and helping people optimize their learning potential.</p>
                        <p>Anand has worked in Taj Group of Hotels for 16 years after completing his education in Hotel Management from IHM, Chennai.</p>
                        <p>He rose to become an Executive Chef in 6 years time and headed the kitchen teams at Fisherman’s Cove and Connemara for 3 years at each place.</p>
                        <p>Developing people is his strength that has been proved throughout his career. Spurred by the desire to be involved full-time in Training and Development of all staff, moved to Training, as Manager – Training for the Madras Region of Taj Group of Hotels, where he established a Regional Training Center.</p>
                        <p>To gain international exposure he joined Spinneys Abu Dhabi as Training Manager. Spinneys Abu Dhabi was part of Inchcape, a Fortune 500 company. There he established a new training centre and created systematic training process for all staff. Acknowledging his abilities he was given an opportunity to lead culture change initiatives of the Company. As part of these initiatives he has been responsible for implementing performance enhancement system which included 3600 Appraisal system, cross functional teams, career planning, succession planning, evaluating organisational interventions & systems etc.</p>
                        <p>Called back by the academic world, he joined as Principal in PES Institute of Hotel Management. Here he has implemented innovative system known as “SMILE”. SMILE stands for Self Managed In-depth Learning.</p>
                        <p>After training the faculty in SMILE system and implementing it successfully moved on to be part of the founding team that has established “Vishwa Mitra Academy of Learning” as a trust to implement “Integral Education - Educational Vision of Swami Vivekananda”. VIMAL Consulting is a subsidiary that focuses on Learning & Development initiatives to corporate clients.</p>
                        <p>Apart from “Vishwa Mitra Academy of Learning” he is also one of the directors who have started “ACE Institute for Creating Excellence”.</p>
                        <p>ACE Institute for Creating Excellence offers a very unique program titled “Igniting Minds” for activating the mid-brain in children falling in the age group of 6 to 15 years and their parents.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m21" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m21')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/rubia.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Ms. Rubia Braun</p>
                        <p>Australian/German Rubia has also been working in the film industry for over a decade in varying positions, companies and continents. She graduated with first class honours with a Bachelor of Communications and a Bachelor of Media Studies at RMIT University.</p>
                        <p>She also attended the Victorian College of Arts (Film and TV School). Rubia consults regularly for ‘Bollywood’ productions; film institutes and is currently delivering keynote speeches on ‘connecting with your market’ as part of ‘Techsparks’ conferences around India.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m22" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m22')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/sanath-ram.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Sanath Ramakrishna</p>
                        <p>Sanath manages the finance, secretarial and corporate development function at VITEOS. In this role, he is also responsible for assisting in strategic growth opportunities and unlocking the value of the company. He brings several years of experience in diverse domains in areas of mergers & acquisitions, transaction structuring, investment advisory, intellectual property management, international taxation etc. Prior to joining the company, Sanath held senior leadership positions in leading Big-6 audit and consulting firms and was primarily responsible for providing innovative top-end holistic and practical solutions as a trusted business advisor for dynamic companies with global ambitions. Sanath is a Fellow member of both the Institutes of Chartered Accountants of India & Company Secretaries of India and an Associate Cost and Management Accountant from the Institute of Cost Accountants of India with Bachelor’s degree in Commerce. He has also completed the executive program on Managing and Transforming Professional Service Firms of the Harvard Business School.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m23" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m23')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/deepak-k.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Deepak Kaushik</p>
                        <p>A CA with more than 18 years of experience, Deepak is the Founder & CEO of FinAKS. He brings a holistic yet focused outlook given his experience in industries such as FMCG, IT, Financial Services and BPO. Deepak has held key Finance positions in Wipro and Oracle where he has proven his ability to negotiate contracts upward of $100 million with Fortune 500 companies. His core areas of expertise include Business Finance, Commercial Contracting, Financial Planning and Analysis, Corporate Governance, Cost Optimization and Mergers & Acquisitions.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m24" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m24')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/amitabh-c.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Amitabh Chaturvedi</p>
                        <p>As Managing Director, Mr. Chaturvedi is responsible for the overall functioning of Essel Finance.</p>
                        <p>With over 26 years of rich experience in the areas of Banking, Asset Management, Investment Banking, and Insurance, Mr. Chaturvedi has worked with leading financial companies such as Reliance Capital Ltd, ICICI Bank Ltd., Lloyds Finance Ltd., and Dhanlaxmi Bank Ltd.</p>
                        <p>His last assignment was with Purple India Holdings Ltd., as an Executive Vice Chairman, where he developed strategic affiliations with international partners, providing a global reach for the company’s clients. Prior to joining Purple, he was the Managing Director and CEO of Dhanlaxmi Bank where he was instrumental in transforming the Bank from a regionally focused bank with a business size of approximately Rs.5800 crores to a pan-India Bank with a business of approximately Rs.23,000 crores in a short span of 3 years.</p>
                        <p>Mr. Chaturvedi is a qualified Chartered Accountant and a commerce graduate from the University of Mumbai.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m25" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m25')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/swami.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Swaminathan</p>
                        <p>School of Inspired Leadership (SOIL) strengthens the SOIL Leadership Team with the appointment of Mr. Swami Swaminathan as the new board member. Mr. Swaminathan is currently the Executive Chairman of Manipal Health Enterprises, a leader in the Healthcare Industry in India.</p>
                        <p>Mr. Swaminathan has over 35 years of rich and varied experience in General Management, Finance & Accounting, Sales & Marketing, International Trading and Human Resources Management. He has performed multiple roles in Sales, Marketing and Operations, leading global teams in the Automobiles, Consumer Durables, Technology, Manufacturing and Services industries. He has also been associated with infrastructure projects in India and overseas.</p>
                        <p>Prior to joining Manipal Health Enterprises he was the Managing Director & Chief Executive Officer of Infosys BPO (a fully owned subsidiary of Infosys Ltd) with annual revenues of over  600 Million dollars.  Mr. Swaminathan led the firm  building a  25000 + team worldwide, of over 65+ different nationalities in their workforce, and  global operations in 6 centers in India and over 18 centers outside India in Americas, Europe, LATAM and  APAC.</p>
                        <p>Recognized as a thought leader in the industry Mr. Swaminathan is a key note speaker in many global conferences and has led teams helping over 150 global corporations in improving their efficiencies, effectiveness and helping them to move into new markets. During his stint at Infosys BPO, Mr. Swaminathan successfully concluded and integrated key acquisitions in USA, Europe and Australia.</p>
                        <p>Mr. Swaminathan is a Chartered Accountant and has had successful stints in various Companies like IBM, East India Hotels, Eicher, Nippon Gulf and OTE group   in   multiple roles and in leadership positions.</p>
                        <p>He is a great believer in processes and metrics and has made operational excellence a key focus for business growth. Under his leadership, Infosys BPO won several key awards for partnerships with clients, such as the Shared Services Excellence Awards for Best New Outsourced Services Delivery   and Innovation breakthrough awards at Global Supplier events of world class corporations.</p>
                        <p>Under his leadership Infosys BPO has also won several awards for people practices, such as The Stars of the Industry award for BPO Organization of the Year and RASBIC Awards for Recruiting and Staffing Programs.</p>
                        <p>Committed to Sustainability, Infosys BPO under his leadership was also recognized by the President of India for its energy efficient work spaces in India.</p>
                        <p>We congratulate Mr. Swaminathan and extend our heartiest welcome to SOIL family.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m26" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m26')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/shyam-p.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Shyam Powar - Head - Corporate Finance</p>
                        <ul style="list-style: inside;">
                            <li>Founded Allegro in 2002</li>
                            <li>24+ years experience in corporate finance roles across multinational organizations including as Director (Corporate Finance) Arthur Andersen and Larsen & Toubro</li>
                            <li>Expertise in M&A, Debt Restructuring & Take-outs, Private Equity and IPO advisory</li>
                            <li>MBA from Tulane University (US), Chemical Engineering Graduate from IT BHU</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="m27" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m27')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/srinivas-k.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Mr. Srinivas Katta - Partner, Induslaw </p>
                        <p>Srinivas represents entrepreneurs and businesses on corporate governance issues, fund raising, partnerships, joint ventures, collaborations, acquisitions and exits including listing. He also advises Investment Funds in their investment into companies and businesses. Srinivas also heads the Hyderabad office of the firm, which was voted as the law firm of the year for 2010 and 2011 and IFLR.</p>
                        <p>Srinivas has been listed in Chambers & Partners as a leading individual in Corporate/ M&A field (Bangalore based) in Band 1. He is also an advisors to business across various sectors and is a member of the board of several companies. Srinivas is also a trustee and advisor to certain charitable foundations & projects.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m28" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m28')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/anjana.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Anjana Vivek - Founder-Director</p>

                        <div class="col-lg-12">
                            <div class="col-lg-4">
                                <p class="ab">FCA, BSc. Honours (Physics), Delhi University :</p>
                                <ul style="list-style: inside;">
                                    <li>Sought out international speaker</li>
                                    <li>Teaching notes on valuation, growth & funding have been Global Top 5% (2014) and 4% (2013) of SlideShare Content viewed</li>
                                    <li>Author of 3 books published by the Institute of Chartered Accountants (ICAI) and Karnataka CA Association</li>
                                    <li>Founding Editor, Venture Activity Reports of Indian Venture Capital Association (IVCA)</li>
                                </ul>
                            </div>

                            <div class="col-lg-4">
                                <p class="ab">30 years of work experience :</p>
                                <ul style="list-style: inside;">
                                    <li>Visiting Faculty, IIM Bengaluru</li>
                                    <li>Visiting Faculty, IIM Udaipur</li>
                                    <li>Charter Member, TiE Bangalore</li>
                                    <li>Mentor, Microsoft Ventures</li>
                                    <li>Executive Committee Member, JGI Ventures</li>
                                    <li>Venture Advisor, Unitus Seed Fund</li>
                                    <li>Co-opted Member, ICAI “Women Members Empowerment Committee” 2014-15.</li>
                                    <li>Faculty, Finance & Control, IIM Bengaluru</li>
                                    <li>COO, NSRCEL, IIM Bangalore</li>
                                    <li>Vice President, Ernst & Young</li>
                                    <li>Consultant, Centre for Technology Development</li>
                                </ul>
                            </div>

                            <div class="col-lg-4">
                                <p class="ab">Areas of Expertise :</p>
                                <ul style="list-style: inside;">
                                    <li>Business and Financial Planning, Business Models</li>
                                    <li>Venture Capital, Funding Strategy</li>
                                    <li>Entrepreneurship, Intrapreneurship</li>
                                    <li>Valuation</li>
                                    <li>M&A, Due-diligence</li>
                                    <li>Women Empowerment and Leadership</li>
                                    <li>Mentoring & Coaching</li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m29" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m29')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/jordan.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Eleanor Tabi Haller-Jorden - President and CEO of The Paradigm Forum GmbH (TPF)</p>
                        <p>Eleanor Tabi Haller-Jorden is the President and CEO of The Paradigm Forum GmbH (TPF), a global consultancy and think tank operating at the intersection of social justice and workplace innovation. TPF works with forward-thinking corporate, governmental and academic partners to translate strategy, communication and experience-based learning into positive organizational change.</p>
                        <p>Previously, Ms. Haller-Jorden held the position of Senior Vice President Global Learning Strategies at Catalyst, where she designed cutting-edge initiatives to promote organizational inclusion and innovation in diverse cultural contexts. As General Manager of Catalyst Europe (CE) upon its founding in 2006, she worked with distinguished European corporate and academic members, as well as governments, to establish its reputation as an effective and agile strategic partner.</p>
                        <p>Prior to Catalyst, Ms. Haller-Jorden founded The Paradigm Group, an international consultancy noted for its research capabilities and programs in workplace design and cross-cultural management. She has held the positions of Officer at J.P. Morgan; Lead Partner at HNC Consulting; Executive Director at The Learning Labs; and Founder of the Public Policy Centre in Philadelphia (US).</p>
                        <p>Ms. Haller-Jorden is a frequent media contributor, speaker and lecturer. Apart from giving the keynote address at the 2015 Healthcare Businesswomen’s Association Annual Summit, 2014 International Women’s Conference (Belfast) and 2014 European Commission International Women’s Day Conference, she spoke at the 2014 Women’s Forum (Deauville) and Zurich-based chapter of TED. She has been interviewed for the Wall Street Journal, Financial Times, BBC and CNN; and featured in Profiles in Diversity Journal, Careerpreneurs (Lessons from Leading Women Entrepreneurs on Building a Career Without Boundaries) by Dorothy Perrin Moore and Capitalizing on the Global Workforce by Michael S. Schell and Charlene Marmer Solomons.</p>
                        <p>Ms. Haller-Jorden has been appointed to two initiatives founded by Hillary Clinton: the Vital Voices Global Partnership as a Global Ambassador, and the Women in Public Service Project as a faculty member during the 2013 Summer Institute Peacebuilding and Development. She has been named a European Thought Leader by the IBM Global Innovation Outlook initiative. In addition, she has acted as a jury member for both the Cisco Networking Academy’s European & Emerging Market Awards and the Opportunity Now 2014 and 2015 Awards.</p>
                        <p>Ms. Haller-Jorden attended Princeton University as an advanced standing scholar and Bryn Mawr College, where she earned her B.A. magna cum laude in History. She was named a Sage Fellow in Design & Environmental Analysis at Cornell University. She holds a M.Sc. in Industrial Relations from the London School of Economics and Political Science.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m50" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m50')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/dr-arun.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Dr. Arun Krishnan</p>
                        <p>Dr. Arun Krishnan is the founder and CEO of a new, HR Analytics
                            startup, nFactorial Analytical Sciences, based out of Bangalore.
                            nFactorial's flagship platform n!Gage is a pioneer in the area of real-time,
                            continuous employee feedback and analytics. Arun obtained his
                            undergraduate degree from the Central Electro-Chemical Engineering
                            Institute and a Ph.D in Chemical Engineering specializing in advanced
                            control algorithms from the University of South Carolina, USA in 1998.After working for a year in a controls company, he left the US and joined Silicon Graphics in Singapore. He then moved into active research in high performance computing and bioinformatics with the Bioinformatics Institute in Singapore.</p>
                        <p>Arun was also an adjunct assistant professor at the National University of
                            Singapore in the Computer Engineering Department. In 2006, he moved
                            to Japan as an Assistant Professor for Computational Biology at the
                            Institute for Advanced Biosciences in Keio University where he did
                            research in protein structures, protein folding and application of
                            Machine Learning and AI to understand gene networks through systems
                            biology.</p>
                        <p>In 2008, Arun returned to India to join Monsanto and set up their
                            Computational Biology unit. He held various positions with Monsanto
                            with his last position being the R&D IT India lead. In 2012 he joined ISB
                            Hyderabad's PGPMAX program and completed his MBA in 2013. Dr.
                            Krishnan started nFactorial Analytical Sciences in December of 2014.
                            Arun is also a visiting faculty at IIM Ranchi where he teaches a course on
                            HR analytics.</p>
                        <p>Arun has more than 50 articles in journals, conferences and book
                            chapters.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <div id="m51" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m51')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/rajiv-r.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Rajiv Raghunand</p>
                        <p>Rajiv has over seventeen years of experience across business consulting, outsourcing (BPO), technology and corporate finance. He has led business units with a $100 mn P&L and has overseen acquisition, implementation and delivery of operational outsourcing programs across multiple industry segments & functional areas. In his most recent role prior to seedX, Rajiv had changed tracks and built & scaled a reporting & compliance technology platform targeted at institutional investors for their investments in alternative assets such as hedge funds, private equity & derivatives.</p>
                        <p>Over the last six years, he has also been actively involved with multiple early stage ventures in different capacities. Ranging from advising on strategy, marketing & operations to himself being an angel investor in a couple of ventures, Raijv has inculcated a passion for enabling success of emerging ventures. He holds a strong belief that angel funding in India is a vast untapped opportunity area; not just for the start-ups but also for the investors as an unexplored avenue of investment. His association with SeedX stems from the common vision that angel investing has been the 'preserve of a few' in India but with the right hand-holding & support this can be changed and a whole new segment of investors can participate in the angel funding & value creation process in many different ways.</p>
                        <p>Rajiv holds a PGDM from the Indian Institute of Management, Bangalore. He has a graduate degree in accounting and a degree in management accounting from the Institute of Cost Accountants of India.</p>
                        <p>LinkedIn Profile : <a target="blank" href="https://www.linkedin.com/in/rajiv-raghunandan-669b27/" style="color: #0088C7;">Rajiv Raghunand</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="m52" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m52')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/ganesh-prabhu.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Prof Ganesh N Prabhu</p>
                        <p>Professor Prabhu's areas of research and teaching are product innovation, strategic management and entrepreneurship. He has published in leading journals like the Academy of Management Review and Research Policy and was invited to be on the editorial board of the Journal of Management, US.</p>
                        <p>Professor Prabhu has conducted top management sessions for Honeywell, ITC, Qualcomm, Tata Group, Tessaract and Tetra Pak and has conducted strategy, visioning or innovation workshops for senior executive groups at Bharat Electronics, Crompton Greaves, ETA Ascon Holding, HAL, Honeywell, Indian Oil, L&T, Quest, Oracle, Union Bank of India. He jointly coordinates executive programmes Strategic Analysis for Competitive Advantage and Creating Successful New Products and has led customized programmes for Amul, Cognizant, CA Technologies, Future Group, Trent, Reliance, Seimens,Wipro-GE and Yahoo.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="m53" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m53')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/nandlal.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Nandlal Narayana</p>
                        <p>Founder and Chief Mentor at Mind Mentor. A Consulting, Coaching, Behavioural and Organizational Development Expert. Close to five decades of experience in the business and social development sectors.  Is an expert in the area of Human Resources Management, Individual Development, and Organizational Development and Change, Strategic Planning, Competency Mapping, Capacity Needs Assessment and Planning, Individual and Group Behavioural Assessment, Personal Change Management. Has led many initiatives of Organisational Change Management in large corporate houses and social development organizations. </p>
                        <p>LinkedIn Profile : <a target="blank" href="https://www.linkedin.com/in/nandlal-narayanan-83b8051/?ppe=1" style="color: #0088C7;">Nandlal Narayanan</a></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div id="m54" class="delModal" style="display:none;background-color: rgb(13, 25, 50);">
        <div class="modal-dialog">

            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" onclick="hideModal('m54')">&times;</button>
                    <h4 class="modal-title ab">e2e Team</h4>
                </div>
                <div class="modal-body" style="display: table-row;">
                    <div class="col-md-12 modal-sub-title">
                        <img class="team-pic" src="images/team/rajesh-ceo.jpg" alt="image">
                        <p style="font-weight: 600;" class="abt-sub-titles">Rajesh Khamat</p>
                        <p>CEO and director of Corporate Chanakya Consulting and Learning, who has over 20 years of experience in consulting</p>
                        <p>He combines the best of western and Indian management science to provide leadership consulting and learning solutions to the industry</p>
                        <p>Rajesh has cofounded More than HR Global , which has grown since then into a knowledge community of over 16,000 members worldwide. </p>
                        <p>He is also on SHRM’s Advisory Council. </p>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php include('footer.php'); ?>

<script>
    function showModal(id) {
        $('#' + id).fadeIn();
        //$(this).fadeIn('slow');
    }

    function hideModal(id) {
        $('#' + id).fadeOut();
    }




    (function() {
        function activateTab() {
            if (activeTab) {
                resetTab.call(activeTab);
            }
            this.parentNode.className = 'tab tab-active';
            activeTab = this;
            activePanel = document.getElementById(activeTab.getAttribute('href').substring(1));
            activePanel.className = 'tabpanel show col-lg-12 tab-max-height';
            activePanel.setAttribute('aria-expanded', true);
        }

        function resetTab() {
            activeTab.parentNode.className = 'tab';
            if (activePanel) {
                activePanel.className = 'tabpanel hide';
                activePanel.setAttribute('aria-expanded', false);
            }
        }

        var doc = document,
            tabs = doc.querySelectorAll('.tab a'),
            panels = doc.querySelectorAll('.tabpanel'),
            activeTab = tabs[0],
            activePanel;

        activateTab.call(activeTab);

        for (var i = tabs.length - 1; i >= 0; i--) {
            tabs[i].addEventListener('click', activateTab, false);
        }

    })();


    /*back arrow*/
    $('.tab').on('click', function(e) {
        e.preventDefault();
        var whichtab = $(this).attr('href');
        $(this).parent().find('.active').removeClass('active');
        updateTab(whichtab, $(this).parent());
        return false;
    });
    $(document).ready(function() {
        if (document.location.hash.length > 0)
            updateTab(document.location.hash);
    });
    var updateTab = function(tab, parent) {
        if (!parent)
            parent = document;
        if (parent.find('.tab[href=' + tab + ']').length < 1)
            return;
        parent.find('.tab[href=' + tab + ']').addClass('active');
        parent.find('.tabContent-' + tab.replace('#', '')).addClass('active');
        window.history.replaceState({}, '', tab);
        return true;
    };

</script>

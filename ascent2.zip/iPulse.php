<!DOCTYPE html>
<html>
	<head>
		<title>iPulse Assessment</title>
	</head>
	<meta name="viewport" content="width-device-width, initial-scale=1.0">
	<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/base/jquery-ui.css" rel="stylesheet"/>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js"></script>
	<style>
		
		.profilepress-reg-status{
  /*border-radius: 6px;*/
  font-size: 17px;
  line-height: 1.471;
  padding: 10px 19px;
  background-color: #e74c3c;
  color: #ffffff;
  font-weight: normal;
  display: block;
  text-align: center;
  vertical-align: middle;
  margin: 5px 0;
}
/*form styles*/

#msform {
 position: relative;
}

#msform fieldset {
  background: white;
  /*border: 0 none;
  border-radius: 3px;
  box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
  padding: 20px 30px;
  box-sizing: border-box;
  width: 80%;
  margin: 0 10%;*/
  /*stacking fieldsets above each other*/
  position: absolute;
}
/*Hide all except first fieldset*/

#msform fieldset:not(:first-of-type) {
  display: none;
}
/*buttons*/

#msform .action-button {
  width: 100px;
  background: #27AE60;
  font-weight: bold;
  color: white;
  border: 0 none;
  border-radius: 1px;
  cursor: pointer;
  padding: 10px 5px;
  margin: 10px 5px;
}

#msform .action-button:hover,
#msform .action-button:focus {
  box-shadow: 0 0 0 2px white, 0 0 0 3px #27AE60;
}
		
	  h4{
			text-align:center;
			font-size: 28px;
			padding: 30px;
		}
	.header{
		height: 150px;
		width:100%;
		background-color:gray;
		margin-top:-40px;
	}
	img{
		margin-top:-250px;
	margin-left: 1000px;
		}
	h5{
		text-align:center;
		font-size: 24px;
	margin-top:20px;
		}
	.title{
		margin-left: 50px;
	font-weight:bold;
		}
	li{
		padding:15px;
	color:black;
	font-style:verdana;
		margin-left: 50px;
	margin-right: 100px;
		}
		
		input{
		margin-left: 450px;
		margin-top: -20px;
	    }
	.input-name{
		margin-left:350px;
		margin-top:20px;
		}
	input[type=text],input[type=email]{
          width: 30%;
		padding:5px;
           margin-top: -40px;
          display: inline-block;
         border: 1px solid #ccc;
          border-radius:3px;
          box-sizing: border-box;
			/*border: none;
    border-bottom: 1px solid #fff;*/
			/*background-color:#092840;*/
			color: black;
           }
		.agree{
			margin-left:400px;}
		.content{
			margin-left:30px;
		margin-top:-20px;
		font-size:18px;}
		.content1{
			margin-left:30px;
		margin-top:-20px;
		font-size:18px;
			color:red;}
			
		.header1{
		height: 210px;
		background-color:gray;
	margin-top:-40px;}
	.img{
		margin-top:-250px;
	margin-left: 1000px;}
		.title1{
			margin-left: 30px;
		margin-top:-20px;}
		
		.col-1{
			margin-left: 20px;
		     height:50px;
		      width: 250px;
		font-size:20px;}
		.col-1:hover,.col-2:hover,.col-3:hover,.col-4:hover,.col-5:hover{
			border:2px solid #489fcc;
		}
		.col-2{
			margin-left:267px;
			margin-top: -50px;
			height:50px;
			width:250px;
		    font-size:20px;
		}
		.col-3{
			margin-left:515px;
			margin-top:-50px;
			height:50px;
			width:250px;
		font-size:20px;}
		.col-4{
			margin-left:764px;
			margin-top:-50px;
			height:50px;
			width:250px;
		font-size:20px;}
		.col-5{
			margin-left:1010px;
			margin-top:-50px;
			height:50px;
			width:250px;
	margin-right:20px;
		font-size:20px;}
		
		input[type="checkbox"]{
			margin-left:20px;}
		
		.redBackground{
background-color:#489fcc;
}
	</style>
	<body>
	<form method="post" action="ip1.php">
  <div id="msform">
    <!-- fieldsets -->
    <fieldset>
      <div class="header">
	<h4>iPulse Personal Values Assessment</h4>
	 <img src="images/iPulse logo.jpg" height="100px" width="130px">
	</div>
	<h5>Welcome to the Values Assessment</h5>
	<p class="title"> INSTRUCTIONS<p>
	<ol>
		<li> The survey takes 5 minutes. At the end of the survey, you will see a message that your responses have been successfully entered.</li>
		<li> You will be asked to select 10 words from a list of values/behaviors.</li>
		<li>iPulse will use the information you share to create cultural analysis reports. Personal information you provide will be used solely for this purpose and processed according to our data privacy policy. In addition, we may anonymize and use your results in an aggregated manner to conduct research and improve future services. To consent to these terms, please tick the box.<br></li>
			</ol>
		<input required type="checkbox" name="Agree" class="agree" id="agree" style="margin-left: 350px;">Agree <br>
		<p class="input-name">Please Enter your name</p><br>
		<input type="text" name="name"  required autocomplete="off" style="margin-left: 350px;">
		<p class="input-name">Please provide your email address for the report</p><br>
		<input type="email" name="email"  required autocomplete="off" style="margin-left: 350px;">
      <input type="button" name="next" id="next" class="next action-button" value="Next"/>
    </fieldset>
	  
    <fieldset>
      <div class="header1">
	<h4>iPulse Personal Values Assessment</h4>
	 <img  class="img" src="images/iPulse logo.jpg" height="100px" width="130px">
		<h3 class="title1">PERSONAL VALUES</h3><br>
		<p class="content">Please select ten of the following values/behaviors that most reflect who you are, not who you desire to become. Click on a word to add or remove your selection.</p>
		  <p class="content1">Please ensure that you select only 10 words else next button wont be enabled!!</p>
		 </div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Caution" class="checkbox">Caution</div>
    <div class="col-2"><input type='checkbox' name='detailsid[]' value="Personal Image" class="checkbox" >Personal Image</div>
    <div class="col-3"><input type='checkbox' name='detailsid[]' value="Health" class="checkbox">Health</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Wisdom" class="checkbox">Wisdom</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Well-being" class="checkbox">Well-being</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Ethics" style="margin-left:20px;">Ethics</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Competence" class="checkbox">Competence</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Self Discipline" class="checkbox">Self Discipline</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Wealth" class="checkbox">Wealth</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Achievement" class="checkbox">Achievement</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Commitment" style="margin-left:20px;" class="checkbox">Commitment</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Integrity" class="checkbox">Integrity</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Forgiveness" class="checkbox">Forgiveness</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Courage" class="checkbox">Courage</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Risk Taking" class="checkbox">Risk Taking</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Friendship" class="checkbox">Friendship</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Humility" class="checkbox">Humility</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Power" class="checkbox">Power</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Balance (Work/life)" class="checkbox">Balance (Work/life)</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Recognition" class="checkbox">Recognition</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Environmental Awareness" class="checkbox">Environmental Awareness</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Community Involvement" class="checkbox">Community Involvement</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Being Liked" class="checkbox">Being Liked</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Professional Growth" class="checkbox">Professional Growth</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Perseverance" class="checkbox">Perseverance</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Vision" class="checkbox" >Vision </div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Future generations" class="checkbox">Future generations</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Safety" class="checkbox">Safety </div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Conflict Resolution">Conflict Resolution</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Family" class="checkbox">Family</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Personal Fulfilment" class="checkbox">Personal Fulfilment</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Ease with Uncertainty" class="checkbox">Ease with Uncertainty</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Excellence" class="checkbox">Excellence</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Enthusiasm/Positive Attitude" class="checkbox">Enthusiasm/Positive Attitude</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Patience" class="checkbox">Patience</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Compassion" class="checkbox">Compassion</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Respect" class="checkbox">Respect</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Financial stability" class="checkbox">Financial stability</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Listening" class="checkbox">Listening</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Independence" class="checkbox">Independence</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Personal Growth" class="checkbox">Personal Growth</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Leadership" class="checkbox">Leadership</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Accountability" class="checkbox">Accountability</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Openness" class="checkbox">Openness</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Coaching/Mentoring" class="checkbox">Coaching/Mentoring</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Making a difference" class="checkbox">Making a difference</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Dialogue" class="checkbox">Dialogue</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Generosity" class="checkbox">Generosity</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Trust" class="checkbox">Trust</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Humor/fun" class="checkbox">Humor/fun</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Control" class="checkbox">Control</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Reward" class="checkbox">Reward</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Ambition" class="checkbox">Ambition</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Efficiency" class="checkbox">Efficiency</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Fairness" class="checkbox">Fairness</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Continuous Learning" style="margin-left:20px;" class="checkbox">Continuous Learning</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Independence" class="checkbox">Independence</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Creativity" class="checkbox">Creativity</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Teamwork" class="checkbox">Teamwork</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Caring" class="checkbox">Caring </div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Job Security" class="checkbox">Job Security </div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Being the best" class="checkbox">Being the best</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Reliability" class="checkbox">Reliability</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Adaptability" class="checkbox">Adaptability </div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Entrepreneurial" class="checkbox">Entrepreneurial</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value="Initiative" class="checkbox">Initiative</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Clarity" class="checkbox">Clarity</div>
	
      <input type="button" name="next" class="next action-button" id="check_all" value="Next" style="margin-left: 800px;margin-top:-100px;" disabled="disabled" />
    </fieldset>
	  
    <fieldset>
		<div class="header">
	<h4>iPulse Personal Values Assessment</h4>
	 <img src="images/iPulse logo.jpg" height="100px" width="130px">
	</div>
		<p style="text-align:center;font-size: 18px;padding:30px;">How are you feeling today?</p> 
            <input type="checkbox" name="emoji" class="emoji" value="1" style="margin-left:250px;"><img class="happy" src="images/smiley1.png" height="80px" width="80px" style="margin-left:5px;margin-top:10px;">
			<input type="checkbox" name="emoji" class="emoji" value="2"><img class="happy" src="images/smiley2.png" height="80px" width="80px"style="margin-left:5px;" >
			<input type="checkbox" name="emoji" class="emoji" value="3"><img class="happy" src="images/smiley3.png" height="80px" width="80px" style="margin-left:5px;">
			<input type="checkbox" name="emoji" class="emoji" value="4"><img class="happy" src="images/smiley4.png" height="80px" width="80px" style="margin-left:5px;">
			<input type="checkbox" name="emoji" class="emoji" value="5"><img class="happy" src="images/smiley5.png" height="80px" width="80px" style="margin-left:5px;"><br>
           <input type="submit" name="submit" class="submit action-button" value="submit" onclick="ip1.php"/>
    </fieldset>
  </div>
</form>
	</body>
	<script>
		$(function() {
    $(".checkbox").click(function(){
        $('.next').prop('disabled',$('input.checkbox:checked').length !=10);
    });
});
	</script>
	<script>
		(function($) {
  var current_fs, next_fs, previous_fs; //fieldsets
  var left, opacity, scale; //fieldset properties which we will animate
  var animating; //flag to prevent quick multi-click glitches

  $(".next").click(function() {
    if (animating) return false;
    animating = true;

    current_fs = $(this).parent();
    next_fs = $(this).parent().next();

    //activate next step on progressbar using the index of next_fs
    $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

    //show the next fieldset
    next_fs.show();
    //hide the current fieldset with style
    current_fs.animate({
      opacity: 0
    }, {
      step: function(now, mx) {
        //as the opacity of current_fs reduces to 0 - stored in "now"
        //1. scale current_fs down to 80%
        scale = 1 - (1 - now) * 0.2;
        //2. bring next_fs from the right(50%)
        left = (now * 50) + "%";
        //3. increase opacity of next_fs to 1 as it moves in
        opacity = 1 - now;
        current_fs.css({
          'transform': 'scale(' + scale + ')'
        });
        next_fs.css({
          'left': left,
          'opacity': opacity
        });
      },
      duration: 800,
      complete: function() {
        current_fs.hide();
        animating = false;
      },
      //this comes from the custom easing plugin
      easing: 'easeInOutBack'
    });
  });

  $(".previous").click(function() {
    if (animating) return false;
    animating = true;

    current_fs = $(this).parent();
    previous_fs = $(this).parent().prev();

    //de-activate current step on progressbar
    $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

    //show the previous fieldset
    previous_fs.show();
    //hide the current fieldset with style
    current_fs.animate({
      opacity: 0
    }, {
      step: function(now, mx) {
        //as the opacity of current_fs reduces to 0 - stored in "now"
        //1. scale previous_fs from 80% to 100%
        scale = 0.8 + (1 - now) * 0.2;
        //2. take current_fs to the right(50%) - from 0%
        left = ((1 - now) * 50) + "%";
        //3. increase opacity of previous_fs to 1 as it moves in
        opacity = 1 - now;
        current_fs.css({
          'left': left
        });
        previous_fs.css({
          'transform': 'scale(' + scale + ')',
          'opacity': opacity
        });
      },
      duration: 800,
      complete: function() {
        current_fs.hide();
        animating = false;
      },
      //this comes from the custom easing plugin
      easing: 'easeInOutBack'
    });
  });

})(jQuery);
	</script>
	<script>
		$("input[type='checkbox']").change(function(){
    if($(this).is(":checked")){
        $(this).parent().addClass("redBackground"); 
    }else{
        $(this).parent().removeClass("redBackground");  
    }
});
	</script>
	<!--<script>
		$(document).ready(function(){
    $("form").submit(function(){
		if ($('input:checkbox').filter(':checked').length == 1){
        alert("Please select any only");
		return false;
		}
    });
});
	</script>-->
	<!--<script>
		$('#next').click(function () {
    if (!$('#agree').is(':checked')) {
        alert('not checked');
        return false;
    }
});
		</script>-->
<script type="text/javascript">
    $('.emoji').on('change', function() {
        $('.emoji').not(this).prop('checked', false);  
    });
	</script>
	
	<!--<script type="text/javascript"> 
		function check(){
var checked=0;
    $( "input:checkbox" ).each(function() {
        if($(this).is(':checked')){
        checked++;
        }
});
    if(checked==10){
    alert('Ok!');
    }
    else{
    alert('At least 10 checkboxes need to be selected!');
    }
}
	</script>-->
	<script>
		$(function() {
    $(".checkbox").click(function(){
        $('.submit').prop('disabled',$('input.checkbox:checked').length !=1);
    });
});
	</script>
			
</html>
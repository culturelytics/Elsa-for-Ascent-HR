<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>
<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center" >Why Executive Presence?</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>Executive presence is a blending of temperament, competencies, and skills that, when combined, send all the right signals. Leaders know they must embody executive presence to get ahead, influence others, and drive results. Leadership development professionals know they must help their executives develop it.</li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	EXECUTIVE PRESENCE
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">Create a Great first Impression</p>
		<ul class="cs-ui">
			<li><a href="https://www.mindtools.com/CommSkll/FirstImpressions.htm" target="_blank">First Impression</a></li>
			<li><a href="https://www.youtube.com/watch?v=dnGQvoqtP88&feature=youtu.be" target="_blank">How to make a great first Impression?-Business Insider (Video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Execution of tasks</p>
		<ul class="cs-ui">
			<li><a href="https://hbr.org/2008/06/the-secrets-to-successful-strategy-execution" target="_blank">The secrets to successful-strategy-execution</a></li>
			<li><a href="https://www.youtube.com/watch?v=JlEZxrezBtQ&feature=youtu.be" target="_blank">Marriott Case Study - The 4 Disciplines of Execution (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Professional Image</p>
		<ul class="cs-ui">
			<li><a href="http://blogs.edweek.org/topschooljobs/careers/2011/03/what_is_a_professional_image.html" target="_blank">What is a professional image?</a></li>
			<li><a href="https://www.youtube.com/watch?v=gUPYyLGXFGs&feature=youtu.be" target="_blank">Becky Rupiper-Greene - Professional Image Keynote - Tero International (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Leader Credibility</p>
		<ul class="cs-ui">
			<li><a href="https://www.inc.com/peter-economy/8-powerful-habits-to-establish-credibility-as-a-leader.html" target="_blank">8 powerful habits to establish credibility as a leader</a></li>
			<li><a href="https://www.youtube.com/watch?v=eSwC2ySkXeg" target="_blank">Building Leadership Credibility (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Communication style</p>
		<ul class="cs-ui">
			<li><a href="https://ie.reachout.com/communication/communication-styles/" target="_blank">Communication styles</a></li>
			<li><a href="https://www.youtube.com/watch?v=s9GQYZsGwx4" target="_blank">4 types of communication styles (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Dealing with difficult people</p>
		<ul class="cs-ui">
			<li><a href="https://www.thebalance.com/dealing-with-difficult-people-at-work-1917903" target="_blank">Dealing with difficult people at work</a></li>
			<li><a href="https://www.youtube.com/watch?v=3e_rdSvwh_E" target="_blank">Dealing with difficult people-overview(video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Motivating others</p>
		<ul class="cs-ui">
			<li><a href="https://www.mindtools.com/pages/article/motivating-your-team.htm" target="_blank">Motivating your team</a></li>
			<li><a href="https://www.youtube.com/watch?v=NVjfSujjnaw" target="_blank">How to Motivate Others | Mark Sanborn Leadership Speaker (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Purpose and Passion</p>
		<ul class="cs-ui">
			<li><a href="https://www.forbes.com/sites/karlmoore/2015/01/19/the-great-power-of-connecting-passion-with-purpose/#28e3ab2e8784" target="_blank">The great power of connecting passion with purpose</a></li>
			<li><a href="https://www.youtube.com/watch?v=fUr7dBHuf84" target="_blank">Passion and Purpose- discover the real you (video)</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Create a Great first Impression</p>
		<ul class="cs-ui">
			<li><a href="https://www.wikihow.com/Make-a-Good-First-Impression" target="_blank">How to make a good first impression?- wikihow</a></li>
			<li><a href="https://beyondphilosophy.com/5-ways-make-great-impression-new-customer/" target="_blank">5 Ways to Make a Great Impression on Your New Customer</a></li>
			<li><a href="http://content.wisestep.com/how-to-make-a-great-impression-at-a-job-interview-tips/" target="_blank">How to Make a Great Impression at a Job Interview: 15 Tips</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Increasing Credibility</p>
		<ul class="cs-ui">
			<li><a href="#">6 Ways To Increase Your Brand's Online Credibility</a></li>
			<li><a href="https://www.businessknowhow.com/growth/speakercred.htm" target="_blank">Boost Your Credibility as a Speaker</a></li>
			<li><a href="https://www.entrepreneur.com/article/243690" target="_blank">8 Ways to Establish Your Business Credibility</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Presenting Complex information</p>
		<ul class="cs-ui">
			<li><a href="https://www.quickbase.com/blog/6-ways-to-clearly-communicate-complex-information" target="_blank">6 Ways to Clearly Communicate Complex Information</a></li>
			<li><a href="#">How to present complex information with simplicity</a></li>
			<li><a href="https://piktochart.com/blog/present-complex-data-infographics-examples/" target="_blank">How to Present Complex Data Using Infographics (with Examples)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Communicating with impact</p>
		<ul class="cs-ui">
			<li><a href="https://icma.org/articles/15-tips-communicating-impact" target="_blank">15 Tips for Communicating with Impact</a></li>
			<li><a href="http://www.cuttingedgepr.com/articles/photographs-create-greater-impact.asp" target="_blank">How you can use photographs to create greater impact</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Building Influential traits</p>
		<ul class="cs-ui">
			<li><a href="https://blog.bufferapp.com/how-the-big-five-personality-traits-can-help-you-build-a-more-effective-team" target="_blank">How The “Big Five” Personality Traits in Science Can Help you Build a More Effective team</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Why we do?</p>
		<ul class="cs-ui">
			<li><a href="https://www.stevepavlina.com/blog/2005/01/how-to-discover-your-life-purpose-in-about-20-minutes/" target="_blank">How to Discover Your Life Purpose in About 20 Minutes - Steve Pavlina</a></li>
			<li><a href="https://zenhabits.net/life-purpose/" target="_blank">How to Find Your Life Purpose: An Unconventional Approach : zen habits</a></li>
		</ul>
		</div>





	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">

	<div class="col-lg-12">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/wat-got.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.wikisummaries.org/wiki/What_Got_You_Here_Won%E2%80%99t_Get_You_There" target="_blank">What got you here won’t get you there : Marshal Goldsmith</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/ricardo.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/Maverick_(book)#Synopsis" target="_blank">Maverick!: Ricardo</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/sam.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.butler-bowdon.com/sam-walton---made-in-america-my-story.html" target="_blank">Made in America : Sam Walton</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/alex.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://worldsoccertalk.com/2015/11/22/review-of-alex-fergusons-new-book-leading-a-lesson-in-making-money/" target="_blank">Leading : Alex Ferguson </a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/guy.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://digitalintelligencetoday.com/speed-summary-enchantment-by-guy-kawasaki-implications-for-social-commerce/" target="_blank">Enchantment: Guy Kawasaki</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/mary-kay.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.pinktruth.com/2015/09/16/miracles-happen-mary-kay-ashs-fudge-factory/" target="_blank">Miracles Happen : Mary Kay Ash</a></p>
	</div>
	</div>

    <div class="col-lg-12">
		<div class="info-n">
		<p class="abt-sub-titles ab">Other Articles</p>
		<ul class="cs-ui">
			<li><a href="http://www.peace.ca/crucialconversations.pdf" target="_blank">Crucial Conversations</a></li>
			<li><a href="https://www.forbes.com/sites/danschawbel/2012/04/23/the-4-disciplines-of-business-execution/#781da3ab7a2e" target="_blank">The 4 Disciplines of Execution</a></li>
			<li><a href="https://www.essence.com/2011/09/28/the-10-principles-of-power" target="_blank">The Essence of Power</a></li>
			<li><a href="https://babettetenhaken.com/2009/11/29/are-you-impeccable-with-your-word/​" target="_blank">Being Impeccable with your word​</a></li>
			<li><a href="https://www.grammarly.com/blog/10-bad-words-at-work/?utm_source=Facebook_org&utm_content=&utm_campaign=Blog_Lifestyle" target="_blank">10 Words and Phrases to Never, Ever Use at Work</a></li>
			<li><a href="https://www.inc.com/justin-bariso/microsofts-ceo-just-gave-some-brilliant-career-advice-here-it-is-in-one-sentence.html" target="_blank">Microsoft's CEO Just Gave Some Brilliant Career Advice. Here It Is in 1 Sentence</a></li>
			<li><a href="https://www.ted.com/talks/judson_brewer_a_simple_way_to_break_a_bad_habit?utm_source=tedcomshare&utm_medium=referral&utm_campaign=tedspread" target="_blank">Judson Brewer: A simple way to break a bad habit</a></li>
		</ul>
		</div>
	</div>	

	</div>
	</div>
   </div>
	</div>	




</div>	

</div>

<?php
}

?>
            
<?php include('footer.php'); ?>
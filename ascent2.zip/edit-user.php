<?php
include_once('connectdb.php');
session_start();
if(!isset($_SESSION["sess_username"])){
 header("Location: admin.php");
}
else
{
?>
<?php if(isset($fmsg)){ ?><div class="alert alert-danger" role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
<?php
$existemail="";
if(isset($_POST) & !empty($_POST)){
  $id = $_GET['id'];
  $name = $_POST['username'];
  $email = $_POST['email'];
  if($email != "") {
    $result = mysqli_query($dbconnect, "SELECT * FROM tbl_user where email='".$email."' AND id!='".$id."'");
    $num_rows = mysqli_num_rows($result);
    if($num_rows >= 1){
        $existemail="email already register choose different";
    }else{
  $password = $_POST['password'];
  $contact = $_POST['contact'];
  $contact = $_POST['kaccess'];
  $contact = $_POST['caccess'];
  $status = $_POST['status'];
  $res = mysqli_query($dbconnect, "UPDATE `tbl_user` SET name='$name', email='$email', password='$password', contact='$contact', status='$status', kaccess='$kaccess', caccess='$caccess' WHERE id=$id");
  if($res){
  header('location: admin-dashboard.php');
}else{
  $fmsg = "Failed to update data.";
}
   }
 }
}
?>
<!doctype html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <title>e2e</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">

        <meta name="keywords" content="">

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="author" href="https://plus.google.com/yourpersonalprofile">
        <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
        <link href="css/css.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">

    <link rel="stylesheet" href="css/m/font-awesome.min.css">
    <link rel="stylesheet" href="css/m/animate.min.css">
    <link rel="stylesheet" href="css/m/default.min.css">
    <link rel="stylesheet" href="css/m/demo.css">
    <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
    <link rel="shortcut icon" href="images/fav_e2e2.ico" />
    <script src="js/m/modernizr.js"></script>
    <script src="http://localhost/project/e2e/assets/global/scripts/datatable.min.js" type="text/javascript"></script>
        <script src="http://localhost/project/e2e/assets/global/plugins/datatables/datatables.min.js" type="text/javascript"></script>
        <script src="http://localhost/project/e2e/assets/global/plugins/datatables/plugins/bootstrap/datatables.bootstrap.js" type="text/javascript"></script>
        <script src="http://localhost/project/e2e/assets/pages/scripts/table-datatables-managed.min.js" type="text/javascript"></script>

    </head>
    <body>

    <div class="comn-bg">

<div class="container">
<div class="col-lg-12  col-sm-12 col-xs-12 header-pdng all-border-btm"> 
        <div class="col-lg-4 col-sm-12 col-xs-12 center-below-992" style="">
                <a href="index.php">
                    <img src="<?php echo $pri_logo ?>"  class="header-logo" alt="image">
                </a>
        </div>

<div class="col-lg-8  col-sm-12 col-xs-12 li-details header-strip " style="margin-top: 15px;">
     
     

<div class="col-lg-8 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <h1>ADMIN DASHBOARD</h1>
</div>
<div class="col-lg-1"></div>
   <!-- <div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <span class="ar">Mail To : </span><a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a>
</div> -->  
<div class="col-lg-1  col-sm-6 col-xs-6"></div>
<div class="col-lg-2  col-sm-6 col-xs-6 nav-li li-login" style="margin-top: 10px">
   <a href="admin-logout.php" class="login-btn">Logout</a>
</div>
</div>    
</div>



<div class="col-lg-12">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">Edit User</h2>
<hr class="line-75">
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mob-no-padng" style="margin-bottom: 6%;margin-top: 5%">
<div class="col-lg-4"></div>
<div class="col-lg-4">

<?php
$id = $_GET['id'];
$res = mysqli_query($dbconnect, "SELECT * FROM `tbl_user` WHERE id=$id");
$row = array();
$r = mysqli_fetch_object($res);
$rows[] = $r;
{
?>
<form method="post" action="" id="register-form">
      <div class="form-sub-w3  left-form-w3-agile" style="padding: 20px">
               <input type="text" class="ar" name="username" placeholder="User Name" value="<?php echo $r->name ?>" required="">
               <input type="email" class="ar" name="email" placeholder="Email" value="<?php echo $r->email ?>" required="">       
               <span><?php echo $existemail ?>
               </span>                                
               <input type="text" class="ar" name="password" placeholder="Password" value="<?php echo $r->password ?>" required="">
               <input type="text" class="ar" name="contact" placeholder="Contact" value="<?php echo $r->contact ?>" required="">                
               <div>     
                <select name="kaccess" class="ar e2eselect">                 
                 <option value="no" <?php if($r->kaccess == 'no'){ echo "selected";} ?> >No</option> 
                 <option value="yes" <?php if($r->kaccess == 'yes'){ echo "selected";} ?> >Yes</option>                 
               </select>

               <select name="caccess" class="ar e2eselect">                 
                 <option value="no" <?php if($r->caccess == 'no'){ echo "selected";} ?> >No</option> 
                 <option value="yes" <?php if($r->caccess == 'yes'){ echo "selected";} ?> >Yes</option>                 
               </select>


               <select name="status" class="ar e2eselect">                 
                 <option value="inactive" <?php if($r->status == 'inactive'){ echo "selected";} ?> >inactive</option> 
                 <option value="active" <?php if($r->status == 'active'){ echo "selected";} ?> >active</option>                 
               </select>
               </div>
      </div>
      <div class="submit-bg"><input type="submit" value="Update" name=""></div>
      </form>
  <?php
    }
   ?>
</div>
<div class="col-lg-4"></div>

</div>  
 


 

</div>

</div>


         
    




<div class="w3-sidebar w3-bar-block w3-border-right" style="display:none;right:0;" id="mySidebar">
  <button onclick="w3_close()" class="w3-bar-item w3-large" style="background-color: #0088C7;">Close &times;</button>



<div class="dropdown" style="padding: 10px 0px;">

<a href="e2e-library.php" class="a-kc  copy-a ar">Knowledge Center</a><i class="dropbtn fa fa-caret-down" aria-hidden="true" onclick="myFunction1()" style="margin-left: 10px"></i>

  <div id="myDropdown1" class="dropdown-content">
    <a href="HR-Analytics.php">HR Analytics</a>
    <a href="Executive-Presence.php">Executive Presence</a>
    <a href="First-Time-Managers.php">First Time Managers</a>
    <a href="Manager-Of-Managers.php">Manager Of  Managers</a>
    <a href="Business-Storytelling.php">Business Storytelling</a>
    <a href="Team-Bonding.php">Team Bonding</a>
    <a href="Developing-Values.php">Developing Values</a>
    <a href="Entrepreneurship.php">Entrepreneurship</a>
    <a href="Team-Dynamics.php">Team Dynamics</a>
    <a href="Time-Management.php">Time Management</a>
    <a href="Stress-Management.php">Stress Management</a>
    <a href="Emotional-Intelligence.php">Emotional Intelligence</a>
    <a href="Stakeholder-Management.php">Stakeholder Management</a>
    <a href="EA-Coaching.php">EA Coaching</a>
    <a href="Customer-Delight.php">Customer Delight</a>
    <a href="New-Age-Banking.php">New Age Banking</a>
    <a href="Behavioral-Interviewing-Skills.php">Behavioral Interviewing Skills</a>
    <a href="SALES-Communication.php">SALES Communication</a>
  </div>
</div>




  <a href="our-team.php" class="w3-bar-item w3-button ar">Our team</a>



  <a href="about-us.php" class="w3-bar-item w3-button ar">About us</a>





  <a href="merges-and-acquisition.php" class="w3-bar-item w3-button ar">Merges and Acquisition</a>
  <a href="news-and-media.php" class="w3-bar-item w3-button ar">News & Media</a>
  <a href="services.php" class="w3-bar-item w3-button ar">Our services</a>  
  <a href="MileStone.php" class="w3-bar-item w3-button ar">MileStone</a>
  <a href="case-study.php" class="w3-bar-item w3-button ar">Case Study</a>
  <a href="careers.php" class="w3-bar-item w3-button ar">Careers</a> 
  <a href="gallery.php" class="w3-bar-item w3-button ar">Gallery</a>
  <a href="contact-us.php" class="w3-bar-item w3-button ar">Contact us</a>     
</div>




        <script src="js/jquery-latest.min.js" type="text/javascript"></script> <!-- jQuery Library -->
        <script src="js/jquery.isotope.min.js" type="text/javascript"></script> <!-- Isotope Layout Plugin -->
        <script src="js/jquery.mCustomScrollbar.js" type="text/javascript"></script> <!-- malihu Scrollbar -->
        <script src="js/tileshow.js" type="text/javascript"></script> <!-- Metromega Custom Tileshow Plugin -->
        <script src="js/bootstrap.min.js" type="text/javascript"></script> <!-- Bootstrap Library -->
        <script src="js/script.js" type="text/javascript"></script> <!-- Metromega Script -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js" type="text/javascript"></script>
        <script src="http://ajax.aspnetcdn.com/ajax/jquery.validate/1.10.0/jquery.validate.js" type="text/javascript"></script>

<script>
    $(document).ready(function() {
     var owl = $("#slider-carousel");
     owl.owlCarousel({
       items: 1,
       itemsDesktop: [1000, 1],
       itemsDesktopSmall: [900, 1],
       itemsTablet: [600, 1],
       itemsMobile: false,
       pagination: false,
     });
     $(".next").click(function() {
       owl.trigger('owl.next');
     })
     $(".prev").click(function() {
       owl.trigger('owl.prev');
     })
   });
</script>

<script>
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}
</script>


<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction() {
    document.getElementById("myDropdown").classList.toggle("show");
}
    // Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>

<script>
/* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
function myFunction1() {
    document.getElementById("myDropdown1").classList.toggle("show");
}
    // Close the dropdown if the user clicks outside of it
window.onclick = function(event) {
  if (!event.target.matches('.dropbtn')) {

    var dropdowns = document.getElementsByClassName("dropdown-content");
    var i;
    for (i = 0; i < dropdowns.length; i++) {
      var openDropdown = dropdowns[i];
      if (openDropdown.classList.contains('show')) {
        openDropdown.classList.remove('show');
      }
    }
  }
}
</script>
<script type="text/javascript">
    $(document).ready(function () {
  
  $("#register-form").validate({
    rules: {
             
            username: {
                required: true,
                minlength: 2
            },
            email: {
                required: true,
                email: true
            },
            password: {
                required: true,
                minlength: 5
            },
            contact: {
                required: true,
                minlength: 10,
                number: true
            },
        },
    messages: {
      password: {
        required: "Please enter your password",
        minlength: "Your password must contain 5 charaters and above",         
      }, 
      username: {
        required: "Please enter username",
        minlength: "Your username contain 5 charaters and above",
      },
      email: {
        required: "Please enter Email",
        email: "Enter Email correctly",        
      },
      contact: {
        required: "Please enter Contact",
        minlength: "Contact required 10 Numbers",
        number: "Please enter Numbers"        
      },
    },
  });
});
</script>

    </body>
</html>
<?php
}
?>
<?php include('header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Gallery</title>
	<style>
		.image-source-link {
	color: #98C3D1;
}

.mfp-with-zoom .mfp-container,
.mfp-with-zoom.mfp-bg {
	opacity: 0;
	-webkit-backface-visibility: hidden;
	/* ideally, transition speed should match zoom duration */
	-webkit-transition: all 0.3s ease-out; 
	-moz-transition: all 0.3s ease-out; 
	-o-transition: all 0.3s ease-out; 
	transition: all 0.3s ease-out;
}

.mfp-with-zoom.mfp-ready .mfp-container {
		opacity: 1;
}
.mfp-with-zoom.mfp-ready.mfp-bg {
		opacity: 0.8;
}

.mfp-with-zoom.mfp-removing .mfp-container, 
.mfp-with-zoom.mfp-removing.mfp-bg {
	opacity: 0;
}
	</style>
<script>
	$(document).ready(function() {
	$('.zoom-gallery').magnificPopup({
		delegate: 'a',
		type: 'image',
		closeOnContentClick: false,
		closeBtnInside: false,
		mainClass: 'mfp-with-zoom mfp-img-mobile',
		image: {
			verticalFit: true,
			titleSrc: function(item) {
				return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
			}
		},
		gallery: {
			enabled: true
		},
		zoom: {
			enabled: true,
			duration: 300, // don't foget to change the duration also in CSS
			opener: function(element) {
				return element.find('img');
			}
		}
		
	});
});
</script>
</head>
<body>
	<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<h2 class="ar career-title text-center">GALLERY</h2>
<hr class="line-75">
<!--<center><h5>e2e participates across all forums and conducts extensive workshops in the HR space. Here are a few moments of it!</h5></center><br>-->
	<div class="col-lg-12 mob-no-padng">

<div class="gallery cf">
	<div class="zoom-gallery">
	
	<a href="images/gallery/g47.jpeg"  style="width:193px;height:125px;">
		<img src="images/gallery/g47.jpeg" width="220px" height="200px">
	</a>
	<a href="images/gallery/g48.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g48.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g49.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g49.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g50.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g50.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g51.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g51.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g52.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g52.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g53.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g53.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g54.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g54.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g55.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g55.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g56.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g56.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g57.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g57.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g59.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g59.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g58.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g58.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g60.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g60.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g61.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g61.jpeg" width="220px" height="200px">
	</a>
<ul class="pagination" style="margin-bottom: 0px">
  <li><a href="gallery.php">1</a></li>
  <li><a href="gallery-2.php">2</a></li>
  <li><a href="gallery-3.php">3</a></li>
  <li class="active"><a href="gallery-4.php">4</a></li>
  <li><a href="gallery-5.php">5</a></li>
	<li><a href="gallery-6.php">6</a></li>
	<li><a href="gallery-7.php">7</a></li>
</ul>
</div>
	
		</div>
		</div>
		</div>	
	</div>
</body>
</html
<?php include('footer.php'); ?>

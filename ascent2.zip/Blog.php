<?php
include_once('connectdb.php');
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Blog:e2e</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="At e2e,our work speaks for itself. Our Blog give you a detailed description on current scenarios">

        <meta name="keywords" content="Mergers and Acquisitions,Leadership,Learning and Development,Culture Audit,Value Added Business Solution,HR Consulting,Team Bonding,LeAP,Business Alignment,Culture Transition,People Analytics">
         <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="author" href="https://plus.google.com/yourpersonalprofile">
        <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
        <link href="css/css.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">

    <link rel="stylesheet" href="css/m/font-awesome.min.css">
    <link rel="stylesheet" href="css/m/animate.min.css">
    <link rel="stylesheet" href="css/m/default.min.css">
    <link rel="stylesheet" href="css/m/demo.css">
    <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
    <link rel="shortcut icon" href="images/fav_e2e2.ico" />
    <script src="js/m/modernizr.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  </head>
    <body>
 <div class="comn-bg">
<div class="container" style="background:url('images/s1.jpg');width:100%;">
<div class="col-lg-12  col-sm-12 col-xs-12 header-pdng all-border-btm"> 
        <div class="col-lg-4 col-sm-12 col-xs-12 center-below-992" style="">
                <a href="index.php">
                    <img src="<?php echo $pri_logo ?>"  class="header-logo" alt="image">
                </a>
        </div>
<div class="col-lg-8  col-sm-12 col-xs-12 li-details header-strip" style="margin-top: 15px;">
     <div class="col-lg-1"></div>
	<div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <span class="ar"> </span>
</div>

<div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <span class="ar"> </span>
</div>

<div class="col-lg-2  col-sm-6 col-xs-6 nav-li li-login" style="margin-top: 10px;padding-left: 0px">
   <!-- <a href="login.php" class="login-btn">Log In</a> -->
</div>
            
<div class="col-lg-1  col-sm-6 col-xs-6 toggle-menu right0-abv768">
    <div class="nav-li-last w3-button w3-xlarge" style="float: right;" onclick="w3_open()">
        <div class="icon"></div>
        <div class="icon"></div>
        <div class="icon"></div>
    </div>        
</div>

</div>   

</div>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>

<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">


	<h2 class="ar career-title text-center">e2e BLOG</h2> 
	<hr class="line-75">
<div class="col-lg-12 cfff mob-no-padng" style="padding-top: 0px">
	
<ul id="accordion">
	
	<!--1-->
	<li><span class="accordion cs-accr ab" style="margin-top: 0px; color:greenyellow;"><marquee behavior="alternate" >Trend's in HR:what's good and what's not!</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
		
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> </p>
		<p text align="justify">Learning and Development in the modern era is a tricky topic of debate. Many views have been expressed as to how this may progress in the days to come. Here’s our view!</p><br>
		<h5><font size="6" color="orange">Let the Learning games begin!</font></h5><br>
			
		<p text align="justify"><span class="ab">A real-time approach to learning :</span> The shift from a procrastinated sense of learning to a real-time platform for learning is the need of the hour. Organizations switching to a continuous and interactive learning platform are guaranteed to see a more effective return on investment. Employees need to engage in the platforms actively to directly result in an increase in efficiency at the workplace.</p><br>
		<div class="gal-center-mob">
    <img src="images/Blog/trend.jpeg" alt="image" />
  </div>
		
		<p> Content is EVERYWHERE!</p><br>
			
		<p text align="justify">With the growth of technology, came the rise of multiple channels of learning. Accessibility is not the issue here. It is matching this ocean of content to an individual employee’s needs. Trending and up-to-date content is key in bridging the gap for learning.</p><br>
			
		<p>A Millennial Workforce: Stats do not lie!</p><br>
		<p text align="justify">Think about it, the majority of your workforce is going to be a millennial by the year 2025! According to a survey, about 74% of the millennial workforce feel like they were not achieving their full potential at work and this could be solved through continuous learning and development through workforce analytics in targeted areas. This number is not seen as a weakness as much as an opportunity to help your current millennial workforce learn and adapt from right now!</p>
		</div>
		</div>
  </li>
	
<!--2-->
	<li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee behavior="alternate">People Analytics: A Blueprint for success</marquee><i class="fa fa-chevron-down" style="float: right"></i></span>
	
	<div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> </p>
		<p text align="justify">At e2e People Practices, we believe an organization is made up of its people. e2e considers people the most important resource and essential in value creation.<br>
		The explosive growth of people analytics is causing a considerable stir among companies. People analytics explores, infers and communicates significant data patterns to initiate and support strategic business decisions related to people in the organisation. The data driven future that was once a myth is now a reality.</p><br>
		
		<div class="gal-center-mob">
    <img src="images/Blog/analytics.jpeg" alt="image" />
		</div>
			<p text align="justify">People analytics has wide application within the HR and the business context and the areas of applications are likely to grow to a multitude of functions in the years to come. The growth of people analytics is global and not confined to one country. According to Deloitte’s Human Capital Trends, the highest percentage comes from fast-growing economies, around 82%, and the lowest coming from France at 48%.<br>
		The shifting role of people analytics is no longer confined just to HR. It covers a much broader category of making big business decisions. The conventional way of looking at people analytics is no longer an option. Organizations need to adapt to this dynamic concept.</p><br>
		<div class="gal-center-mob">
    <img src="images/Blog/analytics2.jpeg" alt="image" />
		</div><br>
			
		
		<p>We are in a time when data builds capabilities and people play the biggest role in aiding this process. It is time that organizations realize the importance of investing into the realm of people analytics in order to explore and expand their vision.</p>
		<p>Is your organization ready for the winds of change?</p>
		</div>
		</div>
  </li>
	<!--3-->
	<li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee behavior="alternate">Transient Learning and Development</marquee><i class="fa fa-chevron-down" style="float: right"></i></span>
		<div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> </p>
		<p text align="justify">At e2e People Practices, we believe an organization is made up of its people. e2e considers people the most important resource and essential in value creation.<br>
		Learning and Development has increasingly become the topic of discussion for many of the top organizations. Once upon a time, this topic and it’s credibility were completely disregarded. However, in recent times, learning and development is one of the most important factors in terms of talent retention.<br>
		67% of the companies have said that they need to entirely revamp and restructure their middle manager development programs. A constructive platform for continuous learning and development is the need of the day. A tailored program suited for every employee’s individual needs is what is revolutionizing the way company’s work. If company’s adopt a robust and dynamic learning and development policy, employees with the highest level of engagement perform 20% better and are 87% less likely to leave the organization. This concept is a game changer for employee retention.</p>
			<div class="gal-center-mob">
    <img src="images/Blog/priority.jpeg" alt="image" />
		</div>
			<p>The figure above denotes that talent retention is still the top most priority on any company’s agenda. If learning and development is given more attention,there is an instantaneous increase in the talent retention percentage.<br>
			The era of change is now, the revolution is taking place. Is your company ready to adapt and adopt?</p>
			</div>
		</div>
	</li>
	<!--4-->
	<li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee behavior="alternate">$3,600,000,000,000 eroded every year!</marquee><i class="fa fa-chevron-down" style="float: right"></i></span>
	<div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> </p>
		<p text align="justify">At e2e People Practices, we believe an organization is made up of its people. e2e considers people the most important resource and essential in value creation.<br>
		Mergers and Acquisitions are one of the most difficult games to play in the business world. What to acquire? When to acquire? How to acquire? These are the key questions one must ask themselves before having the blunt thought of an acquisition. Mergers and Acquisitions are done for one of two reasons: To increase resources or To cut risk.<br> In this volatile world of business, compounded by an even more volatile talent pool, companies must minimize risks before involving themselves in Mergers and Acquisitions. Mergers and Acquisitions were valued at $4.7 trillion in the year of 2017. The percentage of companies that failed to achieve the goals of the merger reached 83%.<br>There is a huge factor that plays a part in the role of Mergers and Acquisitions and that is Culture. Now, culture is usually undermined and not given the due importance it needs to be given – the main reason why we are witnessing such a high rate of failures.<br></p>
	<div class="gal-center-mob">
    <img src="images/Blog/ma.jpeg" alt="image" />
		</div>
		<p>Its time that thought leaders do something about this unique problem. Any thoughts, anyone?</p>
		</div>
		</div>
	</li>
	<!--5-->
	<li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee behavior="alternate">The Ecstasty and Agony of working as an HR Professsional Organizations Today</marquee><i class="fa fa-chevron-down" style="float: right"></i></span>
	<div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> </p>
		<p text align="justify">Looking back 18 years ago, I would never imagine the face of the HR industry shaping up like this. It was a thrill getting inducted into the various stories I had heard about the Human Resources, it was what I call the time of innocent aspirations!<br>
The reality of things set in soon though. The fact of the matter was that, we were seen as post boxes! An array of problems dumped on us by employees expecting the quickest fix for the same. Well, if only the boon of automation and AI had shown its durability then! We were never a part of the teams crunching down numbers, an intangible result which would be appreciated at best in one-off meetings. Leadership teams would often null us down to that of an event management team, which meant pure co-ordination and nothing else. Another side unfolded as we trooped on in the industry. Transparency, in an organization is a great concept to adopt, but, it comes with a dark side. Excessive transparency in an organization often serves as a distraction and I have had my share. A classic case of HR not being able to adopt enough business skills and the business leaders thinking managing people is child’s play.<br>
Do not get me wrong, it isn’t all bad. The fact that we meet, interact and engage with so many people really gives us an edge with people behavior. We can actually see what happens at the grass-root level with people, their experiences, their outlooks and aspirations. Some of the career transformation stories I was able to facilitate have been so rewarding. We are clearly the unsung superheroes of the corporate world by facilitating real-time success of the businesses we support.<br>
The biggest high for me has been working on the Artificial Intelligence platforms, focusing on building hypothesis that can get predictive through machine learning. I am currently stitching together a culture analytics platform that can predict the outcome of an M&A through entropy scores. It’s probably going to be the most dynamic engine ever built as culture is never stagnant. Imagine HR folks driving due diligence and being at investor board meetings with cutting edge analytics, instead of handling the usual ‘post-delivery mess’. AI is very powerful and can transform our community. The automation of HR has been transformative too in the way we execute work. It’s a treat watching these machines work for us. While routine employee interactions are getting less personal, the challenges to engage employees in a hyper- interconnected world seems to be our biggest challenge.<br>
I guess we should start by putting ourselves in an outsider’s position and seeing what real value we actually bring and that is where we see the true relevance and importance of the HR Industry!<br>
The dynamic nature of our industry is what keeps me going, there are so many different facets to HR! At the end of the day, being an HR professional will probably never be demystified and that is what I call the beauty and curse of working as an HR Professional!<br> </p>
		</div>
		</div>
	</li>
	</ul>


<?php include('footer.php'); ?>


<script>
$("#accordion > li > span").click(function() {
    $(this).toggleClass("active").next('div').slideToggle(250)
    .closest('li').siblings().find('span').removeClass('active').next('div').slideUp(250);
});


// $('ul li span').click(function(){
//     $(this).find('i').toggleClass('fa-chevron-down fa-chevron-up')
// });

</script>
	

<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">BUSINESS STORYTELLING</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <p>Storytelling for Business Course Objectives </p>
      <li>To de-mystify storytelling</li>
      <li>Storytelling techniques to create compelling examples</li>
      <li>To create buy-in using storytelling elements</li>
      <li>The opportunity to practice in groups</li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BUSINESS STORYTELLING
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">History of Business Storytelling</p>
		<ul class="cs-ui">
			<li><a href="https://www.business.com/articles/how-to-grow-your-business-with-storytelling/" target="_blank">Be Authentic: How to Grow Your Business with Storytelling</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Business Storytelling</p>
		<ul class="cs-ui">
			<li><a href="https://www.thebalance.com/business-storytelling-skills-with-examples-2059685" target="_blank">Business storytelling with examples</a></li>
			<li><a href="https://www.theschooloflife.com/london/classroom/" target="_blank">The Art of Business Storytelling</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Types of Business Storytelling</p>
		<ul class="cs-ui">
			<li><a href="https://www.alphagamma.eu/entrepreneurship/stories-matter-the-why-and-what-of-business-storytelling/" target="_blank">Stories matter: the why and what of business storytelling</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab"> Business Storytelling techniques</p>
		<ul class="cs-ui">
			<li><a href="https://mirasee.com/blog/business-storytelling-techniques/" target="_blank">5 Effective Business Storytelling Techniques You Need To Use</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">The Psychological power of Storytelling</p>
		<ul class="cs-ui">
			<li><a href="https://www.psychologytoday.com/blog/positively-media/201101/the-psychological-power-storytelling" target="_blank">The psychological power of storytelling-Psychology Today</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">The Power of Business Storytelling</p>
		<ul class="cs-ui">
			<li><a href="https://www.intelligenthq.com/thought-leadership-intelligence/power-storytelling-strategic-business-tool/" target="_blank">The Power Of Storytelling As A Strategic Business Tool</a></li>
			<li><a href="https://blog.hubspot.com/opinion/why-storytelling-will-be-the-biggest-business-skill-of-the-next-5-years" target="_blank">Why Storytelling Will Be the Biggest Business Skill of the Next 5 Years</a></li>
			<li><a href="https://www.sproutworth.com/the-power-of-storytelling/" target="_blank">The Power of Storytelling to Increase ROI: How to increase online conversions by 4 times</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Human Brain and need to frame</p>
		<ul class="cs-ui">
			<li><a href="http://jgrcommunications.com/the-real-science-to-how-storytelling-affects-the-brain/" target="_blank">The real Story on how storytelling affects our brain</a></li>
		</ul>
		</div>
									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng lg-border-left">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">

	<div class="col-lg-12">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/blink.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/Blink_(book)" target="_blank">Blink: The Power of Thinking Without Thinking
By Malcolm Gladwell</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/a-whole-new-mind.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/A_Whole_New_Mind" target="_blank">A Whole New Mind: Why Right-Brainers Will Rule the Future
By Daniel Pink</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/story-telling-in-business.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.sup.org/books/title/?id=18152" target="_blank">Storytelling in Business: The Authentic and Fluent Organization
By Janis Forman</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/story-factor.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://annettesimmons.com/the-story-factor/" target="_blank">The Story Factor: Secrets of Influence from the Art of Storytelling
By Annette Simmons</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/story-telling-animal.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://jonathangottschall.com/storytelling-animal" target="_blank">The Storytelling Animal: How Stories Make Us Human
By Jonathan Gottschall</a></p>
	</div>
	</div>


	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>           
<?php include('footer.php'); ?>
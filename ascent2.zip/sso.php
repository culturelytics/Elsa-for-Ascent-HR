<?php
//if (!isset($_SESSION["sess_email_kaccess"]) && !isset($_SESSION["sess_email_caccess"])) {
//	header("Location: login.php");
//}

include_once('connectdb.php');

function loginwithemail($email, $redirect_url)
{
	global $dbconnect;
	$query = mysqli_query($dbconnect, "SELECT * FROM `tbl_user` WHERE BINARY email='" . $email . "' AND status= 'active';");
	$numrows = mysqli_num_rows($query);
	if($numrows == 0){
		echo '<div class="alert alert-warning text-center">Invalid request!</div>';
	}
	if ($numrows != 0) {
		while ($row = mysqli_fetch_assoc($query)) {
			$dbemail = $row['email'];
			$dbpassword = $row['password'];
			$kaccess = $row['kaccess'];
			$caccess = $row['caccess'];
			$id = $row['id'];
			$name = $row['name'];
		}

		$query = mysqli_query($dbconnect, "INSERT INTO `tbl_user_login_history`( `ulh_u_id`,`ulh_start_time`) VALUES ('" . $id . "','" . date('Y-m-d H:i:s') . "')");
		$last_id = mysqli_insert_id($dbconnect);
		if ($email == $dbemail) { // && $password == $dbpassword) {
			if (!isset($_SESSION)) {
				session_start();
			}
			$_SESSION['sess_email_kaccess']=$email;
			$_SESSION['sess_email_caccess']=$email;
			$_SESSION['user_id']=$id;
			$_SESSION['user_name']=$name;
			$_SESSION['ul_id']=$last_id;
			$_SESSION['redirect_url']=$redirect_url;
			header("Location: home.php");
		}
	} else {
		$errormsg = "Invalid credentials or Your profile is inactive!";
	}
}
?>
<?php include('header.php'); ?>
<?php

require_once('lib/aesencrypt.php');

$plaintext = getDecrypt($_GET['key']);
parse_str(($plaintext), $request);

// print_r($request);
// die;

$isvalidrequest = true;
if ($isvalidrequest) {

	$name = mysqli_real_escape_string($dbconnect, $request['first_name']);
	$email = mysqli_real_escape_string($dbconnect, $request['email_id']);
	//$password=mysqli_real_escape_string($dbconnect,$request['password']);
	$password = rand(10001, 99999);
	$contact = mysqli_real_escape_string($dbconnect, $request['contact_number']);
	$last_name = mysqli_real_escape_string($dbconnect, $request['last_name']);
	//$age=mysqli_real_escape_string($dbconnect,$request['age']);
	$gender = isset($request['gender']) ? mysqli_real_escape_string($dbconnect, $request['gender']) : '';
	$linkedin = mysqli_real_escape_string($dbconnect, $request['linkedin']);
	$twitter = mysqli_real_escape_string($dbconnect, $request['twitter']);
	//$confirm_password=mysqli_real_escape_string($dbconnect,$request['confirm_password']);
	$organization_code = mysqli_real_escape_string($dbconnect, $request['organization_id']);
	$organization_name = mysqli_real_escape_string($dbconnect, $request['organization_name']);
	$industry_code = mysqli_real_escape_string($dbconnect, $request['industry_id']);
	$industry_name = mysqli_real_escape_string($dbconnect, $request['industry_name']);
	$date_of_birth = mysqli_real_escape_string($dbconnect, $request['date_of_birth']);
	$redirect_url = mysqli_real_escape_string($dbconnect, $request['redirectto']);

	$industry_id = '';
	$organization_id = '';

	$confirm_password1 = '';
	$val_name = "";
	$val_email = "";
	$val_password = "";
	$val_contact = "";
	$val_last_name = "";
	$val_age = "";
	$val_gender = "";
	$val_confirm_password = "";
	$val_confirm_password1 = "";
	$val_organization = "";
	if ($name == '' || ctype_space($name)) {
		$val_name = "First name is required";
	}
	if ($email == '' || ctype_space($email)) {
		$val_email = "Email is required";
	}
	if ((!filter_var($email, FILTER_VALIDATE_EMAIL))) {
		$val_email = "Invalid Email";
	}
	/*if ($password == '') {
		$val_password = "Password is required";
	}
	if (!(strlen($password) >= 4 && strlen($password) <= 10)) {
		$val_password = "Password len is min 4 max 10";
	}*/
	/*if($confirm_password==''){
	$val_confirm_password="Confirm Password is required";
	}
	if($confirm_password!=$password){
	$val_confirm_password1="Password Mismatch";
	}*/
	if ($contact == '' || ctype_space($contact)) {
		$val_contact = "Mobile Number is required";
	}
	if (!preg_match('/^[0-9]{10}+$/', $contact)) {
		$val_contact = "Invalid Mobile Number";
	}
	if ($last_name == '' || ctype_space($last_name)) {
		$val_last_name = "Last name is required";
	}
	/*if($age==''){
		$val_age="Age is required";
	}*/
	$age = 1;
	$birth_date = null;
	if($date_of_birth !== null) {
		$dob = DateTime::createFromFormat('d/m/Y', $date_of_birth);
		$to   = new DateTime('today');
		$ageyears = $dob->diff($to)->y;
		//$age = $row->age == "1" ? '21-36' : ($row->age == "2" ? '37-50' : '50+');
		$age = ($ageyears > 21 && $ageyears <= 36 ? 1 : ($ageyears > 36 && $ageyears <= 50 ? 2 : 3));
		$birth_date = $dob->format('Y-m-d');
	}
	// TODO - Create new dob field
	if ($gender == '' || ctype_space($gender)) {
		$val_gender = "Gender is required";
	}

	
	
	$ind_found = false;
	if ($industry_code !== '' && $industry_name !== '' && !ctype_space($industry_name) && !ctype_space($industry_code)) {
		if ($result = mysqli_query($dbconnect, "select  * from tbl_industry where ind_code = '".$industry_code."'")) {
			$ind = '';
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$ind = $row;
					$ind_found = true;
				}
				$industry_id = $ind['id'];
				
				if($ind['ind_name'] !== $industry_name) {
					$irs = mysqli_query($dbconnect, "update tbl_industry set ind_name = '".$industry_name."' where id = ". $ind['id']);
				}
			}
		}
		if($ind_found === false) {
			$irs = mysqli_query($dbconnect, "insert into tbl_industry (ind_name, ind_code) values ('".$industry_name."', '". $industry_code . "')");
			$industry_id = $dbconnect->insert_id;
		}
	}
	else {
		$val_industry = "Industry is required";
	}

	$org_found = false;
	if ($organization_code !== '' && $organization_name !== '' && !ctype_space($organization_name) && !ctype_space($organization_code)) {
		
		if ($result = mysqli_query($dbconnect, "select  * from tbl_organization where org_code = '".$organization_code."'")) {
			$org = '';
			if (mysqli_num_rows($result) > 0) {
				while ($row = mysqli_fetch_assoc($result)) {
					$org = $row;
					$org_found = true;
				}
				$organization_id = $org['id'];
				if($org['org_name'] !== $organization_name || $org['industry_id'] !== $industry_id) {
					$urs = mysqli_query($dbconnect, "update tbl_organization set org_name = '".$organization_name."', industry_id = '".$industry_id."' where id = ". $org['id']);
				}
			}
		}
		if($org_found === false) {
			$urs = mysqli_query($dbconnect, "insert into tbl_organization (org_name, org_code, industry_id) values ('".$organization_name."', '". $organization_code  . "', ". $industry_id . ")");
			$organization_id = $dbconnect->insert_id;
		}
	}
	else {
		$val_organization = "Organization is required";
	}
	
	/*if($organization==''){
	$val_organization="Organization is required";
	}*/

	$val_twitter = $twitter;
	$val_linkedin = $linkedin;

	if ($email != '') {
		$q = mysqli_query($dbconnect, "select * from tbl_user where email='" . $email . "'");
		$rowcount = mysqli_num_rows($q);
		if ($rowcount > 0) {
			$val_email = "E-mail id is already registered";
		}
	}

	$queryorg = "SELECT * FROM `tbl_user` ";
	//$queryorg .= " INNER JOIN `tbl_organization` ON `tbl_organization`.`id` = `tbl_user`.`organization_id` ";
	$queryorg .= " WHERE `tbl_user`.`email` = '$email' AND status= 'active'; ";
	if ($result = mysqli_query($dbconnect, $queryorg)) {
		$user = null;
		if (mysqli_num_rows($result) > 0) {
			while ($row = mysqli_fetch_assoc($result)) {
				$setqr = '';
				// TODO - check organization change
				// birth date, age ?
				if ($row['organization_id'] != $organization_id) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_user`.`organization_id` = ' . $organization_id;
				}
				if ($row['name'] != $name) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_user`.`name` = \'' . $name . '\'';
				}
				if ($row['last_name'] != $last_name) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_user`.`last_name` =  \'' . $last_name . '\'';
				}
				if (strtolower($row['gender']) != strtolower($gender)) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_user`.`gender` =  \'' . strtolower($gender) . '\'';
				}
				if($birth_date !== null) {
					$setqr .= ($setqr == '' ? '' : ', ') . ' `tbl_user`.`birth_date` =  \'' . $birth_date . '\'';
				}
				if ($setqr != '') {
					$setqr = "UPDATE `tbl_user` SET " . $setqr . " WHERE `tbl_user`.`email` = '$email'; ";
					
					// update fields and login automatically
					mysqli_query($dbconnect,$setqr);
					if(mysqli_affected_rows($dbconnect)>0){
					}
				}
				loginwithemail($email, $redirect_url);
			}
		} else {
			//var_dump($val_name,$val_email,$val_password,$val_contact,$val_last_name,$val_age,$val_gender,$val_confirm_password1,$val_confirm_password);
			if ($val_name == "" && $val_email == "" && $val_password == "" && $val_contact == "" && $val_last_name == "" && $val_age == "" && $val_gender == "" && $val_confirm_password1 == ""  && $val_confirm_password == "") {
				// register and login automatically
			   	$setqr2 = "INSERT INTO `tbl_user`( `name`, `email`, `password`, `contact`,  `last_name`, `age`, `gender`, `linkedin`, `twitter`,`status`,`organization_id`,`organization`,`kaccess`,`caccess`,`birth_date`) VALUES ('".$name."'
				   , '".$email."', '".$password."', '".$contact."',  '".$last_name."', '".$age."', '".$gender."', '".$linkedin."', '".$twitter."','active',".$organization_id.",'','no','no',".($birth_date === null ? null : "'" . $birth_date . "'" ).")";
				   
				mysqli_query($dbconnect,$setqr2);
				if(mysqli_affected_rows($dbconnect)>0){
					loginwithemail($email, $redirect_url);
				} else {
					echo '<div class="alert alert-warning text-center">Invalid request! (Failed to setup profile)</div>';
				}
			} else {
				echo '<div class="alert alert-warning text-center">Invalid request! (missing or invalid data)</div>';
			}
		}
		// Free result set
		mysqli_free_result($result);
	}
}

?>
<div class="container">
	<div class="row">
		<div class="col-md-12">
		</div>
	</div>
</div>

<?php include('footer.php'); ?>
<script>
	
</script>
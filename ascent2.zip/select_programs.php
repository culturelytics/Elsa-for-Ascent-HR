<?php include('header.php'); ?>
<style>
	.button {
  background-color: #A41319; /* Green */
  border: none;
  color: white;
  padding: 10px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin-left: 690px;
  margin-top: 10px;
}

</style>
<?php
if(!isset($_SESSION["sess_email_caccess"])){
	header("Location: successmessage.php");
}
else
{
?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">

<div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
<div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">

<?php
    $result2=mysqli_query($dbconnect, "SELECT  tbl_user_idp_programs.ui_id as aid,name,title,subtitle FROM tbl_user_idp_programs LEFT JOIN tbl_user ON tbl_user.id=tbl_user_idp_programs.ui_user_id LEFT JOIN tbl_idp ON tbl_idp.id=tbl_user_idp_programs.ui_idp_id   where ui_user_id='". $_SESSION['user_id']."' AND  idp_status='Active'");
   
?>
  <p style="text-align: right;margin-top: 15px;font-size: 15px;color: #0087cb;">Welcome <?php echo $_SESSION['user_name']; ?></p>
	<!--<button class="button"><a href="feedback.php">Feedback Form</a></button>-->
	<form action="feedback.php"><button type="submit" class="button">Feedback Form</button></form>  
<?php
if(mysqli_num_rows($result2)>0) { ?>
  <div class="col-md-12">
  <h3 style="margin-bottom:20px;">Select your Program</h3>
  <?php while ( $res2 = mysqli_fetch_array($result2)) {
    ?>
	
<div class="col-md-12" style="margin-top:10px">
	<a href="clients.php?id=<?=$res2['aid']?>"> * <?php echo $res2['title']; ?></a>
</div>
 <?php  } ?>
 </div>
 <?php } else { ?>
<div class="col-md-12" align="center">
<p>No Record Found  </p>
</div>
 <?php } ?>
 </div>
</div>
</div>
<?php
}
?>

<?php include('footer.php'); ?>
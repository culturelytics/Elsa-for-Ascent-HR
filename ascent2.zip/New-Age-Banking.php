<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">NEW AGE BANKING</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	The banking licences granted by India’s central bank to entities such as telcos, e-commerce companies and microfinance firms are shaking up one of the most traditional banking sectors in the Asia-Pacific region, threatening the dominance of the full-service public sector banks.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	NEW AGE BANKING
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Current Trends</p>
		<ul class="cs-ui">
			<li><a href="https://www.businessinsider.in/These-are-the-top-trends-that-will-define-the-banking-industry-in-2017/articleshow/57022356.cms" target="_blank">These are the top trends that will define the banking industry in 2017</a></li>
			<li><a href="https://www.pwc.com/gx/en/industries/financial-services/banking-capital-markets/banking-2020/emerging-trends.html" target="_blank">Emerging trends and imperatives</a></li>
			<li><a href="https://thefinanser.com/2017/01/5-banking-tech-trends-2017.html/" target="_blank">5 Banking Tech Trends for 2017</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Impact of fin-tech in Banking </p>
		<ul class="cs-ui">
			<li><a href="http://www.whitlockco.com/fintech-and-your-bank/" target="_blank">How the rise of Fintech could affect your bank</a></li>
			<li><a href="https://www.financierworldwide.com/the-disruptive-influence-of-fintech/#.WjDeXd9fjEo" target="_blank">The disruptive influence of FinTech</a></li>
			<li><a href="https://www.ft.com/content/bc846657-1af0-368e-a933-f14bc971d321" target="_blank">What fin-tech is going to do to banking</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Blockchain and banking</p>
		<ul class="cs-ui">
			<li><a href="https://www.vccircle.com/what-blockchain-and-why-icici-bank-s-use-it-big-deal/" target="_blank">What is ‘blockchain’ and why ICICI Bank’s use of it is a big deal?</a></li>
			<li><a href="https://inc42.com/buzz/understanding-basics-blockchain/" target="_blank">Understanding The Basics Of Blockchain And Why Banks Are Keen To Adopt Them</a></li>
			<li><a href="https://hbr.org/2017/03/the-blockchain-will-do-to-banks-and-law-firms-what-the-internet-did-to-media" target="_blank">The Blockchain Will Do to the Financial System What the Internet Did to Media​</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Using AI and BOTs in Banking</p>
		<ul class="cs-ui">
			<li><a href="https://www.abe.ai/blog/10-big-banks-using-chatbots-boost-business/" target="_blank">How 10 Big Banks Are Using Chatbots to Boost Their Business</a></li>
			<li><a href="http://servion.com/blog/artificial-intelligence-banking/" target="_blank">Artificial Intelligence and The Era Of Conversational Banking </a></li>
			<li><a href="https://www.americanbanker.com/news/why-branch-bankers-shouldnt-fear-bots" target="_blank">Why branch bankers shouldn't fear bots</a></li>
		</ul>
		</div>


		<p class="ab" style="font-size: 17px">DIGITAL BANKING</p>

			
		<div class="info-n">
		<p class="abt-sub-titles ab">Changing characteristics in banking</p>
		<ul class="cs-ui">
			<li><a href="http://www.banksoft.eu/banking-software/banksoft-modern-banking-environment" target="_blank">Modern banking environment</a></li>
			<li><a href="http://dialoguereview.com/santander-exclusive-11-characteristics-bank-future/" target="_blank">Santander exclusive: 11 characteristics of the bank of the future</a></li>
			<li><a href="https://irishtechnews.ie/5-characteristics-of-executives-in-digital-banking/" target="_blank">5 characteristics of executives in digital banking</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Moving towards customer centricity</p>
		<ul class="cs-ui">
			<li><a href="https://www.bcgperspectives.com/content/articles/information_technology_strategy_digital_economy_customer_centricity_financial_services_goes_digital/" target="_blank">Customer-Centricity in Financial Services Goes Digital</a></li>
			<li><a href="https://thefinancialbrand.com/55611/customer-centricity-digital-banking-strategy/" target="_blank">Customer Centricity: Moving From Lip Service to Digital Sales</a></li>
			<li><a href="http://www.smandh.com/performance-insights/conversations-quarterly/" target="_blank">Transforming Your Bank from Branch Centric to Customer Centric: You don't have as much time as you think!</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Increasing efficiency by process automation</p>
		<ul class="cs-ui">
			<li><a href="http://www.aberdeenessentials.com/techpro-essentials/robotic-process-automation-leading-toward-increased-efficiency-heightened-accuracy-and-happier-employees/" target="_blank">Robotic Process Automation: Increased Efficiency, Heightened Accuracy and Happier Employees</a></li>
			<li><a href="http://www.computerweekly.com/feature/Automating-workloads-to-improve-business-efficiency" target="_blank">Automating workloads to improve business efficiency</a></li>
			<li><a href="https://www.grexo.com/process-improvement-keys/" target="_blank">Automation is the Key to Process Improvement</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Using Analytics and Big Data for understanding customer behavior and compliance.</p>
		<ul class="cs-ui">
			<li><a href="https://www.abe.ai/blog/10-big-banks-using-chatbots-boost-business/" target="_blank">What Customer Behavior Analytics Can Do For You – Datameer Whiteboards</a></li>
			<li><a href="http://bigdata-madesimple.com/using-big-data-to-understand-customers-behavior-and-increase-the-business-profits/" target="_blank">Using big data to understand customers’ behavior and increase the business profits</a></li>
			<li><a href="http://www.banktech.com/compliance/compliance-and-customer-experience-is-big-data-the-answer/d/d-id/1296514?" target="_blank">Compliance and Customer Experience: Is Big Data the Answer?</a></li>
		</ul>
		</div>


	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/digital-bank.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://chrisskinner.global/digital-bank-strategies-to-launch-or-become-a-digital-bank/" target="_blank">Digital Bank: Strategies to launch or become a digital bank</a></p>
	</div>
	</div>


		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/bank3.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://thefinancialbrand.com/38749/brett-king-bank3-0-digital-banking-movenbank-disruption/" target="_blank">Bank 3.0: Why Banking Is No Longer Somewhere You Go But Something You Do
Book by Brett King</a></p>
	</div>
	</div>





	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
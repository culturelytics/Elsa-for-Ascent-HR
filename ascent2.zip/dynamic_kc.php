<?php include('header.php'); ?>
<?php
if (!isset($_SESSION["sess_email_kaccess"])) {
	header("Location: login.php");
}
?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
	window.dataLayer = window.dataLayer || [];

	function gtag() {
		dataLayer.push(arguments);
	}
	gtag('js', new Date());

	gtag('config', 'UA-112031379-1');
</script>
<?php
if (1) {
	if (!(isset($_REQUEST['kc_id']))) {
		header("Location: e2e-library.php");
	} else {
		include_once('connectdb.php');

		$msg = "";
		if (isset($_POST) & !empty($_POST)) {
			if ($_POST['prg_id'] != "" && ($_SESSION['user_id'] != "" && $_SESSION['user_id'] != null)) {
				$qrassign = "INSERT INTO `tbl_kc_assignments` (`kca_user_id`, `kca_kc_id`, `kca_created_at`, `kca_isself`) 
	  VALUES (" . $_SESSION['user_id'] . ", " . $_POST['prg_id'] . ", '" . date('Y-m-d H:i:s') . "', 1)";
				$result = mysqli_query($dbconnect, $qrassign);
				if ($result != null) {
					$msg = "Knowledge Center Added to My Reading List.";
				} else {
					$msg = "Knowledge Center Not Added to My Reading List";
				}
			}
		}
?>

		<?php
		$id = $_REQUEST['kc_id'];
		
		// Expire all trophies achieved by User after valid till date
		$expireTrophies = mysqli_query($dbconnect, "UPDATE tbl_module_trophies SET STATUS = '1' WHERE valid_till < UNIX_TIMESTAMP(NOW()) AND STATUS = '0';");

		// Expire all assessments which are past valid till date
        $lastmodifiedon = time();
		$expire_assessment = mysqli_query($dbconnect, "UPDATE tbl_assessment SET STATUS = '2', lastmodifiedon = '".$lastmodifiedon."' WHERE valid_till < UNIX_TIMESTAMP(NOW()) AND STATUS IN ('0', '1');");

		$sql = "select * from tbl_knowledge_center where `prg_id`='" . $id . "' and prg_status='Active'";
		$query = mysqli_query($dbconnect, $sql);
		$numrows = mysqli_num_rows($query);
		if ($numrows != 0) {

			$qr = "SELECT * FROM `tbl_kc_assignments` WHERE kca_user_id=" . $_SESSION['user_id'] . ";";
			$myassignments = [];
			if ($resultind = mysqli_query($dbconnect, $qr)) {
				while ($row1 = mysqli_fetch_object($resultind)) {
					$myassignments[] = $row1;
				}
				mysqli_free_result($resultind);
			}

			$kca_c_list = json_decode(json_encode($myassignments), true);
			$kca_kc_id = array_column($kca_c_list, 'kca_kc_id');

			$row = mysqli_fetch_array($query);
		?>
			<div class="col-lg-12  mob-no-padng">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">
					<div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
						<div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
							<p class="cs-comn-heading-title ar career-title text-center"><?= $row['prg_name'] ?></p>
							<hr class="line-75">
							<ul class="cs-ui">
								<?= $row['prg_desc'] ?>
							</ul>

							<?php
							$user_id = $_SESSION["user_id"];

							function findslab(array $pricing, $needle, $total)
							{
								$last = null; $perc = 0; // return value if $pricing array is empty
								if($needle > 0 && $total > 0) {
									$perc = ($needle * 100) / $total;
								}
								$idx = 0; $res = '';
								foreach ($pricing as $key => $value) {
									$idx++;
									//echo $needle ,' >= '. $value .'<br>' . $key ,'<br>';
									if ($perc >= $value) {
										$res = $key; // found it, return quickly
									}
									//$last = $key; // keep the last key thus far
								}
								$perc = number_format($perc, 0);
								return array($res, $perc); // ($last == -1 ? '' : $last);
							}

							$qtrtp = "SELECT tbl_trophy_template_slab.*, tbl_trophy_template.trpt_name FROM `tbl_trophy_template_slab` ";
							$qtrtp .= " INNER JOIN `tbl_trophy_template` ON `tbl_trophy_template`.`trpt_id` = `tbl_trophy_template_slab`.`trps_trpt_id` ";
							$qtrtp .= " INNER JOIN `tbl_knowledge_center` ON `tbl_knowledge_center`.`prg_trtp_id` = `tbl_trophy_template`.`trpt_id` ";
							$qtrtp .= " WHERE `tbl_knowledge_center`.`prg_id` = " . $id . ";";
							$trpslabs = [];
							$trp_template = '';
							if ($result = mysqli_query($dbconnect, $qtrtp)) {
								while ($row3 = mysqli_fetch_assoc($result)) {
									$trpslabs[$row3['trps_name']] = $row3['trps_perc'];
									$trp_template = $row3['trpt_name'];
								}
								// Free result set
								mysqli_free_result($result);
							}

							$sqlcredits = " SELECT `tbl_kc_list`.`kl_id` AS 'tkl_id', `tbl_kc_list`.`kl_credits` AS 'tkl_credits' FROM `tbl_event_history` ";
							$sqlcredits .= " LEFT JOIN `tbl_kc_list` ON `tbl_event_history`.`eh_kc_list_id` = `tbl_kc_list`.`kl_id`  ";
							$sqlcredits .= " LEFT JOIN `tbl_user` ON `tbl_event_history`.`eh_u_id` = `tbl_user`.`id` ";
							$sqlcredits .= " WHERE `eh_cori` = 'content' ";
							$sqlcredits .= " AND `tbl_event_history`.`eh_u_id` = " . $user_id;
							$sqlcredits .= " AND `tbl_kc_list`.`kl_prg_id` = " . $row['prg_id'] . " AND `tbl_kc_list`.`status` = 'Active' ";
							$sqlcredits .= " GROUP BY tkl_id";
							$sqlcredits .= " ORDER BY `organization` ASC;";

							$cntdata = [];
							$totdata = 0;
							$currentcredits = 0; $completed_items = 0;
							if ($result = mysqli_query($dbconnect, $sqlcredits)) {
								while ($row4 = mysqli_fetch_assoc($result)) {
									$cntdata[$row4['tkl_id']] = $row4['tkl_credits'];
									$totdata += (int) $row4['tkl_credits'];
									$currentcredits += (int) $row4['tkl_credits'];
									$completed_items++;
								}
								// Free result set
								mysqli_free_result($result);
								$obtainedscore=1;
							}

							$total_credits = 0; $total_items = 0;
							$trs = mysqli_query($dbconnect, "select kl_credits as tscore from tbl_kc_list where kl_prg_id = ". $id ." and status = 'Active'");
							if($trs) {
								while($trow =  mysqli_fetch_assoc($trs)) {
									$total_credits += $trow['tscore'];
									$total_items++;
								}
								mysqli_free_result($trs);
							}
							// $qrcrd = "SELECT `tbl_kc_assignments`.`kca_credits` as `kca_credits` FROM `tbl_kc_assignments` WHERE `tbl_kc_assignments`.`kca_user_id` = " . $_SESSION['user_id'] . " AND `tbl_kc_assignments`.`kca_kc_id` = " . $row['prg_id'] . " AND `tbl_kc_assignments`.`kca_status` = 'Active';";
							// if ($rescrd = mysqli_query($dbconnect, $qrcrd)) {
							// 	while ($rwrescrd = mysqli_fetch_object($rescrd)) {
							// 		$currentcredits += $rwrescrd->kca_credits;
							// 	}
							// 	mysqli_free_result($rescrd);
							// }

							$trophy = findslab($trpslabs, $currentcredits, $total_credits);
							$trophy_type_sql = "SELECT trophy_type FROM tbl_module_trophies WHERE `userid` = '".$user_id."' AND `moduleid` = '".$id."' AND status = '0' ORDER BY mtid DESC LIMIT 1";
							$trophy_type_exec = mysqli_query($dbconnect, $trophy_type_sql);
							$trophy_type_no_rows = mysqli_num_rows($trophy_type_exec);
							if ($trophy_type_no_rows != 0) {
								$trophy_type_row = mysqli_fetch_array($trophy_type_exec);
								$trophy_type = $trophy_type_row['trophy_type'];
								$trophy_image = $trp_template.'-'.$trophy_type;
							} else {
								$trophy_type = '-';
								$trophy_image = $trp_template;
							}
							$complete_perc = 0;
							if($total_items > 0 && $completed_items > 0) {
								$complete_perc = number_format(  ( ($completed_items * 100) / $total_items ) , 0);
							}
							?>
							<?php if (in_array($row['prg_id'], $kca_kc_id)) : ?>
								<div class="col-12 align-right">
								<div class="ikc-box">
									<div class="ib-lp">
										<div class="ldTail"><i class="fa fa-circle"></i></div>
										<div class="ldBar" data-preset="circle" data-stroke="#2ecc71" data-value="<?php echo $complete_perc ?>"></div>
									</div>
									<div class="ib-rp">
										<div class="ib-val"><?php echo $completed_items ?> / <?php echo $total_items ?></div>
										<div class="ib-lbl">Content Completed</div>
									</div>
								</div>
								<div class="ikc-box">
										<div class="ib-lp">
											<div class="ldTail"><i class="fa fa-circle"></i></div>
											<div class="ldBar" data-preset="circle" data-stroke="#2ecc71" data-value="<?php echo $trophy[1] ?>"></div>
										</div>
										<div class="ib-rp">
											<div class="ib-val"><?php echo $currentcredits ?> / <?php echo $total_credits ?></div>
											<div class="ib-lbl">Credits Scored</div>
										</div>
									</div>
									<div class="ikc-box">
										<div class="ib-lp">
										<div class="olo-icon oloi-60 <?php echo $trophy_image ?>" style="background-image: url(images/<?php echo $trophy_image ?>.png)"></div>
										</div>
										<div class="ib-rp">
											<div class="ib-val"><?php echo $trophy_type ?></div>
											<div class="ib-lbl">Trophy Achieved</div>
										</div>
									</div>
							</div>
							<?php else : ?>
								<div style="text-align:right">
									<form method="post" action="" id="frm-selfassign">
										<input type="hidden" name="prg_id" value="<?php echo $row['prg_id'] ?>" />
										<button type="submit" class="btn btn-info btn-sm" name="selfassign">Add to My Reading List</button>
									</form>
								</div>
							<?php endif; ?>
							<?php if ($msg != "") : ?>
								<p class="text-center alert alert-success"><?php echo $msg; ?></p>
							<?php endif; ?>
						</div>


						<div class="col-lg-12 mob-no-padng">
							<div class="col-lg-6 mob-no-padng" id="dc_lpanel">
								<div class="heading-6 ab">
									<?= $row['prg_name'] ?>
								</div>
								<div class="cs-left">
									<div class="prg-list">
										<div class="prg-item" title="">
											<div class="prg-title align-center withcreds"><h4>Content</h4></div>
											<div class="prg-progress creds">
												<div class="pnlcredits align-center">Credits</div>
											</div>
										</div>
										<div class="prg-item" style="height: 10px">
										</div>
									</div>
									<?php

									$sql = "select * from tbl_kc_content where `kc_prg_id`='" . $id . "' and status='Active'";
									$query = mysqli_query($dbconnect, $sql);
									$numrows = mysqli_num_rows($query);
									if ($numrows != 0) {
										while ($row5 = mysqli_fetch_array($query)) { ?>
											<div class="info-n">
												<p class="abt-sub-titles ab"><?= $row5['kc_title'] ?></p>
												<div class="prg-list">
													<?php
														$sql1 = "select * from tbl_kc_list where `kl_kc_id`='" . $row5['kc_id'] . "' and status='Active'";
														$query1 = mysqli_query($dbconnect, $sql1);
														$numrows1 = mysqli_num_rows($query1);
														if ($numrows1 != 0) {
															while ($row1 = mysqli_fetch_array($query1)) {
																$showLink = true;
																$showRow = true;
																$icon = 'fa-file-text';
																if($row1['kl_cat'] === 'Video') {
																	$icon = 'fa fa-play-circle';
																}
																else if($row1['kl_cat'] === 'Article') {
																	$icon = 'fa fa-newspaper-o';
																}
																else if($row1['kl_cat'] === 'Assessment' || $row1['kl_cat'] === 'Elsa Assessment') {
																	$icon = 'fa fa-check-square-o';
																	
																	if($row1['kl_cat'] === 'Elsa Assessment') {
																		$asses_sql = "SELECT * FROM tbl_assessment WHERE `subcontentid` = '".$row1['kl_id']."' AND status IN ('1', '2') ORDER BY aid LIMIT 1";
																		$asses_exec = mysqli_query($dbconnect, $asses_sql);
																		$asses_no_rows = mysqli_num_rows($asses_exec);
																		if ($asses_no_rows != 0) {
																			$asses_row = mysqli_fetch_array($asses_exec);
																			if($asses_row['status'] == 2) {
																				$showLink = false;
																			}
																		} else {
																			$showRow = false;
																		}
																	}
																}
																if($showRow) {
														?>
																	<div class="prg-item" title="">
																		<?php if (in_array($row['prg_id'], $kca_kc_id)) : ?>
																			<div class="prg-title withcreds">
																				<?php 
																					if($showLink) {
																						if($row1['kl_cat'] != 'Elsa Assessment') {																		
																				?>
			
			<a class="trlvl" onclick="Testing123()" href="/ascent/admin<?= $row1['kl_file_url'] ?>" target="_blank"  title='<?php echo $row1['kl_list'] ?>'><i class="fa fa-file  <?php echo $icon ?>"></i><?php echo $row1['kl_list'] ?></a>
																		

																				<?php 	} else { ?>
																							<a class="trlvl takeassessment" href="#" title='<?php echo $row1['kl_list'] ?>' data-assessmentid="<?= $asses_row['aid'] ?>" data-moduleid="<?= $asses_row['moduleid'] ?>" data-contentid="<?= $asses_row['contentid'] ?>" data-subcontentid="<?= $asses_row['subcontentid'] ?>" data-assessment_title="<?= $asses_row['assessment_title'] ?>" data-assessment_detail='<?= $asses_row['assessment_detail'] ?>'><i class="fa  <?php echo $icon ?>"></i><?php echo $row1['kl_list'] ?></a>
																				<?php 
																						}
																					} else {
																				?>
																					<a style="color: dimgrey;"><i class="fa <?php echo $icon ?>"></i><?php echo $row1['kl_list'] ?></a>
																				<?php } ?>
																			</div>
																		<?php else : ?>
																			<div class="prg-title withcreds">
																				<div title='<?php echo $row1['kl_list'] ?>'><i class="fa <?php echo $icon ?>"></i><?php echo $row1['kl_list'] ?></div>
																			</div>
																		<?php endif; ?>
																		<?php if($row1['kl_file_url'] != ''): ?><a href="/ascent/admin<?= $row1['kl_file_url'] ?>" target="_blank" id="lnk-file" title="Download File"><i class="fa fa-file inline"></i></a><?php endif;?>
																		<div class="prg-progress creds">
																		<?php 
																			if($row1['kl_cat'] == 'Elsa Assessment') {
																				$totalscore = 0; $obtainedscore = 0;
																				$score_sql = "SELECT totalscore, obtainedscore FROM tbl_user_assessment WHERE `userid` = '".$user_id."' AND `subcontentid` = '".$row1['kl_id']."' ORDER BY obtainedscore DESC LIMIT 1";
																				$score_exec = mysqli_query($dbconnect, $score_sql);
																				$score_no_rows = mysqli_num_rows($score_exec);
																				if ($score_no_rows != 0) {
																					$score_row = mysqli_fetch_array($score_exec);
																					$totalscore = $score_row['totalscore'];
																					$obtainedscore = $score_row['obtainedscore'];
																				}
																		?>
																				<div class="pnlcredits"><?php echo $obtainedscore . " / " . $totalscore; ?></div>
																		<?php 
																			} else {
																		?>
																			
																				<div class="pnlcredits"><?php echo (isset($cntdata[$row1['kl_id']]) ? $cntdata[$row1['kl_id']] : 0) . " / " . $row1['kl_credits']; ?></div>
																		<?php 
																			}
																		?>
																		</div>
																	</div>
														<?php
																}
															}
														} ?>
												</div>
											</div>
									<?php
										}
									}
									?>

								</div>
							</div>


							<!--right side-->


							<div class="col-lg-6 mob-no-padng  "  id="dc_rpanel">
								<div class="heading-6 ab">
									BOOKS TO READ
								</div>
								<div class="cs-left">
									<?php
									$sql = "select * from tbl_image_content where `img_kc_id`='" . $id . "'";
									$query = mysqli_query($dbconnect, $sql);
									$numrows = mysqli_num_rows($query);
									if ($numrows != 0) {
										while ($row = mysqli_fetch_array($query)) { ?>
											<div class="col-lg-12" style="margin-top: 25px">
												<div class="col-lg-4 circle-bottom-10">
													<div class="book-circle" style="background-image: url(ascent/admin/uploads/content_images/<?= $row['img_name'] ?>);" title="<?= $row['img_title'] ?>">
														<!-- <img class="small-book" src="ascent/admin/uploads/content_images/<?= $row['img_name'] ?>" alt="book"> -->
													</div>
												</div>
												<div class="col-lg-8 booktext-top">
													<p class="book-text"><a onclick="save_value_db('<?= $row['img_link'] ?>','<?= $row['img_id'] ?>','image')" href="<?= $row['img_link'] ?>" target="_blank"><?= $row['img_title'] ?></a></p>
												</div>
											</div>
									<?php }
									}
									?>


								</div>
							</div>
						</div>
					</div>
				</div>
			</div>			
			<div class="modal fade" id="takeAssessmentModal" tabindex="-1" role="dialog" aria-labelledby="AssessmentModalLabel" aria-hidden="true">
				<div class="modal-dialog" style="width: 900px; max-width: 900px; transform: translate(0,0); margin: 1.75rem auto !important;" role="document">
					<div class="modal-content">
						<div class="modal-header" style="border-bottom: none;padding: 10px 10px 2px 10px;">
							<h5 class="modal-title" id="takeAssessmentModalTitle" style="color: #0069d9;text-align: center;margin-left: 20%;">Assessment</h5>
							<button class="close" type="button" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">×</span>
							</button>
						</div>
						<div class="modal-body" style="padding-top: 5px; max-height: 600px; overflow: auto; padding-left: 30px; padding-right: 30px;">
							<div class="alert assessmentSubmitted" style=" text-align: center; margin-top: 40px;" role="alert">
								<div class="ikc-box" style="width: 500px; margin-right: 0px; text-align: center;">
									<div class="ib-rp">
										<div class="ib-lbl">You have completed the assessment. Your score is <b class="scoreObtained" style="font-size: 16px;"></b>.</div>
										<div class="ib-val scoreComment" style="font-size: 16px;"></div>
									</div>
								</div>
								<hr class="showTrophy" style="margin-top: 0px; margin-bottom: 15px">
								<div class="ikc-box showTrophy" style="width: 500px; margin-right: 0px">
									<div class="ib-lp">
										<div class="olo-icon oloi-60 trophyType"></div>
									</div>
									<div class="ib-rp">
										<div class="ib-lbl trophyObtained" style="padding-top: 20px;"></div>
									</div>
								</div>
							</div>
							<!-- <form method="post" enctype="multipart/form-data" action="record_assessment.php"> -->
							<form method="post" enctype="multipart/form-data" class="submit-assessment">
								<input type="hidden" name='assessmentid' id='assessmentid' class="form-control" value="">
								<input type="hidden" name='moduleid' id='moduleid' class="form-control" value="">
								<input type="hidden" name='contentid' id='asscontentid' class="form-control" value="">
								<input type="hidden" name='subcontentid' id='asssubcontentid' class="form-control" value="">
								<table width="100%">
									<tr>
										<td id="assessmentTable">
											
										</td>
									</tr>
								</table>
								<input class="btn btn-primary" type="submit" name="Save" value="Submit" style="margin-left: 45%;width: 90px;height: 35px;padding: 1px; border-radius: 4px;">
							</form>
						</div>
					</div>
				</div>
			</div>
			<script>	
				
				$(document).ready(function() { 
					if($("#dc_lpanel").height() > $("#dc_rpanel").height()) {
						$("#dc_lpanel").addClass("lg-border-right");
						$("#dc_rpanel").removeClass("lg-border-left");
					}
					else {
						$("#dc_lpanel").removeClass("lg-border-right");
						$("#dc_rpanel").addClass("lg-border-left");
					}
					$(document).on('click', '.takeassessment', function (e) {
						e.stopPropagation();
						e.preventDefault();
						
						$('.assessmentSubmitted').hide();
						$('.assessmentSubmitted').parent().css('height', 'auto');
						$('.submit-assessment').show();
						var assessmentid = ''; var moduleid = ''; var contentid = ''; var subcontentid = ''; var assessment_title = ''; var assessment_detail = ''; var assessment_details = ''; var status = '';
						assessmentid = $(this).data('assessmentid');
						moduleid = $(this).data('moduleid');
						contentid = $(this).data('contentid');
						subcontentid = $(this).data('subcontentid');
						assessment_title = $(this).data('assessment_title');
						assessment_detail = $(this).data('assessment_detail');
						assessment_details = JSON.parse(JSON.stringify(assessment_detail));
						status = $(this).data('status');
						
						var tableHTML = '';
						$.each(assessment_details, function( index, eachDetail ) {
							var options = '';
							var correctAnswer = '';
							$.each(eachDetail.options, function( eachIndex, value ) {
								if(value.is_correct == 0) {
									correctAnswer += '<input type="hidden" name="correctanswer[]" value="'+value.opttext+'">';
								}
								options += '<div><input type="radio" name="answer'+index+'" value="'+value.opttext+'" required style="float: left; margin-right: 5px;">'+value.opttext+'</div>';
							});							
							tableHTML += '<table width="100%" style="margin-bottom: 10px;">';
							tableHTML += '<tr><td class="questionNo" style="width: 30px; font-weight: bold;">Q'+index+'</td><td style="font-weight: bold;">'+eachDetail.qtitle+'</td></tr>';
							tableHTML += '<tr><td>'+correctAnswer+'</td><td>'+options+'</td></tr></table>';
						});
						$('#assessmentTable').html(tableHTML);
						$('#assessmentid').val(assessmentid);
						$('#moduleid').val(moduleid);
						$('#asscontentid').val(contentid);
						$('#asssubcontentid').val(subcontentid);
						$("#takeAssessmentModalTitle").html(assessment_title);
						$('#takeAssessmentModal').modal('show');
					});
					$('.submit-assessment').submit(function(e) {
						e.preventDefault();						
						// $(this).serialize(); will be the serialized form
						var formData = $(this).serialize();
						if(formData != '') {
							$.ajax({
								type: "POST",
								url: "record_assessment.php",
								data: formData,
								success: function(msg){
									$('.submit-assessment').hide();
									$('.assessmentSubmitted').fadeIn('slow');
									$('.assessmentSubmitted').parent().css('height', '300px');
									var trophyComment = {
										'No Rank' : 'Bring In Your Best!', 'Bronze' : 'You Can Do Much Better Than This!',
										'Silver' : 'Good Going!', 'Gold' : 'Congratulations! You Are An Expert!'};
									var res = msg.split("||");
									$('.assessmentSubmitted').find('.showTrophy').show();
									if(res[3] == 'NO') {
										$('.assessmentSubmitted').find('.showTrophy').hide();
									}
									if(res[2] != '') {
										$('.assessmentSubmitted').find('.trophyType').addClass('threeshields-'+res[0]).css('background-image', 'url(images/threeshields-'+res[0]+'.png)');
										$('.assessmentSubmitted').find('.trophyObtained').html('Congratulations! You have earned <b>'+res[0]+'</b> Trophy.');
										$('.assessmentSubmitted').find('.scoreComment').html(trophyComment[res[2]]);
										$('.assessmentSubmitted').find('.scoreObtained').html(res[1]);										
									} else {
										$('.assessmentSubmitted').find('.trophyType').addClass('threeshields').css('background-image', 'url(images/threeshields.png)');
										$('.assessmentSubmitted').find('.trophyObtained').html('No Rank Upgrade.');
										$('.assessmentSubmitted').find('.scoreComment').html(trophyComment['No Rank']);
										$('.assessmentSubmitted').find('.scoreObtained').html(res[1]);
									}
								},
								error: function(err) {}
							});
						}
					});
				});
				
function Testing123() {		
					<?php 
			
			$trss = mysqli_query($dbconnect, "select ulh_id as tscore from tbl_user_login_history where ulh_u_id = ". $user_id ." ORDER BY ulh_start_time desc LIMIT 1");
			$troww =  mysqli_fetch_assoc($trss);
			$total_creditss = $troww['tscore'];
			
			$sql = "select * from tbl_kc_content where `kc_prg_id`='" . $id . "' and status='Active'";
									$query = mysqli_query($dbconnect, $sql);
									$numrows = mysqli_num_rows($query);
									$row5 = mysqli_fetch_array($query);
									$sql1 = "select * from tbl_kc_list where `kl_kc_id`='" . $row5['kc_id'] . "' and status='Active'";
									$query1 = mysqli_query($dbconnect, $sql1);
									$row1 = mysqli_fetch_array($query1);
														
																
			$testa = $row1['kl_id'];
			$testb = $row1['kl_kc_id'];
			$test1='102';
			$ulh_u_id1='103';
			
			date_default_timezone_set("Asia/Kolkata");
			$date = date("Y-m-d H:i:s");
			$names="insert into tbl_event_history (eh_u_id,eh_kc_content_id,eh_kc_list_id,eh_ul_id,eh_created_at,eh_cori) values ('$user_id','$testb','$testa','$total_creditss','$date','content')";
				
				$result12=mysqli_query($dbconnect,$names);
						?>
					
				
										
				}
				
				
			</script>
<?php
		} else {
			header("Location: e2e-library.php");
		}
	}
}
?>
<?php include('footer-index.php'); ?>
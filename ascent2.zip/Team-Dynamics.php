<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">TEAM DYNAMICS</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>Team dynamics are the unconscious, psychological forces that influence the direction of a team's behaviour and performance.</li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	TEAM DYNAMICS
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">Team Dynamics</p>
		<ul class="cs-ui">
			<li><a href="http://www.teamtechnology.co.uk/team/dynamics/definition/" target="_blank">Definition of team dynamics</a></li>
			<li><a href="https://www.livestrong.com/article/354170-what-is-team-dynamics/" target="_blank">What is team dynamics?</a></li>
			<li><a href="https://money.howstuffworks.com/business/starting-a-job/how-to-adapt-to-new-workplace3.htm" target="_blank">Understanding team dynamics in the workplace</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Group Dynamics</p>
		<ul class="cs-ui">
			<li><a href="https://en.wikipedia.org/wiki/Group_dynamics" target="_blank">Group Dynamics</a></li>
			<li><a href="http://www.yourarticlelibrary.com/management/group-dynamics-its-characteristics-stages-types-and-other-details-management/5363/" target="_blank">Group dynamics- Types, characteristics & Stages</a></li>
			<li><a href="https://www.mindtools.com/pages/article/improving-group-dynamics.htm" target="_blank">Improving group dynamics</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab" >Importance of Team dynamics</p>
		<ul class="cs-ui">
			<li><a href="http://www.teamtechnology.co.uk/team/dynamics/overview/" target="_blank">Team dynamics- how they can affect performance</a></li>
			<li><a href="http://smallbusiness.chron.com/importance-team-dynamics-project-management-37008.html" target="_blank">Importance of team dynamics in Project Management</a></li>
			<li><a href="http://blog.valerisys.com/tlt/the-importance-of-team-roles-in-teamwork/" target="_blank">The Importance of Team Roles In Teamwork</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Benefits of Team Dynamics</p>
		<ul class="cs-ui">
			<li><a href="http://smallbusiness.chron.com/team-concept-group-dynamics-strengths-weaknesses-business-teams-34746.html" target="_blank">The Team Concept of Group Dynamics & the Strengths & Weaknesses of Business Teams</a></li>
			<li><a href="#">Advantages of Teamwork and Why Teamwork is Important in Organizations</a></li>
			<li><a href="http://www.conundrumadventures.com/blog/2014/01/barriers-to-effective-team-dynamics/" target="_blank">Top 5 Barriers to Effective Team Dynamics</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Examples of Team Dynamics</p>
		<ul class="cs-ui">
			<li><a href="http://anderson-sabourin.com/leadership/2011/new-case-study-behavioral-team-dynamics-leadership-team/" target="_blank">Behavioral Team Dynamics - Leadership Team</a></li>
			<li><a href="https://www.projectsmart.co.uk/the-five-stages-of-team-development-a-case-study.php" target="_blank">The Five Stages of Team Development: A Case Study~ By Gina Abudi</a></li>
			<li><a href="https://thefruitfultoolbox.com/case-study-microsoft-team-building-and-group-dynamics/" target="_blank">Case study- Microsoft: Team building and group dynamics</a></li>
		</ul>
		</div>
					

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	CHANGE IN MANAGEMENT
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">Change in Management</p>
		<ul class="cs-ui">
			<li><a href="https://hbr.org/2005/10/the-hard-side-of-change-management" target="_blank">The Hard Side of Change Management</a></li>
			<li><a href="https://www.entrepreneur.com/article/235832" target="_blank">How to Lead Your Team Through Change</a></li>
			<li><a href="http://www.thecentregroup.com/organization-change-what-effective-leaders-do/" target="_blank">Organizational Change: What Effective Leaders Do</a></li>
			<li><a href="https://www.youtube.com/watch?v=__IlYNMdV9E&feature=youtu.be" target="_blank">What is change in management? Training Video</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Helping Employees to cope with change</p>
		<ul class="cs-ui">
			<li><a href="https://hbr.org/2009/01/helping-employees-cope-with-ch.html" target="_blank">Helping Employees to cope with change</a></li>
			<li><a href="https://www.entrepreneur.com/article/235832" target="_blank">How to Lead Your Team Through Change</a></li>
			<li><a href="">Motivating Your Staff in a Time of Change</a></li>
			<li><a href="https://www.youtube.com/watch?v=_GiuysFb-iY" target="_blank">10 ways to motivate employees (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Case studies</p>
		<ul class="cs-ui">
			<li><a href="http://www.managers.org.uk/insights/news/2015/july/the-5-greatest-examples-of-change-management-in-business-history" target="_blank">The 5 Greatest Examples of Change Management in Business History</a></li>
			<li><a href="http://ritzcarltonleadershipcenter.com/2015/08/change-management/" target="_blank">Seven Ways to Engage Employees in Change Management- Ritz- Carlton Leadership Center</a></li>
			<li><a href="https://www.youtube.com/watch?v=7C_z8UuCJ-Y" target="_blank">Change management for HR & Executives: The Case of the Mixed-Up Merger (video)</a></li>
			<li><a href="https://www.notredameonline.com/resources/leadership-and-management/how-leaders-emerge-during-challenging-times/#.WjDBs99fjEo" target="_blank">How Leaders Emerge During Challenging Times</a></li>
		</ul>
		</div>

	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <title>Value Added Business Solutions:e2e</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="e2e People Practices is a leading culture assessment firm based in India with expertise in mergers and acquisitions, HR analytics and behaviour analytics with 9 years of experience across numerous industries.">

    <meta name="keywords" content="Culture Assessment,Learning and Development,Mergers and Acquisitions,Leadership Development,Talent Development,Competency Screening,HR Analytics,Training Services,Consulting Services,Leading HR consulting firm,e-Learning">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="author" href="https://plus.google.com/yourpersonalprofile">
    <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
    <link href="css/css.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <link rel="stylesheet" href="css/m/font-awesome.min.css">
    <link rel="stylesheet" href="css/m/animate.min.css">
    <link rel="stylesheet" href="css/m/default.min.css">
    <link rel="stylesheet" href="css/m/demo.css">
    <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
    <link rel="shortcut icon" href="images/fav_e2e2.ico" />
    <script src="js/m/modernizr.js"></script>

</head>

<body>

    <div class="comn-bg" style="height:100%;">
        <div class="container" style="background:url('images/s1.jpg');width:100%;">
            <div class="col-lg-12  col-sm-12 col-xs-12 header-pdng">
                <div class="col-lg-2 col-sm-12 col-xs-12 center-below-992">
                    <a href="index.php">
                        <img src="<?php echo $pri_logo ?>" class="header-logo" alt="image">
                    </a>
                </div>

                <div class="col-lg-10  col-sm-12 col-xs-12 li-details header-strip" style="margin-top: 15px;">
                    <div class="col-lg-3 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
                        <span style="color:red;" class="ar">Quick Contact : </span>+91 80 23615999
                    </div>

                    <div class="col-lg-3 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
                        <span class="ar"></span><a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a>
                    </div>
                    <div class="col-lg-5" style="margin-top: 9px;">
                        <a href="program-register.php" class="login-btn" style="padding: 9px 9px; font-size: 12px;">e2e pay</a>
                        <a href="feedback.php" class="login-btn" style="padding: 9px 9px; font-size: 12px;">Feedback Form</a>
                        <?php
                        session_start();
                        if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { ?>
                        <a href="home.php" class="login-btn" style="padding: 9px 9px; font-size: 12px;">Home</a>
                        <a href="logout.php" class="login-btn" style="padding: 9px 9px; font-size: 12px;">Logout</a>
                        <?php } else { ?>
                        <a href="login.php" class="login-btn" style="padding: 9px 9px; font-size: 12px;">Log In</a>
                        <?php } ?>
                        <?php
                        if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { ?>
                        <?php } else { ?>
                        <a href="register.php" class="login-btn" style="padding: 9px 9px; font-size: 12px;">Register</a>
                        <?php } ?>
                    </div>

                    <div class="col-lg-1  col-sm-6 col-xs-6 toggle-menu right0-abv768" style="width: 6%; float: right;">
                        <div class="nav-li-last w3-button w3-xlarge" style="float: right;" onclick="w3_open()">
                            <div class="icon"></div>
                            <div class="icon"></div>
                            <div class="icon"></div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
        <div class="container ">

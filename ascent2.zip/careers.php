
<?php include('header.php'); ?>


<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">



<h2 class="ar career-title text-center">CAREERS</h2>
<hr class="line-75">
</div>




<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mob-no-padng">

<div class="col-lg-6 mob-no-padng">
<p style="color:greenyellow;" class="color-fff career-que ab">Why work with e2e?</p>
<div class="ans-box">
<p class="">At e2e People Practices, the responsibility of adding milestones to e2e business story lies with each of the e2e employees, and is a part of our consciousness at work.</p>
<p style="margin-bottom: 15px">At e2e, we believe in an organization with less hierarchy, and faster decision-making.
</p>
</div>

<p style="color:greenyellow;" class="color-fff career-que ab">The e2e advantage gives:</p>
<div class="ans-box">
	<ol style="list-style-type:decimal;margin-left: 25px;margin-bottom: 10px">
		<li>Strong management and process focus.</li>
		<li>Strong analytical capabilities.</li>
		<li>Comprehensive training programs.</li>
		<li>Sound Investment in employee welfare & development.</li>
	</ol>
</div>
</div>


<div class="col-lg-6 mob-no-padng">
<p style="margin-bottom: 10px">We are conscious of our culture that is based on our Values. We strive to imbibe this culture in our employees and consultants.
</p>
<div class="ans-box">
<ol style="list-style-type:decimal;margin-left: 25px;margin-bottom: 10px">
		<li>Honesty & Integrity.</li>
		<li>Client Focus.</li>
		<li>Team work.</li>
		<li>Excellence.</li>	
	   <li>Commitment to our people.</li>
		<li>Supporting learning at all levels by encouraging experimentation.</li>	
</ol>
<p>Though, we have people from diverse work cultures, everyone considers themselves to be a part of one big family.</p>
<p>It starts off right from hiring. We believe in the saying that, if you start with the type of person you want to hire, presumably you can build a work force that is prepared for the culture you desire. We look for attitudes that work towards excellence, and look for those people regardless of job category who enjoy their work and can endear themselves to their team and society.</p>
</div>
</div>

</div><!--col-12-->




<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng" style="margin-top: 25px;">
<section class="faq-form" style="background-color: #0A547B">
               <figure class="clearfix">
                  <div class="wrapper">
                     <div class="pull-left">	
                        <h3 style="color: #fff;padding: 9px;">Submit Your Resume
                        <i class="fa fa-arrow-right" aria-hidden="true" style="margin-left: 5px"></i>
                        </h3>
                     </div>
                     <a href="#form-faq" class="btn pull-right collapsed" data-toggle="collapse" aria-expanded="false" aria-controls="form-faq" style="background-color: #AA1A21;">Click Here</a>
                  </div>
               </figure>
               <div class="collapse" id="form-faq" style="height: 0px;">
                  <div class="">
                        <form action="xyz" method="post" id="contact_us" accept-charset="utf-8" style="padding: 15px;">
                        <div class="form-group">
                           <input type="text" class="form-control std-input-box" name="email"  placeholder="Name" required="">
                        </div>

                        <div class="form-group">
                           <input type="email" class="form-control std-input-box" name="email"  placeholder="Email" required="">
                        </div>

                        <div class="form-group">
                           <input type="text" class="form-control std-input-box" name="email"  placeholder="Phone" required="">
                        </div>

<div class="col-lg-12" style="padding-left: 0px">
<div class="col-lg-4 submit-resume-dropdown" style="padding-left: 0px">
                        <div class="form-sub-w3">
                        <select>
                        <option value="hide" style="background-color: transparent;" disabled>--Experience--</option>
                        <option value="1">Senior Management (>25 Years of Experience)</option>
                        <option value="2">Mid Level Manager (>10 Years of Experience)</option>
                        <option value="3">Fresher</option>
                        </select> 
                        </div>
</div>
<div class="col-lg-8"></div>                        
</div>

<div class="col-lg-12" style="padding-left: 0px">
<div class="col-lg-4 submit-resume-dropdown" style="padding-left: 0px">
                        <div class="form-sub-w3">
                        <select>
                        <option value="hide" style="background-color: transparent;" disabled>--Role--</option>
                        <option value="4">Marketing</option>
                        <option value="5">Human Resource Expert</option>
                        <option value="6">Operations</option>
                        <option value="7">Finance and Administration</option>
                        <option value="8">Business Enabler</option>
                        </select> 
                        </div>
</div>
<div class="col-lg-8"></div>                        
</div>


                        <div class="form-group">
                           <label class="submit-label ab">Upload your latest CV:</label>
                           <input type="file" name="attachment" style="color: #fff">
                        </div>

                        <div class="form-group">
                           <button type="submit" class="career-form-submit ab">SUBMIT</button>
                        </div>
                     </form>                  
                   </div>
               </div>
</section>


</div> 
          

</div>


<?php include('footer.php'); ?>

<script type="text/javascript">
$('select').each(function(){
    var $this = $(this), numberOfOptions = $(this).children('option').length;
  
    $this.addClass('select-hidden'); 
    $this.wrap('<div class="select"></div>');
    $this.after('<div class="select-styled"></div>');

    var $styledSelect = $this.next('div.select-styled');
    $styledSelect.text($this.children('option').eq(0).text());
  
    var $list = $('<ul />', {
        'class': 'select-options'
    }).insertAfter($styledSelect);
  
    for (var i = 0; i < numberOfOptions; i++) {
        $('<li />', {
            text: $this.children('option').eq(i).text(),
            // rel: $this.children('option').eq(i).val()
        }).appendTo($list);
    }
  
    var $listItems = $list.children('li');
  
    $styledSelect.click(function(e) {
        e.stopPropagation();
        $('div.select-styled.active').not(this).each(function(){
            $(this).removeClass('active').next('ul.select-options').hide();
        });
        $(this).toggleClass('active').next('ul.select-options').toggle();
    });
  
    $listItems.click(function(e) {
        e.stopPropagation();
        $styledSelect.text($(this).text()).removeClass('active');
        // $this.val($(this).attr('rel'));
        $list.hide();
        //console.log($this.val());
    });
  
    $(document).click(function() {
        $styledSelect.removeClass('active');
        $list.hide();
    });

});
</script>
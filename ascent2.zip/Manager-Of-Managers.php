<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">MANAGER OF  MANAGERS</p>
    <hr class="line-75">
    <ul class="cs-ui">
    <p>One of the key things that new managers need to internalize is :</p>
      <li>“What got you here won‟t get you there”</li>
      <li>Leading people requires managers to fundamentally look at themselves differently</li>
      <li>That should be the focus of the intervention.</li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	MANAGER OF  MANAGERS
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">Business Acumen</p>
		<ul class="cs-ui">
			<li><a href="http://blog.insight-experience.com/blog/business-acumen-important-aspiring-leaders/" target="_blank">What is business acumen and why it's important for leaders</a></li>
			<li><a href="http://www.allthingsadmin.com/administrative-professionals/5-ways-to-develop-your-business-acumen/" target="_blank">5 ways to develop your business acumen</a></li>
			<li><a href="http://www.prisim.com/case-studies/case-study-3/" target="_blank">Case Study on Business Acumen</a></li>
			<li><a href="https://www.youtube.com/watch?v=pr12giEsBSk" target="_blank">What is Business Acumen? (Video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Personal Branding</p>
		<ul class="cs-ui">
			<li><a href="https://www.thebalance.com/what-is-personal-branding-4056073" target="_blank">What is personal branding?</a></li>
			<li><a href="https://www.entrepreneur.com/slideshow/299671" target="_blank">5 Steps to Build Your Personal Brand</a></li>
			<li><a href="https://www.fastcompany.com/3048401/why-personal-branding-is-essential-to-career-success" target="_blank">Why Personal Branding Is Essential To Career Success</a></li>
			<li><a href="https://www.youtube.com/watch?v=0a0Vm0zHFh0" target="_blank">Personal Branding - why is it important? (Video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Diversity & Inclusion</p>
		<ul class="cs-ui">
			<li><a href="http://www.rbc.com/diversity/what-is-diversity.html" target="_blank">What is diversity?</a></li>
			<li><a href="http://www.talentintelligence.com/blog/bid/377611/inclusion-and-the-benefits-of-diversity-in-the-workplace" target="_blank">Inclusion and the benefits of diversity in the workplace</a></li>
			<li><a href="http://www.diversityjournal.com/14154-10-ways-employees-can-support-diversity-inclusion/" target="_blank">10 Ways Employees can Support Diversity and Inclusion</a></li>
			<li><a href="https://www.youtube.com/watch?v=MtD8A__a8WQ" target="_blank">Diversity in the Workplace  (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Presentation skills & art of handling difficult conversations</p>
		<ul class="cs-ui">
			<li><a href="https://www.wordstream.com/blog/ws/2014/11/19/how-to-improve-presentation-skills" target="_blank">Improve presentation skills</a></li>
			<li><a href="https://hbr.org/2015/01/how-to-handle-difficult-conversations-at-work" target="_blank">how to handle difficult conversations?</a></li>
			<li><a href="https://www.youtube.com/watch?v=wp4ho9raVjA" target="_blank">Presentation Skills: Tips & Tricks (video)</a></li>
			<li><a href="https://www.youtube.com/watch?v=WGcI6RWCohk" target="_blank">Tips on how to handle a difficult conversations (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Strategic thinking</p>
		<ul class="cs-ui">
			<li><a href="http://www.effectivegovernance.com.au/what-is-strategic-thinking/" target="_blank">What is strategic thinking?</a></li>
			<li><a href="https://www.forbes.com/sites/work-in-progress/2012/03/27/how-to-develop-5-critical-thinking-types/#47b18d37ef0a" target="_blank">How to develop 5 critical thinking types</a></li>
			<li><a href="http://www.creativehrm.com/strategic-thinking.html" target="_blank">Strategic Thinking in Human Resources</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Building and sustaining high performance teams</p>
		<ul class="cs-ui">
			<li><a href="https://www.shrm.org/resourcesandtools/tools-and-samples/toolkits/pages/developingandsustaininghigh-performanceworkteams.aspx" target="_blank">Developing and Sustaining High-Performance Work Teams</a></li>
			<li><a href="http://www.corporategeek.info/high-performance-project-team-how-create-sustain-and-disband-one" target="_blank">The high performance project team - How to create, sustain and disband one</a></li>
			<li><a href="http://blessingwhite.com/core-programs/leadership-solutions/building-high-performing-teams/" target="_blank">Building High Performing Teams-What’s Up With Teams?</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Peer Coaching</p>
		<ul class="cs-ui">
			<li><a href="http://www.ascd.org/publications/books/61191149/chapters/A-Definition-of-Peer-Coaching.aspx" target="_blank">A definition of Peer Coaching</a></li>
			<li><a href="https://www.linkedin.com/pulse/20140625215127-205717686-the-power-of-peer-coaching-5-tips-to-improve-your-team-s-performance" target="_blank">The Power of Peer Coaching: 5 Tips to Improve Your Team's Performance</a></li>
			<li><a href="http://www.studylecturenotes.com/management/john-whitmore-grow-model-a-coaching-mentoring-process" target="_blank">John Whitmore GROW Model-A coaching & mentoring process</a></li>
		</ul>
		</div>
									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">

	<div class="col-lg-12">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/the-new-one.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.amazon.com/One-Minute-Manager-Kenneth-Blanchard/dp/0688014291" target="_blank">The One Minute Manager, by Ken Blanchard and Spencer Johnson</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/the-effective.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.humorthatworks.com/what-i-learned-from/12-effectiveness-lessons-from-the-effective-executive/" target="_blank">The Effective Executive: The Definitive Guide to Getting the Right Things Done-Peter F. Drucker</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/leading.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.kotterinternational.com/8-steps-process-for-leading-change/" target="_blank">Leading Change: An Action Plan from the World's Foremost Expert on Business Leadership- John Kotter</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/good-to-great.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="#">Good to Great: Why Some Companies Make the Leap...And Others Don't- Jim Collins</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/now-discover.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/Now,_Discover_Your_Strengths" target="_blank">Now, Discover Your Strengths- Donald O. Clifton and Sally Byrne Woodbridge</a></p>
	</div>
	</div>


	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
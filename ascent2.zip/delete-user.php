<?php
include_once('connectdb.php');
$id = $_GET['id'];
$res = mysqli_query($dbconnect, "DELETE FROM `tbl_user` WHERE id=$id");
if($res){
	header('location: admin-dashboard.php');
}else{
	echo "Failed to delete";
}
?>
<?php
include_once('connectdb.php');
?>
<?php include('header.php'); ?>
<!doctype html>
   <html lang="en">
        <head>
          <meta charset="utf-8">
              <title>Corporate Restructuring:Mergers and Acquisitions:e2e</title>
              <meta name="viewport" content="width=device-width, initial-scale=1">
              <meta name="description" content="Organizational change is inevitable and often required.e2e People practices helps companies improve their odds of successful M&A through tested methods with years of experience">
              <meta name="keywords" content="Mergers and acquisitions,corporate restructure,HR analytics,mergers and acquisition integration,M&A consulting,MnA Genome, Acquisitions,Artifical Intelligences, Culture Analytics, People Analytics,M&A">
              <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
              <link rel="author" href="https://plus.google.com/yourpersonalprofile">
              <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
              <link href="css/css.css" rel="stylesheet" type="text/css">
              <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
              <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
              <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
              <link rel="stylesheet" href="css/style.css" type="text/css">

              <link rel="stylesheet" href="css/m/font-awesome.min.css">
              <link rel="stylesheet" href="css/m/animate.min.css">
              <link rel="stylesheet" href="css/m/default.min.css">
              <link rel="stylesheet" href="css/m/demo.css">
              <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
              <link rel="shortcut icon" href="images/fav_e2e2.ico" />
              <script src="js/m/modernizr.js"></script>
              <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
              <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
              <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
       </head>
    <body>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>

<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">
<h2 class="ar career-title text-center">MERGERS AND ACQUISITIONS</h2>
<hr class="line-75">
</div>




          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">
                     <div class="col-lg-12 cc1">
           <div class="col-lg-6 cc2">
             <h4 class="ab abt-sub-titless1" style="color:greenyellow;padding-top: 10px;"> Why choose us?</h4>
	           <ul>
               <li>We will help you mitigate risks and take informed decisions</li>
                 <ul style="list-style-type:decimal">
                   <li>with $ impact</li>
                    <li>Restructuring (hiring required talent, retaining key people, etc.)</li>
                </ul>
			   <br>
               <li>You get the support of our exclusive framework where experts will help you through the crucial first 300 day integration by leveraging HR Analytics and Predictive Culture Transformation Platform</li><br>
               <li>We are there to work with you across Geos, across projects, round the clock, helping you with key insights that can change your world…</li><br>
			   </ul>


<ul style="list-style-type:none">
<li>"The right organizational culture and team morale are essential for any company's success. Quite often these softer issues are overlooked especially in merger situations leading to failed outcomes"</li>
<li>Exclusive Quote by Mr. Amit Dixit, Senior Managing Director at Blackstone.</li>
			   </ul>
 
</div>
<div class="col-lg-6 cc2" style="padding-top:10px;">
	<iframe width="560" height="315" src="https://www.youtube.com/embed/8PEN2XnSWzE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>
</div>

					   </div>

<!-- <div class="wix-1">
<p class="ab">"In any investment, it's not the size of the cheque but the quality & fit of people that matters”</p>
<p>Exclusive Quote by Mr. Richard Saldanha, Chairperson of Gokuldas Exports, Trans Maldivian Airways. Serves on the boards of several companies, including Bennett, Coleman (Times Group)</p>
</div> -->

	
<br>

<a href="new mnadeck.pdf" target="_blank" class="btn login-btn">Portfolio</a>
	<a href="brochure.pdf" target="_blank" class="btn login-btn">Brochure</a>
								
					  
</div><!--col-12-->
          
				
<?php include('footer.php'); ?>
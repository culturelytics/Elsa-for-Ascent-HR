<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>

<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">MEDIA</h2>
<hr class="line-75">
</div>


<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 news-media" style="padding-top: 0px">


<div class="row mob-no-padng mob-no-margin remove-row">
<ul class="tablist" role="tablist">
  <li  class="tab just-tab" role="tab" ><a href="#panel1">Media room 2006 - 2011</a></li>
  <li  class="tab just-tab" role="tab" ><a href="#panel2">Media room 2010 - 2012</a></li>
  <li  class="tab just-tab" role="tab" ><a href="#panel3">Media room 2012 - CURRENT</a></li>
  <li class="tab-menu">
    <div class="line"></div>
    <div class="line"></div>
    <div class="line"></div>
  </li>
</ul>



<!--panel-1-->

<div class="tabpanel" id="panel1" role="tabpanel" style="background-color: transparent;">
<div class="row">
<ul class="news-ul">
   <li><a href="http://www.thehindubusinessline.com/todays-paper/article1752181.ece" target="_blank">Proactive interventions - a new concept to reduce staff exits - The Hindu Business Line</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/tp-new-manager/article1687441.ece" target="_blank">Develop talent from within - The Hindu Business Line</a></li>
   <li><a href="http://www.pharmabiz.com/article/detnews.asp?articleid=39105&sectionid=50" target="_blank">Manpower crunch looms in bio sector - Pharmabiz.com</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/article1662873.ece" target="_blank">A ‘360-degree’ look to stem biotech attrition - The Hindu Business Line</a></li>
   <li><a href="http://www.businessgyan.com" target="_blank">Passionate about People - Business Gyan</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/tp-marketing/article1667852.ece" target="_blank">PCMM catches up with non-IT industries - The Hindu Business Line</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/tp-new-manager/article1687599.ece" target="_blank">It’s all in the family - The Hindu Business Line</a></li>
   <li><a href="http://www.thehindu.com/archive/" target="_blank">Architecture industry needs to be structured - The Hindu Business Line</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/tp-new-manager/article1687613.ece" target="_blank">Reining in the beast of expectation - The Hindu Business Line</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/tp-new-manager/article1687625.ece" target="_blank">Employee expectations versus business realities - The Hindu Business Line</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/tp-new-manager/article1687637.ece" target="_blank">Finally it’s time to celebrate! - The Hindu Business Line</a></li>
   <li><a href="http://www.livemint.com/Money/g9sipNNjzAlLzAQa6FitjO/Growth-pangs-too-many-firms-not-enough-architects-around.html" target="_blank">Growth pangs: too many firms, not enough architects around - HT Mint</a></li>

   <p class="ab">2008 - 2009</p>


   <li><a href="http://knowledge.wharton.upenn.edu/article/caught-in-the-middle-why-developing-and-retaining-middle-managers-can-be-so-challenging/" target="_blank">Importance of Retaining Middle Managers - Knowledge@Wharton</a></li>
   <li><a href="http://www.businesstoday.in" target="_blank">A prescription for growth - A Business Today</a></li>
   <li><a href="https://economictimes.indiatimes.com/jobs/india-inc-betting-big-on-temporary-employees/articleshow/3697309.cms" target="_blank">India Inc betting big on temporary employees - The Economic Times</a></li>
   <li><a href="http://www.adtan.com/mobilereviews/now-foreigners-throng-indian-job-market/" target="_blank">Now foreigners throng Indian job market - The Economics Times</a></li>
   <li><a href="http://www.livemint.com/Politics/IbXLofaxxo1VaAPVSqnreI/There-are-jobs-for-the-taking-in-the-right-sectors-say-expe.html" target="_blank">There are jobs for the taking in the right sectors, say experts - Live Mint.com</a></li>
   <li><a href="http://www.thehindubusinessline.com/todays-paper/article1044645.ece" target="_blank">Cos deploying benched staff on internal projects - Hindu Business Line</a></li>
   <li><a href="http://www.channelbusiness.in/index.php?option=com_content&task=view&id=359&Itemid=88" target="_blank">The Benefit of HR Outsourcing - Express Channel Business</a></li>  

   <p class="ab">Appraisals 2009</p>

   <li><a href="https://atozhr.wordpress.com" target="_blank">A to Z HR Resources</a></li>
   <li><a href="http://www.livemint.com/Politics/XeMhb7zjFxxFGluRj40FSO/You-can-study-while-you-work-companies-tell-their-employees.html" target="_blank">You can study while you work, companies tell their employees - Livemint</a></li>   
   <li><a href="http://www.thehindubusinessline.com/todays-paper/tp-info-tech/article1054134.ece" target="_blank">Salary freeze a good news here - The Hindu</a></li>     
</ul>
</div>
</div>



<!--panel-2-->

<div class="tabpanel" id="panel2" role="tabpanel" style="background-color: transparent;">
<div class="row">
<ul class="news-ul">
   <li><a href="http://www.deccanherald.com/content/267387/gearing-soar.html" target="_blank">Gearing to soar - Deccan Herald </a></li>
   <li><a href="http://www.newindianexpress.com/cities/bengaluru/2012/jun/27/risk-is-overrated-in-india-381072.html" target="_blank">Risk is overrated in India - New Indian Express</a></li>
   <li><a href="https://www.wsj.com/articles/SB10001424052748704101604576246582543130272" target="_blank">JGI ventures to incubate young student entrepreneurs - WALL STREET JOURNAL</a></li>
   <li><a href="https://www.forbes.com/billionaires/?q=China#744a3d74251c" target="_blank">JGI Ventures Floats Start-Up Fund - FORBES</a></li>
</ul>
</div>
</div>



<!--panel-3-->

<div class="tabpanel" id="panel3" role="tabpanel" style="background-color: transparent;">
<div class="row">
<ul class="news-ul">
   <li><a href="http://www.business-standard.com/article/companies/it-giants-scramble-for-talent-as-demand-changes-job-offers-rise-114042501090_1.html" target="_blank">IT giants scramble for talent as demand changes, job offers rise</a></li>
   <li><a href="DNA-ARTICLE-ANNUAL-MAGAZINE.PDF" target="_blank">DNA ARTICLE- ANNUAL MAGAZINE</a></li>
   <li><a href="http://www.sliceofreallife.com/2014/03/08/interview-of-ms-yeshasvini-ramaswamy-managing-director-of-e2e-people-practices/" target="_blank">Interview of Ms. Yeshasvini Ramaswamy, Managing Director of e2e People Practices</a></li>
   <li><a href="images/second-to-none.jpg" target="_blank">Second to none or still second citizens - Deccan Chronicle</a></li>
   <li><a href="http://content.timesjobs.com/companies-need-to-bring-in-more-women-to-survive-in-the-future/articleshow/57912433.cms" target="_blank">Companies Need To Bring In More Women To Survive In The Future</a></li>
   <li><a href="images/Glittering-India.jpg" target="_blank">Glittering India</a></li>
   <li><a href="images/few-women-top.jpg" target="_blank">Why so few women reach on top in India - Deccan Chronicle</a></li>
   <li><a href="https://lifebeyondnumbers.com/e2e-people-practices-building-people-capability/" target="_blank">e2e People Practices – Building People Capability</a></li>
   <li><a href="images/ceo-cocktail.jpg" target="_blank">The CEO Cocktail - Bangalore Mirror</a></li>
   <li><a href="images/celb-diff.jpg" target="_blank">Celebrating differences - Deccan Chronicle</a></li>
   <li><a href="she-will-put-a smile-on-your-face.pdf" target="_blank">SHE will put a smile upon your face - Deccan Chronicle</a></li>
   <li><a href="images/best-in-world.jpg" target="_blank">Rubbing shoulders with best in world - Deccan Chronicle</a></li>
   <li><a href="images/way-to-go-ladies.jpg" target="_blank">Way to go, ladies - Deccan Herald</a></li>
   <li><a href="Gearing-to-soar.pdf" target="_blank">Deccan Herald-DH Living</a></li>
   <li><a href="images/women-consultants-job.jpg" target="_blank">Women consultants are happier with their jobs - Economic Times</a></li>
   <li><a href="images/People-at-the-Forefront.png" target="_blank">Entrepreneur India-People at the Forefront</a></li>
   <li><a href="images/HER-STORY.jpg" target="_blank">HER STORY</a></li>
   <li><a href="images/who-said-women-cant-lead.jpg" target="_blank">Hindu Business Line</a></li>
   <li><a href="images/hr-honcho.jpg" target="_blank">India Business Journal</a></li>
   <li><a href="images/Indiancolleges.jpg" target="_blank">Indian colleges</a></li>
   <li><a href="images/New-Indian-Express.jpg" target="_blank">New Indian Express</a></li>
   <li><a href="Pitstop4Performers.pdf" target="_blank">Pitstop4Performers</a></li>
   <li><a href="images/Prajavani-Metro.jpg" target="_blank">Prajavani Metro</a></li>
   <li><a href="images/Techgig.png" target="_blank">Techgig</a></li>
   <li><a href="The-Human-Factor.pdf" target="_blank">The Human Factor</a></li>
   <li><a href="images/Women-in-IT.png" target="_blank">Times of India Women in IT Telecom sector are more ambitious than men - The Times Of India</a></li>
   <li><a href="images/The-curious-case-of-creative-employees.png" target="_blank">TIMES The curious case of creative employees!-The Times Of India</a></li>
   <li><a href="images/TOI-Bangalore-Yeshasvini-Ramaswamy.pdf" target="_blank">TOI-Bangalore</a></li>
   <li><a href="WomenMangmt-MBA.pdf" target="_blank">Women in Management-MBA</a></li>
   <li><a href="http://www.newindianexpress.com/cities/bengaluru/2012/jun/27/risk-is-overrated-in-india-381072.html" target="_blank">The New Indian Express</a></li>
   <li><a href="http://www.supportbiz.com/articles/human-resources/nurture-leadership-skills-sustainable-growth.html" target="_blank">Support Biz</a></li>
   <li><a href="http://www.deccanherald.com/content/293939/way-go-ladies.html" target="_blank">Way to go, ladies - deccanherald.com</a></li>
   <li><a href="https://issuu.com/muralide/docs/pitstop4performers_-_november_25__2012_-_contents_" target="_blank">Pitstop4Performers - video</a></li>
   <li><a href="http://www.supportbiz.com/articles/human-resources/hiring-start-ups.html" target="_blank">Support Biz 2012</a></li>
   <li><a href="http://www.glad2bawoman.me" target="_blank">Glad2bawoman</a></li>
   <li><a href="http://content.timesjobs.com/?p=4243" target="_blank">Times Job</a></li>
   <li><a href="https://economictimes.indiatimes.com/jobs/train-campus-recruits-early-to-build-broader-talent-base/articleshow/19915133.cms" target="_blank">The Economic Times</a></li>
   <li><a href="https://www.forbes.com/forbes/welcome/?toURL=https://www.forbes.com/sites/morganhartley/2012/10/23/the-existential-mba/&utm_source=twitterfeed&utm_medium=twitter&refURL=&referrer=" target="_blank">Forbes (Story done by a foreign author)</a></li>
   <li><a href="http://www.india.com/education/" target="_blank">Zee News Website</a></li>
   <li><a href="http://www.thehindubusinessline.com/opinion/columns/who-said-women-cannot-lead/article5065199.ece" target="_blank">Opinion Article - 'Are women less career oriented, less equipped to be leaders?'</a></li>
   <li><a href="http://content.timesjobs.com/women-consultants-happier-with-jobs-than-their-male-counterparts/articleshow/57906051.cms" target="_blank">Times of India - Sep 26, 2013</a></li>
   <li><a href="http://content.timesjobs.com/the-curious-case-of-creative-employees/articleshow/57905124.cms" target="_blank">Times of India - Aug 21, 2013</a></li>
</ul>
</div>
</div>

</div>




</div><!--col-12-->
          

</div>



<script type="text/javascript">
      (function() {
function activateTab() {
    if(activeTab) {
      resetTab.call(activeTab);
    }
    this.parentNode.className = 'tab tab-active just-tab news-actv';
    activeTab = this;
    activePanel = document.getElementById(activeTab.getAttribute('href').substring(1));
      activePanel.className = 'tabpanel show col-lg-12 news-max-height mob-no-padng';
   activePanel.setAttribute('aria-expanded', true);
  }
  
  function resetTab() {
      activeTab.parentNode.className = 'tab just-tab';
    if(activePanel) {
      activePanel.className = 'tabpanel hide';
      activePanel.setAttribute('aria-expanded', false);
    }
  }
  
  var doc = document,
      tabs = doc.querySelectorAll('.tab a'),
      panels = doc.querySelectorAll('.tabpanel'),
      activeTab = tabs[0],
      activePanel;
 
   activateTab.call(activeTab);
  
  for(var i = tabs.length - 1; i >= 0; i--) {
    tabs[i].addEventListener('click', activateTab, false);
  }

})();


/*back arrow*/
$('.tab').on('click', function (e) {
   e.preventDefault();
   var whichtab = $(this).attr('href');
   $(this).parent().find('.active').removeClass('active');
   updateTab(whichtab, $(this).parent());
   return false;
});
$(document).ready(function() {
    if (document.location.hash.length > 0)
        updateTab(document.location.hash);
});
var updateTab = function (tab, parent) {
    if (!parent)
        parent = document;
    if (parent.find('.tab[href='+tab+']').length < 1)
        return;
    parent.find('.tab[href='+tab+']').addClass('active');
    parent.find('.tabContent-'+tab.replace('#', '')).addClass('active');
    window.history.replaceState({}, '', tab);
    return true;    
};
</script>


<?php include('footer.php'); ?>
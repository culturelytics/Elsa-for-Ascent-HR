<?php
session_start();

$query=mysqli_query($dbconnect,"update tbl_user_login_history SET ulh_end_time='".date('Y-m-d H:i:s')."' where ulh_id='".$_SESSION['ul_id']."'");

unset($_SESSION['sess_email']);
session_destroy();
header("Location: login.php");
?>
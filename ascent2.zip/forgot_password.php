<?php include('header.php'); ?>
<?php
function get_rooturl()
{
  $server_name = $_SERVER['SERVER_NAME'];

  if (!in_array($_SERVER['SERVER_PORT'], [80, 443])) {
    $port = ":$_SERVER[SERVER_PORT]";
  } else {
    $port = '';
  }

  if (!empty($_SERVER['HTTPS']) && (strtolower($_SERVER['HTTPS']) == 'on' || $_SERVER['HTTPS'] == '1')) {
    $scheme = 'https';
  } else {
    $scheme = 'http';
  }
  return $scheme . '://' . $server_name . $port . '/';
}


require 'lib\PHPMailer\src\PHPMailer.php';
require 'lib\PHPMailer\src\SMTP.php';
$mailer = new PHPMailer\PHPMailer();

$mailer->isSMTP();
$mailer->SMTPDebug = 0;
$mailer->SMTPAuth = true;
$mailer->SMTPOptions = array(
  'ssl' => array(
    'verify_peer' => false,
    'verify_peer_name' => false,
    'allow_self_signed' => true
  )
);
$mailer->Host = "smtp.gmail.com";
$mailer->SMTPSecure = "ssl";
$mailer->Port = 465;
$mailer->From = "info@e2epeoplepractices.com";
$mailer->Username = 'info@e2epeoplepractices.com';
$mailer->Password = 'E2EPEOPLE@123';

$mailer->IsHTML(true);

//$mailer->addAddress('aksdevtest@gmail.com', 'Avi');
//$mailer->Subject = 'PHPMailer GMail SMTP test';

if (isset($_SESSION["sess_email_kaccess"]) || isset($_SESSION["sess_email_caccess"])) {
  header("Location: index.php");
} else {
  if (isset($_POST['submit']) && $_POST['submit'] == 'forgot') {
    include_once('connectdb.php');
    $email = mysqli_real_escape_string($dbconnect, $_POST['email']);
    if ($email == '' || (!filter_var($email, FILTER_VALIDATE_EMAIL))) {
      $val_email = "Email is required";
    }
    if ($email != '') {
      $q = mysqli_query($dbconnect, "select * from tbl_user where email='" . $email . "' limit 1");
      $rowcount = mysqli_num_rows($q);
      if ($rowcount > 0) {
        $_SESSION['register'] = 1;

        $row = mysqli_fetch_array($q);

        $selector = bin2hex(random_bytes(8));
        $token = random_bytes(32);

        $urlToEmail = get_rooturl() . 'reset_password.php?' . http_build_query([
          'selector' => $selector,
          'validator' => bin2hex($token)
        ]);
        $token = hash('sha256', $token);

        //date_default_timezone_set('Asia/Kolkata'); // TODO - remove this in production

        //$expires = new DateTime('NOW', new \DateTimeZone("UTC"));
        $expires = new DateTime('NOW');
        $expires->add(new DateInterval('PT01H')); // 1 hour

        $qr1 = mysqli_query($dbconnect, "DELETE FROM tbl_account_recovery WHERE user_id=" . $row['id'] . ";");
        $qr2 = mysqli_query($dbconnect, "INSERT INTO tbl_account_recovery (user_id, selector, token, expires) VALUES (" . $row['id'] . ", '" . $selector . "', '" . $token . "', '" . $expires->format('Y-m-d H:i:s') . "');");

        $reseturl = get_rooturl() . "password-reset?email=" . $email . "&token=c39cb247-4624-4248-a411-5514251bc85e";

        $to = $email;
        $subject = 'Reset Password Notification';
        $message = "
<html>
<body>
<p><b>Dear " . $row['name'] . "</b></p>
<p>You are receiving this email because we received a password reset request for your account. If you didn't request this you can safely ignore this email.</p>
<p></p>
<a href=\"" . $urlToEmail . "\" style=\"margin-top:0;margin-bottom:0;color:white;text-decoration:none;display:inline-block;font-size:16px;font-weight:400;line-height:24px;text-transform:initial;letter-spacing:initial;background-color:#5c6ac4;border-radius:3px;padding:0;border-color:#5c6ac4;border-style:solid;border-width:10px 20px\" target=\"_blank\">Reset password</a>
</body>
</html>
";

        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= 'From: <info@e2epeoplepractices.com>' . "\r\n";
        
        try {
          //mail($to, $subject, $message, $headers);

          $mailer->addAddress($email, $row['name']);
          $mailer->Subject = $subject;
          $mailer->Body = $message;
          $mailer->send();
        } catch(Exception $e) {
          //echo 'Message: ' .$e->getMessage();
          $val_email = "Mail sending failed!";
        }
      } else {
        $val_email = "<p style=\"text-align: center;background: #a41313;padding: 5px;margin-top: 15px;\">Email is not registered with us</p>";
      }
    } else {
      $_SESSION['register'] = 2;
    }
  }
  ?>

  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin: 50px 0px;">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <h2 class="ar career-title text-center">Forgot Password</h2>
      <hr class="line-75">
    </div>


    <div class="registercon">
      <p class="bkt" style="text-align: center;">Please enter the registered e-mail id here, we will send your password to the e-mail id</p>
      <?php
        if (isset($_SESSION['register']) && $_SESSION['register'] == 1) {
          ?>
        <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4">
            <p class="bkt" style="text-align: center;background: #13a474;
    padding: 5px;
    margin-top: 15px;">Request Accepted, Kindly check your E-mail</p>
          </div>
          <div class="col-md-4"></div>
        </div>
      <?php
          unset($_SESSION['register']);
          $_POST = array();
        } else if (isset($_SESSION['register']) && $_SESSION['register'] == 2) {
          unset($_SESSION['register']);
          ?>
        <p class="bkt" style="text-align: center;">Enter all mandatory fields</p>
      <?php } else { ?>
        <div class="col-md-4"></div>
        <div class="col-md-4">
          <form method="post" name="customerData" enctype="multipart/form-data" action="" id="programregister-form" style="width: 100%;">

            <div class="logincontainer loginfields">
              <div class="">
                <input type="email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" name="email" class="required" placeholder="Email">
                <?php echo isset($val_email) ? $val_email : '' ?>
              </div>
              <button type="reg_submit" name="submit" value="forgot">Request Now</button>
            </div>
          </form>
        </div>
        <div class="col-md-4"></div>
      <?php } ?>
    </div>

  </div>
<?php } ?>
<?php include('footer.php'); ?>
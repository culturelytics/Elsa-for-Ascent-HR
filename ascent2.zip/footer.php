  
  <!-- footer-->

  <div class="content <?php if (isset($_SESSION["sess_email_caccess"]) || isset($_SESSION["sess_email_kaccess"])) { echo 'lfooter'; } ?>">
    <div class="col-lg-12 col-sm-12 col-xs-12 footer-pdng">
      <!-- <div class="smm">
        <a href="https://www.facebook.com/E2EPeoplePractices/" target="_blank" class="outline-none">
          <div class="footer-social fb-color">
            <img src="images/fbi.png" alt="image">
          </div>
        </a>
        <a href="https://twitter.com/e2ePeople" target="_blank" class="outline-none">
          <div class="footer-social twitter-color">
            <img src="images/twiter.png" alt="image">
          </div>
        </a>
        <a href="https://www.linkedin.com/company/7598695/admin/updates/" target="_blank" class="outline-none">
          <div class="footer-social in-color">
            <img src="images/in.png" alt="image">
          </div>
        </a>
		<a href="https://www.instagram.com/e2epeopleofficial/" target="_blank" class="outline-none">
          <div class="footer-social insta-color">
            <img src="images/istaicon.png" alt="image" width="25px" height="25px">
          </div>
        </a>
      </div> -->
      <p class="copyrt ar"><?php echo $coprights ?></p>
    </div>
  </div>



  <!--      </section> -->




  <div class="w3-sidebar w3-bar-block w3-border-right" style="display:none;right:0;" id="mySidebar">
    <button onclick="w3_close()" class="w3-bar-item w3-large" style="background-color: #0088C7;">Close &times;</button>

    <a href="index.php" class="w3-bar-item w3-button ar">Home</a>

    <div class="dropdown" style="padding: 10px 0px;">
      <a href="e2e-library.php" class="a-kc  copy-a ar">ELSA</a><i class="dropbtn fa fa-caret-down" aria-hidden="true" onclick="myFunction1()" style="margin-left: 10px"></i>

      <div id="myDropdown1" class="dropdown-content">
        <?php
        include_once('connectdb.php');
        $sql = "select * from tbl_knowledge_center where prg_status='Active' order by prg_name";
        $query = mysqli_query($dbconnect, $sql);
        $numrows = mysqli_num_rows($query);
        if ($numrows != 0) {
          while ($row = mysqli_fetch_array($query)) {
        ?>
            <a href="dynamic_kc.php?kc_id=<?php echo $row['prg_id'] ?>"><?php echo $row['prg_name'] ?></a>
        <?php }
        } ?>

      </div>
    </div>




    <a href="case-study.php" class="w3-bar-item w3-button ar">Case Study</a>
    <a href="openprogram.php" class="w3-bar-item w3-button ar">Open Program</a>
    <a href="our-team.php" class="w3-bar-item w3-button ar">Our team</a>
    <a href="about-us.php" class="w3-bar-item w3-button ar">About us</a>
    <a href="merges-and-acquisition.php" class="w3-bar-item w3-button ar">Mergers and Acquisitions</a>
    <a href="news-and-media.php" class="w3-bar-item w3-button ar">Media</a>
    <a href="MileStone.php" class="w3-bar-item w3-button ar">Milestone</a>
    <a href="csr.php" class="w3-bar-item w3-button ar">CSR</a>
    <a href="careers.php" class="w3-bar-item w3-button ar">Careers</a>
    <a href="gallery.php" class="w3-bar-item w3-button ar">Gallery</a>
    <a href="Blog.php" class="w3-bar-item w3-button ar">Blog</a>
    <a href="contact-us.php" class="w3-bar-item w3-button ar">Contact us</a>
  </div>
  </div>
  <script src="js/jquery-latest.min.js" type="text/javascript"></script> <!-- jQuery Library -->
  <script src="js/jquery.isotope.min.js" type="text/javascript"></script> <!-- Isotope Layout Plugin -->
  <script src="js/jquery.mCustomScrollbar.js" type="text/javascript"></script> <!-- malihu Scrollbar -->
  <script src="js/tileshow.js" type="text/javascript"></script> <!-- Metromega Custom Tileshow Plugin -->
  <script src="js/bootstrap.min.js" type="text/javascript"></script> <!-- Bootstrap Library -->
  <script src="js/script.js" type="text/javascript"></script> <!-- Metromega Script -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/owl-carousel/1.3.3/owl.carousel.min.js" type="text/javascript"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.17.0/dist/jquery.validate.js"></script>
  <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
  <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
  <!--milestone-2-->

  <script src="js/jquery.timelinr-0.9.6.js"></script>
  <script src="js/loading-bar.min.js"></script>




  <!--Start of Tawk.to Script-->
  <script type="text/javascript">
    var Tawk_API = Tawk_API || {},
      Tawk_LoadStart = new Date();
    (function() {
      var s1 = document.createElement("script"),
        s0 = document.getElementsByTagName("script")[0];
      s1.async = true;
      s1.src = 'https://embed.tawk.to/5b20f21f07752b51e614647f/default';
      s1.charset = 'UTF-8';
      s1.setAttribute('crossorigin', '*');
      s0.parentNode.insertBefore(s1, s0);
      
      // setTimeout(function() { 
      //   $('document').children('#cmk5Dp0-1577430443235').each(function() { 
      //     alert(this.attr('title'));
      //     if(this.attr('title') === 'chat widget') {
      //       this.css('marginRight', '15px !important');
      //     }
      //   });
      // },1000);
    })();
  </script>
  <!--End of Tawk.to Script-->

  <script>
    $(document).ready(function() {
      var owl = $("#slider-carousel");
      owl.owlCarousel({
        items: 1,
        itemsDesktop: [1000, 1],
        itemsDesktopSmall: [900, 1],
        itemsTablet: [600, 1],
        itemsMobile: false,
        pagination: false,
      });
      $(".next").click(function() {
        owl.trigger('owl.next');
      });
      $(".prev").click(function() {
        owl.trigger('owl.prev');
      });

    });
  </script>
  <script type="text/javascript">
    $(document).ready(function() {

      $("#register-form1").validate({
        rules: {

          email: {
            required: true,
            email: true
          },
          password: {
            required: true,
            minlength: 5
          },

        },
        messages: {

          password: {
            required: "Please enter your password",
            minlength: "Your password must contain 5 charaters and above",
          },
          email: {
            required: "Please enter email",
            minlength: "Your email is wrong"
          },
        },
      });
    });
  </script>
  <script type="text/javascript">
    $(document).ready(function() {

      $("#change-password").validate({
        rules: {

          password: {
            required: true,
            minlength: 5
          },
          password1: {
            required: true,
            minlength: 5,
            equalTo: "#password"
          },

        },
        messages: {

          password: {
            required: "Please enter your password",
            minlength: "Your password must contain 5 charaters and above",
          },
          password1: {
            required: "Please enter email",
            equalTo: "Your password do not match"
          },
        },
      });
    });
  </script>
  <script>
    $(document).ready(function() {
      var owl = $("#slider-carousel");
      owl.owlCarousel({
        items: 1,
        itemsDesktop: [1000, 1],
        itemsDesktopSmall: [900, 1],
        itemsTablet: [600, 1],
        itemsMobile: false,
        pagination: false,
      });
      $(".next").click(function() {
        owl.trigger('owl.next');
      })
      $(".prev").click(function() {
        owl.trigger('owl.prev');
      })
    });
  </script>
  <script>
    function w3_open() {
      document.getElementById("mySidebar").style.display = "block";
    }

    function w3_close() {
      document.getElementById("mySidebar").style.display = "none";
    }
  </script>


  <script>
    /* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
    function myFunction() {
      document.getElementById("myDropdown").classList.toggle("show");
    }
    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
      if (!event.target.matches('.dropbtn')) {

        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
          }
        }
      }
    }
  </script>

  <script>
    /* When the user clicks on the button, 
toggle between hiding and showing the dropdown content */
    function myFunction1() {
      document.getElementById("myDropdown1").classList.toggle("show");
    }
    // Close the dropdown if the user clicks outside of it
    window.onclick = function(event) {
      if (!event.target.matches('.dropbtn')) {

        var dropdowns = document.getElementsByClassName("dropdown-content");
        var i;
        for (i = 0; i < dropdowns.length; i++) {
          var openDropdown = dropdowns[i];
          if (openDropdown.classList.contains('show')) {
            openDropdown.classList.remove('show');
          }
        }
      }
    }
  </script>
  <script type="text/javascript">
    jQuery(function() {
      jQuery("#datepicker").datepicker({
        dateFormat: "dd-mm-yy"
      }).val()
    });
  </script>
  <script type="text/javascript">
    jQuery(function() {
      jQuery("#datepicker1").datepicker({
        dateFormat: "dd-mm-yy"
      }).val()
    });
  </script>
  <script type="text/javascript">
    jQuery('select[name=domain]').change(function() {
      var input_field = jQuery('input#amount');
      switch (jQuery(this).val()) {
        case 'HR-analytics':
          input_field.val('9322');
          break;
        case 'Executive-Presence':
          input_field.val('6962');
          break;
      }
    });
  </script>
  <script>
    jQuery(document).ready(function() {
      jQuery("#programregister-form").validate();
    });
  </script>



  <script type="text/javascript">
    // $('#scroller').imageScroll({

    // // top,right,bottom,left optional

    // orientation:"left",

    // // animation speed

    // speed:600,

    // // animation interval
    // interval:1500,
    // // pause on hover

    // hoverPause:true,
    // // callback function after every scroll motion
    // callback:function(){ return false;}

    // });
  </script>
  <script>
    function save_value_db(url, l_id, cori) {
      id = "<?php echo isset($_REQUEST['kc_id']) ? $_REQUEST['kc_id'] : '' ?>";
      if (id != '') {
        $.ajax({
          type: "POST",
          data: 'kl_id=' + l_id + '&cori=' + cori + '&kc_id=' + id,
          url: "ajax_save.php",
          success: function(data) {},
          error: function(err) {}
        });
      }

    }
  </script>
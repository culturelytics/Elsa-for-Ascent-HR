<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">EA COACHING</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	The Executive Assistant is critical to the success, health, wellbeing, and time management of the effective CEO. However, with so many time management and labor saving tools available for the CEO, it is tempting for the CEO not to have an executive assistant.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	EA COACHING
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Role of an Executive Assistant</p>
		<ul class="cs-ui">
			<li><a href="https://advertisers.careerone.com.au/hr/hr-best-practices/workforce-management/improving-employee-relations/executive-assistants-crucial-boss-success.aspx" target="_blank">Executive assistants crucial to bosses' success</a></li>
			<li><a href="https://coverlettersandresume.com/executive-assistant/executive-assistant-duties-and-responsibilities/" target="_blank">Executive Assistants Duties and Responsibilities</a></li>
			<li><a href="http://www.josephchris.com/executive-assistant-vs-administrative-assistant" target="_blank">Executive assistants vs administrative assistants</a></li>
			<li><a href="https://www.linkedin.com/pulse/difference-between-executive-assistant-personal-viviana-aldama" target="_blank">Executive assistants vs Personal assistants</a></li>
			<li><a href="https://www.thebalance.com/executive-assistant-skills-2062393" target="_blank">Executive Assistant Skills List and Examples</a></li>
			<li><a href="https://careerstint.com/executive-assistant-responsibilities" target="_blank">Executive Assistant- Responsibilities</a></li>
			<li><a href="https://www.inc.com/issie-lapowsky/the-most-important-person-in-the-office.html" target="_blank">The Most Important Person in Your Office Isn't Who You Think-case study</a></li>
			<li><a href="https://chiefexecutive.net/how-to-get-the-most-out-of-your-executive-assistant/" target="_blank">How to Get the Most out of Your Executive Assistant</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Interpersonal Skills</p>
		<ul class="cs-ui">
			<li><a href="https://blog.udemy.com/list-of-interpersonal-skills/" target="_blank">List Of Interpersonal Skills: 10 Must-Have Attributes</a></li>
			<li><a href="http://smallbusiness.chron.com/5-steps-along-workplace-15602.html" target="_blank">5 Steps to Get Along in the Workplace</a></li>
			<li><a href="https://briansmithpld.com/2014/04/18/going-along-to-get-along-the-art-of-working-with-people-you-dont-like/" target="_blank">Going Along to Get Along – The Art of Working With People You Don’t Like</a></li>
			<li><a href="http://darlingmagazine.org/5-ways-to-get-along-with-your-coworkers/" target="_blank">5 Ways To Get Along With Your Coworkers</a></li>
			<li><a href="http://www.workplaceissues.com/pmtenc/" target="_blank">Workplace  Issues​-Ten Commandments of How to Get Along with People</a></li>
			<li><a href="https://woman.thenest.com/important-along-workplace-5384.html" target="_blank">How Important Is It to Get Along in the Workplace?</a></li>
			<li><a href="https://www.thebalance.com/get-along-better-with-coworkers-525457" target="_blank">7 Ways to Get Along Better With Your Coworkers</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Stress & Time Management</p>
		<ul class="cs-ui">
			<li><a href="https://managementhelp.org/personalproductivity/time-stress-management.htm" target="_blank">Stress Management and Time Management- myths & causes</a></li>
			<li><a href="https://www.webmd.com/balance/stress-management/stress-management-managing-your-time" target="_blank">Stress Management: Managing Your Time</a></li>
			<li><a href="http://stress.lovetoknow.com/Stress_Related_to_Time_Management" target="_blank">Understanding Stress Related to Time Management</a></li>
			<li><a href="https://www.helpguide.org/articles/stress/stress-management.htm" target="_blank">Stress Management-Using Self-Help Techniques for Dealing with Stress</a></li>
			<li><a href="http://ezinearticles.com/?The-Connection-Between-Time-and-Stress-Management&id=2264572" target="_blank">The Connection Between Time and Stress Management</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Dining Etiquette</p>
		<ul class="cs-ui">
			<li><a href="https://www.thespruce.com/table-manners-and-dining-etiquette-1216971" target="_blank">Table Manners and Dining Etiquette-For Meals in a Social or Professional Setting</a></li>
			<li><a href="http://travel.tripcase.com/blog/business-dinner-etiquette/" target="_blank">Business Dinner Etiquette That Impresses</a></li>
			<li><a href="https://www.businessinsider.in/16-dining-etiquette-rules-every-professional-should-know/articleshow/58633225.cms" target="_blank">16 dining etiquette rules every professional should know</a></li>
			<li><a href="https://smallbiztrends.com/2017/06/business-dinner-etiquette.html" target="_blank">Chow Down on These 20 Dos and Don’ts for Business Dinner Etiquette</a></li>
			<li><a href="https://www.huffingtonpost.com/diane-gottsman/dining-etiquette-are-you-_b_4632472.html" target="_blank">Dining Etiquette: Are You Guilty of These Business Lunch Don’ts?</a></li>
			<li><a href="https://www.docurex.com/en/business-dinner-etiquette-the-dos-and-donts-of-dining-with-colleagues/" target="_blank">Business Dinner Etiquette: The Dos and Don’ts of Dining with Colleagues</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">VIDEOS</p>
		<ul class="cs-ui">
			<li><a href="https://learn.org/multimedia/What_Does_an_Executive_Assistant_Do_-_Video.html" target="_blank">What Does an Executive Assistant Do? - Video</a></li>
			<li><a href="https://www.youtube.com/watch?v=CRsAs8sYl6c" target="_blank">How Remote Executive Assistants help Busy Executives</a></li>
			<li><a href="https://www.youtube.com/watch?v=4kyvjEpXuPg" target="_blank">How To Have Better Communication Skills</a></li>
			<li><a href="https://www.youtube.com/watch?v=xcf_80IiHwQ" target="_blank">Healthy Relationships: 3 TRICKS To Getting Along At Work</a></li>
			<li><a href="https://www.youtube.com/watch?v=IGVQPU-L7cQ&feature=youtu.be" target="_blank">Time Management Techniques For Stress Free Productivity</a></li>
			<li><a href="https://www.youtube.com/watch?v=nkmEkSGyMvo&feature=youtu.be" target="_blank">Work Hard or Work Happy? Sadhguru on Stress and Time Management</a></li>
			<li><a href="https://www.youtube.com/watch?v=-gWNbmrL0f8" target="_blank">Business Dining Etiquette with Mister Manners</a></li>
			<li><a href="https://www.youtube.com/watch?v=V7SCb_AQSCA" target="_blank">The Art of the Business Lunch HD</a></li>
		</ul>
		</div>
			

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">



	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/the-new-effective-ass.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.vitoselling.com/blog/executive-assistant/" target="_blank">The New Executive Assistant: Advice for Succeeding in Your Career</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/admi-ass.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.safaribooksonline.com/library/view/administrative-assistants-and/9780814433522/" target="_blank">Administrative Assistant's and Secretary's Handbook, 5th Edition
by Jennifer Wauson, Kevin Wilson, James Stroman</a></p>
	</div>
	</div>


		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/get-along.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.speakernow.com/communication/five-ways-to-get-instant-rapport-with-anyone-anytime-anywhere-by-arnold-sanow/" target="_blank">Five Ways to Get Instant Rapport With Anyone, Anytime, Anywhere by Arnold Sanow</a></p>
	</div>
	</div>

		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/the-art-of-people.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.huffingtonpost.com/pam-nochlin/the-art-of-people-11-simp_b_11286964.html" target="_blank">The Art of People: 11 Simple People Skills That Will Get You Everything You Want 
by Dave Kerpen</a></p>
	</div>
	</div>

		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/ea-getting-things-done.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/Getting_Things_Done" target="_blank">Getting Things Done
Book by David Allen</a></p>
	</div>
	</div>

		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/fighting-tigers.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://prezi.com/n29tddrhruc_/fighting-invisible-tigers/#" target="_blank">Fighting Invisible Tigers- Trent Maurer</a></p>
	</div>
	</div>

		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/dining-equi.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.amazon.com/Dining-Etiquette-Essential-Manners-Business/dp/1500221945" target="_blank">Dining Etiquette: Essential Guide for Table Manners, Business Meals, Sushi, Wine and Tea Etiquette by Rebecca Black</a></p>
	</div>
	</div>

		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/business-dining.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.amazon.com/Business-Dining-Etiquette-Social-Skills-ebook/dp/B005BTMBSO" target="_blank">Business Dining Etiquette: Where Business and Social Skills Meet by Mercedes Alfaro</a></p>
	</div>
	</div>




	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
<?php include('header.php'); ?>
<?php
if (isset($_SESSION["sess_email_kaccess"]) || isset($_SESSION["sess_email_caccess"])) {
  header("Location: index.php");
}

function get_rooturl()
{
  $server_name = $_SERVER['SERVER_NAME'];

  if (!in_array($_SERVER['SERVER_PORT'], [80, 443])) {
    $port = ":$_SERVER[SERVER_PORT]";
  } else {
    $port = '';
  }

  if (!empty($_SERVER['HTTPS']) && (strtolower($_SERVER['HTTPS']) == 'on' || $_SERVER['HTTPS'] == '1')) {
    $scheme = 'https';
  } else {
    $scheme = 'http';
  }
  return $scheme . '://' . $server_name . $port . '/';
}

include_once('connectdb.php');

function validateToken($selector, $validator, $email = null)
{
  global $dbconnect;
  $q2 = "SELECT * FROM `tbl_account_recovery` WHERE `tbl_account_recovery`.`selector` = '" . $selector . "' AND `tbl_account_recovery`.`expires` >= NOW();";

  if ($email != null) {
    $q2 = "SELECT * FROM `tbl_account_recovery` INNER JOIN `tbl_user` ON `tbl_user`.`id` = `tbl_account_recovery`.`user_id` WHERE `tbl_user`.`email` = '". $email."' AND `tbl_account_recovery`.`selector` = '" . $selector . "' AND `tbl_account_recovery`.`expires` >= NOW();";
  }
  if ($result = mysqli_query($dbconnect, $q2)) {
    while ($row = mysqli_fetch_object($result)) {
      $calc = hash('sha256', hex2bin($validator));
      if (hash_equals($calc, $row->token)) {
        // The reset token is valid. Authenticate the user.
        return true;
      }
      return false;
    }
  }
}

$isValidToken = validateToken($_GET['selector'], $_GET['validator']);
if (strtoupper($_SERVER['REQUEST_METHOD']) !== 'POST') {
  $_SESSION['reset'] = null;
}
?>
<div class="row">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
      <h2 class="ar career-title text-center">Reset Password</h2>
      <hr class="line-75">
    </div>
</div>
<?php if (!$isValidToken) : ?>
  <div class="row">
    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin: 50px 0px;">
      <div class="alert alert-warning1">Invalid token received. Please try again with a valid token.</div>
    </div>
  </div>

<?php else : ?>
  <?php
    if (isset($_POST['submit']) && $_POST['submit'] == 'reset') {
      $email = mysqli_real_escape_string($dbconnect, $_POST['email']);
      $password = mysqli_real_escape_string($dbconnect, $_POST['password']);
      $confirm_password = mysqli_real_escape_string($dbconnect, $_POST['confirm_password']);
      $val_password = "";
      $val_confirm_password = "";
      $val_confirm_password1 = "";

      if ($email == '' || (!filter_var($email, FILTER_VALIDATE_EMAIL))) {
        $val_email = "Email is required";
      }
      if ($password == '') {
        $val_password = "Password is required";
      }
      if (!(strlen($password) >= 4 && strlen($password) <= 10)) {
        $val_password = "Password len is min 4 max 10";
      }
      if ($confirm_password == '') {
        $val_confirm_password = "Confirm Password is required";
      }
      if ($confirm_password != $password) {
        $val_confirm_password1 = "Password Mismatch";
      }
      $isValidToken = validateToken($_GET['selector'], $_GET['validator'], $email);

      if ($isValidToken && $val_email == "" && $val_password == "" && $val_confirm_password1 == ""  && $val_confirm_password == "") {
        $q = mysqli_query($dbconnect, "select * from tbl_user where email='" . $email . "' limit 1");
        $rowcount = mysqli_num_rows($q);
        if ($rowcount > 0) {
          $_SESSION['reset'] = 1;

          $row = mysqli_fetch_array($q);

          $q2 = mysqli_query($dbconnect, "DELETE FROM tbl_account_recovery WHERE selector = '" . $_GET['selector'] . "';");
          $q2 = mysqli_query($dbconnect, "UPDATE `tbl_user` SET `password` = '". $password ."' WHERE `email` = '" . $email . "';");
          // TODO - encrypt password

          $to = $email;
          $subject = 'Reset Password Notification';
          $message = "
<html>
<body>
<p><b>Dear " . $row['name'] . "</b></p>
<p>Your password has been updated successfully..</p>
</body>
</html>
";

          $headers = "MIME-Version: 1.0" . "\r\n";
          $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
          $headers .= 'From: <info@e2epeoplepractices.com>' . "\r\n";

          mail($to, $subject, $message, $headers);
          
          //unset($_SESSION['reset']);
          $_POST = array();
          ?>
          <div class="row">
          <div class="col-md-4"></div>
          <div class="col-md-4">
            <p class="bkt" style="text-align: center;background: #13a474;
    padding: 5px;
    margin-top: 15px;">Password changed successfully. Kindly check your E-mail</p>
          </div>
          <div class="col-md-4"></div>
        </div>
        <div class="row">
          <br>
          <div class="col-md-12 text-center">
            <a href="login.php" class="login-btn">Log In</a>
          </div>
        </div>
      <?php
        } else {
          $val_email = "<p style=\"text-align: center;background: #a41313;padding: 5px;margin-top: 15px;\">Email is not registered with us</p>";
        }
      } else {
        $_SESSION['reset'] = 2;
      }
    }
    ?>

  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12" style="margin: 50px 0px;">
    <div class="registercon">
      <?php
      if (isset($_SESSION['reset']) && $_SESSION['reset'] == 2) {
          unset($_SESSION['reset']);
          ?>
        <p class="bkt" style="text-align: center;">Enter all mandatory fields</p>
      <?php } 
      if ((!isset($_SESSION['reset']) || $_SESSION['reset'] == NULL) || (isset($_SESSION['reset']) && $_SESSION['reset'] == 2)) { ?>
        <div class="col-md-4"></div>
        <div class="col-md-4">
          <form method="post" name="customerData" enctype="multipart/form-data" action="" id="programregister-form" style="width: 100%;">
            <?php if(!$isValidToken): ?>
              <p class="bkt" style="text-align: center;">Invalid token received. Please try again with a valid token.</p>
            <?php endif;?>
            <div class="logincontainer loginfields">
              <div class="">
                <input type="email" value="<?php echo isset($_POST['email']) ? $_POST['email'] : ''; ?>" name="email" class="required" placeholder="Email">
                <?php echo isset($val_email) ? $val_email : '' ?>
              </div>
              <div class="">
                <input type="password" name="password" class="required" placeholder="Password">
                <?php echo isset($val_password) ? $val_password : '' ?>
              </div>
              <div class="">
                <input type="password" name="confirm_password" class="required" placeholder="Confirm password">
                <?php echo isset($val_confirm_password) ? $val_confirm_password : '' ?>
                <?php echo isset($val_confirm_password1) ? $val_confirm_password1 : '' ?>
              </div>
            </div>

            <div class="">

              <button type="submit" name="submit" value="reset">Submit</button>
            </div>
          </form>
        </div>
        <div class="col-md-4"></div>
      <?php } ?>
    </div>

  </div>
<?php endif; ?>
<?php include('footer.php'); ?>
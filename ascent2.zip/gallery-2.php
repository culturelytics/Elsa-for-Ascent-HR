<?php include('header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Gallery</title>
	<style>
		.image-source-link {
	color: #98C3D1;
}

.mfp-with-zoom .mfp-container,
.mfp-with-zoom.mfp-bg {
	opacity: 0;
	-webkit-backface-visibility: hidden;
	/* ideally, transition speed should match zoom duration */
	-webkit-transition: all 0.3s ease-out; 
	-moz-transition: all 0.3s ease-out; 
	-o-transition: all 0.3s ease-out; 
	transition: all 0.3s ease-out;
}

.mfp-with-zoom.mfp-ready .mfp-container {
		opacity: 1;
}
.mfp-with-zoom.mfp-ready.mfp-bg {
		opacity: 0.8;
}

.mfp-with-zoom.mfp-removing .mfp-container, 
.mfp-with-zoom.mfp-removing.mfp-bg {
	opacity: 0;
}
	</style>
<script>
	$(document).ready(function() {
	$('.zoom-gallery').magnificPopup({
		delegate: 'a',
		type: 'image',
		closeOnContentClick: false,
		closeBtnInside: false,
		mainClass: 'mfp-with-zoom mfp-img-mobile',
		image: {
			verticalFit: true,
			titleSrc: function(item) {
				return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
			}
		},
		gallery: {
			enabled: true
		},
		zoom: {
			enabled: true,
			duration: 300, // don't foget to change the duration also in CSS
			opener: function(element) {
				return element.find('img');
			}
		}
		
	});
});
</script>
</head>
<body>
	<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<h2 class="ar career-title text-center">GALLERY</h2>
<hr class="line-75">

	<div class="col-lg-12 mob-no-padng">

<div class="gallery cf">
	<div class="zoom-gallery">
	
	<a href="images/gallery/g16.jpeg"  style="width:193px;height:125px;">
		<img src="images/gallery/g16.jpeg" width="220px" height="200px">
	</a>
	<a href="images/gallery/g17.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g17.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g18.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g18.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g19.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g19.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g20.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g20.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g21.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g21.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g22.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g22.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g23.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g23.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g24.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g24.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g25.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g25.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g26.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/g26.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g27.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g27.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g28.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g28.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g29.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g29.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/g30.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/g30.jpeg" width="220px" height="200px">
	</a>


<ul class="pagination" style="margin-bottom: 0px">
  <li><a href="gallery.php">1</a></li>
  <li class="active"><a href="gallery-2.php">2</a></li>
  <li><a href="gallery-3.php">3</a></li>
  <li><a href="gallery-4.php">4</a></li>
  <li><a href="gallery-5.php">5</a></li>
	<li><a href="gallery-6.php">6</a></li>
	<li><a href="gallery-7.php">7</a></li>
</ul>
</div>
	
		</div>
		</div>
		</div>	
	</div>
</body>
</html
<?php include('footer.php'); ?>

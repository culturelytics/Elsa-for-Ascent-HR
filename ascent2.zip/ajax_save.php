<?php
include_once('connectdb.php');
session_start();

if(isset($_POST) && $_POST['kl_id']!='' && $_POST['cori']!='' && $_POST['kc_id']!='' ){
	$hashistory = 0;
	$qrcrd = "SELECT COUNT(`tbl_event_history`.`eh_kc_list_id`) as `total` FROM `tbl_event_history` WHERE `tbl_event_history`.`eh_u_id` = ".$_SESSION['user_id']." AND `tbl_event_history`.`eh_kc_list_id` = ".$_POST['kl_id'].";";
	if ($rescrd = mysqli_query($dbconnect,$qrcrd)) {
		while ($rwrescrd = mysqli_fetch_object($rescrd)) {
			$hashistory = $rwrescrd->total;
		}
		//mysqli_free_result($rwrescrd);
	}

	$query=mysqli_query($dbconnect,"INSERT INTO `tbl_event_history`(`eh_u_id`, `eh_kc_content_id`, `eh_kc_list_id`, `eh_ul_id`,`eh_cori`) VALUES ('".$_SESSION['user_id']."','".$_POST['kc_id']."','".$_POST['kl_id']."','".$_SESSION['ul_id']."','".$_POST['cori']."')");

	if($hashistory == 0) {
		$currentcredits = 0;
		$qrcrd = "SELECT `tbl_kc_assignments`.`kca_credits` as `kca_credits` FROM `tbl_kc_assignments` WHERE `tbl_kc_assignments`.`kca_user_id` = ".$_SESSION['user_id']." AND `tbl_kc_assignments`.`kca_kc_id` = ".$_POST['kc_id']." AND `tbl_kc_assignments`.`kca_status` = 'Active';";
		if ($rescrd = mysqli_query($dbconnect,$qrcrd)) {
			while ($rwrescrd = mysqli_fetch_object($rescrd)) {
				$currentcredits = $rwrescrd->kca_credits;
			}
			//mysqli_free_result($rwrescrd);
		}

		$klcredits = 0;
		$qrcrd = "SELECT `tbl_kc_list`.`kl_credits` as `kl_credits` FROM `tbl_kc_list` WHERE `tbl_kc_list`.`kl_id` = ".$_POST['kl_id']." AND `tbl_kc_list`.`status` = 'Active';";
		if ($rescrd = mysqli_query($dbconnect,$qrcrd)) {
			while ($rwrescrd = mysqli_fetch_object($rescrd)) {
				$klcredits = $rwrescrd->kl_credits;
			}
			//mysqli_free_result($rwrescrd);
		}
		$credits = $currentcredits + $klcredits;

		$rescredits=mysqli_query($dbconnect,"UPDATE `tbl_kc_assignments` SET `tbl_kc_assignments`.`kca_credits` = ".$credits." WHERE `tbl_kc_assignments`.`kca_user_id` = ".$_SESSION['user_id']." AND `tbl_kc_assignments`.`kca_kc_id` = ".$_POST['kc_id']." AND `tbl_kc_assignments`.`kca_status` = 'Active';");
	}
	
	$query=mysqli_query($dbconnect,"update tbl_user_login_history SET ulh_end_time='".date('Y-m-d H:i:s')."' where ulh_id='".$_SESSION['ul_id']."'");

}

?>
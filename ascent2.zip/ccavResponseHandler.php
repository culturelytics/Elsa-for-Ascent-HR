<?php include('Crypto.php');
include_once('connectdb.php');
?>
<?php
		
	$workingKey='F540B852FFF3B6A400294C5EA6169B8C';		//Working Key should be provided here.
	$encResponse=$_POST["encResp"];			//This is the response sent by the CCAvenue Server

	$rcvdString=decrypt($encResponse,$workingKey);	
	
		//Crypto Decryption used as per the specified working key.
	$order_status="";
 	$decryptValues=explode('&', $rcvdString);
  	$dataSize=sizeof($decryptValues);
	
	parse_str($rcvdString,$output);
	echo "<center>";
		if($output['order_status']==="Success")
		{
		 //$result=mysqli_query($dbconnect, "UPDATE tbl_program SET paymentstatus = '".$output['order_status']."' WHERE orderid = '$order_id'");

			 $result=mysqli_query($dbconnect, "UPDATE tbl_program SET paymentstatus = '".$output['order_status']."' WHERE orderid ='".$output['order_id']."' ");

			echo "<br>Thank you for shopping with us. Your credit card has been charged and your transaction is successful. We will be shipping your order to you soon.";
		else if($order_status==="Aborted")
		{
			echo "<br>Thank you for shopping with us.We will keep you posted regarding the status of your order through e-mail";
		
		}
		else if($order_status==="Failure")
		{
			echo "<br>Thank you for shopping with us.However,the transaction has been declined.";
		}
		else
		{
			echo "<br>Security Error. Illegal access detected";
		
		}
	echo "</center>";
?>
<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
	header("Location: login.php");
}


else
{
?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">WHY HR ANALYTICS?</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>The basic premise of the “people analytics” approach is that accurate people management decisions are the most important and impactful decisions that a firm can make. You simply can’t produce superior business results unless your managers are making accurate people management decisions.</li>
      <li>Quantification of HR - across employee life cycle.</li>
      <li>Dimensions of HR Metrics - Efficiency, Effectiveness & Impact.</li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	HR ANALYTICS
	</div>
	<div class="cs-left">
		<div class="info-n">
		<p class="abt-sub-titles ab" >Information to insights</p>
		<ul class="cs-ui">
			<li><a href="https://www.thinkwithgoogle.com/marketing-resources/data-measurement/data-to-insights-blueprint-for-your-business/" target="_blank">Data to insights: blueprint for your business</a></li>
			<li><a href="https://www.hpe.com/us/en/insights.html" target="_blank">Big data maturity- the path of information to insight to income</a></li>
			<li><a href="https://www.youtube.com/watch?v=UcBgTKTYOyY" target="_blank">Digital Series: Analytics: From Information To Insights (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">People analytics and its importance</p>
		<ul class="cs-ui">
			<li><a href="https://www.mckinsey.com/business-functions/organization/our-insights/people-analytics-reveals-three-things-hr-may-be-getting-wrong" target="_blank">People Analytics -reveals three things HR may get wrong</a></li>
			<li><a href="https://www.ae.be/blog-en/people-analytics-hr-numbers-game/" target="_blank">People Analytics: Because HR is a numbers game, too!</a></li>
			<li><a href="https://www.youtube.com/watch?v=yEHU9netQOY&feature=youtu.be" target="_blank">Getting People Analytics Right-Pwc US (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Evolution of HR</p>
		<ul class="cs-ui">
			<li><a href="http://www.yourarticlelibrary.com/hrm/evolution-and-development-of-human-resource-management-hrm/35234/" target="_blank">Evolution and development of human resources management</a></li>
			<li><a href="http://www.businessmanagementideas.com/essays/evolution-of-human-resource-management-in-india/2471" target="_blank">Evolution of human resource management in India</a></li>
			<li><a href="http://smallbusiness.chron.com/four-main-stages-hr-evolved-over-years-63019.html" target="_blank">Four main stages of how HR has evolved over the years</a></li>
			<li><a href="https://www.youtube.com/watch?v=z6jaRUv7np0" target="_blank">HR Evolution througout the years (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Role of HR</p>
		<ul class="cs-ui">
			<li><a href="http://www.bbc.co.uk/bitesize/higher/business_management/human_resource_management/role_importance_human_resources/revision/1/" target="_blank">Role and importance of human resources</a></li>
			<li><a href="https://www.thebalance.com/the-new-roles-of-the-human-resources-professional-1918352" target="_blank">The new roles of a human resource professional</a></li>
			<li><a href="https://www.youtube.com/watch?v=ukmC6F0JvQw&feature=youtu.be" target="_blank">The role of HR has evolved. Meet the 21st century HR Leader</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">HR Leadership</p>
		<ul class="cs-ui">
			<li><a href="https://hbr.org/2015/08/what-separates-great-hr-leaders-from-the-rest" target="_blank">What separates great HR leaders from the rest?</a></li>
			<li><a href="https://www.halogensoftware.com/blog/creating-effective-leadership-requires-hr-to-fulfill-4-key-roles" target="_blank">Creating Effective Leadership requires HR to fulfill 4 key roles</a></li>
			<li><a href="http://www.isbm.ac.in" target="_blank">Changing role of HR in Today's Scenario</a></li>
			<li><a href="https://www.youtube.com/watch?v=uO3MyG-FlM8&feature=youtu.be" target="_blank">An Open Door to HR Leadership- the mindfid series (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Future of HR Analytics</p>
		<ul class="cs-ui">
			<li><a href="https://www.advorto.com/en-gb/resources/recruitment-articles/people-analytics-is-it-really-the-future-of-hr.aspx" target="_blank">People Analytics- is it the future of HR?</a></li>
			<li><a href="https://www.mindtickle.com/blog/future-hr/" target="_blank">What is the Future of HR?</a></li>
			<li><a href="http://blogs.workday.com/the-future-of-hr-analytics-qa-with-workdays-adeyemi-ajao/">The Future of HR Analytics: Q&A with Workday’s Adeyemi Ajao</a></li>
			<li><a href="https://www.youtube.com/watch?v=Ph-LXDCHr3M&feature=youtu.be" target="_blank">SAP-the future of HR (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Workforce Optimization</p>
		<ul class="cs-ui">
			<li><a href="https://info.corporateunited.com/knowledge-center/hr-articles/bid/75086/Workforce-Optimization-through-Integrated-Resource-Fulfilment" target="_blank">Workforce Optimization through Integrated Resource Fulfillment</a> </li>
			<li><a href="http://www.icmi.com/Resources/Technology/2016/09/Impact-of-Workforce-Optimization-on-Marketing-Campaigns" target="_blank">Impact of Workforce Organization on Marketing Campaigns</a></li>
			<li><a href="https://www.knoahsoft.com/workforce-optimization-software" target="_blank">Workforce Optimization Software</a></li>
			<li><a href="https://www.youtube.com/watch?v=5JcWcJJDQBg&feature=youtu.be" target="_blank">Optimizing Workforce Analytics with Workforce Segmentation webinar, May 6, 2015 (video) </a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Workforce Intelligence</p>
		<ul class="cs-ui">
			<li><a href="https://talentculture.com/5-questions-that-will-help-you-find-the-right-workforce-intelligence-solution/" target="_blank">Five questions that will help you to find to find the right workforce intelligence solution</a></li>
			<li><a href="https://insights.randstadsourceright.com/h/i/147857593-5-tips-for-using-talent-analytics-predictive-workforce-intelligence" target="_blank">Five tips for using talent analytics & predictive workforce intelligence</a></li>
			<li><a href="https://www.youtube.com/watch?v=NLuixnUmUu0&feature=youtu.be" target="_blank">Openspan Workforce Intelligence webinar 2015 (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Different types of analytics</p>
		<ul class="cs-ui">
			<li><a href="http://www.ingrammicroadvisor.com/data-center/four-types-of-big-data-analytics-and-examples-of-their-use" target="_blank">Four Types of Big Data Analytics and Examples of Their Use</a></li>
			<li><a href="https://www.youtube.com/watch?v=Bu6ZG9qDQAE&feature=youtu.be" target="_blank">What are the types of Analytics? (Video)</a></li>
		</ul>

		</div>
	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">

	<div class="col-lg-12">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/nike.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.tracycarbasho.com/id12.html" target="_blank">Nike the vision behind the victory : Tracy Cardasho</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/tribes.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://sidsavara.com/product-reviews/tribes-by-seth-godin-book-review" target="_blank">Tribes : Seth Godin</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/jack.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.bookrags.com/studyguide-straight-from-the-gut/#gsc.tab=0" target="_blank">Straight from the gut : Jack Welch</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/pour-ur-heart.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.bookrags.com/studyguide-pour-your-heart-into-it/#gsc.tab=0" target="_blank">Pour your heart into it : Howard Schultz</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/hp.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.slideshare.net/shivoo.koteshwar/book-summary-the-hp-way-26385643" target="_blank">The HP Way : David Packard</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/the-UN.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://stephenbray.com/unpublished-david-ogilvy/" target="_blank">The Unpublished : David Oglivy</a></p>
	</div>
	</div>


	<div class="info-n">
		<p class="abt-sub-titles ab">Other Articles</p>
		<ul class="cs-ui">
			<li><a href="https://hbr.org/2010/10/competing-on-talent-analytics">Competing on Talent Analytics</a></li>
			<li><a href="http://docs.wixstatic.com/ugd/fd579f_642577f111d445e297ba6222058a7d65.pdf">Radical HRM innovation and competitive advantage: the Moneyball Story</a></li>
			<li><a href="http://docs.wixstatic.com/ugd/fd579f_d58634c8eda549529a216f4217b6ad3f.pdf">Connecting People Investments and Business Outcomes at Lowe’s: Using Value Linkage Analytics to Link Employee Engagement to Business Performance</a></li>
			<li><a href="http://docs.wixstatic.com/ugd/fd579f_c17f465fd96a473c8bd182038d7070d9.pdf">Coca - Cola Enterprises (CCE) Case Study: The Thirst for HR Analytics Grows</a></li>
		</ul>
	</div>	

	</div>
	</div>
   </div>
	</div>	




</div>	

</div>

<?php
}
?>
<?php include('footer.php'); ?>
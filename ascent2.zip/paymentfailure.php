<?php 
echo "<center>";
			echo "<br>Your transaction is failed. Please try again";

echo "</center>";
			?>
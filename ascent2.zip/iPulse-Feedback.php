<?php
session_start();
if (isset($_POST['detailsid'])){
	if (empty($_POST['detailsid'])){
		$_SESSION['error_page2'] = "Mandatory field(s) are missing, Please fill it again"; // Setting error message.
 //header("location: iPulse-Details.php"); // Redirecting to second page. 
 }
	else {
 // Fetching all values posted from second page and storing it in variable.
 foreach ($_POST as $key => $value) {
 $_SESSION['post'][$key] = $value;
 }
 }
}
$checkbox1 = $_POST['detailsid'];
    $chk="";  
    foreach($checkbox1 as $chk1)  
       {  
          $chk.= $chk1.",";  
       } 
?>
<!DOCTYPE html>
<html>
	<meta name="viewport" content="width-device-width, initial-scale=1.0">
	<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/base/jquery-ui.css" rel="stylesheet"/>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js"></script>
<head>
<title>Ipulse Personal Values Assessment</title>
	</head>
		<style>
		h4{
			text-align:center;
			font-size: 28px;
			padding: 30px;
		}
	.header{
		height: 150px;
		background-color:gray;
	margin-top:-30px;}
	img{
		margin-top:-250px;
	margin-left: 1000px;}
	.feedback-form{
		margin-top:50px;
		margin-left: 350px;
			width:60%;}
			.select{
				width:60%;
			padding: 10px;
			margin-bottom:30px;}
			.comments{
				width:60%;
			height: 200px;}
			.submit{
				margin-left: 400px;
				margin-top: 30px;
			}
.happy{
	margin-top:30px;
	margin-left: 10px;}
	</style>
	<body>
	<div class="header">
	<h4>iPulse Personal Values Assessment</h4>
	 <img src="images/iPulse logo.jpg" height="100px" width="130px">
	</div>
		<div class="feedback-form">
		<form action="iPulse-Database.php" method="post">
			<label>How are you feeling today?</label><br>
			<input type="checkbox" name="emoji" class="emoji" value="1"><img class="happy" src="images/smiley1.png" height="80px" width="80px">
			<input type="checkbox" name="emoji" class="emoji" value="2"><img class="happy" src="images/smiley2.png" height="80px" width="80px">
			<input type="checkbox" name="emoji" class="emoji" value="3"><img class="happy" src="images/smiley3.png" height="80px" width="80px">
			<input type="checkbox" name="emoji" class="emoji" value="4"><img class="happy" src="images/smiley4.png" height="80px" width="80px">
			<input type="checkbox" name="emoji" class="emoji" value="5"><img class="happy" src="images/smiley5.png" height="80px" width="80px"><br>
		<input type="submit" value="Submit" class="submit">
		</form>
		</div>
		
		</body>
	<script type="text/javascript">
    $('.emoji').on('change', function() {
        $('.emoji').not(this).prop('checked', false);  
    });
	</script>
	<script>
		$(document).ready(function(){
    $("form").submit(function(){
		if ($('input:checkbox').filter(':checked').length !=1 ){
        alert("Please select any one");
		return false;
		}
    });
});
	</script>
</html>
<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<!doctype html>
    <html lang="en">
         <head>
		     <title>e2e Learning Station</title>
			 <style>
				 .search{ border-radius: 25px;
                          border: 2px solid #ADFF2F;
                          margin-left: 30px;
                          width: 120px;
                          height: 60px;  
				 }
				 </style>
			 <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="e2e People Practices believes that your business grows through the people that it comprises of. We offer to help build on this resource that will help your business flourish">

        
			  <meta name="keywords" content="HR-Analytics, Executive Presence,  Entrepreneurship, Team Dynamics, Time Management, Communication, Stress Management, Emotional Intelligence, Stakeholder Management,Customer Delight, Behavioral Interviewing Skills, Effective Communication,ELSA, L&OD, Online Learning, Corporate Learning, Culture Assesment, Learning For All, Learning Station, Culture Audit firm, Knowledge Center,Personality Development">
			 
			 
               <script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
		       <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
               <link rel="stylesheet" href="/resources/demos/style.css">
               <script src="https://code.jquery.com/jquery-1.12.4.js"></script>
               <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
		        <script>
                  window.dataLayer = window.dataLayer || [];
                  function gtag(){dataLayer.push(arguments);}
                  gtag('js', new Date());
                  gtag('config', 'UA-112031379-1');
                </script>
				<script>
             $(document).ready(function() {
		var data = [
			{label: 'HR-Analytics', value:'HR-Analytics.php'},
			{label: 'Business StoryTelling', value:'Business-Storytelling.php'},
			{label: 'Team Dynamics', value:'Team-Dynamics.php'},
			{label: 'Stakeholder Management', value:'Stakeholder-Management.php'},
			{label: 'Behavioral Interviewing Skills', value:'Behavioral-Interviewing-Skills.php'},
			{label: 'Effective Communication', value:'/dynamic_kc.php?kc_id=23'},
			{label: 'Executive Presence', value:'Executive-Presence.php'},
			{label: 'Team Bonding', value:'Team-Bonding.php'},
			{label: 'Time Management', value:'Time-Management.php'},
			{label: 'EA Coaching', value:'EA-Coaching.php'},
			{label: 'Sales Communication', value:'SALES-Communication.php'},
			{label: 'First Time Managers', value:'First-Time-Managers.php'},
			{label: 'Developing Values', value:'Developing-Values.php'},
			{label: 'Stress Management', value:'Stress-Management.php'},
			{label: 'Customer Delight', value:'Customer-Delight.php'},
			{label: 'POSH', value:'posh.php'},
			{label: 'Game Changers', value:'select_programs.php'},
			{label: 'Entrepreneurship', value:'Entrepreneurship.php'},
			{label: 'Emotional Intelligence', value:'Emotional-Intelligence.php'},
			{label: 'New Age Banking', value:'New-Age-Banking.php'},
			{label: 'Personality Development', value:'/dynamic_kc.php?kc_id=21'}
		];
		
    	$("input#autocomplete").autocomplete({
			source: data,
			focus: function (event, ui) {
				$(event.target).val(ui.item.label);
				return false;
			},
			select: function (event, ui) {
				$(event.target).val(ui.item.label);
				window.location = ui.item.value;
				return false;
			}
		});
  	});
			 </script>	 
	     </head>
<body>
<!--?php
	
	$querysa = "SELECT  * FROM `tbl_event_history` ";
	$querysa .= " LEFT JOIN `tbl_kc_list` ON `tbl_event_history`.`eh_kc_list_id` = `tbl_kc_list`.`kl_id` ";
	$querysa .= " LEFT JOIN `tbl_kc_content` ON `tbl_kc_list`.`kl_kc_id` = `tbl_kc_content`.`kc_id` ";
	$querysa .= " LEFT JOIN `tbl_knowledge_center` ON `tbl_kc_content`.`kc_prg_id` = `tbl_knowledge_center`.`prg_id` ";
	$querysa .= " LEFT JOIN `tbl_user` ON `tbl_event_history`.`eh_u_id` = `tbl_user`.`id` ";
	$querysa .= " LEFT JOIN `tbl_user_login_history` ON `tbl_event_history`.`eh_ul_id` = `tbl_user_login_history`.`ulh_id` ";
	$querysa .= " INNER JOIN `tbl_organization` ON `tbl_organization`.`id` = `tbl_user`.`organization_id` ";

	$querywhere = " WHERE `eh_cori` = 'content' ";
	//$querywhere = $querywhere . " AND eh_u_id = " . $_SESSION['user_id'] . " ";
	//$querysa1 = $querysa . $querywhere . " ORDER BY `tbl_event_history`.`eh_created_at` DESC LIMIT 0,3;";
	$querysa1 = $querysa . $querywhere . " ORDER BY `tbl_event_history`.`eh_created_at` DESC;";
	
	$recentLearnings = [];
	if ($resultind = mysqli_query($dbconnect, $querysa1)) {
		while ($row = mysqli_fetch_object($resultind)) {
			$recentLearnings[] = $row;
		}
		mysqli_free_result($resultind);
	}
	?>
	?php if(isset($recentLearnings) && count($recentLearnings) > 0): ?>
	?php $old_id = 0; ?>
	<div class="row">
		<div class="col-md-6">
		<!--<input class="search" id="autocomplete" placeholder="    Ask ELSA.." style="background-color:GreenYellow;margin: 30px;width: 300px; float:right" />
		</div>
		<div class="col-md-6">
			<div class="pull-right">
				<p class="abt-sub-titles ab margin-top-7">Recent Learning Items</p>
				?php 
				$idx = 0;
				foreach($recentLearnings as $k => $row) {
					if ($old_id != $row->eh_ul_id) {
						echo '<p><a href="'.$row->kl_link.'" target="_blank">'.$row->kc_title.'</a></p>';
						if($idx++ >= 2){
							break;
						}
					}
					$old_id = $row->eh_ul_id;
				} ?>
			</div>
		</div>
	</div>
	?php endif;?>

	 <div class="col-lg-12">
       <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
          <!--<h2 class="ar career-title text-center"> ELSA </h2>
	         <hr class="line-75">
		   
	          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">
	             <div class="col-lg-12 green-vex1 mob-no-padng">
		             <div class="col-lg-12 lib-high-box1">-->
	
		              <p class="lib-high-title text-center ab">HIGHLIGHTS</p>
    	                <p class="text-center">This Industry developed and designed library combines the right mix of conceptual                              framework and practical wisdom.</p>

    	              <div class="col-lg-12 mob-no-padng"  style="margin-top: 20px">
    		            <div class="col-lg-4 text-center">
                          <img src="images/e2elib/1.jpg" alt="image">
    			      <p class="abt-sub-titles ab margin-top-7" style="color:greenyellow;" >We Encourage Experiential Learning</p>
    			      <p>Each module is based on the premise that learning from experiences with an attitude leads to constant improvement. This is done through a problem solving based approach and experimental learning methods.</p>
    			<p></p>
    		</div>

    		<div class="col-lg-4 text-center mar-top-30-sm">
                <img src="images/e2elib/2.jpg" alt="image">
    			<p class="abt-sub-titles ab margin-top-7" style="color:greenyellow;">Our Engagement</p>
    			<p>Each participant is provided a platform to connect with the group on an online basis. Access to monthly video conversations with experts.</p>
    		</div>

    		<div class="col-lg-4 text-center mar-top-30-sm">
                <img src="images/e2elib/3.jpg" alt="image">
    			<p class="abt-sub-titles ab margin-top-7" style="color:greenyellow;">Get Skilled</p>
    			<p>The Library is specially developed and designed for our programs/interventions.Each participant gets skilled while going through all the content.</p>
    		</div>
    	</div>
					

    	<div class="col-lg-12 mob-no-padng mar-top-20-lg">
    		<div class="col-lg-4 text-center mar-top-30-sm">
                <img src="images/e2elib/4.jpg" alt="image">
    			<p class="abt-sub-titles ab margin-top-7" style="color:greenyellow;">Peer to Peer Learning</p>
    			<p>One of the key constructs of each module is the diversity and pedegree of each participating fellow. We belive that when a group is formed the learning takes place in a multidimensional mode.</p>
    		</div>

    		<div class="col-lg-4 text-center mar-top-30-sm">
               <img src="images/e2elib/5.jpg" alt="image">
               <p class="abt-sub-titles ab margin-top-7" style="color:greenyellow;">Engaging Industry Experts</p>
               <p>The learning modules are handpicked from established sources in the industry who are experts in respective area of work.</p>      
            </div>

    		<div class="col-lg-4 text-center mar-top-30-sm">
            <img src="images/e2elib/1.jpg" alt="image">
            <p class="abt-sub-titles ab margin-top-7" style="color:greenyellow;">Developing Key Competencies</p>
            <p>Focus on each module is to ensure every participant is able to understand and realize their true potential and become a speacialist in their choosen competency.</p>      
            </div>
    	</div>
    </div> 

    <div class="col-lg-12 cc6">
        <div class="rgg">
            
     
			</div>
				</div>
           <!-- ?php
				//session_start();
				if( (isset($_SESSION["sess_email_caccess"])) || (isset($_SESSION["sess_email_kaccess"]))){
				  ?>
				  <!--<a href="clients.php" class="login-btn">View More</a>
				  ?php 
					}
					else
					{
					?>
					   <a href="login.php" class="login-btn">Log In</a>
					   ?php
					}
				?>-->
	
		


    <div class="col-lg-12  mob-no-padng">
    <p class="abt-sub-titles ab" style="color:greenyellow;">Publications</p>
    <ol class="merges-ol">
        <li>e2e team participates in writing white papers for National & International Universities and for International Collaborations. The papers are based on thorough research, e2e’s experience and expertise in the domain.</li>
        <li>A paper on People Capability Maturity Model got selected for publication in -
            <ul>
                <li>Carnegie Mellon University, USA, knowledge repository available online (This can be viewed by you if you are a member of CMU).</li>
                <li>National Institute of Construction Management, India. It has got published in NICMAR Journal, Volume XXIII, Jan – Mar 2008 Edition.</li>
            </ul>
        </li>
    </ol>
    </div>



<div class="col-lg-12 red-box-area">
    <p class="text-center abt-sub-titles ab" style="color:greenyellow;">"Without Knowledge action is useless and Knowledge without action is futile", -Abu Bakr</p>
    <p class="text-center abt-sub-titles ab" style="margin-top: 0px;margin-bottom: 25px;color: greenyellow">Click below to read in depth about the topics, Happy Learning!</p> 

<div class="col-lg-12">
<?php 
 include_once('connectdb.php');
$sql="select * from tbl_knowledge_center where prg_status='Active' order by prg_name";
$query = mysqli_query($dbconnect, $sql);
$numrows = mysqli_num_rows($query);
if($numrows !=0) {
    while($row = mysqli_fetch_array($query)){;
?>
    <div class="col-lg-3">
        <p class="line-height-30"><a href="dynamic_kc.php?kc_id=<?=$row['prg_id']?>" class="margin-10"><?=$row['prg_name']?></a></p>
    </div>
	
	
<?php }
} ?>
</div>
<div class="col-lg-12">
<!--     <div class="col-lg-3">
           <p class="line-height-30"><a href="HR-Analytics.php" class="margin-10">HR Analytics</a></p>

           <p class="line-height-30"><a href="Executive-Presence.php" class="margin-10">Executive Presence</a></p>

            <p class="line-height-30"><a href="First-Time-Managers.php" class="margin-10">First Time Managers</a></p>

            <p class="line-height-30"><a href="Manager-Of-Managers.php" class="margin-10">Manager Of  Managers</a></p>

            <p class="line-height-30"><a href="Business-Storytelling.php" class="margin-10">Business Storytelling</a></p>

            <p class="line-height-30"><a href="Team-Bonding.php" class="margin-10">Team Bonding</a></p>
    </div>
    <div class="col-lg-3">
            <p class="line-height-30"><a href="Developing-Values.php" class="margin-10">Developing Values</a></p>

            <p class="line-height-30"><a href="Entrepreneurship.php" class="margin-10">Entrepreneurship</a></p>

            <p class="line-height-30"><a href="Team-Dynamics.php" class="margin-10">Team Dynamics</a></p>

            <p class="line-height-30"><a href="Time-Management.php" class="margin-10">Time Management</a></p>

            <p class="line-height-30"><a href="Stress-Management.php" class="margin-10">Stress Management</a></p>

            <p class="line-height-30"><a href="Emotional-Intelligence.php" class="margin-10">Emotional Intelligence</a></p>
    </div>
    <div class="col-lg-3">
            <p class="line-height-30"><a href="Stakeholder-Management.php" class="margin-10">Stakeholder Management</a></p>

            <p class="line-height-30"><a href="EA-Coaching.php" class="margin-10">EA Coaching</a></p>

            <p class="line-height-30"><a href="Customer-Delight.php" class="margin-10">Customer Delight</a></p>

            <p class="line-height-30"><a href="New-Age-Banking.php" class="margin-10">New Age Banking</a></p>

            <p class="line-height-30"><a href="Behavioral-Interviewing-Skills.php" class="margin-10">Behavioral Interviewing Skills</a></p>
            
            <p class="line-height-30"><a href="SALES-Communication.php" class="margin-10">Sales Communication</a></p>
    </div>
	<div class="col-lg-3">
		<p class="line-height-30"><a href="posh.php" class="margin-10">POSH</a></p>
	</div> -->
</div>


<!-- <div class="col-lg-12  mob-no-padng posh">
    <p class="abt-sub-titles ab">POSH</p>
    <ol class="merges-ol">
        <li><a href="https://www.poshatwork.com/sexual-harassment-act-rules/" target="_blank">https://www.poshatwork.com/sexual-harassment-act-rules/</a></li>
        <li><a href="https://www.peoplematters.in/article/diversity/few-steps-to-remove-the-unconscious-gender-bias-at-workplace-17336" target="_blank">https://www.peoplematters.in/article/diversity/few-steps-to-remove-the-unconscious-gender-bias-at-workplace-17336</a></li>
        <li><a href="https://www.nolo.com/legal-encyclopedia/preventing-sexual-harassment-workplace-29851.html" target="_blank">https://www.nolo.com/legal-encyclopedia/preventing-sexual-harassment-workplace-29851.html</a></li>
        <li><a href="https://www.nytimes.com/2017/12/11/upshot/sexual-harassment-workplace-prevention-effective.html" target="_blank">https://www.nytimes.com/2017/12/11/upshot/sexual-harassment-workplace-prevention-effective.html</a></li>
        <li><a href="https://blog.ipleaders.in/sexual-harassment-at-workplace/" target="_blank">https://blog.ipleaders.in/sexual-harassment-at-workplace/ </a></li>
        <li><a href="https://www.youtube.com/watch?v=d0pbHOliQu0" target="_blank">https://www.youtube.com/watch?v=d0pbHOliQu0</a></li>
        <li><a href="https://www.youtube.com/watch?v=DWq_mDJq9IA" target="_blank">https://www.youtube.com/watch?v=DWq_mDJq9IA </a></li>
        <li><a href="https://www.youtube.com/watch?v=YmRKlZEXVQM&t=18s" target="_blank">https://www.youtube.com/watch?v=YmRKlZEXVQM&t=18s </a></li>
    </ol>
</div>
 -->


    </div>

				  </div>
		  </div>
			</div>
		</div>
	</body>
</html>


					 
<?php //include('footer.php'); ?>
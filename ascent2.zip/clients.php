<?php include('header.php'); ?>
<?php
if(!isset($_SESSION["sess_email_caccess"])){
  if(isset($_SESSION["sess_email_kaccess"])){
    header("Location: no_access.php");  
  }else{
    header("Location: successmessage.php");  
  }
	
}
else
{
$id=$_GET['id'];
$result2=mysqli_query($dbconnect, "SELECT  tbl_user_idp_programs.ui_id as aid,name,title,subtitle,description,ui_module_ids,ui_idp_id FROM tbl_user_idp_programs LEFT JOIN tbl_user ON tbl_user.id=tbl_user_idp_programs.ui_user_id LEFT JOIN tbl_idp ON tbl_idp.id=tbl_user_idp_programs.ui_idp_id   where ui_user_id='". $_SESSION['user_id']."' AND  idp_status='Active' AND  ui_id='".$id."'");

if(mysqli_num_rows($result2)>0){ 
 $res2 = mysqli_fetch_array($result2);
 $passing_ui_idp_id=$res2['ui_idp_id'];

 $mod_id=unserialize($res2['ui_module_ids']);
 $mod_in=implode(",", $mod_id);

 $active_modules=mysqli_query($dbconnect, "select * from tbl_programs where prg_id IN ($mod_in) AND prg_status='Active'");

 if(count($mod_id)>0 && mysqli_num_rows($active_modules)>0){

?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">
	<p style="text-align: right;margin-top: 15px;font-size: 15px;color: #0087cb;">Welcome <?php echo $res2['name']; ?></p>
    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
		<div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px" >
			<p class="cs-comn-heading-title ar career-title text-center"><?php echo $res2['title']; ?></p>
			<hr class="line-75">
			<p class="cs-comn-heading-title ar text-center" style="margin-bottom: 15px;"><?php echo $res2['subtitle']; ?> </p>
			<p class="idpdep"> <?php echo $res2['description']; ?> </p>
		</div>
    </div>
	<div class="col-lg-3 inside-box mob-no-padng" style="padding-top: 0px">
		<div id="moduleshortdes_box" class="col-lg-12" style="margin-top: 20px;padding: 0px;display:none">
			<div id="toggle_btn" class="login-btn" style="font-weight: inherit;align-content:right; cursor: pointer;width: fit-content;">RECAP</div>			
			<!--<div class="col-sm-12" style="padding:0px"><div style="border: solid 2px #a41319;display: inline-block;padding: 5px 20px;margin-bottom: 15px;">RECAP</div></div>-->
			<div id="toggle_Sec" style="display:none;border: solid 1px;float: left;padding: 10px;">
				<div id="useripdmod_content" style="padding-bottom: 10px;margin-bottom: 10px;border-bottom: solid 1px #3c3b3b;">
				
				</div>
				<div id="mod_links" class="col-sm-12" style="text-align:right">
					<a id="mod_docs_links" href="" target="_blank">Documents  | </a> 
					<a id="mod_readmore_links" href=""  target="_blank">Read More</a>
				</div>
			</div>
		</div>
		
	</div>
    <div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

</div>



<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mob-no-padng" style="margin-bottom:30px;margin-top: 20px">
<h2 class="ar text-center" style="margin-bottom:40px">MLP</h2>
<hr class="line-75"><br />
  <div id="query-container">
   
      <div class="form-sub-w3  left-form-w3-agile" style="padding: 20px">
            <div class="c1r1">
              <div class="c1l">
              <div class="cnaa">Name : </div>
                <input type="text" name="name" placeholder="Name" required="" id="name" class="name">
              </div>
              <div class="c1m">
              <?php  
              $active_modules=mysqli_query($dbconnect, "select * from tbl_programs where prg_id IN ($mod_in) AND prg_status='Active'");
              ?>
              <div class="cnaa">Module : </div>
                <select name="module" id="module" class="module">
                  <option value="" >Select Module</option>
                  <?php while($a_m = mysqli_fetch_array($active_modules)){ ?>
                      <option value="<?=$a_m['prg_id']?>"><?=$a_m['prg_name']?></option>
                  <?php } ?>
                </select>
              </div>
            </div>

          <div class="c1r2">
          <p class="c1g">Smart Goal Statement</p>
            <div class="c1sd">
              <div class="cnaa">Start date : </div>
               <input required="" type="text" id="datepicker" class="sdate required" name="sdate"  placeholder="Start Date">
            </div>
             <div class="c1cd">
              <div class="cnaa">Completion Date : </div>
               <input required="" type="text" id="datepicker1" class="cdate required" name="cdate" placeholder="Completion Date">
            </div>
          </div>


          <div class="depr">
            <div class="depc1">
              <div class="cnaa">Department : </div>
                <input type="text" name="department" placeholder="Department" required="" id="department" class="department">
            </div>
            <div class="depc2">
              <div class="cnaa">City : </div>
                <input type="text" name="sign" placeholder="City" required="" id="sign" class="sign">
            </div>
            
          </div>

          <div class="c1r3">
             <div class="c1ds">
              <div class="cnaa">What I will stop doing </div>
              <input required="" type="text"  name="dstop[]" class="dstop required" placeholder="Stop Doing" id="dstop1"> 
              <input type="text"  name="dstop[]" class="dstop required" id="dstop2"> 
              <input  type="text"  name="dstop[]" class="dstop required" id="dstop3"> 
              <input  type="text"  name="dstop[]" class="dstop required " id="dstop4"> 
              <!--  <textarea required="" class="dstop" placeholder="Stop doing" name="dstop"></textarea> -->
             </div>
            



            <div class="c1c">
              <div class="cnaa">Consequences of this action </div>
               <input required="" type="text"  name="consequence[]" class="consequence required"  placeholder="consequences" id="consequence1">
               <input  type="text"  name="consequence[]" class="consequence required " id="consequence2">
               <input  type="text"  name="consequence[]" class="consequence required" id="consequence3">
               <input  type="text"  name="consequence[]" class="consequence required" id="consequence4">
            </div>
          </div>





          <div class="c1r4">
             <div class="c1ds">
              <div class="cnaa">What I will start doing </div>
               <input required="" type="text"  name="dstart[]" class="dstart required" placeholder="Start Doing" id="dstart1"> 
               <input  type="text"  name="dstart[]" class="dstart required" id="dstart2"> 
               <input  type="text"  name="dstart[]" class="dstart required " id="dstart3"> 
               <input  type="text"  name="dstart[]" class="dstart required" id="dstart4"> 
               <!-- <textarea required="" class="dstart" placeholder="Start doing" name="dstart"></textarea> -->

            </div>

             <div class="c1b">
              <div class="cnaa">Benefits of this action </div>
               <input required="" type="text"  name="benefits[]" class="benefits required" placeholder="Benefits" id="benefits1">
               <input  type="text"  name="benefits[]" class="benefits required" id="benefits2">
               <input  type="text"  name="benefits[]" class="benefits required" id="benefits3">
               <input  type="text"  name="benefits[]" class="benefits required" id="benefits4">
            </div>
          </div>

          <div class="c1r5">
           
              <div class="c1ap">
               <p class="c1g">My Action Plan</p>
              <div class="cnaa">The actions I will take to make my goal a reality </div>
               <input required="" type="text"  name="aplan" class="aplan srequired" placeholder="Plan">
            </div>
			
			<div class="c1ap">
               <p class="c1g">My Psychometric Assessment Score</p>
              <div class="cnaa">Tangible inputs that I will implement in my work</div>
               <input required="" type="text"  name="mypas" class="mypas srequired" placeholder="Psychometric Assessment Score">
            </div>
			
            <div class="c1p">
            <p class="c1g">My Progress</h3>
            <div class="cnaa">Tick or color a box for each day successfully completed</div><br />
              <table id="hei"><tr>
              
              <td><span><label for="p1"><input type='checkbox' name='progress' value='1' class="progress" id="p1">1</label></span></td><td><span><label for="p2"><input type='checkbox' name='progress' value='2' class="progress" id="p2">2</label></span></td><td><span><label for="p3"><input type='checkbox' name='progress' value='3' class="progress" id="p3">3</label></span></td><td><span><label for="p4"><input type='checkbox' name='progress' value='4' class="progress" id="p4">4</label></span></td><td><span><label for="p5"><input type='checkbox' name='progress[]' value='5' class="progress" id="p5">5</label></span></td><td><span><label for="p6"><input type='checkbox' name='progress[]' value='6' class="progress" id="p6">6</label></span></td><td><span><label for="p7"><input type='checkbox' name='progress[]' value='7' class="progress" id="p7">7</label></span></td><td><span><label for="p8"><input type='checkbox' name='progress[]' value='8' class="progress" id="p8">8</label></span></td><td><span><label for="p9"><input type='checkbox' name='progress[]' value='9' class="progress" id="p9">9</label></span></td><td><span><label for="p10"><input type='checkbox' name='progress[]' value='10' class="progress" id="p10">10</label></span></td></tr>
             
             <tr>
              <td><span><label for="p11"><input type='checkbox' name='progress[]' value='11' class="progress" id="p11">11</label></span></td><td><span><label for="p12"><input type='checkbox' name='progress[]' value='12' class="progress" id="p12">12</label></span></td><td><span><label for="p13"><input type='checkbox' name='progress[]' value='13' class="progress" id="p13">13</label></span></td><td><span><label for="p14"><input type='checkbox' name='progress[]' value='14' class="progress" id="p14">14</label></span></td><td><span><label for="p15"><input type='checkbox' name='progress[]' value='15' class="progress" id="p15">15</label></span></td><td><span><label for="p16"><input type='checkbox' name='progress[]' value='16' class="progress" id="p16">16</label></span></td><td><span><label for="p17"><input type='checkbox' name='progress[]' value='17' class="progress" id="p17">17</label></span></td><td><span><label for="p18"><input type='checkbox' name='progress[]' value='18' class="progress" id="p18">18</label></span></td><td><span><label for="p19"><input type='checkbox' name='progress[]' value='19' class="progress" id="p19">19</label></span></td><td><span><label for="p20"><input type='checkbox' name='progress[]' value='20' class="progress" id="p20">20</label></span></td></tr>

              <tr>
              <td><span><label for="p21"><input type='checkbox' name='progress[]' value='21' class="progress" id="p21">21</label></span></td><td><span><label for="p22"><input type='checkbox' name='progress[]' value='22' class="progress" id="p22">22</label></span></td><td><span><label for="p23"><input type='checkbox' name='progress[]' value='23' class="progress" id="p23">23</span></td><td><span><label for="p24"><input type='checkbox' name='progress' value='24' class="progress" id="p24">24</label></span></td><td><span><label for="p25"><input type='checkbox' name='progress[]' value='25' class="progress" id="p25">25</label></span></td><td><span><label for="p26"><input type='checkbox' name='progress[]' value='26' class="progress" id="p26">26</label></span></td><td><span><label for="p27"><input type='checkbox' name='progress[]' value='27' class="progress" id="p27">27</label></span></td><td><span><label for="p28"><input type='checkbox' name='progress[]' value='28' class="progress" id="p28">28</label></span></td><td><span><label for="p29"><input type='checkbox' name='progress[]' value='29' class="progress" id="p29">29</label></span></td><td><span><label for="p30"><input type='checkbox' name='progress[]' value='30' class="progress" id="p30">30</label></span></td></tr></table>
          </div>
          <br />
            <div class="c1w">

            <p class="c1g">My rating of my weekly progress (enter a number on a scale of 1-5)</p>
            <div class="wa1">
             <div class="cnaa">Ratings for week1 : </div>
               <select name="week1" id="week1" class="week1">
                  <option value="" selected   >Select Ratings</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
            </div>

            <div class="wa2">
                 <div class="cnaa">Ratings for week2 : </div>
                <select name="week2" id="week2" class="week2">
                 <option selected  value="">Select Ratings</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
            </div>

            <div class="wa3">
                 <div class="cnaa">Ratings for week3 : </div>
                <select name="week3" id="week3" class="week3">
                 <option selected  value="">Select Ratings</option>
                  <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
            </div>

            <div class="wa4"></div>
                 <div class="cnaa">Ratings for week4 : </div>
                <select name="week4" id="week4" class="week4">
                 <option selected  value="">Select Ratings</option>
                 <option value="1">1</option>
                  <option value="2">2</option>
                  <option value="3">3</option>
                  <option value="4">4</option>
                  <option value="5">5</option>
                </select>
            </div>

            </div>
 

  
      <div class="qsub"><input type="button" value="submit" name="submit" id="submit"></div>
   
  </div>
      <!-- <div style="color: green;padding:20px 0px;"><?php echo 	$sm ?> </div>
      <div style="color: green;padding:20px 0px;"><?php echo 	$fm ?> </div> -->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
    <script src="http://code.jquery.com/jquery-1.9.1.js"></script>
    <script>
    $(document).ready(function(){
      $("#submit").click(function(e){
      var name = $(".name").val();
      var module = $(".module").val();
      var sdate = $(".sdate").val();
      var cdate = $(".cdate").val();
      var department = $(".department").val();
      var sign = $(".sign").val();
      // var dstop = $(".dstop").val();
      var dstop = new Array();
        $(".dstop").each(function() {
           dstop.push($(this).val());
             });
        console.log(dstop);
     
       var consequence = new Array();
        $(".consequence").each(function() {
           consequence.push($(this).val());
             });
      // var dstart = $(".dstart").val();
      var dstart = new Array();
        $(".dstart").each(function() {
           dstart.push($(this).val());
             });
       var benefits = new Array();
        $(".benefits").each(function() {
           benefits.push($(this).val());
             });
      var aplan = $(".aplan").val();
	  var mypas = $(".mypas").val();
      // var progress = $(".progress").val();
       var week1 = $(".week1").val();
       var week2 = $(".week2").val();
        var week3 = $(".week3").val();
         var week4 = $(".week4").val();
      var progress = new Array();
        $("input:checked").each(function() {
           progress.push($(this).val());
             });

     
      // Returns successful data submission message when the entered information is stored in database.
      var dataString = 'name='+ name + '&module='+ module + '&sdate='+ sdate + '&cdate='+ cdate + '&department='+ department + '&sign='+ sign + '&dstop='+ dstop + '&consequence='+ consequence + '&dstart='+ dstart + '&benefits='+ benefits + '&aplan='+ aplan + '&mypas='+ mypas + '&progress='+ progress + '&week1='+ week1 + '&week2='+ week2 + '&week3='+ week3 + '&week4='+ week4+'&idp_id_from_uip=<?=$passing_ui_idp_id?>'; 
      
      if(name==''||module==''||sdate==''||cdate==''||dstop==''||consequence==''||dstart==''||benefits==''||aplan==''||mypas==''||progress=='')
      {
      alert("Please Fill All Fields");
      }
      else
      {
      // AJAX Code To Submit Form.
      $.ajax({
      type: "POST",
      url: "submit.php?method=save",
      data: dataString,
      cache: false, 
      success: function(result){
       alert(result);
       location.href="";
      }
      });
      }
      return false;
      });
      });
    </script>

<script>
$('#module').on('change',function(e){
  mod=this.value;
  if(mod!=''){
      $.ajax({
      type: "POST",
      url: "submit.php?method=view_last_data",
      data:"module="+mod+'&idp_id_from_uip=<?=$passing_ui_idp_id?>',
      success: function(result){
       for(i=1;i<=31;i++){
        $('#p'+i).parent().removeClass('highlight');
       }
       data=result.split('|*|');
       $('#name').val(data[0]);
       $('input[name="sdate"]').val(data[1]);
       $('input[name="cdate"]').val(data[2]);
       $('#department').val(data[3]);
       $('#sign').val(data[4]);
       dstop=data[5].split(',');
       $('#dstop1').val(dstop[0]);
       $('#dstop2').val(dstop[1]);
       $('#dstop3').val(dstop[2]);
       $('#dstop4').val(dstop[3]);
       consequence=data[6].split(',');
       $('#consequence1').val(consequence[0]);
       $('#consequence2').val(consequence[1]);
       $('#consequence3').val(consequence[2]);
       $('#consequence4').val(consequence[3]);
       dstart=data[7].split(',');
       $('#dstart1').val(dstart[0]);
       $('#dstart2').val(dstart[1]);
       $('#dstart3').val(dstart[2]);
       $('#dstart4').val(dstart[3]);
       benefits=data[8].split(',');
       $('#benefits1').val(benefits[0]);
       $('#benefits2').val(benefits[1]);
       $('#benefits3').val(benefits[2]);
       $('#benefits4').val(benefits[3]);
       $('input[name="aplan"]').val(data[9]);
	   $('input[name="mypas"]').val(data[10]);
       //$('input[name="progress"]').val(data[10]);
        progress=data[11].split(',');
        for(i=0;i<progress.length;i++){
            sel=progress[i];
            $('#p'+sel).attr('checked',true);
            $('#p'+sel).parent().addClass('highlight');
        }
       $('#week1').val(data[12]);
       $('#week2').val(data[13]);
       $('#week3').val(data[14]);
       $('#week4').val(data[15]);
      }
      });
	  $.ajax({
		  type: "POST",
		  url: "submit.php?method=getmodulecontent",
		  data:"module="+mod+'&idp_id_from_uip=<?=$passing_ui_idp_id?>',
		  dataType: "json",
		  success: function(result){
			  if(result == 'NULL') {
				  $('#moduleshortdes_box').show();
				  $('#useripdmod_content').html('Module content need to update by admin');
				  $('#mod_docs_links').hide(); 
				  $('#mod_readmore_links').hide();
				 // alert("No records founds");
			  }else {
				  //alert(result[0]);
				  $('#moduleshortdes_box').show();
				 
				  if(result[4]!="") {
					  
					var regX = /(<([^>]+)>)/ig;
					var html = result[4];
					//alert(html.replace(regX, ""));
					
					
					  $('#useripdmod_content').html(html.replace(regX, ""));
					  //$('#useripdmod_content').html(result[4].substring(0,150) + '.....');
					  $('#mod_readmore_links').show();
            $("#mod_readmore_links").attr("href", "modulecontent.php?id="+result[0]+"");
					 //alert(result[4]);
				  }else {
					  $('#useripdmod_content').html('Description values need to update by admin');
					  $('#mod_readmore_links').hide();
				  }
				  if(result[5]!="") {
					  $('#mod_docs_links').show();
					  $("#mod_docs_links").attr("href", "admin/uploads/usermoduledocs/"+result[5]+"");
            //alert(result[5]);
				  }else {
					  $('#mod_docs_links').hide();
				  }
				  
				  // if(result[5] == ) {
					  
				  // }
			  }
			  
			  //alert(result[0]);
		  }
	  });
    }else{
      alert("Please select a value");
      $('#name').val('');
       $('input[name="sdate"]').val('');
       $('input[name="cdate"]').val('');
       $('#department').val('');
       $('#sign').val('');
       $('#dstop1').val('');
       $('#dstop2').val('');
       $('#dstop3').val('');
       $('#dstop4').val('');
       $('#consequence1').val('');
       $('#consequence2').val('');
       $('#consequence3').val('');
       $('#consequence4').val('');
       $('#dstart1').val('');
       $('#dstart2').val('');
       $('#dstart3').val('');
       $('#dstart4').val('');
       $('#benefits1').val('');
       $('#benefits2').val('');
       $('#benefits3').val('');
       $('#benefits4').val('');
       $('input[name="aplan"]').val('');
	   $('input[name="mypas"]').val('');
	   
       //$('input[name="progress"]').val(data[10]);
        
        for(i=1;i<=31;i++){
            $('#p'+i).parent().removeClass('highlight');
        }
       $('#week1').val('');
       $('#week2').val('');
       $('#week3').val('');
       $('#week4').val('');
    }

});



 $(":checkbox").on("change", function() {
    $(this).parent().toggleClass("highlight");
    });
</script>
 <!-- <script>
 $(":checkbox").on("change", function() {
    var that = this;
    $(this).parent().css("background-color", function() {
        return that.checked ? "#000000" : "";
    });
});
</script>  -->

<script>
 $("#hei td").click(function() {
    $(this).child().toggleClass("highlight");
});
$("#toggle_btn").click(function() {
    $('#toggle_Sec').toggle();
});
</script> 

</div>

</div><!--col-12-->
          

</div>



</div>
</div>

<?php
}else{ ?>

<div class="col-md-12">
No Module Present
</div>
<?php }
} else { 
  header("Location: select_programs.php");
 } 

 }?>
<?php include('footer-index.php'); ?>
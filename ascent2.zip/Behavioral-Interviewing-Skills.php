<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">BEHAVIORAL INTERVIEWING SKILLS</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	 Is a popular approach to assess a candidate’s past experiences and judge his/her response to similar situations on a future job. This variety of interviewing is based on the premise that past performance in comparable circumstances is the best predictor of future performance.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	BEHAVIORAL INTERVIEWING SKILLS
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Introduction</p>
		<ul class="cs-ui">
			<li><a href="https://biginterview.com/blog/2011/02/behavioral-interview.html" target="_blank">Behavioral Interview: Tips for Crafting Your Best Answers</a></li>
			<li><a href="http://www.businessdictionary.com/definition/behavioral-interview.html" target="_blank">Business interview- Definition</a></li>
			<li><a href="https://www.thebalance.com/behavioral-interviews-525761" target="_blank">Behavioral Interviews-It's Not What You Know, It's What You Did</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Tips/Techniques</p>
		<ul class="cs-ui">
			<li><a href="https://hiring.monster.com/hr/hr-best-practices/recruiting-hiring-advice/interviewing-candidates/behavioral-interviewing-tips.aspx" target="_blank">Behavioral Interviewing Reinvented</a></li>
			<li><a href="http://www.mentalgamecoach.com/articles/BehavioralInterviewingTechniques.html" target="_blank">Behavioral Interviewing Techniques – Smart Strategies To Help You Master This Challenging Approach.</a></li>
			<li><a href="https://www.money-zine.com/career-development/finding-a-job/behavioral-interviewing-technique/" target="_blank">Behavioral Interviewing Technique</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Advantages & Disadvantages</p>
		<ul class="cs-ui">
			<li><a href="http://smallbusiness.chron.com/advantages-disadvantages-behavioral-employment-testing-16562.html" target="_blank">​Advantages & Disadvantages of Behavioral Employment Testing</a></li>
			<li><a href="https://resources.careerbuilder.com/employer-blog/best-behavioral-interview-questions" target="_blank">The Pros and Cons of Behavioral Interviewing</a></li>
			<li><a href="https://www.forbes.com/sites/lizryan/2014/03/04/why-i-hate-behavioral-interviewing/#168a0fe7693c" target="_blank">The Trouble With Behavioral Interviewing</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">VIDEOS</p>
		<ul class="cs-ui">
			<li><a href="https://www.youtube.com/watch?v=KTATIx8gUxU&feature=youtu.be" target="_blank">Interviewing Skills: STAR Technique</a></li>
			<li><a href="https://www.youtube.com/watch?v=M0zyf05GlIg&feature=youtu.be" target="_blank">How to Conduct an Interview | Effective Interview Questions</a></li>
		</ul>
		</div>


	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/behav-intrv.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://books.google.pn/books/about/Behavioral_Interviewing_Guide.html?id=lQFWAAAAQBAJ" target="_blank">Behavioral Interviewing Guide: A Practical, Structured Approach For Conducting Effective Selection Interviews.- Tom S Turner</a></p>
	</div>
	</div>


		<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/high-impact-intrv.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.bookdepository.com/High-Impact-Interview-Questions-701-Behaviour-Based-Questions-Find-Right-Person-for-Every-Job-Victoria-Hoevemeyer/9780814473016" target="_blank">High-Impact Interview Questions: 701 Behavior-Based Questions to Find the Right Person for Every Job-Victoria A Hoevemeyer</a></p>
	</div>
	</div>





	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
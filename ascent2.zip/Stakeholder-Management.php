<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">STAKEHOLDER MANAGEMENT</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	Stakeholder management is a critical component to the successful delivery of any project, programme or activity. A stakeholder is any individual, group or organization that can affect, be affected by, or perceive itself to be affected by a programme.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	STAKEHOLDER MANAGEMENT
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Introduction</p>
		<ul class="cs-ui">
			<li><a href="https://www.cleverism.com/ultimate-guide-to-stakeholder-management/" target="_blank">Ultimate guide to stakeholder management</a></li>
			<li><a href="https://www.slideshare.net/VincenzoCapozzoli/stakeholder-management-a-short-introduction" target="_blank">Stakeholder management- a short introduction</a></li>
			<li><a href="http://www.betterprojects.net/2007/05/introduction-to-stakeholder-management.html" target="_blank">An introduction to stakeholder management</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Definition</p>
		<ul class="cs-ui">
			<li><a href="http://www.businessdictionary.com/definition/stakeholder-management.html" target="_blank">What is stakeholder management- business dictionary​</a></li>
			<li><a href="https://www.projectsmart.co.uk/what-is-stakeholder-management.php" target="_blank">What is stakeholder management?-  By Duncan Haughey</a></li>
			<li><a href="http://asq.org/quality-progress/2011/03/back-to-basics/stakeholder-management-101.html" target="_blank">Back-to-basics-Stakeholder management</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Principles</p>
		<ul class="cs-ui">
			<li><a href="https://www.td.org/insights/seven-guiding-principles-of-stakeholder-engagement" target="_blank">Seven Guiding Principles of Stakeholder Engagement</a></li>
			<li><a href="https://www.apm.org.uk/resources/find-a-resource/stakeholder-engagement/key-principles/" target="_blank">10 key principles of stakeholder engagement</a></li>
			<li><a href="https://www.stakeholdermap.com/principles-stakeholder-management.html" target="_blank">The Principles of Stakeholder Management</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Tools & techniques</p>
		<ul class="cs-ui">
			<li><a href="http://www.projectmanagementguru.com/communication.html" target="_blank">project management tools & techniques</a></li>
			<li><a>Stake Management-Wikipedia</a></li>
			<li><a href="https://www.projecttimes.com/articles/tips-on-stakeholder-management.html" target="_blank">Tips On Stakeholder Management</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Importance</p>
		<ul class="cs-ui">
			<li><a href="http://cloud-collaboration.kahootz.com/why-stakeholder-management-is-an-important-part-of-project-management" target="_blank">Why stakeholder management is an important part of project management</a></li>
			<li><a href="https://www.girlsguidetopm.com/4-unusual-reasons-why-stakeholder-management-is-important/" target="_blank">4 unusual reasons why stakeholder management is important</a></li>
			<li><a href="http://smallbusiness.chron.com/importance-identifying-stakeholders-project-74730.html" target="_blank">The Importance of Identifying Stakeholders in a Project
​</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Stakeholder management plan</p>
		<ul class="cs-ui">
			<li><a href="https://www.smartsheet.com/how-create-stakeholder-management-and-communication-plans" target="_blank">how to create a stakeholder management and communication plans?</a></li>
			<li><a href="https://www.thebalance.com/stakeholder-management-plan-1669432" target="_blank">Stakeholder management plan in project management</a></li>
			<li><a href="http://www.mypmllc.com/project-management-resources/free-project-management-templates/stakeholder-management-plan-template/" target="_blank">Stakeholder management plan template</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Barriers faced in effectively managing stakeholders</p>
		<ul class="cs-ui">
			<li><a href="http://www.brighthubpm.com/project-planning/38618-project-communication-obstacles/" target="_blank">Project communication obstacles</a></li>
			<li><a href="http://smallbusiness.chron.com/six-barriers-effective-planning-45281.html" target="_blank">Six barriers to effective planning</a></li>
			<li><a href="https://www.bizmanualz.com/better-project-management/how-to-reduce-barriers-to-project-implementation.html" target="_blank">How to Reduce Barriers to Project Implementation​</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Case studies on stakeholder management</p>
		<ul class="cs-ui">
			<li><a href="http://www.scielo.cl/scielo.php?script=sci_arttext&pid=S0718-27242015000200004" target="_blank">Project stakeholder management- A case study of a Brazilian Science Park</a></li>
			<li><a href="https://www.slideshare.net/NnadozieIzidor/a-case-of-stakeholder-management-by-oil-and-gas-mn-cs-in-nigeria-nnadozie-izidor-2013" target="_blank">A Case of Stakeholder Management by Oil and Gas MNCs in Nigeria - Izidor, N (2013)</a></li>	
			<li><a href="https://library.iated.org/view/SUCOZHANAY2016AST" target="_blank">A Stakeholder management approach to university change- a case study in Latin America</a></li>
		</ul>
		</div>
									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">



	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/managing-for-holder.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.jstor.org/stable/j.ctt1npxrg" target="_blank">Managing for Stakeholders: Survival, Reputation, and Success - Andrew C. Wicks, Jeffrey S Harrison, and R. Edward Freeman</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/project-stakeholder.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.pmi.org/learning/library/project-stakeholder-management-5216" target="_blank">Project Stakeholder Management</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/stakeholder-engagement.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.crcnetbase.com/isbn/978-1-4822-3067-3" target="_blank">Stakeholder Engagement: The Game Changer for Program Management
Book by Amy Baugh</a></p>
	</div>
	</div>



        <div class="col-lg-12" style="margin-top: 20px">
		<div class="info-n">
		<p class="abt-sub-titles ab">VIDEO</p>
            <iframe width="100%" height="254" src="https://www.youtube.com/embed/DCFA8mw60ys" allowfullscreen></iframe>
		</div>
		</div>


	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
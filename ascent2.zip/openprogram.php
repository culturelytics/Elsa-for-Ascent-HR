<?php include('header.php'); ?>

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">OPEN PROGRAM</h2>
<hr class="line-75">
</div>


<div class="col-lg-12"> 

<div class="col-lg-12 cc1"> 
<h4 class="ab abt-sub-titless1" style="color:greenyellow;">About e2e</h4>
<p>We are a culture audit firm focusing on Merger and Acquisitions. We are experts in people behavior analytics and have been consulting across industries for the last 8 years.</p> 
<p>We have also successfully delivered programs / interventions pertaining to leadership development (training workshops, coaching, performance management systems, etc.)</p>
<p>Our clientele has been a combination of Fortune 100 companies, Educational Institutions, mid-sized firms and high growth start-ups.</p>
</div>
</div>

<div class="col-lg-12 cc1">
<div class="col-lg-6 cc2" >
<h4 class="ab abt-sub-titless1" style="color:greenyellow;">e2e Open Program</h4>
 
<p>We believe in giving back to the community through collaborative learning through the Master Class series on domains such as HR Analytics and Executive Presence. Speakers are domain experts from leading industries who will bring in highly relevant practices and thus build on the certification of the program.</p> 
<p>We completed our second Open Program on HR Analytics and Executive Presence successfully on the 16th of February, 2017 </p> 
<p>We had 20 nominations from 14 different organizations being facilitated by 9 Industry experts on the specified topics. </p> 
<p>We achieved an overall learning rating of 8 on 10.</p>
</div>

<div class="col-lg-6 cc2"> 
<iframe width="100%" height="315" src="https://www.youtube.com/embed/yETs1GbnGt4" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>
</div>

<div class="col-lg-12 cc1">
<div class="col-lg-6 cc2">
	<h4 class="ab abt-sub-titless1" style="color:greenyellow;">What is HR Analytics?</h4>
	<p>The basic premise of the “people analytics” approach is that accurate people management decisions are the most important and impactful decisions that a firm can make. You simply can’t produce superior business results unless your managers are making accurate people management decisions.</p>
	
	<ol style="margin-top: 15px;">
		<li>Quantification of HR - across employee life cycle.</li>
    	<li>Dimensions of HR Metrics - Efficiency, Effectiveness & Impact</li>
    </ol>
    
</div>


<div class="col-lg-6 cc2">
	<iframe width="100%" height="315" src="https://www.youtube.com/embed/WLHDsbPEeCY" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>
</div>

<div class="col-lg-12 cc1">
<div class="col-lg-6 cc2">
	<h4 class="ab abt-sub-titless1" style="color:greenyellow;">What is Executive Presence?</h4>
	<p>Executive presence is a blending of temperament, competencies, and skills that, when combined, send all the right signals. Leaders know they must embody executive presence to get ahead, influence others, and drive results. Leadership development professionals know they must help their executives develop it.</p>
    
</div>


<div class="col-lg-6 cc2">
	<iframe width="100%" height="315" src="https://www.youtube.com/embed/_LKfb8og5Rk" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
</div>
</div>

<div class="col-lg-12 cc5">
  <div class="col-lg-6  imm">
	<img src="images/program/program.jpg">    
  </div>

  <div class="col-lg-6 cc6">
  	<div class="rgg">
  	<h4 class="ab abt-sub-titless1" style="color:greenyellow;">Register</h4>
  		<h5>Click here to register for our events</h5>
  		<span class="bbb1"><a href="program-register.php" class="btn login-btn">Register</a></span>
  	</div>
  	<div class="rgg2">
  		<h4 class="ab abt-sub-titless1" style="color:greenyellow;">Our Report</h4>
  		<h5>Click here to view our report</h5>
  		<span class="bbb2"><a href="images/program/Proposal-for-Master-Class.pdf" target="_blank" class="btn login-btn">Report</a></span>
  	</div>
  </div>
</div>


</div>
<?php include('footer.php'); ?>
<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">FIRST TIME MANAGERS</p>
    <hr class="line-75">
    <ul class="cs-ui">
    <p>One of the key things that new managers need to internalize is :</p>
      <li>“What got you here won‟t get you there”</li>
      <li>Leading people requires managers to fundamentally look at themselves differently</li>
      <li>That should be the focus of the intervention.</li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	FIRST TIME MANAGERS
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">Role Appreciation</p>
		<ul class="cs-ui">
			<li><a href="https://www.entrepreneur.com/article/244657" target="_blank">Appreciation at Work: Two Major Misconceptions Leaders Hold</a></li>
			<li><a href="https://www.wsj.com/articles/appreciating-the-big-role-of-small-businesses-1472855429" target="_blank">Appreciating the big role of small businesses</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Time management and prioritization techniques</p>
		<ul class="cs-ui">
			<li><a href="http://thepeakperformancecenter.com/development-series/skill-builder/personal-effectiveness/time-management/" target="_blank">What is Time Management?</a></li>
			<li><a href="http://www.prioritymanagement.com/nsw/resources/resource.php?resource_id=151" target="_blank">12 Top Time Management Tips</a></li>
			<li><a href="https://www.skillsyouneed.com/ps/time-management.html" target="_blank">Time Management Skills</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Business Communication</p>
		<ul class="cs-ui">
			<li><a href="https://www.forbes.com/sites/amyanderson/2013/05/28/successful-business-communication-it-starts-at-the-beginning/#474e10e71db5" target="_blank">Successful Business Communication: It Starts At The Beginning</a></li>
			<li><a href="http://learningindia.in/forms-of-business-communication-in-india/" target="_blank">The Golden Rule for Choosing the Best Forms of Business Communication in India</a></li>
			<li><a href="https://www.infosciencetoday.org/communication-technology/forms-of-business-communication.html" target="_blank">Forms of Business Communication</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Effective Coaching</p>
		<ul class="cs-ui">
			<li><a href="http://www.prydale.com/corporate/effective-coaching-in-the-workplace/" target="_blank">Effective coaching in the workplace</a></li>
			<li><a href="https://www.thebalance.com/what-s-the-new-coaching-role-for-hr-staff-1917841" target="_blank">What's the New Coaching Role for HR Staff?</a></li>
			<li><a href="https://www.inc.com/articles/2001/04/22404.html" target="_blank">Six Coaching Strategies You Can Apply in the Workplace</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Career tools</p>
		<ul class="cs-ui">
			<li><a href="https://ie.reachout.com/communication/communication-styles/" target="_blank">5 Career Tools You Can Use to Advance Your Career</a></li>
			<li><a href="https://novisurvey.net/blog/a-career-interest-survey-is-an-important-tool-for-teenagers-to-take.aspx" target="_blank">A career interest survey is an important tool for teenagers to take</a></li>
			<li><a href="https://www.eatyourcareer.com/2013/07/the-most-important-tool-for-accelerating-your-career-growth/" target="_blank">The Most Important Tool for Accelerating Your Career Growth</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Conflict Management</p>
		<ul class="cs-ui">
			<li><a href="http://www.yourarticlelibrary.com/business/conflict-management-characteristics-types-stages-causes-and-other-details/5431/" target="_blank">What is conflict management?</a></li>
			<li><a href="http://thedisputeresolutioncenter.org/services/case-studies/" target="_blank">Case studies on conflict management</a></li>
			<li><a href="http://www.umsl.edu/~sauterv/analysis/488_f01_papers/Ohlendorf.htm" target="_blank">Conflict Resolution in Project Management</a></li>
			<li><a href="https://www.youtube.com/watch?v=KY5TWVz5ZDU" target="_blank">Conflict resolution (video)</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Art of setting SMART Goals</p>
		<ul class="cs-ui">
			<li><a href="http://www.startupist.com/2015/01/07/the-art-of-setting-s-m-a-r-t-goals/" target="_blank">What is the meaning of  S.M.A.R.T. goals?</a></li>
			<li><a href="http://nightingale.edu/blog/goal-setting-nursing-learners-learning-art-s-m-r-t-goals/" target="_blank">Goal Setting for Nursing Learners: Learning the Art of S.M.A.R.T. Goals</a></li>
			<li><a href="https://www.youtube.com/watch?v=d6o5PyJM3bY" target="_blank">How To Set SMART Goals (video)</a></li>
		</ul>
		</div>


		<!-- <div class="info-n">
		<p class="abt-sub-titles ab">Training Manuals</p>
		<ul class="cs-ui">
			<li><a href="http://docs.wixstatic.com/ugd/fd579f_2b02a5a8628d418c9bec444cdedad89f.pdf" target="_blank">TE Pune(First Time Managers)</a></li>
			<li><a href="http://docs.wixstatic.com/ugd/fd579f_b122de2a2b414dd48c864479af4fae02.pdf" target="_blank">TE Bangalore(First Time Managers)</a></li>
		</ul>
		</div>	 -->									


	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">

	<div class="col-lg-12">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/nego.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.umsl.edu/~sauterv/analysis/488_f01_papers/Ohlendorf.htm" target="_blank">Conflict Resolution in Project Management-Amy Ohlendorf</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/drive.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/Drive:_The_Surprising_Truth_About_What_Motivates_Us" target="_blank">Drive: The Surprising Truth About What Motivates Us- Daniel H. Pink</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/one-thing.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://davidmays.org/BookNotes05/BucOnet.html" target="_blank">The One Thing You Need to Know, by Marcus Buckingham</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/thinking-fast.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/Thinking,_Fast_and_Slow" target="_blank">Thinking, Fast and Slow, by Daniel Kahneman</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/act-like.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://herminiaibarra.com/books/" target="_blank">Act Like a Leader, Think Like a Leader, by Herminia Ibarra</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/great.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/Good_to_Great" target="_blank">Good to Great, by Jim Collins</a></p>
	</div>
	</div>

	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
 ?>            
<?php include('footer.php'); ?>
<?php
include_once('connectdb.php');
error_reporting(E_ERROR);
echo "<body style='background-color:#C8C581'>";
$sql="INSERT INTO feedback (Name,Email,Desg,Contact,DOB,Company,Date,Program,Coverage,Clarity,CaseStudy,Knowledge,Presentation,Examples,Queries,Impact,Comments,Testimonial,TrainingThings)
VALUES
('$_POST[firstname]','$_POST[email]','$_POST[desg]','$_POST[contact]','$_POST[dob]','$_POST[company]','$_POST[date]','$_POST[program]','$_POST[coverage]','$_POST[clarity]','$_POST[casestudy]','$_POST[knowledge]','$_POST[presentation]','$_POST[examples]','$_POST[queries]','$_POST[impact]','$_POST[comments]','$_POST[testimonial]','$_POST[trainingthings]')";

if (!mysqli_query($dbconnect,$sql))
  {
  die('Error: ' . mysqli_error($dbconnect));
  }
echo " <center>Thank you, Your Response has been recorded.</center>";
?>
<div style="margin-top: 9px; margin-left: 45%; font-size: 16px;">
  <a href="index.php" style="padding: 9px 9px;">Click Here To Go To E2E People Practices</a>
</div>

<?php include('header.php'); ?>
<?php

include_once("connectdb.php");
if(!isset($_SESSION["sess_email_kaccess"]) && !isset($_SESSION["sess_email_caccess"])){
header("Location: login.php");
}
else
{
?>
<div class="col-lg-12">
<!--col-12-->
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mob-no-padng" style="margin-bottom: 2%;margin-top: 3%;min-height: 350px;">
<div class="col-lg-4"></div>
<div class="col-lg-4">
	 <h3 style="margin-bottom: 15px;">You have Successfully Logged-in.</h3>
	  <p style="margin-bottom: 10px;">Now you can access Below pages </p>
	  <p><?php if($_SESSION['sess_email_kaccess'] != NULL ) {echo "<a href=\"e2e-library.php\" style=\"color:#ADFF2F\">ELSA</a>";} ?></p>
	  <p><?php if($_SESSION['sess_email_caccess'] != NULL ) {echo "<a href=\"select_programs.php\" style=\"color:#ADFF2F\">Client </a>";} ?></p>
</div>
<div class="col-lg-4"></div>
</div>
          

</div>

<?php
}
?>
<?php include('footer.php'); ?>
<?php include('header.php'); ?>
<?php

include_once("connectdb.php");
if(!isset($_SESSION["sess_email"])){
 header("Location: login.php");
}
else
{
?>

<?php
  $fmsg="";
   
if(isset($_POST) & !empty($_POST)){
   $email = $_SESSION['sess_email'];
  $password = $_POST['password1'];
   $res = mysqli_query($dbconnect, "UPDATE `tbl_user` SET password='$password' WHERE email='$email'");
if($res){
  $fmsg = "<span style = 'color: green;'>your password is changed.</span>";
}else{
  $fmsg = "<span style = 'color: red;'>Failed to change password.</span>";
}
}
 
?>

<div class="col-lg-12">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<!-- <h2 class="ar career-title text-center">LOG IN</h2>
<hr class="line-75"> -->
</div>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mob-no-padng" style="margin-bottom: 2%;margin-top: 3%">
<div class="col-lg-4"></div>
<div class="col-lg-4">
 <h3>You are Successfully Logged-in, now you can access Clients pages.</h3>
</div>
<div class="col-lg-4"></div>

</div>
<!--col-12-->
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12  mob-no-padng">
<div class="col-lg-4"></div>
<div class="col-lg-4">
 <form method="post" action="" id="change-password">
      <div class="form-sub-w3  left-form-w3-agile" style="padding: 20px">
                <?php echo $fmsg ?> 
               <p>Change Password :</p> 

               <input type="text" class="ar" placeholder="Enter new password" name="password" id="password" value="" required="">
               <input type="text" class="ar" placeholder="Confirm new password" name="password1" value="" required="">
                
      </div>
      <div class="submit-bg"><input type="submit" value="Change password" name="submit"></div>
      </form>
</div>
<div class="col-lg-4"></div>
</div>
          

</div>

<?php
}
?>
<?php include('footer.php'); ?>
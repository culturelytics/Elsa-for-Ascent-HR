<?php
include_once('connectdb.php');
session_start();

if(isset($_POST) && $_POST['subcontentid']!=''){
	$user_id = $_SESSION['user_id'];
	$assessmentid = $_POST['assessmentid'];
	$moduleid = $_POST['moduleid'];
	$contentid = $_POST['contentid'];
	$subcontentid = $_POST['subcontentid'];
	$totalscore = count($_POST['correctanswer']);
	$completedon = time();

	$answer_detail_arr = array();
	$obtainedscore = 0;

	if($totalscore > 0) {
		for($i=1; $i<=$totalscore; $i++) {
			$answer_detail_arr[$i]['answer'] = $_POST['answer'.$i];
			$answer_detail_arr[$i]['is_correct'] = ($_POST['answer'.$i] == $_POST['correctanswer'][$i-1]) ? 0 : 1;
			if($answer_detail_arr[$i]['is_correct'] == 0) {
				$obtainedscore++;
			}
		}
	}
	$answer_detail = json_encode($answer_detail_arr);
	$percentage = ($obtainedscore*100)/$totalscore;

	$query=mysqli_query($dbconnect,"INSERT INTO `tbl_user_assessment`(`userid`,`assessmentid`,`moduleid`,`contentid`,`subcontentid`,`answer_detail`,`totalscore`,`obtainedscore`,`percentage`,`completedon`) VALUES 
	('".$user_id."', '".$assessmentid."', '".$moduleid."', '".$contentid."', '".$subcontentid."', '".$answer_detail."', '".$totalscore."', '".$obtainedscore."', '".$percentage."', '".$completedon."')");

	$current_trophy_type = ''; $current_trophy_value = 0;
	if ($percentage <= 35 ) {
		$current_trophy_type = 'Bronze';
		$current_trophy_value = 1;
	} else if ($percentage > 50 && $percentage <= 75) {
		$current_trophy_type = 'Silver';
		$current_trophy_value = 2;
	} else if ($percentage > 75 && $percentage <= 100) {
		$current_trophy_type = 'Gold';
		$current_trophy_value = 3;
	}

	// Get Highest Score
	$trophy_type = ''; $trophy_value = 0;
	$percent_sql = "SELECT percentage FROM tbl_user_assessment WHERE `userid` = '".$user_id."' AND `moduleid` = '".$moduleid."' ORDER BY percentage DESC LIMIT 1";
	$percent_exec = mysqli_query($dbconnect, $percent_sql);
	$percent_no_rows = mysqli_num_rows($percent_exec);
	if ($percent_no_rows != 0) {
		$percent_row = mysqli_fetch_array($percent_exec);
		$highest_percent = $percent_row['percentage'];
		if ($highest_percent <= 35) {
			$trophy_type = 'Bronze';
			$trophy_value = 1;
		} else if ($highest_percent > 50 && $highest_percent <= 75) {
			$trophy_type = 'Silver';
			$trophy_value = 2;
		} else if ($highest_percent > 75 && $highest_percent <= 100) {
			$trophy_type = 'Gold';
			$trophy_value = 3;
		}
	}

	// Trophy Update
	if($trophy_type != '') {
		$trophy_sql = "SELECT mtid FROM tbl_module_trophies WHERE `userid` = '".$user_id."' AND `moduleid` = '".$moduleid."'";
		$trophy_exec = mysqli_query($dbconnect, $trophy_sql);
		$trophy_no_rows = mysqli_num_rows($trophy_exec);
		if ($trophy_no_rows != 0) {
			$trophy_row = mysqli_fetch_array($trophy_exec);
			$mtid = $trophy_row['mtid'];
			$trophy_record = mysqli_query($dbconnect,"UPDATE `tbl_module_trophies` SET `trophy_type` = '".$trophy_type."', `lastachievedon` = '".$completedon."' WHERE `userid` = '".$user_id."' AND `moduleid` = '".$moduleid."'");
		} else {
			$validtill = strtotime("+12 months");
			$trophy_record = mysqli_query($dbconnect,"INSERT INTO `tbl_module_trophies`(`moduleid`,`userid`,`trophy_type`,`achievedon`,`valid_till`) VALUES 
										('".$moduleid."', '".$user_id."', '".$trophy_type."', '".$completedon."', '".$validtill."')");
		}
	}

	// Mark Content Completion
	$uaid_sql = "SELECT uaid FROM tbl_user_assessment WHERE `userid` = '".$user_id."' AND `moduleid` = '".$moduleid."' AND `assessmentid` = '".$assessmentid."'";
	$uaid_exec = mysqli_query($dbconnect, $uaid_sql);
	$uaid_no_rows = mysqli_num_rows($uaid_exec);
	if($uaid_no_rows == 1) {
		$_POST['kl_id'] = $subcontentid;
		$_POST['cori'] = 'content';
		$_POST['kc_id'] = $moduleid;
		if($_POST['kl_id']!='' && $_POST['cori']!='' && $_POST['kc_id']!='' ){
			$query=mysqli_query($dbconnect,"update tbl_user_login_history SET ulh_end_time='".date('Y-m-d H:i:s')."' where ulh_id='".$_SESSION['ul_id']."'");
		
			$hashistory = 0;
			$qrcrd = "SELECT COUNT(`tbl_event_history`.`eh_kc_list_id`) as `total` FROM `tbl_event_history` WHERE `tbl_event_history`.`eh_u_id` = ".$_SESSION['user_id']." AND `tbl_event_history`.`eh_kc_list_id` = ".$_POST['kl_id'].";";
			if ($rescrd = mysqli_query($dbconnect,$qrcrd)) {
				while ($rwrescrd = mysqli_fetch_object($rescrd)) {
					$hashistory = $rwrescrd->total;
				}
				//mysqli_free_result($rwrescrd);
			}
		
			$query=mysqli_query($dbconnect,"INSERT INTO `tbl_event_history`(`eh_u_id`, `eh_kc_content_id`, `eh_kc_list_id`, `eh_ul_id`,`eh_cori`) 
			VALUES ('".$_SESSION['user_id']."','".$_POST['kc_id']."','".$_POST['kl_id']."','".$_SESSION['ul_id']."','".$_POST['cori']."')");
		
			if($hashistory == 0) {
				$currentcredits = 0;
				$qrcrd = "SELECT `tbl_kc_assignments`.`kca_credits` as `kca_credits` FROM `tbl_kc_assignments` WHERE `tbl_kc_assignments`.`kca_user_id` = ".$_SESSION['user_id']." AND `tbl_kc_assignments`.`kca_kc_id` = ".$_POST['kc_id']." AND `tbl_kc_assignments`.`kca_status` = 'Active';";
				if ($rescrd = mysqli_query($dbconnect,$qrcrd)) {
					while ($rwrescrd = mysqli_fetch_object($rescrd)) {
						$currentcredits = $rwrescrd->kca_credits;
					}
					//mysqli_free_result($rwrescrd);
				}
		
				$klcredits = 0;
				$qrcrd = "SELECT `tbl_kc_list`.`kl_credits` as `kl_credits` FROM `tbl_kc_list` WHERE `tbl_kc_list`.`kl_id` = ".$_POST['kl_id']." AND `tbl_kc_list`.`status` = 'Active';";
				if ($rescrd = mysqli_query($dbconnect,$qrcrd)) {
					while ($rwrescrd = mysqli_fetch_object($rescrd)) {
						$klcredits = $rwrescrd->kl_credits;
					}
					//mysqli_free_result($rwrescrd);
				}
				$credits = $currentcredits + $klcredits;
		
				$rescredits=mysqli_query($dbconnect,"UPDATE `tbl_kc_assignments` SET `tbl_kc_assignments`.`kca_credits` = ".$credits." WHERE `tbl_kc_assignments`.`kca_user_id` = ".$_SESSION['user_id']." AND `tbl_kc_assignments`.`kca_kc_id` = ".$_POST['kc_id']." AND `tbl_kc_assignments`.`kca_status` = 'Active';");
			}
			
		}
	}

	$showTrophyDetails = 'NO';
	if($current_trophy_value >= $trophy_value) {
		$showTrophyDetails = 'YES';
	}
	echo $trophy_type.'||'.$obtainedscore.'/'.$totalscore.'||'.$current_trophy_type.'||'.$showTrophyDetails;
}

?>
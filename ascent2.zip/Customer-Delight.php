<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">CUSTOMER DELIGHT</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	In order to create customer satisfaction, you need to go beyond good customer service and exceed your customers‟ expectations with exceptional service
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	CUSTOMER DELIGHT
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Customer is King</p>
		<ul class="cs-ui">
			<li><a href="https://orcommalienomore.wordpress.com/2011/10/02/‘customer-is-king’-what-it-means-in-today’s-market/" target="_blank">‘Customer is King’: What it means in Today’s Market</a></li>
			<li><a href="https://en.wikipedia.org/wiki/The_customer_is_always_right" target="_blank">The customer is always right</a></li>
			<li><a href="https://www.fatbit.com/fab/is-customer-really-the-king-perspectives-of-different-departments/" target="_blank">Is Customer Really The King? Perspectives of Different Organizational Departments</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Customer Relations</p>
		<ul class="cs-ui">
			<li><a href="http://smallbusiness.chron.com/customer-relations-43230.html" target="_blank">What is Customer Relations?</a></li>
			<li><a href="https://en.wikipedia.org/wiki/Customer_relationship_management" target="_blank">Customer Relationship Management</a></li>
			<li><a href="https://www.collinsdictionary.com/dictionary/english/customer-relations" target="_blank">Definition of Customer Relations</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Customer Delight</p>
		<ul class="cs-ui">
			<li><a href="https://www.impactbnd.com/blog/what-is-customer-delight" target="_blank">What is Customer Delight? (And Why Should You Care?)</a></li>
			<li><a href="https://en.wikipedia.org/wiki/Customer_delight" target="_blank">Customer Delight-Wikipedia</a></li>
			<li><a href="https://www.strategy-business.com/article/The-Art-of-Customer-Delight?gko=e9da8" target="_blank">The Art of Customer Delight</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Customer Satisfaction to Customer Delight</p>
		<ul class="cs-ui">
			<li><a href="https://www.getcloudcherry.com/blog/customer-satisfaction-vs-customer-delight/" target="_blank">Customer Satisfaction vs Customer Delight</a></li>
			<li><a href="https://www.business.com/articles/customer-delight-the-new-standard-in-customer-service/" target="_blank">Customer Delight: The new standard in Customer Service</a></li>
			<li><a href="https://www.zonkafeedback.com/blog/customer-satisfaction-vs-customer-delight/" target="_blank">Difference between customer satisfaction and customer delight</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">How to create Customer Delight?</p>
		<ul class="cs-ui">
			<li><a href="https://articles.bplans.com/13-ways-to-surprise-and-delight-your-customers-today/" target="_blank">13 Ways to Surprise and Delight Your Customers Today</a></li>
			<li><a href="https://www.biznessapps.com/blog/4-principles-to-achieve-customer-delight/" target="_blank">4 Principles to Achieve Customer Delight</a></li>
			<li><a href="https://www.mcorpcx.com/articles/23-ways-delight-amaze-customers" target="_blank">23 Ways to Delight and Amaze Your Customers</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Principles</p>
		<ul class="cs-ui">
			<li><a href="https://www.inc.com/matt-ehrlichman/the-8-principles-of-customer-delight.html" target="_blank">The 8 Principles of Customer Delight</a></li>
			<li><a href="https://www.clientsuccess.com/blog/the-golden-rule-of-customer-success-guiding-principles/" target="_blank">The Golden Rule of Customer Success – 8 Guiding Principles</a></li>
			<li><a href="https://blog.intercom.com/real-customer-delight-isnt-over-the-top/" target="_blank">Real customer delight isn’t over the top</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Examples</p>
		<ul class="cs-ui">
			<li><a href="http://customerthink.com/3-brilliant-examples-of-customer-delight/" target="_blank">3 Brilliant Examples Of Customer Delight</a></li>
			<li><a href="https://www.referralcandy.com/blog/delight-customer-examples/" target="_blank">17 Ways That 15 Companies Got Massive Word-of-Mouth By Delighting Their Customers</a></li>
			<li><a href="https://www.impactbnd.com/blog/customer-delight-examples-b2b-marketers-can-learn-from" target="_blank">5 Badass Customer Delight Examples Every B2B Marketer Can Learn From</a></li>
		</ul>
		</div>
			

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/customer-delight.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://customerdelightbook.com/#" target="_blank">Customer Delight: Strategic Insights for Market Leaders- Alain Guillemain</a></p>
	</div>
	</div>


	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/customer-delight-365.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.brianmonahan.me/books/" target="_blank">Customer Delight 365-
Brian Monahan</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/delight-ur-customer.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.stevecurtin.com/blog/tag/delight-your-customers/" target="_blank">Delight your Customers- Steve Curtin & Brian O' Neil</a></p>
	</div>
	</div>


	    <div class="col-lg-12" style="margin-top: 20px">
		<div class="info-n">
		<p class="abt-sub-titles ab">VIDEO</p>
            <iframe width="100%" height="225" src="https://www.youtube.com/embed/RYd1tZAqLys" allowfullscreen></iframe>
		</div>
		</div>



	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
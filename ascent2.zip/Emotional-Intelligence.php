<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">EMOTIONAL INTELLIGENCE</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	Emotional intelligence (EI) is the capability of individuals to recognize their own emotions and those of others, discern between different feelings and label them appropriately, use emotional information to guide thinking and behavior, and manage and/or adjust emotions to adapt to environments or achieve one's goal(s)
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	EMOTIONAL INTELLIGENCE
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Introduction</p>
		<ul class="cs-ui">
			<li><a href="https://www.verywell.com/what-is-emotional-intelligence-2795423" target="_blank">What is emotional intelligence?</a></li>
			<li><a href="https://en.wikipedia.org/wiki/Emotional_intelligence" target="_blank">Emotional Intelligence-Wikipedia</a></li>
			<li><a href="https://www.slideshare.net/evisioninc/emotional-intelligence-introduction-28298116-%20PPT%20(SLIDESHARE)" target="_blank">Emotional Intelligence-Introduction</a></li>
		</ul>
		</div>


		<div class="info-n">
		<p class="abt-sub-titles ab">Definition</p>
		<ul class="cs-ui">
			<li><a href="https://www.essentiallifeskills.net/what-is-emotional-intelligence.html" target="_blank">What is emotional intelligence?-essentiallifeskills.net</a></li>
			<li><a href="https://economictimes.indiatimes.com/definition/emotional-intelligence" target="_blank">Emotional intelligence-definition</a></li>
			<li><a href="http://www.dictionary.com/browse/emotional-intelligence" target="_blank">Emotional Intelligence-dictionary</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Components</p>
		<ul class="cs-ui">
			<li><a href="http://inspirebusinesssolutions.com/blog/5-main-components-of-emotional-intelligence" target="_blank">5 main components of emotional intelligence</a></li>
			<li><a>Our Approaches-Emotional Intelligence (EI or EQ)</a></li>
			<li><a href="https://www.inc.com/jessica-stillman/the-12-components-of-exceptional-emotional-intelligence.html" target="_blank">The 12 components of exceptional emotional intelligence</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Concepts/Theories</p>
		<ul class="cs-ui">
			<li><a href="http://www.educational-business-articles.com/emotional-intelligence-theory/" target="_blank">Emotional Intelligence theory</a></li>
			<li><a href="http://www.6seconds.org/2010/01/27/the-six-seconds-eq-model/" target="_blank">The Six Seconds EQ Model</a></li>
			<li><a href="http://nobaproject.com/modules/emotional-intelligence" target="_blank">Emotional Intelligence- Modules</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Importance</p>
		<ul class="cs-ui">
			<li><a href="http://yourdost.com/blog/2016/03/why-emotional-intelligence-is-important-for-students.html" target="_blank">Why emotional intelligence is important for students</a></li>
			<li><a href="http://www.selectinternational.com/blog/why-is-emotional-intelligence-an-important-leadership-trait" target="_blank">Why is emotional intelligence an important leadership trait</a></li>
			<li><a href="https://www.huffingtonpost.com/tracy-crossley/10-reasons-why-emotional-_b_6770864.html" target="_blank">10 Reasons Why Emotional Intelligence Is Critical for Leaders</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Pros & Cons</p>
		<ul class="cs-ui">
			<li><a href="https://brandongaille.com/12-pros-and-cons-of-emotional-intelligence/" target="_blank">12 pros & cons of emotional intelligence</a></li>
			<li><a href="https://www.theatlantic.com/health/archive/2014/01/the-dark-side-of-emotional-intelligence/282720/" target="_blank">The dark side of emotional intelligence</a></li>
			<li><a href="https://www.frontiersin.org/articles/10.3389/fpsyg.2017.00463/full" target="_blank">The Positive Effects of Trait Emotional Intelligence during a Performance Review Discussion – A Psychophysiological Study</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Benefits of EI in the workplace</p>
		<ul class="cs-ui">
			<li><a href="http://blog.readytomanage.com/the-benefits-of-emotional-intelligence-in-the-workplace/" target="_blank">The benefits of emotional intelligence in the workplace</a></li>
			<li><a href="https://erickson.edu/blog/why-emotional-intelligence-matters-at-work" target="_blank">Why emotional intelligence matters at work</a></li>
			<li><a href="https://www.td.org/insights/emotional-intelligence-is-key-to-our-success" target="_blank">Emotional intelligence is the key to our success</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Improvements of Emotional Intelligence</p>
		<ul class="cs-ui">
			<li><a href="https://www.psychologytoday.com/blog/communication-success/201410/how-increase-your-emotional-intelligence-6-essentials" target="_blank">Six ways to increase your emotional intelligence</a></li>
			<li><a href="https://www.helpguide.org/articles/mental-health/emotional-intelligence-eq.htm" target="_blank">Key Skills for Managing Your Emotions and Improving Your Relationships</a></li>
			<li><a href="https://www.rochemartin.com/blog/50-tips-improving-emotional-intelligence/" target="_blank">50 tips for improving your emotional intelligence</a></li>
		</ul>
		</div>
									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">



	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/the-leaders-guide.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://clearpointleadership.com/tlgei" target="_blank">The Leader's Guide to Emotional Intelligence- Drew Bird</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/the-eq-edge.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.eqedge.com/" target="_blank">The EQ Edge-Emotional Intelligence and your success- Steven Stein</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/the-brain.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.wildmind.org/blogs/book-reviews/the-brain-and-emotional-intelligence-new-insights-by-daniel-goleman" target="_blank">“The Brain and Emotional Intelligence: New Insights,” by Daniel Golemans</a></p>
	</div>
	</div>

        <div class="col-lg-12" style="margin-top: 20px">
		<div class="info-n">
		<p class="abt-sub-titles ab">VIDEO</p>
            <iframe width="100%" height="225" src="https://www.youtube.com/embed/n6MRsGwyMuQ" allowfullscreen></iframe>
		</div>
		</div>


	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
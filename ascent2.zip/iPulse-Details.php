<?php
session_start();
// Checking first page values for empty,If it finds any blank field then redirected to first page.
if (isset($_POST['name']))
	if (empty($_POST['name'])
 || empty($_POST['email'])){ 
 // Setting error message
 $_SESSION['error'] = "Mandatory field(s) are missing, Please fill it again";
 header("location: iPulse.php.php"); // Redirecting to first page 
 }
else {
 // Sanitizing email field to remove unwanted characters.
 $_POST['email'] = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);		
}

?>		
		
		
<!DOCTYPE html>
<html>
	<meta name="viewport" content="width-device-width, initial-scale=1.0">
	<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/base/jquery-ui.css" rel="stylesheet" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js"></script>
<head>
<title>iPulse Personal Values Assessment</title>
	</head>
	<style>
		h4{
			text-align:center;
			font-size: 28px;
			padding: 10px;
		}
	.header{
		height: 210px;
		background-color:gray;
	margin-top:-40px;}
	img{
		margin-top:-250px;
	margin-left: 1000px;}
		.title1{
			margin-left: 30px;
		margin-top:-20px;}
		.content{
			margin-left:30px;
		margin-top:-20px;
		font-size:18px;}
		.redBackground{
background-color:#489fcc;
}
		.col-1{
			margin-left: 20px;
		     height:50px;
		      width: 250px;
		font-size:20px;}
		.col-1:hover,.col-2:hover,.col-3:hover,.col-4:hover,.col-5:hover{
			border:2px solid #489fcc}
		.col-2{
			margin-left:267px;
			margin-top: -50px;
			height:50px;
			width:250px;
		font-size:20px;}
		.col-3{
			margin-left:515px;
			margin-top:-50px;
			height:50px;
			width:250px;
		font-size:20px;}
		.col-4{
			margin-left:764px;
			margin-top:-50px;
			height:50px;
			width:250px;
		font-size:20px;}
		.col-5{
			margin-left:1010px;
			margin-top:-50px;
			height:50px;
			width:250px;
	margin-right:20px;
		font-size:20px;}
    .continue{
		margin-left: 850px;
		margin-top: -40px;}
		/*div:hover{
			border:1px solid red;}*/
	</style>
<body>
	<div class="header">
	<h4>iPulse Personal Values Assessment</h4>
	 <img  class="img" src="images/iPulse logo.jpg" height="100px" width="130px">
		<h3 class="title">PERSONAL VALUES</h3><br>
		<p class="content">Please select ten of the following values/behaviors that most reflect who you are, not who you desire to become. Click on a word to add or remove your selection.</p>
	</div>
	<?php
	if (!empty($_SESSION['error_page2'])) {
 echo $_SESSION['error_page2'];
 unset($_SESSION['error_page2']);
}
?>
	<form  method="post" action="iPulse-Feedback.php">
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Caution'>Caution</div>
    <div class="col-2"><input type='checkbox' name='detailsid[]' value='Personal Image'>Personal Image</div>
    <div class="col-3"><input type='checkbox' name='detailsid[]' value='Health'>Health</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Wisdom">Wisdom</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Well-being">Well-being</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Ethics'>Ethics</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Competence'>Competence</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Self Discipline'>Self Discipline</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Wealth">Wealth</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Achievement">Achievement</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Commitment'>Commitment</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Integrity'>Integrity</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Forgiveness'>Forgiveness</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Courage">Courage</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Risk Taking">Risk Taking</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Friendship'>Friendship</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Humility'>Humility</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Power'>Power</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Balance (Work/life)">Balance (Work/life)</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Recognition">Recognition</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Environmental Awareness'>Environmental Awareness</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Community Involvement'>Community Involvement</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Being Liked'>Being Liked</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Professional Growth">Professional Growth</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Perseverance">Perseverance</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Vision '>Vision </div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Future generations'>Future generations</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Safety'>Safety </div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Conflict Resolution">Conflict Resolution</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Family">Family</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Personal Fulfilment'>Personal Fulfilment</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Ease with Uncertainty'>Ease with Uncertainty</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Excellence'>Excellence</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Enthusiasm/Positive Attitude">Enthusiasm/Positive Attitude</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Patience">Patience</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Compassion'>Compassion</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Respect'>Respect</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Financial stability'>Financial stability</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Listening">Listening</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Independence">Independence</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Personal Growth'>Personal Growth</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Leadership'>Leadership</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Accountability'>Accountability</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Openness">Openness</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Coaching/Mentoring">Coaching/Mentoring</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Making a difference'>Making a difference</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Dialogue'>Dialogue</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Generosity'>Generosity</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Trust">Trust</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Humor/fun">Humor/fun</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Control'>Control</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Reward'>Reward</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Ambition'>Ambition</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Efficiency">Efficiency</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value="Fairness">Fairness</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Continuous Learning'>Continuous Learning</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Independence'>Independence</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value='Creativity'>Creativity</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value="Teamwork">Teamwork</div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value='Caring'>Caring </div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Job Security'>Job Security </div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value='Being the best'>Being the best</div>
	<div class="col-3"><input type='checkbox' name='detailsid[]' value="Reliability">Reliability</div>
	<div class="col-4"><input type='checkbox' name='detailsid[]' value='Adaptability'>Adaptability </div>
	<div class="col-5"><input type='checkbox' name='detailsid[]' value='Entrepreneurial'>Entrepreneurial</div>
	<div class="col-1"><input type='checkbox' name='detailsid[]' value='Initiative'>Initiative</div>
	<div class="col-2"><input type='checkbox' name='detailsid[]' value="Clarity">Clarity</div>
	<button name="subject" type="submit" value="continue" class="continue" id="details" onclick="goBack()">Continue</button>
	</form>
	
	</body>
	<script>
		$("input[type='checkbox']").change(function(){
    if($(this).is(":checked")){
        $(this).parent().addClass("redBackground"); 
    }else{
        $(this).parent().removeClass("redBackground");  
    }
});
	</script>
	<script>
		$(document).ready(function(){
    $("#details").submit(function(){
		if ($('input:checkbox').filter(':checked').length != 10){
        alert("Please select 10 words only");
		return false;
		}
    });
});
	</script>
	<script>
function goBack() {
  window.history.back();
}
</script>

</html>

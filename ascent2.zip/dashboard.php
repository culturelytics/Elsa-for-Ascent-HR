<?php //include 'header.php'; ?>
<style>
	.panel {
		background: transparent
	}
</style>
<?php

include_once "connectdb.php";
if(!isset($_SESSION["sess_email_kaccess"]) && !isset($_SESSION["sess_email_caccess"])){
header("Location: login.php");
}
else {
	$user_id = $_SESSION["user_id"];

	$cntdata = array('Article' => 0, 'Video' => 0, 'Assessment' => 0, 'Booksuggestion' => 0, 'Module' => 0);
	if ($result = mysqli_query($dbconnect, "SELECT kl_cat, COUNT(*) AS total FROM tbl_kc_list WHERE STATUS = 1 GROUP BY kl_cat;")) {
		while ($row = mysqli_fetch_assoc($result)) {
			$cntdata[$row['kl_cat']] = $row['total'];
		}
		// Free result set
		mysqli_free_result($result);
	}

	
	$organization_id = null;
	$org_name = "";

	$queryorg = "SELECT * FROM `tbl_user` ";
	$queryorg .= " INNER JOIN `tbl_organization` ON `tbl_organization`.`id` = `tbl_user`.`organization_id` ";
	$queryorg .= " WHERE `tbl_user`.`id` = $user_id; ";
	if ($result = mysqli_query($dbconnect, $queryorg)) {
		while ($row = mysqli_fetch_assoc($result)) {
			$org_name = $row['org_name'];
			$organization_id = $row['organization_id'];
		}
		// Free result set
		mysqli_free_result($result);
	}
	
	/* analytics -start */

	/*$this->db->select('*');
    $this->db->from('tbl_event_history');
    $this->db->join('tbl_kc_list', 'tbl_event_history.eh_kc_list_id = tbl_kc_list.kl_id', 'left');
    $this->db->join('tbl_kc_content', 'tbl_kc_list.kl_kc_id = tbl_kc_content.kc_id', 'left');
    $this->db->join('tbl_knowledge_center', 'tbl_kc_content.kc_prg_id = tbl_knowledge_center.prg_id', 'left');
    $this->db->join('tbl_user', 'tbl_event_history.eh_u_id = tbl_user.id', 'left');
    $this->db->join('tbl_user_login_history', 'tbl_event_history.eh_ul_id = tbl_user_login_history.ulh_id', 'left');
     */

	/*$querysa = <<<EOT
    SELECT * FROM `tbl_event_history`
    LEFT JOIN `tbl_kc_list` ON `tbl_event_history`.`eh_kc_list_id` = `tbl_kc_list`.`kl_id`
    LEFT JOIN `tbl_kc_content` ON `tbl_kc_list`.`kl_kc_id` = `tbl_kc_content`.`kc_id`
    LEFT JOIN `tbl_knowledge_center` ON `tbl_kc_content`.`kc_prg_id` = `tbl_knowledge_center`.`prg_id`
    LEFT JOIN `tbl_user` ON `tbl_event_history`.`eh_u_id` = `tbl_user`.`id`
    LEFT JOIN `tbl_user_login_history` ON `tbl_event_history`.`eh_ul_id` = `tbl_user_login_history`.`ulh_id`
    EOT;*/

	//t_ts => total time spent
	//t_mdl => total modules
	//a_mdl => array of modules
	$t_ts_m = $t_ts_h = $t_mdl_learnt = $t_mdl_total = $p_modules_learnt = $t_ppl = 0;
	$a_mdl_learnt = [];
	$a_mdl_ts = [];
	$t_ts_male_m = $t_ts_male_h = $t_ts_female_m = $t_ts_male_h = 0;
	$a_ts_male = $a_ts_female = [];
	$a_mdl_cat = $a_mdl_cat_video = $a_mdl_cat_article = $a_mdl_cat_book = [];

	if ($result = mysqli_query($dbconnect, "SELECT COUNT(DISTINCT kc_title) AS total FROM tbl_kc_content;")) {
		while ($row = mysqli_fetch_assoc($result)) {
			$t_mdl_total = $row['total'];
		}
		// Free result set
		mysqli_free_result($result);
	}

	$querysa = "SELECT * FROM `tbl_event_history` ";
	$querysa .= " LEFT JOIN `tbl_kc_list` ON `tbl_event_history`.`eh_kc_list_id` = `tbl_kc_list`.`kl_id` ";
	$querysa .= " LEFT JOIN `tbl_kc_content` ON `tbl_kc_list`.`kl_kc_id` = `tbl_kc_content`.`kc_id` ";
	$querysa .= " LEFT JOIN `tbl_knowledge_center` ON `tbl_kc_content`.`kc_prg_id` = `tbl_knowledge_center`.`prg_id` ";
	$querysa .= " LEFT JOIN `tbl_user` ON `tbl_event_history`.`eh_u_id` = `tbl_user`.`id` ";
	$querysa .= " LEFT JOIN `tbl_user_login_history` ON `tbl_event_history`.`eh_ul_id` = `tbl_user_login_history`.`ulh_id` ";
	$querysa .= " INNER JOIN `tbl_organization` ON `tbl_organization`.`id` = `tbl_user`.`organization_id` ";

	$querywhere = " WHERE `eh_cori` = 'content' ";

	//$this->db->where('eh_cori','content');
	if ($user_id != 'ALL') {
		//$this->db->where('eh_u_id', $user_id);
		$querywhere = $querywhere . " AND eh_u_id = " . $user_id . " ";
	}
	//$this->db->order_by('organization', 'asc');
	//$res=$this->db->get()->result();
	//echo $this->db->last_query();die;

	$querysa1 = $querysa . $querywhere . " ORDER BY `organization` ASC;";

	$newline = "\n";
	$newtab = "\t";
	$columnHeader = "" . $newtab . $newtab . $newtab . "Analytical Report" . $newtab . "" . "\t \n \n";
	$columnHeader = $columnHeader . "Sl.NO" . $newtab . "Date" . $newtab . "User ID" . $newtab . "First Name " . "$newtab" . "Last Name" . "$newtab" . "Email ID" . "$newtab" . "Phone No" . "$newtab" . "Organization" . "$newtab" . "Sex" . "$newtab" . "Age" . "$newtab" . "Linked IN" . "$newtab" . "Twitter" . "$newtab" . "Date" . "$newtab" . "Login Time" . "$newtab" . "Logout Time" . "$newtab" . "Page Name" . "$newtab" . "Links" . "$newtab" . "Page Link Open Time" . "$newtab" . "Module" . "$newtab" . "\t \n";
	$setData = '';

	if ($result = mysqli_query($dbconnect, $querysa1)) {
		$old_id = 0;
		$i = 0;
		while ($row = mysqli_fetch_object($result)) {
			$age = $row->age == "1" ? '21-36' : ($row->age == "2" ? '37-50' : '50+');
			if ($old_id != $row->eh_ul_id) {
				$i++;
                $t_ppl++;
				$Startdate = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
				$Starttime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_start_time)));
				$endtime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_end_time)));
				$createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
				$date = date('Y-m-d', strtotime('+0 minutes', strtotime($row->ulh_start_time)));
				$setData = $setData . "$i" . $newtab . date('Y-m-d', strtotime($Startdate)) . $newtab . "E2E" . sprintf("%06d", $row->id) . $newtab . "$row->name" . "$newtab" . "$row->last_name" . "$newtab" . "$row->email" . "$newtab" . "$row->contact" . "$newtab" . "$row->organization" . "$newtab" . "$row->gender" . "$newtab" . "$age" . "$newtab" . "$row->linkedin" . "$newtab" . "$row->twitter" . "$newtab" . "$date" . "$newtab" . "$Starttime" . "$newtab" . "$endtime" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";

				$start_date = new DateTime($Startdate);
				$ts = $start_date->diff(new DateTime($endtime));
				$t_ts_m += $ts->m;
				$t_ts_h += $ts->h;
				//var_dump($since_start, $t_ts);

				if (!array_key_exists($row->kc_title, $a_mdl_ts)) {
					$a_mdl_ts[$row->kc_title] = (float) $ts->m;
				} else {
					$a_mdl_ts[$row->kc_title] = $a_mdl_ts[$row->kc_title] + (float) $ts->m;
				}
				
                if (!array_key_exists($row->kl_cat, $a_mdl_cat)) {
                  $a_mdl_cat[$row->kl_cat] = 1;
                } else {
                  $a_mdl_cat[$row->kl_cat] = $a_mdl_cat[$row->kl_cat] + 1;
                }

				if ($row->gender == 'male') {
					if (!array_key_exists($row->eh_ul_id, $a_ts_male)) {
						$a_ts_male[$row->eh_ul_id] = (float) $ts->m;
					} else {
						$a_ts_male[$row->eh_ul_id] = $a_ts_male[$row->eh_ul_id] + (float) $ts->m;
					}
				} else {
					if (!array_key_exists($row->eh_ul_id, $a_ts_female)) {
						$a_ts_female[$row->eh_ul_id] = (float) $ts->m;
					} else {
						$a_ts_female[$row->eh_ul_id] = $a_ts_female[$row->eh_ul_id] + (float) $ts->m;
					}
				}
			} else {
				if ($old_id1 != $row->kc_title) {
					$createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
					$setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";
					$t_mdl_learnt++;
					//var_dump($old_id1, $row->kc_title);
					if (!array_key_exists($row->kc_title, $a_mdl_learnt)) {
						$a_mdl_learnt[$row->kc_title] = 1;
					} else {
						$a_mdl_learnt[$row->kc_title] = $a_mdl_learnt[$row->kc_title] + 1;
					}
				} else {
					$createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
					$setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "\n";
				}
			}
			$old_id = $row->eh_ul_id;
			$old_id1 = $row->kc_title;
		}
		// Free result set
		mysqli_free_result($result);

		
            /* org data -start */
            $t_ts_m_ind = $t_ts_h_ind = $t_ppl_ind = 0;
            $a_mdl_ts_ind = [];
            $a_mdl_learnt_ind = [];
            $t_mdl_learnt_ind = 0;
			$old_id1 = '';
			
			$querysa2 = $querysa . " AND  eh_u_id != " . $user_id . " AND organization_id=" . $organization_id . " ORDER BY `organization` ASC;";

			if ($resultind = mysqli_query($dbconnect, $querysa2)) {
              $old_id = 0;
              $i = 0;
              while ($row = mysqli_fetch_object($resultind)) {
                //var_dump($row);
                $age = $row->age == "1" ? '21-36' : ($row->age == "2" ? '37-50' : '50+');
                if ($old_id != $row->eh_ul_id) {
                  $i++;
                  $t_ppl_ind++;
                  $Startdate = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                  $Starttime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_start_time)));
                  $endtime = date(' H:i:s', strtotime('+330 minutes', strtotime($row->ulh_end_time)));
                  $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                  $date = date('Y-m-d', strtotime('+0 minutes', strtotime($row->ulh_start_time)));
                  $setData = $setData . "$i" . $newtab . date('Y-m-d', strtotime($Startdate)) . $newtab . "E2E" . sprintf("%06d", $row->id) . $newtab . "$row->name" . "$newtab" . "$row->last_name" . "$newtab" . "$row->email" . "$newtab" . "$row->contact" . "$newtab" . "$row->organization" . "$newtab" . "$row->gender" . "$newtab" . "$age" . "$newtab" . "$row->linkedin" . "$newtab" . "$row->twitter" . "$newtab" . "$date" . "$newtab" . "$Starttime" . "$newtab" . "$endtime" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";

                  $start_date = new DateTime($Startdate);
                  $ts = $start_date->diff(new DateTime($endtime));
                  $t_ts_m_ind += $ts->m;
                  $t_ts_h_ind += $ts->h;
                  //var_dump($since_start, $t_ts);

                  if (!array_key_exists($row->kc_title, $a_mdl_ts_ind)) {
                    $a_mdl_ts_ind[$row->kc_title] = (float) $ts->m;
                  } else {
                    $a_mdl_ts_ind[$row->kc_title] = $a_mdl_ts_ind[$row->kc_title] + (float) $ts->m;
                  }
                } else {
                  if ($old_id1 != $row->kc_title) {
                    $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                    $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kc_title" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "$row->prg_name" . "\n";
                    $t_mdl_learnt_ind++;
                    //var_dump($old_id1, $row->kc_title);
                    if (!array_key_exists($row->prg_name, $a_mdl_learnt_ind)) {
                      $a_mdl_learnt_ind[$row->prg_name] = 1;
                    } else {
                      $a_mdl_learnt_ind[$row->prg_name] = $a_mdl_learnt_ind[$row->prg_name] + 1;
                    }
                  } else {
                    $createdat = date('Y-m-d H:i:s', strtotime('+330 minutes', strtotime($row->eh_created_at)));
                    $setData = $setData . "" . $newtab . "" . $newtab . "" . $newtab . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "" . "$newtab" . "$row->kl_list" . "$newtab" . "$createdat" . "$newtab" . "\n";
                  }
                }
                $old_id = $row->eh_ul_id;
                $old_id1 = $row->kc_title;
			  }
			  
				mysqli_free_result($resultind);
			}
			
            /* org data -end */

		$cntdata = array(
			'Article' => (isset($a_mdl_cat['Article']) ? ($a_mdl_cat['Article']) : 0),
			'Video' => (isset($a_mdl_cat['Video']) ? ($a_mdl_cat['Video']) : 0),
			'Assessment' => (isset($a_mdl_cat['Assessment']) ? ($a_mdl_cat['Assessment']) : 0),
			'Booksuggestion' => (isset($a_mdl_cat['Booksuggestion']) ? ($a_mdl_cat['Booksuggestion']) : 0)
		);
		
		$t_mdl_learnt = count($a_mdl_learnt);
		$tperc = (($t_mdl_learnt / (float) $t_mdl_total) * 100);
		$p_modules_learnt = number_format($tperc, 2, '.', '');
		//var_dump($t_mdl_learnt, $t_mdl_total, $p_modules_learnt, $tperc);

		// Top 3 modules by count
		arsort($a_mdl_learnt);
		$a_mdl_top3 = array_reverse(array_slice($a_mdl_learnt, 0, 3));
		arsort($a_mdl_top3);

		// Top 3 modules by time spent
		arsort($a_mdl_ts);
		$a_mdl_ts_top3 = array_reverse(array_slice($a_mdl_ts, 0, 3));
		arsort($a_mdl_ts_top3);

		// Top 3 time spen male
		arsort($a_ts_male);
		$a_ts_male_top3 = array_reverse(array_slice($a_ts_male, 0, 3));
		arsort($a_ts_male_top3);

		// Top 3 time spen female
		arsort($a_ts_female);
		$a_ts_female_top3 = array_reverse(array_slice($a_ts_female, 0, 3));
		arsort($a_ts_female_top3);

		$t_ts_gw = array('male' => array(
			'min' => (count(array_slice($a_ts_male, (count($a_ts_male) - 1), 1)) > 0 ? array_slice($a_ts_male, (count($a_ts_male) - 1), 1)[0] : 0),
			'max' => (count(array_slice($a_ts_male, 0, 1)) > 0 ? array_slice($a_ts_male, 0, 1)[0] : 0),
			'avg' => (count($a_ts_male) > 0 ? round(array_sum($a_ts_male) / count($a_ts_male), 2) : 0),
		), 'female' => array(
			'min' => (count(array_slice($a_ts_female, (count($a_ts_female) - 1), 1)) > 0 ? array_slice($a_ts_female, (count($a_ts_female) - 1), 1)[0] : 0),
			'max' => (count(array_slice($a_ts_female, 0, 1)) > 0 ? array_slice($a_ts_female, 0, 1)[0] : 0),
			'avg' => (count($a_ts_female) > 0 ? round(array_sum($a_ts_female) / count($a_ts_female), 2) : 0),
		));
		
		$tt_mdl_total = (count($a_mdl_learnt) > 0 ? count($a_mdl_learnt) : 0) + (count($a_mdl_learnt_ind) > 0 ? count($a_mdl_learnt_ind) : 0);
		$t_mdl_learnt_avg = ($tt_mdl_total == 0 ? 0 : round(((count($a_mdl_learnt) > 0 ? count($a_mdl_learnt) : 0) * 100 / $tt_mdl_total), 0));
		$t_mdl_learnt_ind_avg = ($tt_mdl_total == 0 ? 0 : round(((count($a_mdl_learnt_ind) > 0 ? count($a_mdl_learnt_ind) : 0) * 100 / $tt_mdl_total), 0));
		//var_dump(count($a_mdl_learnt), count($a_mdl_learnt_ind), $t_mdl_learnt_avg, $t_mdl_learnt_ind_avg);
	}
	/*header("Content-type: application/octet-stream");
    header("Content-Disposition: attachment; filename=Analytical Report.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
    echo ucwords($columnHeader) . $setData . "\n";die;*/

	//var_dump($t_ts_m , $t_ppl, $t_ts_m_ind , $t_ppl_ind, round($t_ts_m / $t_ppl,0), round($t_ts_m_ind / $t_ppl_ind,0))

	/* analytics -end */
	?>

	<div class=" page-dark">
		<div class="row">
			<div class="col-md-12"><br>
				<h2 class="text-center">Welcome <?php echo $_SESSION['user_name']; ?></h2><br>
			</div>
		</div>

		<div class="row">
			<div class="col-md-6">
				<div class="panel">
					<div class="panel-heading text-center">
						<h4>ONLINE LEARNING (<?php echo $org_name ?>)</h4>
					</div>
					<div class="panel-body">
						<div class="row clearfix">
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
								<div class="info-box infbv bg-pink hover-expand-effect">
									<div class="icon"><i class="fa fa-files-o"></i></div>
									<div class="content">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?= $cntdata['Article'] ?>"><?= $cntdata['Article'] ?></div>
										<div class="text">ARTICLES</div>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
								<div class="info-box infbv bg-cyan hover-expand-effect">
									<div class="icon"><i class="fa fa-video-camera"></i></div>
									<div class="content">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?= $cntdata['Video'] ?>"><?= $cntdata['Video'] ?></div>
										<div class="text">VIDEOS</div>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
								<div class="info-box infbv bg-light-green hover-expand-effect">
									<div class="icon"><i class="fa fa-check-square-o"></i></div>
									<div class="content">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?= $cntdata['Assessment'] ?>"><?= $cntdata['Assessment'] ?></div>
										<div class="text">ASSESSMENTS</div>
									</div>
								</div>
							</div>
							<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
								<div class="info-box infbv bg-orange hover-expand-effect">
									<div class="icon"><i class="fa fa-book"></i></div>
									<div class="content">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?= $cntdata['Booksuggestion'] ?>"><?= $cntdata['Booksuggestion'] ?></div>
										<div class="text">BOOK SUGGESTIONS</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-6">
				<div class="panel">
					<div class="panel-heading text-center">
						<h4>MY LEARNING REPORT</h4>
					</div>
					<div class="panel-body">
						<div class="row clearfix">
                          <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <span class="icn bg-yellow">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small>YOUR LEARNING</small>&nbsp;
                            <span class="icn bg-purple">&nbsp;&nbsp;&nbsp;&nbsp;</span>&nbsp;<small>PEERS LEARNING</small>
                          </div>
							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="info-box bg-transparent hover-expand-effect no-margin">
									<div class="icon"><i class="fa fa-clock-o"></i></div>
									<div class="content full-width">
										<div class="text col-white">TOTAL TIME SPENT</div>
										<div class="progress col-transparent">
											<div class="progress-bar bg-yellow" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round($t_ts_m / $t_ppl,0) ?>%"><span><?php echo round($t_ts_m,0) ?> Minutes</span></div>
										</div>
										<div class="progress col-transparent">
											<div class="progress-bar bg-purple" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo round($t_ts_m_ind / $t_ppl_ind,0) ?>%"><span><?php echo round($t_ts_m_ind,0) ?> Minutes</span></div>
										</div>
									</div>
								</div>
							</div>

							<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
								<div class="info-box bg-transparent hover-expand-effect no-margin">
									<div class="icon"><i class="fa fa-building-o"></i></div>
									<div class="content full-width">
										<div class="text col-white">TOTAL MODULES LEARNT</div>
										<div class="progress col-transparent">
											<div class="progress-bar bg-yellow" role="progressbar" aria-valuenow="" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $t_mdl_learnt_avg ?>%"><span><?php echo $t_mdl_learnt_avg ?></span></div>
										</div>
										<div class="progress col-transparent">
											<div class="progress-bar bg-purple" role="progressbar" aria-valuenow="" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo $t_mdl_learnt_ind_avg ?>%"><span><?php echo $t_mdl_learnt_ind_avg ?></span></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row clearfix">
			<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">
				<div class="panel">
					<div class="panel-body text-center">
						<div class="info-box infbv infb-ml2 bg-light-green hover-expand-effect">
							<div class="icon"><i class="fa fa-building-o"></i></div>
							<div class="content">
								<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="<?= $t_mdl_learnt ?>"><?= $t_mdl_learnt ?></div>
							</div>
						</div>
					</div>
					<div class="panel-footer no-border">
						<h4 class="text-center">MODULES</h4>
					</div>
				</div>
			</div>
			<div class="col-lg-10 col-md-10 col-sm-10 col-xs-12">
				<div class="row">
					<div class="col-md-6">
						<div class="panel">
							<div class="panel-body">
								<div class="row clearfix">
									<?php foreach ($a_mdl_ts_top3 as $km => $module) : ?>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<div class="info-box1 infb-hl1 hover-expand-effect">
												<div class="content">
													<div class="text list-item" title="<?php echo ($module / 60) . 'hours'; ?>"><?php echo $km; ?></div>
												</div>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							</div>
							<div class="panel-footer no-border">
								<h4 class="text-center">Your Top Module Learnt</h4>
							</div>
						</div>
					</div>

					<div class="col-md-6">
						<div class="panel">
							<div class="panel-body">
								<div class="row clearfix">
									<?php foreach ($a_mdl_top3 as $km => $module) : ?>
										<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
											<div class="info-box1 infb-hl1 hover-expand-effect">
												<div class="content">
													<div class="text list-item"><?php echo $km; ?></div>
												</div>
											</div>
										</div>
									<?php endforeach; ?>
								</div>
							</div>
							<div class="panel-footer no-border">
								<h4 class="text-center">Top 3 Modules Learnt</h4>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>

		<div class="row clearfix">
			<hr>
			<div class="col-md-12">
				<div class="panel">
					<div class="panel-heading">
						<h4 class="text-center text-capital">SUGGESTED MODULES BASED ON YOUR PROFILE AND READING HABITS</h4>
					</div>
					<div class="panel-body">
						<div class="row clearfix">
							<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
								<div class="info-box infbv bg-light-green hover-expand-effect">
									<div class="icon"><i class="fa fa-clock-o"></i></div>
									<div class="content">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="243">TIME MANAGEMENT</div>
										<div class="text">BENEFITS O TIME MANAGEMENT</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
								<div class="info-box infbv bg-light-green hover-expand-effect">
									<div class="icon"><i class="fa fa-building-o"></i></div>
									<div class="content">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="243">FIRST TIME MANAGERS</div>
										<div class="text">APPRECIATING THE BIG ROLE OF SMALL BUSINESSES</div>
									</div>
								</div>
							</div>
							<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
								<div class="info-box infbv bg-light-green hover-expand-effect">
									<div class="icon"><i class="fa fa-building-o"></i></div>
									<div class="content">
										<div class="number count-to" data-fresh-interval="20" data-from="0" data-speed="1000" data-to="243">EFFECTIVE COMMUNICATION</div>
										<div class="text">OVERCOME STAGE FRIGHT</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>

			</div>
		</div>

		<div class="clearfix">
			<hr>
		</div>

		

	</div>
<?php
}
?>
<?php //include 'footer.php'; ?>
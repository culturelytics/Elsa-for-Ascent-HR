<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">TIME MANAGEMENT</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	Time management is the process of planning and exercising conscious control over the amount of time spent on specific activities, especially to increase effectiveness, efficiency or productivity.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	TIME MANAGEMENT
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">Time Management</p>
		<ul class="cs-ui">
			<li><a href="https://en.wikipedia.org/wiki/Time_management" target="_blank">What is time Management?</a></li>
			<li><a href="http://www.time-management-success.com/time-management-in-the-workplace.html" target="_blank">Time Management in the Workplace: How to Run Your Day</a></li>
			<li><a href="http://www.managementstudyguide.com/effective-time-management-workplace.htm" target="_blank">How to Practice Effective Time Management at Workplace</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Tips for time management</p>
		<ul class="cs-ui">
			<li><a href="https://www.forbes.com/sites/francesbooth/2014/08/28/30-time-management-tips/#6f3b550875e5" target="_blank">30 Time Management Tips For Work-Life Balance</a></li>
			<li><a href="http://www.studygs.net/workplace/timman.htm" target="_blank">Ten applications of time management
for the workplace</a></li>
			<li><a href="http://www.creativitypost.com/create/work_smarter_not_harder_21_time_management_tips_to_hack_productivity" target="_blank">Work Smarter, Not Harder: 21 Time Management Tips to Hack Productivity</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Importance of Time management</p>
		<ul class="cs-ui">
			<li><a href="http://www.evoliatraining.co.uk/public/The_importance_of_time_management_in_the_workplace.cfm" target="_blank">The importance of time management in the workplace-Evolia training</a></li>
			<li><a href="https://www.appointment-plus.com/blog/why-time-management-is-important" target="_blank">Why Time Management Is Important</a></li>
			<li><a href="http://www.managementstudyguide.com/time-management-in-corporates.htm" target="_blank">Time Management in Corporates - Need and its Importance</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Benefits of Time Management</p>
		<ul class="cs-ui">
			<li><a href="http://www.managementstudyguide.com/time-management-benefits.htm" target="_blank">Benefits of Time Management</a></li>
			<li><a href="https://content.wisestep.com/top-advantages-disadvantages-time-management/" target="_blank">Top 18 Advantages and Disadvantages of Time Management</a></li>
			<li><a href="http://www.career-success-for-newbies.com/why-is-time-management-important.html" target="_blank">Why Is Time Management Important? Here Are 9 Quick Reasons</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Examples of Time Management</p>
		<ul class="cs-ui">
			<li><a href="https://www.youtube.com/watch?v=go5XyuI7DkA&spfreload=5" target="_blank">How to Manage Time With 10 Tips That Work(video)</a></li>
			<li><a href="http://www.asianefficiency.com/case-studies/time-management-case-study-busy-business-people/" target="_blank">Time Management Case Study - Busy Business People</a></li>
			<li><a href="https://www.youtube.com/watch?v=58FyJOVh3pk" target="_blank">Time Management Case Study - Good MSE608B (video)</a></li>
		</ul>
		</div>

									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">



	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/becoming-the-1.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.amazon.com/Becoming-The-1-Productivity-ebook/dp/B00AAESF3U/ref=zg_bs_154838011_2" target="_blank">Becoming the 1% and Rise to the Top in 7 Days:Dennis Crosby</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/getting-things-done.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.amazon.com/Getting-Things-Done-Productivity-ebook/dp/B000WH7PKY/ref=zg_bs_154838011_1" target="_blank">Getting Things Done: The Art of Stress-Free Productivity:David Allen</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/the-checklist.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://www.amazon.com/The-Checklist-Manifesto-Things-ebook/dp/B0030V0PEW/ref=zg_bs_154838011_6" target="_blank">The Checklist Manifesto: How to Get Things Right:Atul Gawande</a></p>
	</div>
	</div>



	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
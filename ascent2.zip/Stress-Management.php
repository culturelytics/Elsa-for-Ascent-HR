<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>

<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">STRESS MANAGEMENT</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	Stress management is a wide spectrum of techniques and psychotherapies aimed at controlling a person's level of stress, especially chronic stress, usually for the purpose of improving everyday functioning.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	STRESS MANAGEMENT
	</div>
	<div class="cs-left">


		<div class="info-n">
		<p class="abt-sub-titles ab">Introduction</p>
		<ul class="cs-ui">
			<li><a href="https://caps.byu.edu/node/515" target="_blank">Introduction to Stress Management</a></li>
			<li><a href="http://www.drkidder.com/cgi-bin/rtsys/sbpg/rt_hdln_dsply2.cgi?Autoincrement=000009&value_6=Stress+Management" target="_blank">Dr. David Kidder- Introduction to Stress Management</a></li>
			<li><a href="http://stresscourse.tripod.com/id9.html" target="_blank">Stress Management for Health Course-Stress - Introduction</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Definition</p>
		<ul class="cs-ui">
			<li><a href="https://en.wikipedia.org/wiki/Stress_management" target="_blank">What is Stress Management?</a></li>
			<li><a href="https://www.psychologistworld.com/stress/stress-management" target="_blank">Stress Management- Psychologist World</a></li>
			<li><a href="http://kalyan-city.blogspot.in/2011/03/what-is-stress-meaning-definition-and.html" target="_blank">Stress- Meaning & Definition</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Types</p>
		<ul class="cs-ui">
			<li><a href="https://www.healthline.com/health/whats-your-stress-type#overview1" target="_blank">What's your Stress Type? (Overview 1)</a></li>
			<li><a href="http://www.apa.org/helpcenter/stress-kinds.aspx" target="_blank">Stress- Kinds</a></li>
			<li><a href="https://www.verywell.com/types-of-stress-and-stress-relief-techniques-3144482" target="_blank">Types of Stress and Stress Relief Techniques</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Stress at the workplace</p>
		<ul class="cs-ui">
			<li><a href="https://www.headsup.org.au/healthy-workplaces/workplace-stressors" target="_blank">Managing Stress at work </a></li>
			<li><a href="http://www.apa.org/helpcenter/work-stress.aspx" target="_blank">Coping with Stress at work</a></li>
			<li><a href="https://theundercoverrecruiter.com/strategies-to-manage-stress/" target="_blank">Strategies to manage Stress</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Causes</p>
		<ul class="cs-ui">
			<li><a href="https://www.webmd.com/balance/stress-management/stress-management-causes-of-stress" target="_blank">Stress Management-causes of stress</a></li>
			<li><a href="https://www.psychologistworld.com/stress/ten-causes-of-stress-how-to-avoid-them" target="_blank">Ten causes of stress and how to avoid them-Psychologist World</a></li>
			<li><a href="https://www.mayoclinic.org/healthy-lifestyle/stress-management/in-depth/stress-management/art-20044151?pg=1" target="_blank">Stress management: Know your triggers</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Techniques</p>
		<ul class="cs-ui">
			<li><a href="https://bebrainfit.com/stress-management-techniques/" target="_blank">Stress Management techniques</a></li>
			<li><a href="https://www.rd.com/health/wellness/stress-management-tips/" target="_blank">Tips for Stress Management</a></li>
			<li><a href="https://www.psychologytoday.com/blog/thrive/201206/4-easy-stress-management-strategies" target="_blank">4 easy stress management Strategies</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Benefits</p>
		<ul class="cs-ui">
			<li><a href="https://psychcentral.com/lib/the-benefits-of-stress-management/" target="_blank">Benefits of Stress Management-Psych Central​</a></li>
			<li><a href="http://www.employee-motivation-skills.com/stress-management-in-the-workplace.html" target="_blank">Stress Management in the Workplace-Employee Motivation Skills</a></li>
			<li><a href="https://www.forbes.com/sites/lisaquast/2011/09/26/the-importance-of-proactively-managing-workplace-stress/#297038a662ee" target="_blank">The importance of proactively managing workplace stress</a></li>
		</ul>
		</div>

									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">



	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/the-art-of-stress-free.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="http://gettingthingsdone.com/" target="_blank">Getting Things Done Book by David Allen</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/stress-management.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="#">Stress Management 
A Wellness Approach
By Nanette E. Tummers </a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/the-upside-of-stress.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="#">The Upside of Stress by Kelly McGonigal, PhD</a></p>
	</div>
	</div>



	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
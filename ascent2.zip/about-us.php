<?php include_once('connectdb.php'); ?>
<!doctype html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <title>Culture Assessment firm|e2e</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="e2e People Practices believes that your business grows through the people that it comprises of. We offer to help build on this resource that will help your business flourish">

        <meta name="keywords" content="Training Audit,Training Effectiveness Assessment,Train the Trainer,Transformational Leadership Workshop,Management Development Program,Developmental Training,Transitional Skills Training,Outbound Training,Competency Mapping,HR Consulting Services,Mergers and Acquisiions">

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="author" href="https://plus.google.com/yourpersonalprofile">
        <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
        <link href="css/css.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">

    <link rel="stylesheet" href="css/m/font-awesome.min.css">
    <link rel="stylesheet" href="css/m/animate.min.css">
    <link rel="stylesheet" href="css/m/default.min.css">
    <link rel="stylesheet" href="css/m/demo.css">
    <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
    <link rel="shortcut icon" href="images/fav_e2e2.ico" />
    <script src="js/m/modernizr.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 


    </head>
    <body>

    <div class="comn-bg">

<div class="container" style="background:url('images/s1.jpg');">
<div class="col-lg-12  col-sm-12 col-xs-12 header-pdng all-border-btm"> 
        <div class="col-lg-4 col-sm-12 col-xs-12 center-below-992" style="">
                <a href="index.php">
                    <img src="<?php echo $pri_logo ?>"  class="header-logo" alt="image">
                </a>
        </div>

<div class="col-lg-8  col-sm-12 col-xs-12 li-details header-strip " style="margin-top: 15px;">
     
     <div class="col-lg-1"></div>

<div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <span class="ar" style="color:red" >Quick Contact : </span>+91 80 41155269
</div>

<div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <span class="ar" style="color:red">Mail To : </span><a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a>
</div>

<div class="col-lg-2  col-sm-6 col-xs-6 nav-li li-login" style="margin-top: 10px;padding-left: 0px">
   <!-- <a href="login.php" class="login-btn">Log In</a> -->
   <?php
session_start();
if(!isset($_SESSION["sess_email"])){
  ?>
  <a href="login.php" class="login-btn">Log In</a>
  
  <?php 
}
else
{
?>
   <a href="logout.php" class="login-btn">Logout</a>
   <?php
}
?>
</div>
            
<div class="col-lg-1  col-sm-6 col-xs-6 toggle-menu right0-abv768">
    <div class="nav-li-last w3-button w3-xlarge" style="float: right;" onclick="w3_open()">
        <div class="icon"></div>
        <div class="icon"></div>
        <div class="icon"></div>
    </div>        
</div>

</div>   

</div>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>


<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">


<h2 class="ar career-title text-center">ABOUT US</h2>
<hr class="line-75">

 <div id="wrapper">
    <div id="page-content-wrapper">
      <div class="container-fluid">
        <div class="row component-wrapper">

          <div class="col-lg-3" style="padding:0">
            <ul class="nav nav-tabs tabs-left" style="margin-bottom: 20px;">
              <li class="nav-title "><span class="ab">About Us</span></li>
              <li><a href="#one" data-toggle="tab" class="ab">Mergers and Acquisitions</a></li>
              <li><a href="#two" data-toggle="tab" class="ab">HR Consultancy</a></li>
              <li class="active"><a href="#three" data-toggle="tab" class="ab">LnOD - <span style="font-size: 10px">Learning & Organizational Development</span></a></li>
            </ul>
          </div>

          <div class="col-lg-9">
            <div class="tab-content">


<!--tab-1-->            
              <div class="tab-pane" id="one">
                <div class="container-fluid">
                  <div class="row abt-row-lg-right">
                    <div class="col-lg-12 abt-right-pdng">
                      <!-- <h3 class="ab abt-right-title">Business Alignment :</h3> -->
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
<p class="abt-sub-titles ab" style="margin-top: 0px">Why choose us?</p>
<ol class="merges-ol">
   <li>We will help you mitigate risks and take informed decisions</li>
   <ul style="list-style: inside;">
      <li>with $ impact</li>
      <li>Restructuring (hiring required talent, retaining key people, etc.)</li>
   </ul>
   <li>You get the support of our exclusive framework where experts will help you through the crucial first 300 day integration by leveraging HR Analytics and Predictive Culture Transformation Platform</li>
   <li>We are there to work with you across Geos, across projects, round the clock, helping you with key insights that can change your world…</li>
</ol>
<br>

<div class="wix-1">
<p class="ab">"The right organizational culture and team morale are essential for any company's success. Quite often these softer issues are overlooked especially in merger situations leading to failed outcomes"</p>
<p>Exclusive Quote by Mr. Amit Dixit, Senior Managing Director at Blackstone.</p>
</div>


<!-- <div class="wix-1">
<p class="ab">"In any investment, it's not the size of the cheque but the quality & fit of people that matters”</p>
<p>Exclusive Quote by Mr. Richard Saldanha, Chairperson of Gokuldas Exports, Trans Maldivian Airways. Serves on the boards of several companies, including Bennett, Coleman (Times Group)</p>
</div> -->
<br>
	<div class="col-lg-6 cc2" style="padding-top:10px;">
	<iframe width="560" height="315" src="https://www.youtube.com/embed/8PEN2XnSWzE" frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
     </div>					  
<!--<a href="MnA.pdf" target="_blank" class="btn login-btn">Portfolio</a>-->
   <a href="new mnadeck.pdf" target="_blank" class="btn login-btn" style="margin-top: 350px;margin-left:-380px;">Portfolio</a>
	<a href="brochure.pdf" target="_blank" class="btn login-btn" style="margin-top: 350px;">Brochure</a>
						  
                      </div>
                    </div>
                  </div>
                </div>
              </div>
        

<!--tab-2-->                
              <div class="tab-pane" id="two">
                  <div class="container-fluid">
                  <div class="row abt-row-lg-right">
                    <div class="col-lg-12 abt-right-pdng">
<h4 class="ab">HR CONSULTING SERVICES</h4>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/hr-consultng.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>Our services cover :</p>
         <ol class="services-ol" style="margin-bottom: 10px">
            <li>Policies (Regulatory & Business Aligned)</li>
            <li>End to End support on Employee Alignment</li>
            <li>Climate Studies & Engagement Surveys</li>
            <li>Business Coaching for High Performers / Senior Leaders</li>
            <li>Competency Mapping</li>
            <li>Performance Management Design and Implementation Support</li>
            <li>People CMM</li>
         </ol>
          </div>
          </div>



<p class="ab abt-sub-titles">1. Policies (Regulatory & Business Alignment)</p>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
       <div class="col-lg-3">
         <img class="img-150" src="images/about-us/business-align.png" style="margin-top: 10px" alt="image">
      </div>
        <div class="col-lg-9">
          <p>The alignment of the management's strategic intent, business objectives and the practices of the organisation dramatically increase energy levels in an organisation.</p>
          <p>Through a careful study of the organisation's practices and its structure we help develop and align critical organisation practices, strengthen and deepen culture that results in delivery excellence.</p>
          <p>Our solutions in the field of Organization Development help address important priorities in the organization and we help through our service offerings which include Culture Outsourcing, Bench Management, Competency Mapping & Development and Quantifiable Performance Management Systems, Balance Scorecard.</p>
          <p>Our alignment initiatives result in the creation of a self aligned, dynamic self sustained culture of excellence that distributes leadership and energy throughout the organisation. This achieved through a genuine devolution of HR functions from the department to the line manager.</p>
        </div>
</div>

<p class="ab abt-sub-titles">2. End to End support on Employee Alignment</p>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
       <div class="col-lg-3">
         <img class="img-150" src="images/about-us/employee.png" style="margin-top: 10px" alt="image">
      </div>
        <div class="col-lg-9">
          <p>Aligning employees to the organization’s goals and strategies is essential in realising the vision of the organization. When employee connects to the purpose and vision of the organization, they successfully cope with setbacks and celebrate the successes of the organization, as it grows. e2e's interventions culminate in an enhanced sense of pride within the organisation. This is reflected in the quality of the products and services offered by the organisation over the long term.</p>
          <p>Our offerings include HR Process Audits, Assessments (Assessment Centre), and Behaviour Event Interviews and Employee Alignment and Best Practices Surveys All of these services help us understand the practices that can be adapted to the organisations needs and evolve a strategy to positively impact work place culture.</p>
        </div>
</div>

<p class="ab abt-sub-titles">3. Climate Studies & Engagement Surveys</p>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
       <div class="col-lg-3">
         <img class="img-150" src="images/about-us/Organizational.png" style="margin-top: 10px" alt="image">
      </div>
        <div class="col-lg-9">
         <p>We work as partners in proactively developing, planning and implementing a customized framework in the sphere of organization transformation. This may involve restructuring, redesigning or reinventing an organization’s practices that require changing people's mindset and attitudes. These interventions are done after a careful and thorough study of the organization, its vision, beliefs and practices, policies, systems and processes.</p>
        </div>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
      <div class="col-lg-3">
         <img class="img-150" src="images/about-us/best-practice.png" alt="image">
      </div>
        <div class="col-lg-9">
         <p>We have a number of surveys on HR Best Practices followed in specific industries and some of our surveys encompass unique subjects. The latest study dealt with the recent trends in Indian and Multi-National Companies on the special care they provide to their Women Executives.</p>
        </div>
  </div>
</div>

<p class="ab abt-sub-titles">4. Business Coaching for High Performers / Senior Leaders</p>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
       <div class="col-lg-3">
         <img class="img-150" src="images/about-us/employee-align.png" style="margin-top: 10px" alt="image">
      </div>
        <div class="col-lg-9">
          <p>Employee Engagement or Work Engagement is a concept that is viewed as managing discretionary effort. It studies the engagement level of the employees’ since High levels of employee engagement correlates to individual, group and corporate performance in areas such as retention, turnover, productivity, customer service and loyalty, whereas, actively disengaged employees are less productive, less profitable, less likely to provide excellent customer service and are often disruptive.</p>
          <p>Employee Satisfaction helps the company maintain standards & increase productivity. Our surveys help identify factors that satisfy and motivate the employees to increase their efficiency and productivity.</p>
          <p>We offer the engagement and satisfaction surveys with a multistage approach that is not limited only to a written survey but also involves personal interviews and focus group discussions with a sample to understand the holistic improvement needed.</p>
        </div>
</div>

<p class="ab abt-sub-titles">5. Competency Mapping</p>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
       <div class="col-lg-3">
         <img class="img-150" src="images/about-us/Competency.png" style="margin-top: 10px" alt="image">
      </div>
        <div class="col-lg-9">
          <p>Knowing one’s competencies can give one, a competitive edge in the job market. It is a process through which one’s strengths as an individual worker and in some cases, as part of an organization can be assessed. The value of competency mapping and identifying emotional strengths is in ensuring the position gets an employee with specific competencies, like someone who enjoys taking initiative or someone who is very good at taking direction.</p>
          <p>We have defined competencies for junior, mid and senior level employees in IT/ITes, Infrastructure Development and Energy manufacturing firms. Mapping competencies to the position has helped employees in encouraging themselves to raise their delivery levels.</p>
        </div>
</div>


<p class="ab abt-sub-titles">6. Performance Management Design and Implementation Support</p>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
       <div class="col-lg-3">
         <img class="img-150" src="images/about-us/run.png" style="margin-top: 10px" alt="image">
      </div>
        <div class="col-lg-9">
          <p>It is a systematic process of assessing progress toward achieving predetermined goals, either individually or collectively as teams or departments. Properly designed, such systems help in improving organizational effectiveness by providing a mechanism for feedback while simultaneously communicating priorities and the strategic intent of top management.</p>
          <p>e2e has conducted appraisals for our clients across sectors like construction, IT, facility management. Moreover we have helped smaller firms who have just set up HR departments, evolve appropriate performance management systems on a build own operate and transfer model.</p>
          <p>We have successfully used 360 degree method of evaluation senior management professionals within their teams.</p>
          <p>Our services offerings include developing an effective performance management system, creating job descriptions, defining meaningful and pertinent Key Performance Indicators, and developing Balance Scorecards for the organizations.</p>
        </div>
</div>


<p class="ab abt-sub-titles">7. People CMM</p>
  <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
       <div class="col-lg-3">
         <img class="img-150" src="images/about-us/people-capability.png" style="margin-top: 10px" alt="image">
      </div>
        <div class="col-lg-9">
          <p>People Capability Maturity Model (People CMM) was designed with a purpose to enable a benchmark from the HR function in the IT firms.</p>
          <p>e2e People Practices pioneered P-CMM in non IT sectors in India. We are certified by Carnegie Mellon University to provide the People CMM literature in a regional language to help the non IT firms benefit from this model.</p>
          <p>We have helped firms in diverse industries to bring maturity in their HR functions through the implementation of People CMM the principles.</p>
          <p>Unlike any other firm, our services include helping the organization implement the practices than following a consulting approach.</p>
          <p>The architect of People CMM, Dr. Bill Curtis, acknowledged the step taken by e2e to assist the non IT firm in delivering excellence through their people strategies.</p>
          <p>We have written couple of articles on our experience in implementing the practices of People CMM in the construction industry especially, since this industry in India has begun applying the practices of Human Resource Management from early years of 2000 only. And the experience is vast as the nature of work, the section of employees, employees’ understanding of the human principles, the communication language (needs to be regional) and much more.</p>
        </div>
</div>

                    </div>
                  </div>
                </div>
              </div>
<!--tab-2-end-->
                


<!--tab-3-->                
<div class="tab-pane active" id="three">
<div class="container-fluid">
<div class="row abt-row-lg-right">
  <div class="col-lg-12 abt-right-pdng">

<h4 class="ab">SKILL ENCHANCEMENT</h4>
<div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
  <div class="col-lg-3" style="padding-left: 0px">
      <img class="img-150" src="images/about-us/skill-enhan.png" alt="img" style="margin-top: 10px">
  </div>
<div class="col-lg-9">
<p>e2e aims at providing transformational trainings. Our training offerings are strategically designed to enhance organization effectiveness by developing its human capital to meet the changing business demands and tailor-made offerings.</p>
<p>The unique approach we adopt is Experiential Learning that creates a lasting impact on our audience.</p>
<p>Our understanding of importance of adult learning psychology, good learning design and leveraging the power of various media empowers our programs. We adopt Donald Kirkpatrick Model to deliver excellence in the training cycle.</p>
<p>In addition to facilitating the complete training life cycle for your organization, we also conduct audit of the training division, through Training Effectiveness Assessments.</p>
<p>We conduct a unique Train the Trainer workshops to create in-house experts in the organizations to deliver effective training programs. </p>

         <ol class="services-ol" style="margin-bottom: 10px;margin-top: 10px">
            <li>Training Audit</li>
            <li>Training Effectiveness Assessment</li>
            <li>Train the trainer</li>
            <li>Transformational leadership workshop</li>
            <li>Management Development program</li>
            <li>Development Training</li>
            <li>Transitional Skills Training (Our courses offered) </li>
            <li>Outbound Training</li>
         </ol>
</div>
</div>

<p class="ab abt-sub-titles">1. Training Audit</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/about-us/training-adt.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>Training audit is a health check on the fitness of your training function. It involves reviewing the strategy, the policy (ies), the training need analysis, the evaluation process, the learning designs & materials, the delivery options adopted, capability of the training staff, and any other input that has an impact on the input and output of the function.</p>
                      <p>Depending on the scope of the audit and audit intent, the process we follow uses various data points obtained by using a variety of techniques for data collection such as personal interviews, questionnaire, audit of policies, an assessment of the system(study of processes), and a discussion with the stakeholders of the training function.</p>
                      </div>
                      </div>

                      <p class="ab abt-sub-titles">2. Training Effectiveness Assessment</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/about-us/training-effective.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>Training assessment that we deliver is defined on the Donald Kirkpatrick Model. It aims at adding value to the trainings offered and enhancing the employee skills to benefit the organization.</p>
                      <p>Our customised process benchmarks the audience prior and post the training program. The pre-training benchmarking results help in arriving at training frameworks that relate to actual requirements of the organisation thus enriching the overall experience.</p>
                      </div>
                      </div>

                      <p class="ab abt-sub-titles">3. Train the Trainer</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/about-us/train-the-trainer.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>We conduct workshops on specific subjects to eventually develop an effective trainer. To list a few topics that we typically deliver in Train the Trainer workshops are team building, negotiation skills, time management, interviewing skills and more.</p>
                      <p>Our workshops include ‘mentoring’ as a feature.</p>
                      </div>
                      </div>

                      <p class="ab abt-sub-titles">4. Transformational Leadership Workshop</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/about-us/transformational-leadership.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>A leader’s role is inevitable to drive change and lead higher levels of performance, for which the leader should create a vision to guide the change through inspiration to deliver excellence.</p>
                      <p>We offer workshops on Transformational Leadership that focuses on developing skills to "transform" others. We adopt a variety of strategies to identify and develop the leadership skills. Our latest program was for our Banking customer that included developing fifty odd General Managers & Branch Managers.</p> 
                      </div>
                      </div>

                      <p class="ab abt-sub-titles">5. Management Development Program</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/about-us/management-development.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>This is based on an engagement with the client that would be for a specific term. The program is modelled around the Harvard Management Development Program.</p>
                      <p>The program includes the key skills required by the leader, the characteristics of leadership, how an effective leadership team can be developed and managed, administering change and fostering innovation, developing optimal planning strategies, and other key characteristics of a foremost leader.</p>
                      </div>
                      </div>

                      <p class="ab abt-sub-titles">6. Developmental Training</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/about-us/devlp-training.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>Every organization has an evolution process in the Organization Lifecycle. The requirements at each stage are unique and require focus. Each stage of the lifecycle demands specific skill sets in its employees to deliver excellence to improve the curve.</p>
                      <p>After thorough research we have strategically designed our training offerings enhance organization effectiveness by developing its human capital to meet the changing business demands. We address this need by identifying trainings for specific stages and graduating them within the organization levels.</p>
                      </div>
                      </div>
                      <p class="ab abt-sub-titles">7. Transitional Skills Training</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" alt="image" src="images/about-us/Transitional-skill.png">
                        </div>
                      <div class="col-lg-9">
                      <p>We understand the importance of transition skills and the need for psychological and social context which an individual encounters during transition. Since transition is inevitable, our trainings are well crafted using the methods of self discovery & self mastery to drive change and make it an exceptional yet effective experience.</p>
                      <p>To assist in changing behaviour and delivering consistency, we apply the concepts of social learning theories and systems in mutual agreement with our customers to be a backbone and support the trainees even after the training program. A glimpse on the programs we provide:</p>
                      </div>
                      </div>
                      <div class="col-lg-12" style="margin-top: 10px;margin-bottom: 10px">
                      <div class="col-lg-4">
                        <p  style="color:greenyellow;" class="ab about-sub-text skill-course">Regular Courses</p>
                        <ul class="case-study-ul">
                          <li>Presentation Skills</li>
                          <li>Email Etiquette</li>
                          <li>Conference Call Etiquette</li>
                          <li>Communication Skills</li>
                          <li>Campus to Corporate Workshops </li>
                          <li>Stress Management</li>
                          <li>Time Management </li>
                          <li>Goal Setting</li>
                          <li>Self Motivation</li>
                          <li>Negotiating Skills</li>
                          <li>Interpersonal Relationship </li>
                          <li>Empathy and Listening Skills</li>
                          <li>Assertiveness Training </li>
                          <li>Memory and Focus Creativity and Lateral Thinking</li>
                          <li>MS Suite</li>
                        </ul>
                      </div>

                      <div class="col-lg-4">
                        <p style="color:greenyellow;" class="ab about-sub-text  skill-course">Premium Courses</p>
                        <ul class="case-study-ul">
                          <li>Managing Adversity</li>
                          <li>Speaking with Impact</li>
                          <li>Purposeful Living</li>
                          <li>Tactical Leadership and Mentoring</li>
                          <li>WinWin Negotiation</li>
                          <li>Creative Thinking</li>
                          <li>Problem Solving</li>
                          <li>Leadership and Motivation</li>
                          <li>Management Development</li>
                          <li>Professional Presentation Skills</li>
                          <li>Superior Interpersonal Skills</li>
                          <li>Team Building</li>
                          <li>Train The Trainer</li>
                          <li>Self Awareness and Managing Emotions</li>
                        </ul>
                      </div>

                      <div class="col-lg-4">
                            <p style="color:greenyellow;" class="ab about-sub-text  skill-course">Advanced Courses</p>
                        <ul class="case-study-ul">
                        <li>Advanced Communication</li>
                        <li>Attitude-Your Most Priceless Possession</li>
                        <li>Creating Customer Wow</li>
                        <li>Personal Organization & Self Management</li>
                        <li>Winning The Service Game</li>
                        <li>Business Etiquette Work-Life Balance</li>
                        </ul>
                      </div>

                      </div>

                      <p class="ab abt-sub-titles">8. Outbound Training</p>
                      <div class="col-lg-12 abt-sub-btm-30 mob-no-padng">
                        <div class="col-lg-3">
                          <img class="img-150" src="images/about-us/Outbound-training.png" alt="image">
                        </div>
                      <div class="col-lg-9">
                      <p>In unfamiliar environments and unpredictable situations, stretched beyond the normal comfort zones, people tend to lose their inhibitions, shed their masks and become more receptive to learning. Our trained facilitators help the participants extrapolate the learning from the outdoor activities to their workplace in each session they conduct.</p>
                      <p>We have delivered outbound learning programs to enhance the ability of a heterogeneous group to successfully cope with the challenges in diverse industries like, Creative Product Designing, R&D, IT, Facility Management, Infrastructure Development and more. The subjects that we covered in outbound learning are increasing self & team confidence, conflict resolution, personal and professional effectiveness, interpersonal skills, communication skills, leadership development, change management, to name a few.</p>
                      </div>
                      </div>

  </div>
</div>
</div>
</div>
<!--tab-3-end-->

                
            </div>
          </div>

          <div class="clearfix"></div>

        </div>
      </div>
    </div><!-- /#page-content-wrapper -->
  </div><!-- /#wrapper -->

</div>	

</div>



<?php include('footer.php'); ?>
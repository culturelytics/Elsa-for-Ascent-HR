<?php include('header.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Gallery</title>
	<style>
		.image-source-link {
	color: #98C3D1;
}

.mfp-with-zoom .mfp-container,
.mfp-with-zoom.mfp-bg {
	opacity: 0;
	-webkit-backface-visibility: hidden;
	/* ideally, transition speed should match zoom duration */
	-webkit-transition: all 0.3s ease-out; 
	-moz-transition: all 0.3s ease-out; 
	-o-transition: all 0.3s ease-out; 
	transition: all 0.3s ease-out;
}

.mfp-with-zoom.mfp-ready .mfp-container {
		opacity: 1;
}
.mfp-with-zoom.mfp-ready.mfp-bg {
		opacity: 0.8;
}

.mfp-with-zoom.mfp-removing .mfp-container, 
.mfp-with-zoom.mfp-removing.mfp-bg {
	opacity: 0;
}
	</style>
<script>
	$(document).ready(function() {
	$('.zoom-gallery').magnificPopup({
		delegate: 'a',
		type: 'image',
		closeOnContentClick: false,
		closeBtnInside: false,
		mainClass: 'mfp-with-zoom mfp-img-mobile',
		image: {
			verticalFit: true,
			titleSrc: function(item) {
				return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank">image source</a>';
			}
		},
		gallery: {
			enabled: true
		},
		zoom: {
			enabled: true,
			duration: 300, // don't foget to change the duration also in CSS
			opener: function(element) {
				return element.find('img');
			}
		}
		
	});
});
</script>
</head>
<body>
	<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
	<h2 class="ar career-title text-center">GALLERY</h2>
<hr class="line-75">

	<div class="col-lg-12 mob-no-padng">

<div class="gallery cf">
	<div class="zoom-gallery">
	
	<a href="images/gallery/i1.jpeg"  style="width:193px;height:125px;">
		<img src="images/gallery/i1.jpeg" width="220px" height="200px">
	</a>
	<a href="images/gallery/i2.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/i2.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i3.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/i3.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i4.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/i4.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i5.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/i5.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i6.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/i6.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i7.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/i7.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i8.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/i8.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i9.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/i9.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i10.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/i10.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i11.jpeg" style="width:82px;height:125px;">
		<img src="images/gallery/i11.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i12.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/i12.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i13.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/i13.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i14.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/i14.jpeg" width="220px" height="200px">
	</a>
		<a href="images/gallery/i15.jpeg"  style="width:82px;height:125px;">
		<img src="images/gallery/i15.jpeg" width="220px" height="200px">
	</a>


<ul class="pagination" style="margin-bottom: 0px">
  <li><a href="gallery.php">1</a></li>
  <li><a href="gallery-2.php">2</a></li>
  <li><a href="gallery-3.php">3</a></li>
  <li><a href="gallery-4.php">4</a></li>
  <li><a href="gallery-5.php">5</a></li>
	<li class="active"><a href="gallery-6.php">6</a></li>
	<li><a href="gallery-7.php">7</a></li>
</ul>
</div>
	
		</div>
		</div>
		</div>	
	</div>
</body>
</html
<?php include('footer.php'); ?>

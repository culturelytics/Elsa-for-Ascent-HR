<?php 
include_once('connectdb.php');
include('header-index.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<head>
	<title></title>
	<meta name="sitelock-site-verification" content="5156" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="">
    <meta name="keyword" content="">
<style>
	.small-title:hover{
		-ms-transform: scale(1.1); /* IE 9 */
    -webkit-transform: scale(1.1); /* Safari 3-8 */
		transform: scale(1.1); 
	}
</style>
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script charset="UTF-8" src="//cdn.sendpulse.com/js/push/db8cde1c62db5073de7f1354dfe65ed7_0.js" async></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>


<!--     <section id="content"> -->

<div class="col-lg-12" style="background:url('images/s1.jpg');">

<div class="col-lg-12  col-sm-12 col-xs-12 small-scrn" style="margin-bottom: 50px;">

<div class="col-lg-6 hidden-md hidden-sm hidden-xs">


<div class="customNavigation" style="z-index: 9;
    position: relative;
    top: 15px;">
    <a class="btn gray prev pdng-0" onclick="plusDivs(-1)"><i class="fa fa-chevron-left left-right"></i>
    </a>
    <a class="btn gray next pdng-0 margin-top-10" style="margin-left: 10px;" onclick="plusDivs(1)"><i class="fa fa-chevron-right left-right"></i></a>
  </div>

<div class="w3-content w3-section" style="margin-top: -37px!important;margin-bottom: 37px!important;">

<?php 
   $sql = "SELECT uploadimage, imagelink FROM tbl_images";
    $result = $dbconnect->query($sql);

    while($row = $result->fetch_assoc()) { ?>
        <a href="<?php echo $row['imagelink']; ?>">
            <img class="mySlides" src= "admin/uploads/<?php echo $row['uploadimage']; ?>" style="background-size: 100% 100%;width:100%">
           
        </a>
    <?php }
  ?>

</div>




 <!-- <div class="customNavigation" style="z-index: 9;
    position: relative;
    top: 15px;">
    <a class="btn gray prev pdng-0"><i class="fa fa-chevron-left left-right"></i>
    </a>
    <a class="btn gray next pdng-0 margin-top-10" style="margin-left: 10px;"><i class="fa fa-chevron-right left-right"></i></a>
  </div>
 -->
 <!--   <div id="slider-carousel" class="owl-carousel" style="top: -36px;">

    <a href="mergers-and-acquisition.php">
    <div class="item" style="background-image: url('images/banner-img/Slide1.JPG');background-size: 100% 100%;">
    </div>
    </a>

    <a href="mergers-and-acquisition.php">
    <div class="item" style="background-image: url('images/banner-img/Slide2.JPG');background-size: 100% 100%;">
    </div>
    </a>

    <a href="e2e-library.php">
    <div class="item" style="background-image: url('images/banner-img/Slide3.JPG');background-size: 100% 100%;">
    </div>
    </a>

    <a href="e2e-library.php">
    <div class="item" style="background-image: url('images/banner-img/Slide4.JPG');background-size: 100% 100%;">
    </div>
    </a>

    <a href="http://mailchi.mp/74c35b1f5877/2017-in-a-nutshell-70925" target="blank">
    <div class="item" style="background-image: url('images/banner-img/Slide5.JPG');background-size: 100% 100%;">
    </div>
    </a>

    <a href="about-us.php">
    <div class="item" style="background-image: url(images/banner-img/Slide6.JPG);background-size: 100% 100%;">
    </div>
    </a>

    <a href="about-us.php">
    <div class="item" style="background-image: url(images/banner-img/Slide7.JPG);background-size: 100% 100%;">
    </div>
    </a>
  </div> -->
<!-- <div id="slider-carousel" class="owl-carousel" style="top: -36px;">
  <?php 
   $sql = "SELECT uploadimage, imagelink FROM tbl_images";
    $result = $dbconnect->query($sql);

    while($row = $result->fetch_assoc()) { ?>
        <a href="<?php echo $row['imagelink']; ?>">
            <div class="item" style="background-image: url(admin/uploads/<?php echo $row['uploadimage']; ?>);background-size: 100% 100%;">
            </div>
        </a>
    <?php }
  ?>
</div> -->
 <!-- <div class="customNavigation" style="z-index: 9;
    position: relative;
    top: 15px;">
    <a class="btn gray prev pdng-0" onclick="plusDivs(-1)"><i class="fa fa-chevron-left left-right"></i>
    </a>
    <a class="btn gray next pdng-0 margin-top-10" style="margin-left: 10px;" onclick="plusDivs(1)"><i class="fa fa-chevron-right left-right"></i></a>
  </div> -->

<div class="w3-content w3-section" style="margin-top: -37px!important;margin-bottom: 37px!important;">

<!-- <a href="merges-and-acquisition.php">
  <img class="mySlides" src="images/banner-img/Slide1.JPG" style="width:100%">
</a>

<a href="merges-and-acquisition.php">
  <img class="mySlides" src="images/banner-img/Slide2.JPG" style="width:100%">
</a>

<a href="e2e-library.php">
  <img class="mySlides" src="images/banner-img/Slide3.JPG" style="width:100%">
</a>

<a href="e2e-library.php">
  <img class="mySlides" src="images/banner-img/Slide4.JPG" style="width:100%">
</a>

<a href="http://mailchi.mp/74c35b1f5877/2017-in-a-nutshell-70925" target="blank">
  <img class="mySlides" src="images/banner-img/Slide5.JPG" style="width:100%">
</a>

<a href="about-us.php">
  <img class="mySlides" src="images/banner-img/Slide6.JPG" style="width:100%">
</a>

<a href="about-us.php">
  <img class="mySlides" src="images/banner-img/Slide7.JPG" style="width:100%">
</a>
 -->

</div>


</div>


<div class="col-lg-3 col-md-12">
           <div class="col-lg-12 col-md-6 cs-testi">
            <a href="case-study.php">
            <div class="text-center same-pdng prpl">
				<div class="small-title title-oswald">
                    <img src="images/casestudy.png" alt="image" >
				<p class="small-title title-oswald"> Our Client Testimonial</p>
				</div>
            </div>
           </a>
           </div>
    
            <a href="our-team.php">
            <div class="col-lg-12 col-md-6 text-center same-pdng pink" style="">
				<div class="small-title title-oswald">
                    <div class="col-lg-6" style="margin-left:50px;">
                    <img src="images/ourteam.png" alt="image">
                    </div>
                   <div class="col-lg-6" style="margin-left:50px;" >
					   <p class="small-title title-oswald">Our Team</p>
				</div> 
				</div>
            </div>
            </a>
</div>

<div class="col-lg-3 col-md-12 mar-top-25">
        <div class="sec-aboutus">
        <div class="col-lg-12 abt-top">
            <img style="float: left;" src="images/aboutus.png" alt="image">
            <p class="abtus-text">About us</p>
        </div>
        <div class="col-lg-12" style="background-color: #101C32;padding: 0 0 0 10px">
            <p class="ar abt-text" style="height: 240px;overflow-x: auto">e2e People Practices Pvt Ltd., a respected boutique consulting firm that undertakes new age business transformation, HR Consulting and L&OD projects. We are experts in People Behavior Analytics and have been consulting across industries for the last 10 years. We focus on aligning <strong>Business Solutions</strong> by <strong>Building People Capability</strong>. Through our meaningful insights on employee behavior from our AI powered products, audits and interventions, we have been successful in aligning HR functions with the business objectives of our clients. </p>
        </div>
        <div class="col-lg-12" style="background-color: #0088C7">
                    <a href="about-us.php" class="">
                        <p class="abt-knowmore">Know More</p>
                    </a>
        </div>            
        </div>
</div>


</div>


<!-- 2nd row-->

 <div class="col-lg-12 col-sm-12 col-xs-12 small-scrn" style="top: -10px">
    <div class="col-lg-8 col-md-12 mar-top-25 padng-right-0 padng-left-0">
		<div class="col-lg-4 col-md-4">
           <!--<a href="merges-and-acquisition.php">-->
			<a href="https://www.mnagenome.com">
            <div class="text-center same-pdng m-red">
               <img src="images/m&a.png" class="grow" alt="image">
            </div>
            </a>
        </div>
        
<!--     <div class="col-lg-4 col-md-4">
            <a href="news-and-media.php">
            <div class="text-center news-yellow"></div>
            <div class="col-lg-12 col-sm-12 col-xs-12 pdng-0" style="background-color: #523D12;">
            <div class="col-lg-8 col-sm-8 col-xs-8 padng-right-0"><p class="news-media">Media</p></div>
            <div class="col-lg-4 col-sm-4 col-xs-4"><img style="" src="images/news&amp;media.png" class="grow" alt="image"></div>
            </div>
            </a>
        </div> -->

        <div class="col-lg-4 col-md-4">
            <a href="news-and-media.php">
            <div class="text-center news-yellow">
            <div class="media-home-pdng" style="padding: 38px 0px;">
            <img style="" src="images/media-home.png" class="grow" alt="image">
            </div>
            </div>
            </a>
        </div>

        <div class="col-lg-4 col-md-4">
            <a href="e2e-library.php">
            <div class="text-center same-pdng knowlg-box" style="padding: 39px 0px;">
                <center><img src="images/e1.png" class="grow" alt="image" height="100px" width="160px"></center>
				
            </div>
            </a>
        </div>
    </div>

    <div class="col-lg-4 col-md-12 mar-top-25">
            <a href="MileStone.php">
            <div class="text-center same-pdng green-box">
				<div class="small-title title-oswald">
                    <img src="images/Icon-Milestones.png" alt="image" style="height: 100px" >
                    <img src="images/e2emilestone.png" alt="image">
				</div>
            </div>
            </a>
	     </div>
   
</div>


<!-- 3rd row-->

<div class="col-lg-12 col-sm-12 col-xs-12 small-scrn" style="margin-top: 17px;">

    <div class="col-lg-7 col-md-12 pdng-0">
        <div class="col-lg-7 col-md-6 twitter-link">
			<a class="twitter-timeline" data-width="100%" data-height="200px" href="https://twitter.com/e2ePeople"></a><script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
        </div>

        <div class="col-lg-5 col-md-6 knowlg-div">
            <a href="csr.php">
            <div class="text-center same-pdng service-box">
				<div class="small-title title-oswald">
                    <img src="images/csr.png" alt="image">
                    <p class="small-title title-oswald">CSR</p>
				</div>
            </div>
            </a>
        </div>
    </div>

    <div class="col-lg-5 col-md-12 mar-top-25 padng-left-0">
        <div class="col-lg-4 col-md-4 padng-right-0">
            <a href="careers.php">
            <div class="text-center same-pdng careers-box">
				<div class="small-title title-oswald">
                    <img src="images/career.png" alt="image">
                    <p class="small-title title-oswald">Careers</p>
				</div>
            </div>
            </a>
        </div>

        <div class="col-lg-4 col-md-4 padng-right-0">
            <a href="gallery.php">
            <div class="text-center same-pdng gallery-box">
				<div class="small-title title-oswald">
                    <img src="images/gallery.png" alt="image">
                    <p class="small-title title-oswald">Gallery</p>
				</div>
            </div>
            </a>
        </div>

        <div class="col-lg-4 col-md-4 padng-right-0">
            <a href="contact-us.php">
            <div class="text-center same-pdng contact-box">
				<div class="small-title title-oswald">
                    <img src="images/contact.png" alt="image">
                    <p class="small-title title-oswald">Contact Us</p>
				</div>
            </div>
            </a>
        </div>

    </div>
</div>



<?php include('footer-index.php'); ?>

<script>
var myIndex = 0;
carousel();

function carousel() {
    var i;
    var x = document.getElementsByClassName("mySlides");
    for (i = 0; i < x.length; i++) {
       x[i].style.display = "none";  
    }
    myIndex++;
    if (myIndex > x.length) {myIndex = 1}    
    x[myIndex-1].style.display = "block";  
    setTimeout(carousel, 5000); // Change image every 5 seconds
}




var slideIndex = 1;
showDivs(slideIndex);

function plusDivs(n) {
  showDivs(slideIndex += n);
}

function showDivs(n) {
  var i;
  var x = document.getElementsByClassName("mySlides");
  if (n > x.length) {slideIndex = 1}    
  if (n < 1) {slideIndex = x.length}
  for (i = 0; i < x.length; i++) {
     x[i].style.display = "none";  
  }
  x[slideIndex-1].style.display = "block";  
}
</script>
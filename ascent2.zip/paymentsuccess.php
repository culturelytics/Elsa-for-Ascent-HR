<?php 
echo "<center>";
			echo "<br>Thank you for registering with us.";

echo "</center>";
			?>
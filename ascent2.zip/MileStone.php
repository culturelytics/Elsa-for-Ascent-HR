<?php include_once('connectdb.php'); ?>
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <title>Milestones:e2e</title>

    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="e2e People Practices takes pride in showcasing the milestones that has been accomplished through the 10 years of success">

    <meta name="keywords" content="Milestones,Culture Alignment,Culture audit,Hr Consulting,M&A,mergers and acquisition,Build,Operate,Transfer,Learning and Development,Leadership,Business Alignment,Business Development">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="author" href="https://plus.google.com/yourpersonalprofile">
    <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
    <link href="css/css.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <link rel="stylesheet" href="css/m/font-awesome.min.css">
    <link rel="stylesheet" href="css/m/animate.min.css">
    <link rel="stylesheet" href="css/m/default.min.css">
    <link rel="stylesheet" href="css/m/demo.css">
    <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
    <link rel="shortcut icon" href="images/fav_e2e2.ico" />
    <script src="js/m/modernizr.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>



</head>￼

<body>

    <div class="comn-bg">

        <div class="container" style="background:url('images/s1.jpg');">
            <div class="col-lg-12  col-sm-12 col-xs-12 header-pdng all-border-btm">
                <div class="col-lg-4 col-sm-12 col-xs-12 center-below-992" style="">
                    <a href="index.php">
                        <img src="<?php echo $pri_logo ?>" class="header-logo" alt="image">
                    </a>
                </div>

                <div class="col-lg-8  col-sm-12 col-xs-12 li-details header-strip " style="margin-top: 15px;">

                    <div class="col-lg-1"></div>

                    <div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
                        <span class="ar">Quick Contact : </span>+91 80 41155269
                    </div>

                    <div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
                        <span class="ar">Mail To : </span><a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a>
                    </div>

                    <div class="col-lg-2  col-sm-6 col-xs-6 nav-li li-login" style="margin-top: 10px;padding-left: 0px">
                        <!-- <a href="login.php" class="login-btn">Log In</a> -->
                        <?php
session_start();
if(!isset($_SESSION["sess_email"])){
  ?>
                        <a href="login.php" class="login-btn">Log In</a>

                        <?php 
}
else
{
?>
                        <a href="logout.php" class="login-btn">Logout</a>
                        <?php
}
?>
                    </div>

                    <div class="col-lg-1  col-sm-6 col-xs-6 toggle-menu right0-abv768">
                        <div class="nav-li-last w3-button w3-xlarge" style="float: right;" onclick="w3_open()">
                            <div class="icon"></div>
                            <div class="icon"></div>
                            <div class="icon"></div>
                        </div>
                    </div>

                </div>

            </div>

            <!-- Global site tag (gtag.js) - Google Analytics -->
            <script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
            <script>
                window.dataLayer = window.dataLayer || [];

                function gtag() {
                    dataLayer.push(arguments);
                }
                gtag('js', new Date());

                gtag('config', 'UA-112031379-1');

            </script>

            <style type="text/css">
                @media(max-width: 992px) {
                    #timeline {
                        width: 100% !important;
                    }
                }

                @media(max-width: 600px) {
                    #dates {
                        display: none;
                    }

                    #timeline {
                        background-image: none !important;
                        margin: 0px auto 0px auto !important;
                    }
                }

                @media(max-width: 1200px) {
                    #issues li p {
                        margin-right: 75px !important;
                    }
                }

                @media(max-width: 768px) {
                    #issues li p {
                        margin-right: 50% !important;
                    }

                    #issues li h1 {
                        font-size: 25px !important;
                    }
                }

                @media(max-width: 470px) {
                    #issues li p {
                        margin-right: 70% !important;
                    }
                }

                .sociales {
                    text-align: center;
                    margin-bottom: 20px;
                }

                #timeline {

                    /*height: 375px;*/
                    overflow: hidden;
                    /*margin: 100px auto;*/
                    margin: 0px auto 0px auto;
                    position: relative;
                    background: url('mile-2/images/dot.gif') left 45px repeat-x;
                }

                #dates {
                    width: 800px;
                    height: 60px;
                    overflow: hidden;
                }

                #dates li {
                    list-style: none;
                    float: left;
                    width: 200px;
                    height: 50px;
                    font-size: 20px;
                    text-align: center;
                    background: url('mile-2/images/biggerdot.png') center bottom no-repeat;
                }

                #dates a {
                    line-height: 38px;
                    padding-bottom: 10px;
                }

                #dates .selected {
                    text-decoration: none;
                    font-size: 25px;
                    color: #FFBE2D;
                }

                #issues {
                    width: 800px;
                    /*height: 350px;*/
                    overflow: hidden;
                }

                #issues li {
                    width: 800px;
                    /*height: 350px;*/
                    list-style: none;
                    float: left;
                }

                #issues li.selected img {
                    -webkit-transform: scale(1.1, 1.1);
                    -moz-transform: scale(1.1, 1.1);
                    -o-transform: scale(1.1, 1.1);
                    -ms-transform: scale(1.1, 1.1);
                    transform: scale(1.1, 1.1);
                }

                #issues li img {
                    float: left;
                    margin: 10px 30px 15px 10px;
                    background: transparent;
                    -ms-filter: "progid:DXImageTransform.Microsoft.gradient(startColorstr=#00FFFFFF,endColorstr=#00FFFFFF)";
                    /* IE 8 */
                    filter: progid:DXImageTransform.Microsoft.gradient(startColorstr=#00FFFFFF, endColorstr=#00FFFFFF);
                    /* IE 6 & 7 */
                    zoom: 1;
                    -webkit-transition: all 2s ease-in-out;
                    -moz-transition: all 2s ease-in-out;
                    -o-transition: all 2s ease-in-out;
                    -ms-transition: all 2s ease-in-out;
                    transition: all 2s ease-in-out;
                    -webkit-transform: scale(0.7, 0.7);
                    -moz-transform: scale(0.7, 0.7);
                    -o-transform: scale(0.7, 0.7);
                    -ms-transform: scale(0.7, 0.7);
                    transform: scale(0.7, 0.7);
                }

                #issues li h1 {
                    color: #ffcc00;
                    font-size: 48px;
                    margin: 20px 0;
                    text-shadow: #000 1px 1px 2px;
                }

                #issues li p {
                    font-size: 14px;
                    margin-right: 25px;
                    font-weight: normal;
                    line-height: 22px;
                    text-shadow: #000 1px 1px 2px;
                }

                #grad_left,
                #grad_right {
                    width: 100px;
                    height: 350px;
                    position: absolute;
                    top: 0;
                }

                #grad_left {
                    left: 0;
                }

                #grad_right {
                    right: 0;
                }

                #next,
                #prev {
                    position: absolute;
                    top: 0;
                    font-size: 70px;
                    top: 170px;
                    width: 22px;
                    height: 38px;
                    background-position: 0 0;
                    background-repeat: no-repeat;
                    text-indent: -9999px;
                    overflow: hidden;
                }

                #next:hover,
                #prev:hover {
                    background-position: 0 -76px;
                }
		@media(max-width: 600px) {
                #next {
                    right: 0;
                    background-image: url('images/mile-2/next.png');
                }
				}
				@media(max-width: 600px) {
                #prev {
                    left: 0;
                    background-image: url('images/mile-2/prev.png');
                }
				}

                #next.disabled,
                #prev.disabled {
                    opacity: 0.2;
                }

            </style>


            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.2/jquery.min.js"></script>
            <script src="js/jquery.timelinr-0.9.6.js"></script>
            <script>
                $(function() {
                    $().timelinr({
                        arrowKeys: 'true'
                    })
                });

            </script>
			<script type="text/javascript">

var _gaq = _gaq || [];

_gaq.push(['_setAccount', 'UA-XXXXX-X']);

_gaq.push(['_trackPageview']);

(function() {

var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;

ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') +

'.google-analytics.com/ga.js';

var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);

})();

</script>

            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                <h2 class="ar career-title text-center">Milestones</h2>
                <hr class="line-75">
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-xs-11">
                <div id="timeline">
                    <ul id="dates">
                        <li><a href="#2009-October">2009-October</a></li>
                        <li><a href="#2009">2009</a></li>
                        <li><a href="#2009-2010">2009-2010</a></li>
                        <li><a href="#2010-2011">2010-2011</a></li>
                        <li><a href="#2010-2012">2010-2012</a></li>
                        <li><a href="#2010-2013">2010-2013</a></li>
                        <li><a href="#2015-Ongoing">2015-Ongoing</a></li>
                        <li><a href="#2011-Ongoing">2011-Ongoing</a></li>
                        <li><a href="#2016-Ongoing">2016-Ongoing</a></li>
                        <li><a href="#2016-Ongoing">2016-Ongoing</a></li>
                        <li><a href="#2016">2016</a></li>
                        <li><a href="#2017">2017</a></li>
                        <li><a href="#2018">2018</a></li>
                        <li><a href="#2019">2019</a></li>
                    </ul>
                    <div class="issues-class">
                        <ul id="issues">
                            <li id="2009-October">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/1.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2009 - October</h1>
                                        <p>Started Operation (BootStrap)</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2009">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/2.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2009</h1>
                                        <p>First Fortune 400 client signed on culture transformation intervention across national &amp; international locations</p>
                                        <p class="line-height-30">1. Framework prototype &amp; launch covered &gt;800 employees</p>
                                        <p class="line-height-30">2. Mindset shift from a services support to product company</p>
                                        <p class="line-height-30">3. Positive impact on stakeholder engagement indices</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2009-2010">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/3.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2009 - 2010</h1>
                                        <p>Initiates its first rural skill development program in Trichy with St. Joseph’s University</p>
                                        <p class="line-height-30">1. >1000 students trained</p>
                                        <p class="line-height-30">2. Acceleration of job matches by 65%</p>
                                        <p class="line-height-30">3. Integrated framework on employability institutionalized</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2010-2011">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/5.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2010 - 2011</h1>
                                        <p>Wins Recognition for handling end to end HR transformation for Regional TV (Kannada)</p>
                                        <p class="line-height-30">1. Employee retention ↑35%</p>
                                        <p class="line-height-30">2. HR Budgets ↓15%</p>
                                        <p class="line-height-30">3. Integrated HR best practices framework to >250 employees</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2010-2012">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/4.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2010 - 2012</h1>
                                        <p>Successfully delivers a Pan India Management Consulting Assignment with a private bank</p>
                                        <p class="line-height-30">1. Management Transition in the backdrop of labor unions covering 181 locations Pan India.</p>
                                        <p class="line-height-30">2. Introduction of new HR Practices supported scale to >300.</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2010-2013">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/6.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2010 - 2013</h1>
                                        <p>Successfully delivers its first BOT of skill development in Techno Park, Thiruvananthapuram, Kerala</p>
                                        <p class="line-height-30">1. Covered 30,000 corporate lives</p>
                                        <p class="line-height-30">2. Achieved a positive financial impact within the first 18 months by an average of 90% year on year (3 years)</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2015-Ongoing">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/7.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2015 - Ongoing</h1>
                                        <p>Introduces forward thinking HR practices for India’s leading Association of Machine Tool Manufacturers</p>
                                        <p class="line-height-30">1. Strong support in facilitating design & delivery of senior management workshops on vision, leadership etc</p>
                                        <p class="line-height-30">2. Mapping competencies for an overall progressive shift</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2011-Ongoing">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/8.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2011 - Ongoing</h1>
                                        <p>Facilitates the setup of India’s first PG Entrepreneur Program with committed funding through JGI Ventures. Consolidates Ventures Holding and Mentors 46 incubates</p>
                                        <p class="line-height-30">1. Covered >100 Students, 6th batch running</p>
                                        <p class="line-height-30">2. Achieved > 29% of successful start ups</p>
                                        <p class="line-height-30">3. Consolidated a combined turnover of >$22mn USD, creating >2000 jobs at average of 15% ↑ year on year (3 years)</p>
                                        <p class="line-height-30">4. Integrates a high impact coaching framework to support entrepreneurs</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2016-Ongoing">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/9.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2016 - Ongoing</h1>
                                        <p class="line-height-30">1. 214 participants certified across 3 companies</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2016-Ongoing">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/10.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2016 - Ongoing</h1>
                                        <p>Co-founded a predictive health insights company</p>
                                        <p class="line-height-30">1. Facilitates domestic acquisitions of > 300 employees</p>
                                        <p class="line-height-30">2. Supports end to end Pan- India set up</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2016">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/11.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2016</h1>
                                        <p>Founded K-Arogia : Health analytics company</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2017">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/11.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2017</h1>
                                        <p>Certification Rollout of HR Analytics & Executive Presence</p>
                                        <p class="line-height-30">1. 29 companies across 13 industries</p>
                                        <p class="line-height-30">2. 50 certifications across 4 sessions</p>
                                        <p class="line-height-30">3. 14 speakers & 4 Panel</p>
                                        <br>
                                        <p>1st Acquisition - WhiteCross clinics</p>
                                        <p>ELSA Conceptualized</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2018">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/11.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2018</h1>
                                        <p>Launches LeAP & M&A Genome</p>
                                        <p>Open programs started</p>
                                        <p>ELSA Became a full fledged learning platform and was featured on the website</p>
                                    </div>
                                </div>
                            </li>

                            <li id="2019">
                                <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                                    <div class="col-lg-5 col-md-5 col-sm-5 col-xs-12">
                                        <img src="images/m1/11.png" style="width: 200px" />
                                    </div>
                                    <div class="col-lg-7 col-md-7 col-sm-7 col-xs-12">
                                        <h1>2019</h1>
                                        <p>Designed, facilitated and program managed an Event for CII on B-HAG (Big Hairy Audacious Goals - A Jim Collins concept of Goal Setting) for top management</p>
                                    </div>
                                </div>
                            </li>
                        </ul>
                    </div>

                    <div id="grad_left"></div>
                    <div id="grad_right"></div>
                    <a href="#" id="next">+</a>
                    <a href="#" id="prev">-</a>
                </div>

            </div>

            <?php include('footer.php'); ?>

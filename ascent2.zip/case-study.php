<?php
include_once('connectdb.php');
?>
<!doctype html>
<html lang="en">
    <head>

        <meta charset="utf-8">
        <title>Case studies and Client testimonials:e2es</title>

        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="At e2e,our work speaks for itself. Our case studies give you a detailed description on how the various business gaps wer identified,strategized and how the solutions were implemented">

        <meta name="keywords" content="Mergers and Acquisitions,Leadership,Learning and Development,Culture Audit,Value Added Business Solution,HR Consulting,Team Bonding,LeAP,Business Alignment,Culture Transition">

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="author" href="https://plus.google.com/yourpersonalprofile">
        <link rel="publisher" href="https://plus.google.com/yourbusinessprofile">
        <link href="css/css.css" rel="stylesheet" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
        <link rel="stylesheet" href="css/bootstrap.min_1.css" type="text/css">
        <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
        <link rel="stylesheet" href="css/style.css" type="text/css">

    <link rel="stylesheet" href="css/m/font-awesome.min.css">
    <link rel="stylesheet" href="css/m/animate.min.css">
    <link rel="stylesheet" href="css/m/default.min.css">
    <link rel="stylesheet" href="css/m/demo.css">
    <link rel="stylesheet" href="css/m/frst-timeline-style-4.css">
    <link rel="shortcut icon" href="images/fav_e2e2.ico" />
    <script src="js/m/modernizr.js"></script>
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
 


    </head>
    <body>

    <div class="comn-bg">

<div class="container" style="background:url('images/s1.jpg');width:100%;">
<div class="col-lg-12  col-sm-12 col-xs-12 header-pdng all-border-btm"> 
        <div class="col-lg-4 col-sm-12 col-xs-12 center-below-992" style="">
                <a href="index.php">
                    <img src="<?php echo $pri_logo ?>"  class="header-logo" alt="image">
                </a>
        </div>

<div class="col-lg-8  col-sm-12 col-xs-12 li-details header-strip " style="margin-top: 15px;">
     
     <div class="col-lg-1"></div>

<div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <span  style="color:red;" class="ar">Quick Contact : </span>+91 80 41155269
</div>

<div class="col-lg-4 nav-li ar hidden-md hidden-sm hidden-xs margin-top-10">
    <span  style="color:red;" class="ar">Mail To : </span><a href="mailto:info@e2epeoplepractices.com">info@e2epeoplepractices.com</a>
</div>

<div class="col-lg-2  col-sm-6 col-xs-6 nav-li li-login" style="margin-top: 10px;padding-left: 0px">
   <!-- <a href="login.php" class="login-btn">Log In</a> -->
   <?php
session_start();
if(!isset($_SESSION["sess_email"])){
  ?>
  <a href="login.php" class="login-btn">Log In</a>
  
  <?php 
}
else
{
?>
   <a href="logout.php" class="login-btn">Logout</a>
   <?php
}
?>
</div>
            
<div class="col-lg-1  col-sm-6 col-xs-6 toggle-menu right0-abv768">
    <div class="nav-li-last w3-button w3-xlarge" style="float: right;" onclick="w3_open()">
        <div class="icon"></div>
        <div class="icon"></div>
        <div class="icon"></div>
    </div>        
</div>

</div>   

</div>

<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>

<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">


<h2 class="ar career-title text-center">CASE STUDY</h2>
<hr class="line-75">


<div class="col-lg-12 cfff mob-no-padng" style="padding-top: 0px">


<ul id="accordion">



<!--1-->
  <li><span class="accordion cs-accr ab" style="margin-top: 0px; color:greenyellow;"><marquee>Case 1 : Noise to Notes – Where the brave dread to tread.</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> One of the big four consulting giants (US)</p>
  <p><span class="ab">Mandate :</span> To align organisational developmental practices of the acquired entity to the Global Framework</p>
  <p>Commonly called the billion dollar start-up the challenges were many. With acquisition came rapid growth. With rapid growth came the usual pangs of sustaining innovation. The intervention had to be inclusive and yet adopt an aggressive approach of growth and revenue stabilization.</p>
  <p class="ab abt-sub-titles">Highlights :</p>
  <p style="margin-bottom: 10px">1. A <span class="ab">strategic approach</span> that covered close to 1200 employees across all levels. A model was developed that promoted role-model leaders and also gave opportunities for cross fertilization of ideas that led to the formation of an Innovation Council</p>
  <p>2. <span class="ab">Global practices were studied and benchmarked with Indian practices</span> with the main objectives of:</p>
  <ol>
    <li>a. Attracting the best talent</li>
    <li>b. Investment through real time development</li>
    <li>c. Employee Engagement Initiatives</li>
  </ol>
  <p style="margin-top: 10px">3. <span class="ab">Business Alignment through restructuring was achieved</span></p>
  <ol>
    <li>a. Diversity in offerings </li>
    <li>b. Setting up a strong roadmap for the next 3 year horizon with a capacity building capability of upwards of 3000 employees</li>
  </ol>
  <p class="ab abt-sub-titles">Example of a framework :</p>
  <img src="images/case-study/cs-img-1.png" alt="image">
</div></div>
  </li>



<!--2-->
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 2 : The Culture Vulture : Engage! Enliven! Execute!</marquee><i class="fa fa-chevron-down" style="float: right"></i></span>
    <div>  <div class="cs-accr-body">
    <p class="ab"> Fortune 400 client outcome (Change Management – Culture)</p>
    <img src="images/case-study/Slide1.JPG" alt="case2" style="margin-top: 10px">
  </div></div>
  </li>
  


<!--3-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 3 : Climate Change in God’s own Country</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div>  <div class="cs-accr-body">
    <p class="ab">Fast Growing Kerala HQ Bank BFSI (Culture Transition)</p>
    <img src="images/case-study/Slide2.JPG" alt="case3" style="margin-top: 10px">
  </div></div>
  </li>
  


<!--4-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 4 : LeAP of faith</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div>  <div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> LeAP – US and India Financial Hedge Fund Services</p>
  	<p><span class="ab">Mandate : </span>Was to develop the middle management of the firm across their India locations as the business pipeline was healthy. High attrition in lateral hiring was a concern and hence immediate capabilities were needed to be identified and nurtured.</p>

  	<p class="ab abt-sub-titles">Outcomes we have achieved</p>
  	<ul class="case-study-ul">
  		<li>1. Scalability – increase of 30% capacity in operations that led to an aggressive BD push that resulted in closing on deals (47% of revenue)</li>
  		<li>2. Attrition %age brought down by 5%</li>
  		<li>3. Customer  complaints brought down to 1%</li>
      <li>4. Promotion School</li>
  	</ul>

  	<p class="ab abt-sub-titles">LeAP framework :</p>
  	<img src="images/case-study/cs-4-img.png" alt="image">
  </div></div> 
  </li>



<!--5-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 5 : Evolution Revolution</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
  <p class="ab" style="margin-bottom: 10px"> Life Sciences Company (US and India - Bangalore)</p>
  <img src="images/case-study/5.jpg" alt="case3" style="margin-top: 10px">
  <p><span class="ab">Mandate : </span>To integrate the sales force with the rest of the firm as they were graduating from a product based sales effort to a ‘concept’ base sales effort. Our intervention was to kick-start the process of redefining practices within the system. Major challenges faced were communication protocols and team bonding. Feedback was also sought on key people as restructuring was underway.</p>

  <p class="ab abt-sub-titles">Highlights :</p>
  <p>The intervention was based on the broad theme of this initiative - "Connecting the Dots"</p>
  <p>Curriculum developed for this program was based on concepts involving</p>
    <ul class="case-study-ul">
  		<li>Communication as an enabler for effective team work </li>
  		<li>Interpersonal Skills</li>
  		<li>Team bonding & appreciating diversity</li>
  		<li>Professional Etiquette</li>
  	</ul>
    <p>The methodology adopted was 'activity based learning' where structured activities to influence intended behaviour were introduced. Group learning was encouraged through collective presentations and we deployed role play / assessments / videos as aids in learning</p>
</div></div> 
  </li>  



<!--6-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 6 : B.E – The Business of Entrepreneurship.</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px"> Jain Group of Institutions - JGI</p>
    <p>Jain University has ranked No. 21 among the top universities in India (India Today - Nielson Best Universities Survey, 2014) and among top 10 in the private space (India Today)</p>

    <p class="ab abt-sub-titles">Mandate 1 (Education) :</p>
    <p>End to End development of entrepreneurship programs, investment strategies, building a new vertical for the Group.</p>

    <p>Having entered into a long term (4 years) agreement with JGI on a BOT model, we created the only MBA in Entrepreneurship with committed funding (Incubation & Development of Entrepreneurial ability) from an idea generation to a market ready product and successfully ran 3 batches for them. JGI is currently operating its 5th batch and e2e has transferred the IP to them and moved into an advisory setup. We created a maximum capacity of 15 start-up’s per annum.  We pioneered in building an incubation centre with all the essentials (including shared services) that is required by any start-up to operate seamlessly. We developed a global standard curriculum (References / Working relationships with Babson, London Business School, Asian Institute of Management, Philippines, Angel Investors and First Generation Entrepreneurs) involving the student entrepreneurs to be trained by real time investors during the course work where they were made to work upon their Business idea and have that developed into a concrete Business Plan eligible for funding at the end of their term (Subject Name: Bi to Bp).</p>

  <p class="ab abt-sub-titles">Highlights :</p>
  <p>1. Student Enrolment</p>
    <ul class="case-study-ul">
  		<li>Marketing Strategy & Implementation Support – A 360 degree support (radio, on ground campaigns, paper advertisements, press coverage & articles. We covered 28 locations across India- hence student diversity was also brought in)</li>
      <li>Student examinations & counselling support – We developed a psychometric test on assessing applicants on key entrepreneurial attributes. We then counselled parents and students on benefits of opting for a career as an entrepreneur and submitted our reports to help make a call on admissions.</li> 		
  	</ul>

  <p style="margin-top: 10px">2. Curriculum Development – We based it on sound psychological concepts of entrepreneur behaviour. A boot-camp was conceptualized before segregating students into different streams. Eg. Sports (Golf, Archery and Swimming) were made a mandatory subject. We continually held workshops on personality development and team building.</p>

  <p style="margin-top: 10px">3. Started the Entrepreneurship Club – En-Act (Entrepreneurs in Action) & Odyssey (Innovation & Creativity)  covering 1500 undergraduate students and 600 Post Graduate students</p>

  <p style="margin-top: 10px">4. Enrolled 20 faculty members (Mix of VCs, IBs, Professors and senior corporate professionals)</p>

  <p style="margin-top: 10px">5. End to End strategy on student investments & ROI – A total of 48 companies, where 11 are doing well and out of 11, four are doing exceedingly well.</p>

  <p class="ab abt-sub-titles">Mandate 2 (Ventures) :</p>
  <p>To re/structure Angel investments and create a self-sustaining framework that would be a catalyst for sector agnostic student incubations. Nature of the assignment was Build-Operate-Transfer</p>
  <p>A team of venture capitalists, investment bankers and angel mentors were brought into the new entity set up, JGI Ventures Pvt. Ltd. The scope was broadly classified into 3 categories:</p>
  <ul class="case-study-ul">
    <li>Re/structure equity & debt options to aid quick decisions into invested firms / companies</li>
    <li>Create an inclusive process for new investments</li>
    <li>Strengthening relationships amongst the invested companies</li>
    <li>Setting up an Advisory Board and laying down a vision for the entity</li>
  </ul>
  <p class="ab abt-sub-titles">Outcomes :</p>
  <p>While the mandate was successfully delivered through the BOT Model, some of the highlights were:</p>

  <ul class="case-study-ul">
   <li>A Satsang concept was created where best practices could be shared amongst the entrepreneurs and network shared to deepen relationships</li>
   <li>Shared services was introduced to fast track incubations and lessen the lab to land turnaround time with a capacity of 15 student incubations per annum</li>
   <li>A combined turnover of around 146cr. was achieved with an aggregate increase of 22% profitability and employment generation of more than 1200 people.</li>
  </ul>
  <p>We still continue to engage our advisory services and a full time team has been built and transferred to JGI Ventures.</p>
</div></div> 
  </li>  



<!--7-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 7 : Where Angels Dare</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px">Pan IIM Entrepreneur Accelerator Program, supported by NSRCEL</p>
    <img src="images/case-study/7.jpg" alt="case3" style="margin-top: 10px">
  <p>Ms. Yeshasvini Ramaswamy was the Co-Director of the program; this program was supported by the NS Raghavan Cell. The program was open to ALL students of IIM. Objective was to increase the ratio of students opting for funding for their start-ups rather than jobs. Our mandate was to develop curriculum and put together mentors and base it from IIM - Bangalore. Duration – On-Going</p>

  <p class="ab abt-sub-titles">Broad Curriculum Highlights :</p>
    <ul class="case-study-ul">
  		<li>Theory was kept at a minimum as students would have already learnt it in their course.</li>
  		<li>Class room sessions were limited to refining the business plan and testing POCs were a large part of the program.</li>
      <li>Put together a mentor pool of angel investors and investment bankers.</li>		
  	</ul>
</div></div> 
  </li> 



<!--8-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 8 : Konkan Express – the rail to Education</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px">Audit / Strategic Advisory Services to the Manipal Group (Education)</p>

  <p><span class="ab">Mandate : </span>Study the whole Distance Education set up and provide inputs on:</p>
    <ul class="case-study-ul">
  		<li>Internal - Work Efficiencies (staff ratio, conflicts, restructuring, etc.)</li>
  		<li>External – Market potential (rankings, introduction of relevant courses, infrastructure upgrades, etc.)</li>		
  	</ul>

   <p class="ab abt-sub-titles">Promoting entrepreneurship</p>
   <p>We looked at the opportunities of the entire Distance Education business / industry for India for a short term strategic outlay of 3 years and mapped it to the potential of core employees of the distance education unit. Key team members were profiled and employees who displayed good business acumen and entrepreneurial spirit were selected and handed over larger mandates. </p>
   <p>We also completed an end to end study with relevant business stage inputs. The period of study was about 6 months. We are now listed with them and hence recalled at strategic points of scale for recommendations and audits of processes.</p>
   <p><span>Outcomes –</span> selection of i/entrepreneurs, revenue efficiencies and restructure of the whole DE setup to ensure delivery on the new business plan developed.</p> 
</div></div> 
  </li> 


<!--9-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 9 : When cancer is no longer a zodiac sign</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px">Start-up Clinical Trial Company</p>

  <p class="ab abt-sub-titles">Nature of the company :</p>
    <ul class="case-study-ul">
  		<li>A clinical trial company headquartered in Bangalore and funded from the US.</li>
  		<li>It established an impressive track record of helping clients achieve their goals in pivotal as well as early stage Proof of Concept (PoC) studies. It worked closely with clients on trial design and implementation to bring the multiple advantages of India to their early clinical development programs.</li>
  	</ul>

  <p class="ab abt-sub-titles">Specialties :</p>
    <ul class="case-study-ul">
      <li>Proof of Concept Studies, and pivotal oncology trials with extra-ordinary expertise in Oncology.</li>
    </ul>

  <p class="ab abt-sub-titles">Other areas covered :</p>
    <img src="images/case-study/cs-9-img.png" alt="image">

  <p class="ab abt-sub-titles">Background of the Start-up CEO : </p>
    <ul class="case-study-ul">
      <li>Vast experiences in the conduct of clinical research in India and the United States as well as the global management of various clinical research projects. He has served as the CEO of Clin Test International and Triesta Sciences, a clinical genomics company focused on RNA and DNA fingerprints in Oncology. While at the Harvard-MIT Clinical Research Centre, Cambridge, MA, he led a clinical research team focused on early stage clinical research. He is a graduate of St. John’s Medical College, India and the Sloan School of Management, MIT, Cambridge, MA. Age >35 years.</li>
    </ul>

  <p class="ab abt-sub-titles">Mandate of e2e :</p>
  <ul class="case-study-ul">
    <li>Mentorship & Guidance</li>
    <li>To set up the complete people policies and procedures</li>
  </ul>


  <p class="ab abt-sub-titles">Team & Duration :</p>
    <p>Led by Ms. Yeshasvini Ramaswamy, MD, e2e, the team comprised of highly qualified consultants with backgrounds in Strategy, Law, Psychology, and Business Development. The project was executed over a 30 month period.</p>


  <p class="ab abt-sub-titles">Results :</p>
  <ul>
    <li>Successful implementation of a ‘high quality’ delivery model that helped the company bag repeat orders</li>
    <li>Efficient model of communication and review developed to effectively engage multiple stakeholders (Investors, offices of the govt. of India, Core team, employees, customers)</li>
    <li>The company grew from a 5 member team to a 35 member team with multiple offices across India with strong employee ownership patterns</li>
    <li>Effective business mandate implementation that ensured profitable operations which helped attract further rounds of funding</li>
  </ul>
</div></div> 
  </li>    
  


<!--10-->  
<li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 10 : Clean Bowled</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px">Start-up Bath ware Company</p>

  <p class="ab abt-sub-titles">Nature of the company :</p>
    <ul class="case-study-ul">
      <li>A privately held bath fittings and bath ware retail company headquartered in Mohali with an extensive distribution network across India.</li>
      <li>A leader in this industry segment (turnover wise) with positive goodwill created over 25 years.</li>
      <li>International tie-ups was seen as the next step up (value chain)</li>
    </ul>

  <p class="ab abt-sub-titles">Specialties :</p>
    <ul class="case-study-ul">
      <li>Fusion of good engineering with good designs</li>
      <li>Captive manufacturing plant</li>
      <li>Good track record of customer service</li>
      <li>Good quality products combined with low cost</li>
    </ul>

  <p class="ab abt-sub-titles">Background of the Next Gen Leader :</p>
    <ul class="case-study-ul">
      <li>Young MBA graduate of entrepreneurship studies with a good track record of academics</li>
      <li>Less work experience other than being with his father for a few meetings</li>
      <li>Came from a family of strong human values and business expertise</li>
      <li>Age 26 years</li>
    </ul>


  <p class="ab abt-sub-titles">Mandate of e2e :</p>
    <ul class="case-study-ul">
      <li>To help them in their vision to be a Global player & excel in supply of quality Bath Fittings, Bath Accessories, Bath Wares, allied products and enhance customer base through mentorship & guidance</li>
      <li>To help build an international network of brands, suppliers of brands and distributors.</li>
    </ul>

    <p class="ab abt-sub-titles">Team & Duration :</p>
    <ul class="case-study-ul">
      <li>Led by Ms. Yeshasvini Ramaswamy, MD, e2e, the team comprised of highly qualified consultants with backgrounds in Strategy, Law, Psychology, and Business Development. The project is still being executed.</li>
    </ul>

    <p class="ab abt-sub-titles">Results :</p>
    <ul class="case-study-ul">
      <li>Encouraging him to come up with multiple options of reaching the same goal. Keeping infusion low and ensuring a good rotation of finances through well thought out working capital management practices.</li>
      <li>Guiding the creation of the ‘next gen’ Business Plan and establishing check points before the plan is put up for funding (private funding with a %age investment from the family)</li>
      <li>Ensuring he gets project experience by helping him intern in relevant companies</li>
      <li>The business plan is under implementation with funding secured and ties established with Italy, Germany and China. A good sharing structure has also been reached within the partners and their sons.</li>
    </ul>

</div></div> 
  </li>  



<!--11-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 11 : Healthy Habits - Heart of the matter</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
    <p class="ab" style="margin-bottom: 10px">Team Cohesion Intervention for a  Leading Healthcare Enterprise</p>

  <p class="ab abt-sub-titles">Nature of the company :</p>
    <ul class="case-study-ul">
      <li>Our Client is headquartered in Bengaluru, India, and operate a national network of hospitals in India with a particularly strong presence in the southern state of Karnataka and eastern India, as well as an emerging presence in western and central India. Their first facility was established in Bengaluru with approximately 225 operational beds and we have since grown to 23 hospitals, 7 heart centres and a network or primary care facilities across India and one hospital in the Cayman islands with 5,347 operational beds through a combination of green field projects and acquisitions and potential to reach a capacity of over 6,600 beds as on First may 2016.</li>
      <li>The company’s mission is to deliver high quality, affordable healthcare services to the broader population of India.</li>
    </ul>

  <p class="ab abt-sub-titles">Mandate & Solution offered </p>
      <p>Considering the aggressive growth witnessed, e2e had to create a  solution where employees were motivated and taught new skills to be able to manage multiple tasks and responsibilities in terms of patient footfall  and new staff additions .This required them to learn and practice new tools and also bond effectively.</p>
      <p>Hence, a framework was designed on a high touch model of interactive workshops and coaching assistance to support the staff to deliver.</p>
      <p>The framework focused on 3 key skill enhancements :</p>
      <ul class="case-study-ul">
        <li>Time Management</li>
        <li>Team Dynamics</li>
        <li>Communication skills</li>
      </ul>

  <p class="ab abt-sub-titles">Background of the team</p>
  <p>The Team consisted of a combination of Nurses, care staff, inclusive of receptionists as well as administrative staff. They were a very diverse group. The average age range was between 25-35 years.</p>
  <p>Hence, new interactive, high energy methodologies of learning had to be introduced.</p>

  <p class="ab abt-sub-titles">Team & Duration</p>
  <p>Led by Ms Yeshasvini Ramaswamy, MD, e2e, the team comprised of highly qualified consultants with backgrounds in Strategy, Medicine, Psychology, and Business Development. The project was executed over a 9 month period.</p>

  <p class="ab abt-sub-titles">Results</p>
  <ul class="case-study-ul">
    <li>Improved team relations amongst staff.</li>
    <li>Less attrition was observed within the organization.</li>
    <li>Enhanced methodologies for patient care and improved footfall</li>
  </ul>
</div></div> 
  </li> 



<!--12-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 12 : Nature of the company</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">

  <p class="ab" style="margin-bottom: 10px">Build Operate Transfer Processes for a Medical NGO  Care 360 - We dare to care and share</p>
   <p>Samatvam Endocrinology Diabetes Centre (SEDC) is a health care and medical institution that specializes in treating and managing diabetes and other endocrine metabolic disorders. Samatvam’s motto is “Service with devotion”. The core philosophy is the integration of science and spirituality, in the context of health care.</p>

  <p class="ab abt-sub-titles">Mandate & Solution offered </p>
      <p>The opportunity was to advise them and support them with end to end process solution. The objective was to help them leverage on the huge goodwill built over the years of women service and develop an operational model that was financially sustainable without compromising on the quality of care.</p>
      <p>The broad areas of implemented work were :</p>
      <ul class="case-study-ul">
        <li>Completely restructured operations to suit the new operating model</li>
        <li>Train staff members of new methodologies.</li>
        <li>Enhance brand awareness</li>
        <li>Participate in grants by refining templates and reports</li>
        <li>Build a community</li>
        <li>Build a community contributor image by introduction of Camps  and volunteer based initiatives to increase footfall</li>
      </ul>

  <p class="ab abt-sub-titles">Background of the team @ Samatvam</p>
   <ul class="case-study-ul">
     <li>Diverse age ranges between 25-65</li>
     <li>Low domain expertise & technological interface knowledge</li>
     <li>Extremely sincere, loyal & dedicated staff with minimal attrition</li>
     <li>High societal reputation from patients</li>
     <li>Low process oriented  and recall heavily dependent on people</li>
     <li>Low ability to plan & manage operations effectively</li>
   </ul>

  <p class="ab abt-sub-titles">Team & Duration</p>
  <p>Led by Ms Yeshasvini Ramaswamy, MD, e2e, the team comprised of highly qualified consultants with backgrounds in Strategy, Medicine, Psychology, and Business Development. The project was executed over a 36 month period.</p>

  <p class="ab abt-sub-titles">Results</p>
  <ul class="case-study-ul">
    <li>Increased productivity through reestablished processes and SOPs</li>
    <li>Consistent brand outreach</li>
    <li>Additional footfalls and improved patient care (end to end)</li>
  </ul>
</div></div> 
</li>



<!--13-->  
  <li><span class="accordion cs-accr ab" style="color:greenyellow;"><marquee>Case 13 : Nerves of steel</marquee><i class="fa fa-chevron-down" style="float: right;"></i></span>
    <div><div class="cs-accr-body">
 <p class="ab" style="margin-bottom: 10px">Process Set up and Employment Engagement for a leading Neuropsychiatric Hospital</p>

  <p class="ab abt-sub-titles">Nature of the company</p>
   <p>Our client is the premier private dedicated neuropsychiatric hospital in Karnataka. Established in 1964, it is the oldest such hospital in Karnataka, and has a reputation for being able to manage even the most complex mental health problems, and those in psychiatric crisis.</p>

  <p class="ab abt-sub-titles">Mandate & Solution offered </p>
      <p>The context was to increase foot falls in a very intense competitive landscape of mental health care.</p>
      <p>The broad areas of implemented work were :</p>
      <ul class="case-study-ul">
        <li>Process introduced to trace the number of enquiries</li>
        <li>Identified the leakage in the system</li>
        <li>Benchmarked different doctor analysis and improved upon patient care </li>
        <li>Improved on the Outpatient v/s In patient ratios </li>
        <li>Brand awareness</li>
        <li>Monitoring every employees role</li>
      </ul>

  <p class="ab abt-sub-titles">Background of the team</p>
   <p>The team comprised of young doctors and the whole staff of the hospital. Since new investments were recently bought it, the need to turn a quick turnaround. Exit options were also considered by the management.</p>

  <p class="ab abt-sub-titles">Team & Duration</p>
  <p>Led by Ms Sudha Raju, e2e Strategic Business Advisor, the team comprised of highly qualified consultants with backgrounds in Strategy, Medicine, Psychology, and Business Development. The project was executed over a 24 month period.</p>

  <p class="ab abt-sub-titles">Results</p>
  <ul class="case-study-ul">
    <li>Increased Bed Occupancy</li>
    <li>Billing per patient improved</li>
    <li>Effective processes were introduced resulting in better productivity</li>
    <li>Aligned the goals to the vision of the hospital</li>
  </ul>

 <p class="ab abt-sub-titles">Team</p>
 <p>Led by the entrepreneurial mind of Ms. Yeshasvini Ramaswamy, the support team of e2e currently comprises of consultants who have relevant industry experience of developing & managing ROI based interventions of Operations and HR functions. Their formal education has been in the areas of Management, HR, Marketing, Industrial Psychology, and Commerce. The average experience of the identified team is around 15 years. The team is familiar with working geographies of India, USA, England, Australia, Dubai, Hong Kong, China, and Germany.</p>
 <p>The team brings in a rich experience in IT&ITES, Banking, Hospitality, Infrastructure, Media, Manufacturing and the Education Sector of domestic and international practices</p>

</div>
</div> 
  </li>


</ul>

</div>


</div>
</div>

<?php include('footer.php'); ?>


<script>
$("#accordion > li > span").click(function() {
    $(this).toggleClass("active").next('div').slideToggle(250)
    .closest('li').siblings().find('span').removeClass('active').next('div').slideUp(250);
});


// $('ul li span').click(function(){
//     $(this).find('i').toggleClass('fa-chevron-down fa-chevron-up')
// });

</script>
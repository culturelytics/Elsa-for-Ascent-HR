<?php
$con=mysqli_connect("localhost","nexevonew","Hameed@786","admin_nexevonew");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
$checkbox1 = $_POST['detailsid'];
    $chk="";  
    foreach($checkbox1 as $chk1)  
       {  
          $chk.= $chk1.",";  
       }  

$sql="INSERT INTO iPulse(Name,Email,Details,Feedback)
VALUES
('$_POST[name]','$_POST[email]','$chk','$_POST[emoji]')";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
header("Location: http://mnagenome.com.s3-website.ap-south-1.amazonaws.com/ThankYou"); 
mysqli_close($con);
?>
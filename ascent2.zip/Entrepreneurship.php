<?php include('header.php'); ?>
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-112031379-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-112031379-1');
</script>
<?php
if(!isset($_SESSION["sess_email_kaccess"])){
 header("Location: login.php");
}

else
{
?>


<div class="col-lg-12  mob-no-padng">
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 mob-no-padng">





    <div class="col-lg-12 inside-box mob-no-padng" style="padding-top: 0px">
    <div class="cs-comn-heading mob-no-padng" style="padding-top: 0px">
    <p class="cs-comn-heading-title ar career-title text-center">ENTREPRENEURSHIP</p>
    <hr class="line-75">
    <ul class="cs-ui">
      <li>
      	Entrepreneurship - The capacity and willingness to develop, organize and manage a business venture along with any of its risks in order to make a profit.
      </li>
    </ul>
    </div>


<div class="col-lg-12 lib-scroll mob-no-padng">
	<div class="col-lg-6 mob-no-padng lg-border-right">
	<div class="heading-6 ab">
	ENTREPRENEURSHIP
	</div>
	<div class="cs-left">

		<div class="info-n">
		<p class="abt-sub-titles ab">What is entrepreneurship?</p>
		<ul class="cs-ui">
			<li><a href="http://www.managementstudyguide.com/what-is-entrepreneurship.htm" target="_blank">What is Entrepreneurship and Who is an Entrepreneur ?</a></li>
			<li><a href="http://www.paggu.com/entrepreneurship/what-is-entrepreneurship/" target="_blank">What is Entrepreneurship?</a></li>
			<li><a href="http://www.quickmba.com/entre/definition/" target="_blank">A definition of entrepreneurship</a></li>
			<li><a href="https://www.youtube.com/watch?v=CfJd8Vuc0VU" target="_blank">What is entrepreneurship? (Video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Types</p>
		<ul class="cs-ui">
			<li><a href="http://www.yourarticlelibrary.com/entrepreneur/top-10-types-of-entrepreneurs-explained/40648/" target="_blank">Top 10 Types of Entrepreneurs – Explained!</a></li>
			<li><a href="https://businessjargons.com/types-of-entrepreneurs.html" target="_blank">Types of Entrepreneurs</a></li>
			<li><a href="https://www.spinxdigital.com/blog/the-8-types-of-entrepreneurs-which-are-you/" target="_blank">The 8 Types of Entrepreneurs – Which Are You?</a></li>
			<li><a href="https://www.youtube.com/watch?v=758nBp9jEgM" target="_blank">Types of entrepreneurs (Video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Characteristics</p>
		<ul class="cs-ui">
			<li><a href="http://www.yourarticlelibrary.com/entrepreneur/entrepreneurship-characteristicsimportance-types-and-functions-of-entrepreneurship/5228/" target="_blank">Entrepreneurship: Characteristics,Importance, Types, and Functions of Entrepreneurship</a></li>
			<li><a href="http://businesscasestudies.co.uk/iet/entrepreneurship-in-engineering/characteristics-of-an-entrepreneur.html" target="_blank">Entrepreneurship in engineering:Characteristics of an entrepreneur</a></li>
			<li><a href="http://smallbusiness.chron.com/good-characteristics-entrepreneur-18385.html" target="_blank">Good Characteristics of an Entrepreneur</a></li>
			<li><a href="https://www.youtube.com/watch?v=e5sbQpq1VGg" target="_blank">25 Common Characteristics of Successful Entrepreneurs (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Difference between entrepreneur and manager</p>
		<ul class="cs-ui">
			<li><a href="https://keydifferences.com/difference-between-entrepreneur-and-manager.html" target="_blank">Difference Between Entrepreneur and Manager</a></li>
			<li><a href="http://smallbusiness.chron.com/traits-entrepreneur-vs-manager-38558.html" target="_blank">Traits of an Entrepreneur vs. a Manager</a></li>
			<li><a href="http://entrepreneurship-isemi.com/article/8" target="_blank">The Entrepreneur and the Manager - The Significant Difference</a></li>
			<li><a href="https://www.youtube.com/watch?v=hIweJyMfQlg" target="_blank">What is the difference between a manager, a leader, and an entrepreneur? (video)</a></li>
		</ul>
		</div>

		<div class="info-n">
		<p class="abt-sub-titles ab">Women Entrepreneurship</p>
		<ul class="cs-ui">
			<li><a href="http://www.bbamantra.com/women-entrepreneurship/" target="_blank">Women Entrepreneurship</a></li>
			<li><a href="https://yourstory.com/2017/04/challenges-of-women-entrepreneurs/" target="_blank">Challenges of women entrepreneurs</a></li>
			<li><a href="https://smallb.sidbi.in/%20/fund-your-business%20/additional-benefits-msmes%20/women-entrepreneurship" target="_blank">Benefits for women entrepreneurs</a></li>
			<li><a href="https://www.youtube.com/watch?v=NsqwiOiOOXU" target="_blank">Female Entrepreneurship in India (video)</a></li>
			<li><a href="https://www.sumhr.com/list-successful-women-entrepreneurs-india-top/" target="_blank">List of top successful women entrepreneurs in India</a></li>
			<li><a href="https://www.youtube.com/watch?v=FU8iKyYyfTE" target="_blank">10 Richest Female Entrepreneurs of India (video)</a></li>
		</ul>
		</div>
									

	</div>
	</div>


<!--right side-->


	<div class="col-lg-6 mob-no-padng">
	<div class="heading-6 ab">
	BOOKS TO READ
	</div>
	<div class="cs-left">



	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4 circle-bottom-10">
	<div class="book-circle">
		<img class="small-book" src="images/books/the-4-hour.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://en.wikipedia.org/wiki/The_4-Hour_Workweek" target="_blank">The 4-Hour Workweek By Timothy Ferriss</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/art-start.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://guykawasaki.com/books/the-art-of-the-start/" target="_blank">The Art of the Start 2.0 by Guy Kawasaki</a></p>
	</div>
	</div>

	<div class="col-lg-12" style="margin-top: 25px">
	<div class="col-lg-4">
	<div class="book-circle circle-bottom-10">
		<img class="small-book" src="images/books/running-learn.jpg" alt="book">
	</div>
	</div>
	<div class="col-lg-8 booktext-top">
	<p class="book-text"><a href="https://www.safaribooksonline.com/library/view/running-lean-2nd/9781449321529/" target="_blank">Running Lean: Iterate from Plan A to a Plan That Works by Ash Maurya</a></p>
	</div>
	</div>



	</div>
	</div>
   </div>
	</div>	




</div>	

</div>


<?php
}
?>            
<?php include('footer.php'); ?>
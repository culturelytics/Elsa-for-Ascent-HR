<?php
session_start(); // Session starts here.
?>
<!DOCTYPE html>
<html>
	<meta name="viewport" content="width-device-width, initial-scale=1.0">
	<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/themes/base/jquery-ui.css" rel="stylesheet" />
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js"></script>
	<script src='https://www.google.com/recaptcha/api.js'></script>
<head>
<title>iPulse Personal Values Assessment</title>
	</head>
<style>
		h4{
			text-align:center;
			font-size: 28px;
			padding: 30px;
		}
	.header{
		height: 150px;
		width:100%;
		background-color:gray;
		margin-top:-40px;
	}
	img{
		margin-top:-250px;
	margin-left: 1000px;}
	h5{
		text-align:center;
		font-size: 24px;
	margin-top:20px;}
	.title{
		margin-left: 50px;
	font-weight:bold;}
	li{
		padding:15px;
	color:black;
	font-style:verdana;
		margin-left: 50px;
	margin-right: 100px;}
	input{
		margin-left: 450px;
		margin-top: -20px;
	    }
	.input-name{
		margin-left:350px;
		margin-top:20px;}
	input[type=text],input[type=email]{
          width: 30%;
		padding:5px;
           margin-top: -40px;
          display: inline-block;
         border: 1px solid #ccc;
          border-radius:3px;
          box-sizing: border-box;
			/*border: none;
    border-bottom: 1px solid #fff;*/
			/*background-color:#092840;*/
			color: black;
           }
	.continue{
		margin-left: 300px;}
	</style>
	
<body>
	<div class="header">
	<h4>iPulse Personal Values Assessment</h4>
	 <img src="images/iPulse logo.jpg" height="100px" width="130px">
	</div>
	<h5>Welcome to the Values Assessment</h5>
	<p class="title"> INSTRUCTIONS<p>
	<ol>
		<li> The survey takes 5 minutes. At the end of the survey, you will see a message that your responses have been successfully entered.</li>
		<li> You will be asked to select 10 words from a list of values/behaviors.</li>
		<li>iPulse will use the information you share to create cultural analysis reports. Personal information you provide will be used solely for this purpose and processed according to our data privacy policy. In addition, we may anonymize and use your results in an aggregated manner to conduct research and improve future services. To consent to these terms, please tick the box.<br>
			</ol>
	<?php
 if (!empty($_SESSION['error'])) {
 echo $_SESSION['error'];
 unset($_SESSION['error']);
 }
 ?>
	<form  method="post" action="iPulse-Details.php">
			<input type="checkbox" name="Agree" class="agree" required> Agree<br>
		<p class="input-name">Please Enter your name</p><br>
		<input type="text" name="name" required autocomplete="off" style="margin-left: 350px;">
		<p class="input-name">Please provide your email address for the report</p><br>
		<input type="email" name="email" required autocomplete="off" style="margin-left: 350px;">
		<button name="subject" type="submit" value="continue" class="continue">Continue</button>
	</form>
	<div class="g-recaptcha" data-sitekey="6LcE4I0UAAAAAL44VJbCym8_uttSE0sbOgn1dlu-" style="margin-left:350px;margin-top:20px;"></div>
</body>
</html>
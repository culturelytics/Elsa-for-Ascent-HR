
<?php include('header.php'); ?>


<div class="col-lg-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">



<h2 class="ar career-title text-center">OUR SERVICES</h2>
<hr class="line-75">
</div>




<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 services-scroll mob-no-padng">



<div class="col-lg-12 mob-no-padng">
<p class="abt-sub-titles ab">Training Services</p>
<div class="col-lg-12 mob-no-padng" style="padding-left: 0px">
   <div class="col-lg-3 mob-no-padng" style="padding-left: 0px">
      <img src="images/training-services.jpg" alt="image">
   </div>
   <div class="col-lg-9 mob-no-padng">

<p>We offer customised programs for all levels (entry, mid, senior) of the firm. Examples are:</p>
         <ol class="services-ol" style="margin-bottom: 10px">
            <li>Campus to Corporate</li>
            <li>Day one – three day programs</li>
            <li>Workshops on specific needs aided with multisource feedback, psychometric tools, etc.</li>
            <li>Customised vision & strategy workshops co-facilitated with Profs. from IIM, ISB, Harvard and LBS and business experts / game changers</li>
            <li>Facilitate Speaker engagements and curriculum design for quarter / annual events</li>
         </ol>

<p>We are primarily a leadership audit firm and our main focus has been on value capture (merger & acquisition related clientele). We have also delivered successfully on areas pertaining to leadership development (training workshops, coaching, performance management systems, etc.) Our clientele has been a combination of Fortune companies, Educational Institutions, mid-sized firms and start-ups on an aggressive growth path.</p>
<p>One of our common approaches to client servicing is working on BOT (Build Operate and Transfer) assignments for our clients where we support them with services starting from developing a viable business plan / strategy for their ideas, performing necessary market research, recruiting potential resources to mobilize & execute the plan. Thereafter, we operate the business for a specified duration in its nasal stage and ultimately transfer it to the parent organization.</p>
<p>We have capabilities to deliver pan - India projects and have established delivery centers in 9 countries across the world, including UK, Australia, US and Dubai.</p>
</div>
</div>
</div>


<div class="col-lg-12 mob-no-padng">
<p class="abt-sub-titles ab">HR Consulting Services</p>
<div class="col-lg-12 mob-no-padng" style="padding-left: 0px">
   <div class="col-lg-3 mob-no-padng" style="padding-left: 0px">
      <img src="images/hr-consultng.png" alt="image">
   </div>
   <div class="col-lg-9 mob-no-padng">

<p>Our services cover</p>
         <ol class="services-ol" style="margin-bottom: 10px">
            <li>End to End support of complete employee life cycle management</li>
            <ol class="services-ol">
               <li>Recruitment Support in psychometric tests and assessments reports</li>
               <li>Induction Program Facilitation</li>
               <li>Job descriptions / Goal Setting exercises</li>
               <li>Appraisal management Support</li>
               <li>Employee Surveys and Skip Level Engagements</li>
               <li>Exit management support</li>
            </ol>
            <li>Policies (Regulatory & Business Aligned)</li>
            <li>Climate Studies & Engagement Surveys</li>
            <li>Business Coaching for High Performers / Senior Leaders</li>
            <li>Performance Management Design and Implementation Support</li>
         </ol>

<p>We are primarily a leadership audit firm and our main focus has been on value capture (merger & acquisition related clientele). We have also delivered successfully on areas pertaining to leadership development (training workshops, coaching, performance management systems, etc.) Our clientele has been a combination of Fortune companies, Educational Institutions, mid-sized firms and start-ups on an aggressive growth path.</p>
<p>One of our common approaches to client servicing is working on BOT (Build Operate and Transfer) assignments for our clients where we support them with services starting from developing a viable business plan / strategy for their ideas, performing necessary market research, recruiting potential resources to mobilize & execute the plan. Thereafter, we operate the business for a specified duration in its nasal stage and ultimately transfer it to the parent organization.</p>
<p>We have capabilities to deliver pan - India projects and have established delivery centers in 9 countries across the world, including UK, Australia, US and Dubai.</p>
</div>
</div>
</div>


<div class="col-lg-12 mob-no-padng">
<p class="abt-sub-titles ab">Management Consulting Services</p>
<div class="col-lg-12 mob-no-padng" style="padding-left: 0px">
   <div class="col-lg-3 mob-no-padng" style="padding-left: 0px">
      <img src="images/mangment-consultng.png" alt="image">
   </div>
   <div class="col-lg-9 mob-no-padng">

<p>We have built a commendable track record in the following areas:</p>
         <ol class="services-ol" style="margin-bottom: 10px">
            <li>People & Culture Alignment post a merger or an acquisition</li>
            <li>Restructure of reporting structures and organization departments to align better and efficient delivery of the intended promise</li>
            <li>Hiring of senior executives (only)</li>
            <li>Interventions on vision alignment and communication</li>
         </ol>

<p>We are primarily a leadership audit firm and our main focus has been on value capture (merger & acquisition related clientele). We have also delivered successfully on areas pertaining to leadership development (training workshops, coaching, performance management systems, etc.) Our clientele has been a combination of Fortune companies, Educational Institutions, mid-sized firms and start-ups on an aggressive growth path.</p>
<p>One of our common approaches to client servicing is working on BOT (Build Operate and Transfer) assignments for our clients where we support them with services starting from developing a viable business plan / strategy for their ideas, performing necessary market research, recruiting potential resources to mobilize & execute the plan. Thereafter, we operate the business for a specified duration in its nasal stage and ultimately transfer it to the parent organization.</p>
<p>We have capabilities to deliver pan - India projects and have established delivery centers in 9 countries across the world, including UK, Australia, US and Dubai.</p>
</div>
</div>
</div>


</div><!--col-12-->
          

</div>


<?php include('footer.php'); ?>
<?php 


require('db_config.php');

$mysqli=mysqli_connect("localhost","nexevonew","Hameed@786","admin_nexevonew");
$position = $_POST['position'];


$i=1;
foreach($position as $k=>$v){
    $sql = "Update sorting_items SET position_order=".$i." WHERE id=".$v;
    $mysqli->query($sql);


	$i++;
}


?>
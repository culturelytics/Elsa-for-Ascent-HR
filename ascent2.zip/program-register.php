<?php include('header.php'); ?>
<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">

<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
<h2 class="ar career-title text-center">Register For Program</h2>
<hr class="line-75">
</div>

<div class="registercon">
<p class="bkt" style="text-align: center;">Register by filling the below form</p>
<form method="post" name="customerData" enctype="multipart/form-data" action="ccavRequestHandler.php" id="programregister-form">

    <div class="logincontainer loginfields">
    <input type="hidden" name="merchant_id" value="163920">
    <input type="hidden" name="order_id" value="<?php echo $order_id; ?>">
    <input type="hidden" name="currency" value="INR" >

  <div class="ename">
    <input type="text" name="billing_name" class="required" placeholder="Name">
  </div>
  <div class="eemail">
    <input type="email"  name="billing_email" class="required" placeholder="Email">
  </div>
  <div class="eph">
    <input type="text" name="billing_tel"  min="7" class="required" placeholder="Phone No">  </div>
  <div class="edob">
    <input required="" type="text" id="datepicker" name="dob" class="required" placeholder="Date of birth">
  </div>
  <div class="eorg">
    <input type="text" name="position" class="required" placeholder="Position & Name of organization">
  </div>
  <div class="eexp">
    <input type="text" name="experience" class="required" placeholder="Work Experience">
  </div>
  <div class="eadd">
    <textarea rows="4" cols="50" name="officeaddressss" class="required" placeholder="Office Address"></textarea>
    	
    
  </div>
  
  <div class="dom1">
    <input type="text" placeholder="Remarks" name="domain" id="select" class="required" value="">
  </div>
  
  <div class="dom1">
  <input type="text" name="amount" class="required" id="amount"  placeholder="Amount" >
  </div>

  <div class="methods">
  <p> Payment Method</p>
    <input type="radio" name="paymethod" value="Cheque" required> Cheque<br>
    <input type="radio" name="paymethod" value="DD"> DD<br>
    <input type="radio" name="paymethod" value="NEFT"> NEFT<br>
    <input type="radio" name="paymethod" value="Online"> Online<br>
  </div>
    <input type="hidden" name="redirect_url" value="http://www.e2epeoplepractices.com/paymentsuccess.php" > 
    <input type="hidden" name="cancel_url" value="http://www.e2epeoplepractices.com/paymentfailure.php" >
    <input type="hidden" name="language" value="EN">
    <button type="submit" name="submit" >Register</button>
   </div> 
</form>
</div>

</div>
 
 
<?php include('footer.php'); ?>